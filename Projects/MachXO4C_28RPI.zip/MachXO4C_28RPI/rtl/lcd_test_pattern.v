// -----------------------------------------------------------------------------
// lcd_test_pattern
// Test client for dpi666_lcd: on every fill request it loads the line buffer
// with one solid colour for the requested line, then signals fill_done.
//   IDLE -> WAIT_REQ -> FILL (H_ACTIVE writes) -> DONE -> WAIT_REQ
// Mode (pattern) is sampled once per frame so a frame never mixes patterns.
// -----------------------------------------------------------------------------
module lcd_test_pattern #(
    parameter H_ACTIVE   = 480,
    parameter V_ACTIVE   = 640,
    parameter SCROLL_STEP = 2      // lines per frame in mode 3
)(
    input  wire        clk_i,
    input  wire        rst_n_i,
    input  wire [1:0]  mode_i,       // asynchronous (DIP switches)

    input  wire        frame_start_i,
    input  wire        fill_req_i,
    input  wire [9:0]  fill_line_i,
    output reg         fill_done_o,

    output reg         wr_en_o,
    output reg  [8:0]  wr_addr_o,
    output reg  [17:0] wr_data_o
);
    localparam [1:0] S_IDLE = 2'd0,
                     S_WAIT = 2'd1,
                     S_FILL = 2'd2,
                     S_DONE = 2'd3;

    reg [1:0] state;
    reg [1:0] mode_meta, mode_sync, mode_frame;
    reg [9:0] scroll;
    reg [2:0] stripe_ofs;          // mode 2: stripes move one stripe (8 lines) per frame
    reg [9:0] line_q;
    wire [17:0] line_color;

    // DIP switch synchroniser + per-frame sampling, scroll counter
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            mode_meta  <= 2'd0;
            mode_sync  <= 2'd0;
            mode_frame <= 2'd0;
            scroll     <= 10'd0;
            stripe_ofs <= 3'd0;
        end else begin
            mode_meta <= mode_i;
            mode_sync <= mode_meta;
            if (frame_start_i) begin
                mode_frame <= mode_sync;
                stripe_ofs <= stripe_ofs + 3'd1;
                scroll     <= (scroll >= V_ACTIVE - SCROLL_STEP) ?
                              scroll + SCROLL_STEP - V_ACTIVE : scroll + SCROLL_STEP;
            end
        end
    end

    lcd_line_color u_color (
        .mode_i   (mode_frame),
        .line_i   (line_q),
        .scroll_i     (scroll),
        .stripe_ofs_i (stripe_ofs),
        .color_o      (line_color)
    );

    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            state       <= S_IDLE;
            line_q      <= 10'd0;
            fill_done_o <= 1'b0;
            wr_en_o     <= 1'b0;
            wr_addr_o   <= 9'd0;
            wr_data_o   <= 18'd0;
        end else begin
            fill_done_o <= 1'b0;
            wr_en_o     <= 1'b0;
            case (state)
                S_IDLE: state <= S_WAIT;

                S_WAIT: if (fill_req_i) begin
                    line_q    <= fill_line_i;
                    wr_addr_o <= 9'd0;
                    state     <= S_FILL;
                end

                S_FILL: begin                    // line_color is valid here
                    wr_en_o   <= 1'b1;
                    wr_data_o <= line_color;
                    if (wr_en_o)
                        wr_addr_o <= wr_addr_o + 9'd1;
                    if (wr_en_o && wr_addr_o == H_ACTIVE - 2)
                        state <= S_DONE;         // last write issued this clock
                end

                S_DONE: begin
                    fill_done_o <= 1'b1;
                    state       <= S_WAIT;
                end
            endcase
        end
    end
endmodule
