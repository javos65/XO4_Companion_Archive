// -----------------------------------------------------------------------------
// lcd_line_color
// Combinational colour of one display line (RGB666 = {R[5:0],G[5:0],B[5:0]}).
// Shared by the test-pattern FSM and the testbench reference model.
//   mode 0: 8 horizontal bands of 80 lines (colour bars)
//   mode 1: 8 colours in stripes of 8 lines; the stripes move down by 8 lines
//           (one stripe) per frame: colour index = line[5:3] - stripe_ofs
//   mode 2: per-line gradient, every line a different colour
//   mode 3: mode 0 shifted by "scroll" lines (animation)
// -----------------------------------------------------------------------------
module lcd_line_color (
    input  wire [1:0]  mode_i,
    input  wire [9:0]  line_i,       // 0..639
    input  wire [9:0]  scroll_i,     // 0..639
    input  wire [2:0]  stripe_ofs_i, // mode 2: stripe offset, +1 per frame
    output reg  [17:0] color_o
);
    function [17:0] palette;
        input [2:0] idx;
        case (idx)
            3'd0: palette = {6'h3F, 6'h3F, 6'h3F};  // white
            3'd1: palette = {6'h3F, 6'h3F, 6'h00};  // yellow
            3'd2: palette = {6'h00, 6'h3F, 6'h3F};  // cyan
            3'd3: palette = {6'h00, 6'h3F, 6'h00};  // green
            3'd4: palette = {6'h3F, 6'h00, 6'h3F};  // magenta
            3'd5: palette = {6'h3F, 6'h00, 6'h00};  // red
            3'd6: palette = {6'h00, 6'h00, 6'h3F};  // blue
            default: palette = {6'h00, 6'h00, 6'h00}; // black
        endcase
    endfunction

    function [2:0] band80;           // line / 80 for line 0..639
        input [9:0] l;
        begin
            if      (l < 10'd80)  band80 = 3'd0;
            else if (l < 10'd160) band80 = 3'd1;
            else if (l < 10'd240) band80 = 3'd2;
            else if (l < 10'd320) band80 = 3'd3;
            else if (l < 10'd400) band80 = 3'd4;
            else if (l < 10'd480) band80 = 3'd5;
            else if (l < 10'd560) band80 = 3'd6;
            else                  band80 = 3'd7;
        end
    endfunction

    wire [10:0] sum      = {1'b0, line_i} + {1'b0, scroll_i};
    wire [9:0]  scrolled = (sum >= 11'd640) ? (sum - 11'd640) : sum[9:0];

    always @* begin
        case (mode_i)
            2'd0: color_o = palette(band80(line_i));
            2'd1: color_o = palette(line_i[5:3] - stripe_ofs_i);
            2'd2: color_o = {line_i[5:0], line_i[8:3], ~line_i[9:4]};
            default: color_o = palette(band80(scrolled));
        endcase
    end
endmodule
