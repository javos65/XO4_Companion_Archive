// -----------------------------------------------------------------------------
// lcd_test  -  test block for the DPI666 driver
//
// Generates everything the driver needs for the bouncing-block demo:
//   - pixel clock: PLL 12 MHz -> 26.88 MHz (pll_pix, fractional-N)
//   - reset: power-on delay + debounced SW2, released only with PLL lock
//   - video: lcd_logo_seq, AXI4-Stream master (black frame, 49x40 logo
//            from logo_rgb666.mem shown 1:1 (doc/logo.png rotated 90 degrees
//            counter-clockwise by make_logo_mem.py), starting at pixel (0,0),
//            +2/+2 per frame, bouncing)
//   - status LEDs (active low): LED1 PLL lock, LED2 frame heartbeat,
//            LED3 underrun, LED4 stream sync error
// The stream runs on the pixel clock.
// -----------------------------------------------------------------------------
module lcd_test (
    input  wire        clk12_i,         // 12 MHz board clock
    input  wire        sw2_n_i,         // push button SW2, low when pressed

    // clock and reset for the driver
    output wire        pclk_o,          // 26.88 MHz pixel clock
    output reg         rst_n_o,         // synchronous to pclk_o, active low

    // AXI4-Stream master (video to the driver)
    output wire [17:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    input  wire        m_axis_tready,
    output wire        m_axis_tuser,
    output wire        m_axis_tlast,

    // driver status
    input  wire        frame_start_i,
    input  wire        underrun_i,
    input  wire        sync_err_i,

    output wire [3:0]  led_n_o
);
    // ---------------------------------------------------------------- clock
    wire pclk;
    wire pll_lock;

    pll_pix u_pll (
        .clki_i  (clk12_i),
        .clkop_o (pclk),
        .lock_o  (pll_lock)
    );

    assign pclk_o = pclk;

    // ---------------------------------------------------------------- reset
    reg [1:0]  lock_sync;
    reg [1:0]  sw_sync;
    reg [17:0] deb_cnt;          // 2^18 / 26.88 MHz = 9.8 ms
    reg        sw_pressed;
    reg [15:0] por_cnt;          // 2^16 / 26.88 MHz = 2.4 ms

    always @(posedge pclk) begin
        lock_sync <= {lock_sync[0], pll_lock};
        sw_sync   <= {sw_sync[0], ~sw2_n_i};
    end

    always @(posedge pclk) begin
        if (!lock_sync[1]) begin
            deb_cnt    <= 18'd0;
            sw_pressed <= 1'b0;
        end else if (sw_sync[1] != sw_pressed) begin
            deb_cnt <= deb_cnt + 18'd1;
            if (&deb_cnt)
                sw_pressed <= sw_sync[1];
        end else begin
            deb_cnt <= 18'd0;
        end
    end

    always @(posedge pclk) begin
        if (!lock_sync[1] || sw_pressed) begin
            por_cnt <= 16'd0;
            rst_n_o <= 1'b0;
        end else if (!(&por_cnt)) begin
            por_cnt <= por_cnt + 16'd1;
            rst_n_o <= 1'b0;
        end else begin
            rst_n_o <= 1'b1;
        end
    end

    // ---------------------------------------------------------------- video source
    lcd_logo_seq #(
        .H_ACTIVE (480), .V_ACTIVE (640),
        .LOGO_W (49), .LOGO_H (40), .LOGO_DEPTH (2048),   // logo.png rotated 90 deg CCW
        .LOGO_FILE ("../rtl/lcd_test/logo_rgb666.mem"),
        .STEP (2)
    ) u_seq (
        .aclk          (pclk),
        .aresetn       (rst_n_o),
        .en_i          (1'b1),
        .m_axis_tdata  (m_axis_tdata),
        .m_axis_tvalid (m_axis_tvalid),
        .m_axis_tready (m_axis_tready),
        .m_axis_tuser  (m_axis_tuser),
        .m_axis_tlast  (m_axis_tlast),
        .logo_x_o      (),
        .logo_y_o      ()
    );

    // ---------------------------------------------------------------- LEDs
    reg [5:0] frame_cnt;
    always @(posedge pclk) begin
        if (!rst_n_o)           frame_cnt <= 6'd0;
        else if (frame_start_i) frame_cnt <= frame_cnt + 6'd1;
    end

    assign led_n_o[0] = ~lock_sync[1];
    assign led_n_o[1] = ~frame_cnt[5];   // 60 Hz / 64 -> ~0.5 Hz blink
    assign led_n_o[2] = ~underrun_i;
    assign led_n_o[3] = ~sync_err_i;
endmodule
