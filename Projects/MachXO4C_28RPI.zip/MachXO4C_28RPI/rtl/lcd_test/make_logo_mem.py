"""Converts a PNG logo into the ROM init file of lcd_logo_seq.

The logo is shown 1:1 on a black background, so every pixel is blended over
black in advance (colour x alpha); fully transparent pixels become black.
Colours are converted from RGB888 to RGB666 with rounding.

Output: one 18-bit word {R[5:0],G[5:0],B[5:0]} per line in hex ($readmemh),
row by row (address = y * width + x), padded with zeros to DEPTH words.

Usage: python make_logo_mem.py <logo.png> <out.mem> [depth] [rotate]
  rotate: ccw90 = rotate 90 degrees counter-clockwise before converting
          (the panel is mounted portrait; this makes the logo upright on the board)
"""
import sys
from PIL import Image

src, dst = sys.argv[1], sys.argv[2]
depth = int(sys.argv[3]) if len(sys.argv) > 3 else 2048
rotate = sys.argv[4] if len(sys.argv) > 4 else ""

im = Image.open(src).convert("RGBA")
if rotate == "ccw90":
    im = im.transpose(Image.Transpose.ROTATE_90)      # 90 degrees counter-clockwise
elif rotate:
    sys.exit(f"unknown rotate option {rotate!r}")
w, h = im.size
if w * h > depth:
    sys.exit(f"logo {w}x{h} = {w * h} pixels does not fit in {depth} words")


def to6(v):
    return min(63, (v * 63 + 127) // 255)


words, visible = [], 0
for y in range(h):
    for x in range(w):
        r, g, b, a = im.getpixel((x, y))
        r, g, b = (r * a + 127) // 255, (g * a + 127) // 255, (b * a + 127) // 255
        word = (to6(r) << 12) | (to6(g) << 6) | to6(b)
        visible += word != 0
        words.append(word)
words += [0] * (depth - len(words))

with open(dst, "w") as fh:
    fh.write("\n".join(f"{v:05x}" for v in words) + "\n")
print(f"{src}: {w} x {h}, {visible} non-black pixels, {depth} words -> {dst}")
