// -----------------------------------------------------------------------------
// lcd_logo_seq
// AXI4-Stream video source for dpi666_axis: a black frame with a LOGO_W x
// LOGO_H logo shown 1:1. The logo starts at pixel (0,0) and moves STEP pixels
// diagonally per frame, bouncing off the frame edges.
//
// The logo is stored in a ROM (block RAM), initialised from LOGO_FILE
// ($readmemh, one 18-bit {R,G,B} word per pixel, row by row, made by
// make_logo_mem.py; transparency is already blended over black).
//
//   m_axis_tdata  {R[5:0], G[5:0], B[5:0]}
//   m_axis_tuser  first pixel of the frame (x = 0, y = 0)
//   m_axis_tlast  last pixel of each line (x = H_ACTIVE-1)
//
// The ROM has a registered read port. Its address is computed for the pixel
// that will be offered in the next clock (the next pixel after an accepted
// beat, otherwise the current one), so tdata is valid together with tvalid
// and only changes after an accepted beat, as AXI4-Stream requires.
// en_i gates tvalid (tie to 1; a testbench uses it to insert idle cycles).
// -----------------------------------------------------------------------------
module lcd_logo_seq #(
    parameter H_ACTIVE   = 480,
    parameter V_ACTIVE   = 640,
    parameter LOGO_W     = 40,
    parameter LOGO_H     = 49,
    parameter LOGO_DEPTH = 2048,           // >= LOGO_W * LOGO_H
    parameter LOGO_FILE  = "../rtl/lcd_test/logo_rgb666.mem",
    parameter STEP       = 2,
    parameter [17:0] COLOR_BACK = 18'd0    // black
)(
    input  wire        aclk,
    input  wire        aresetn,
    input  wire        en_i,

    output wire [17:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    input  wire        m_axis_tready,
    output wire        m_axis_tuser,
    output wire        m_axis_tlast,

    output wire [9:0]  logo_x_o,         // current logo position (debug)
    output wire [9:0]  logo_y_o
);
    localparam [9:0] X_MAX = H_ACTIVE - LOGO_W;    // last legal logo x
    localparam [9:0] Y_MAX = V_ACTIVE - LOGO_H;    // last legal logo y
    localparam       AW    = $clog2(LOGO_DEPTH);

    reg [9:0] x, y;             // pixel being offered
    reg [9:0] bx, by;           // logo position of the current frame
    reg       x_neg, y_neg;     // movement direction
    reg       run;

    wire beat       = m_axis_tvalid & m_axis_tready;
    wire last_x     = (x == H_ACTIVE - 1);
    wire last_pixel = last_x && (y == V_ACTIVE - 1);
    wire frame_end  = beat & last_pixel;

    // ---------------------------------------------------------------- next frame position
    reg [9:0] bx_nf, by_nf;
    reg       xn_nf, yn_nf;
    always @* begin
        xn_nf = x_neg;
        yn_nf = y_neg;
        if (!x_neg) begin
            if (bx + STEP > X_MAX) begin xn_nf = 1'b1; bx_nf = bx - STEP; end
            else                         bx_nf = bx + STEP;
        end else begin
            if (bx < STEP)         begin xn_nf = 1'b0; bx_nf = bx + STEP; end
            else                         bx_nf = bx - STEP;
        end
        if (!y_neg) begin
            if (by + STEP > Y_MAX) begin yn_nf = 1'b1; by_nf = by - STEP; end
            else                         by_nf = by + STEP;
        end else begin
            if (by < STEP)         begin yn_nf = 1'b0; by_nf = by + STEP; end
            else                         by_nf = by - STEP;
        end
    end

    // ---------------------------------------------------------------- next pixel
    wire [9:0] x_n  = beat ? (last_x ? 10'd0 : x + 10'd1) : x;
    wire [9:0] y_n  = (beat && last_x) ? ((y == V_ACTIVE - 1) ? 10'd0 : y + 10'd1) : y;
    wire [9:0] bx_n = frame_end ? bx_nf : bx;
    wire [9:0] by_n = frame_end ? by_nf : by;

    wire        in_n = (x_n >= bx_n) && (x_n < bx_n + LOGO_W) &&
                       (y_n >= by_n) && (y_n < by_n + LOGO_H);
    wire [9:0]  lx_n = x_n - bx_n;
    wire [9:0]  ly_n = y_n - by_n;
    wire [AW-1:0] addr_n = in_n ? (ly_n * LOGO_W + lx_n) : {AW{1'b0}};

    // ---------------------------------------------------------------- logo ROM
    (* syn_romstyle = "block_rom" *)
    reg [17:0] rom [0:LOGO_DEPTH-1];
    initial $readmemh(LOGO_FILE, rom);

    reg [17:0] rom_q;           // pixel data of the pixel being offered
    reg        in_q;            // the pixel being offered is inside the logo
    always @(posedge aclk) begin
        rom_q <= rom[addr_n];
        in_q  <= in_n;
    end

    assign m_axis_tdata  = in_q ? rom_q : COLOR_BACK;
    assign m_axis_tvalid = run & en_i;
    assign m_axis_tuser  = (x == 10'd0) && (y == 10'd0);
    assign m_axis_tlast  = last_x;
    assign logo_x_o      = bx;
    assign logo_y_o      = by;

    // ---------------------------------------------------------------- state
    always @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            x     <= 10'd0;
            y     <= 10'd0;
            bx    <= 10'd0;
            by    <= 10'd0;
            x_neg <= 1'b0;
            y_neg <= 1'b0;
            run   <= 1'b0;
        end else begin
            run   <= 1'b1;
            x     <= x_n;
            y     <= y_n;
            bx    <= bx_n;
            by    <= by_n;
            if (frame_end) begin
                x_neg <= xn_nf;
                y_neg <= yn_nf;
            end
        end
    end
endmodule
