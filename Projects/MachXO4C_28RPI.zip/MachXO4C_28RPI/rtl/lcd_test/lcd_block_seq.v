// -----------------------------------------------------------------------------
// lcd_block_seq
// AXI4-Stream video source for dpi666_axis: a black frame with one red
// SIZE x SIZE block. The block starts at pixel (0,0) and moves STEP pixels
// diagonally per frame, bouncing off the frame edges.
//
//   m_axis_tdata  {R[5:0], G[5:0], B[5:0]}
//   m_axis_tuser  first pixel of the frame (x = 0, y = 0)
//   m_axis_tlast  last pixel of each line (x = H_ACTIVE-1)
//
// en_i gates tvalid (tie to 1; a testbench uses it to insert idle cycles).
// tdata/tuser/tlast only change after an accepted beat, as AXI4-Stream requires.
// -----------------------------------------------------------------------------
module lcd_block_seq #(
    parameter H_ACTIVE = 480,
    parameter V_ACTIVE = 640,
    parameter SIZE     = 8,
    parameter STEP     = 2,
    parameter [17:0] COLOR_BLOCK = {6'h3F, 6'h00, 6'h00},   // red
    parameter [17:0] COLOR_BACK  = {6'h00, 6'h00, 6'h00}    // black
)(
    input  wire        aclk,
    input  wire        aresetn,
    input  wire        en_i,

    output wire [17:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    input  wire        m_axis_tready,
    output wire        m_axis_tuser,
    output wire        m_axis_tlast,

    output wire [9:0]  block_x_o,       // current block position (debug)
    output wire [9:0]  block_y_o
);
    localparam [9:0] X_MAX = H_ACTIVE - SIZE;   // last legal block x
    localparam [9:0] Y_MAX = V_ACTIVE - SIZE;   // last legal block y

    reg [9:0] x, y;             // pixel being offered
    reg [9:0] bx, by;           // block position of the current frame
    reg       x_neg, y_neg;     // movement direction
    reg       run;

    wire in_block = (x >= bx) && (x < bx + SIZE) && (y >= by) && (y < by + SIZE);

    assign m_axis_tdata  = in_block ? COLOR_BLOCK : COLOR_BACK;
    assign m_axis_tvalid = run & en_i;
    assign m_axis_tuser  = (x == 10'd0) && (y == 10'd0);
    assign m_axis_tlast  = (x == H_ACTIVE - 1);
    assign block_x_o     = bx;
    assign block_y_o     = by;

    wire beat       = m_axis_tvalid & m_axis_tready;
    wire last_pixel = (x == H_ACTIVE - 1) && (y == V_ACTIVE - 1);

    always @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            x     <= 10'd0;
            y     <= 10'd0;
            bx    <= 10'd0;
            by    <= 10'd0;
            x_neg <= 1'b0;
            y_neg <= 1'b0;
            run   <= 1'b0;
        end else begin
            run <= 1'b1;
            if (beat) begin
                if (x == H_ACTIVE - 1) begin
                    x <= 10'd0;
                    y <= (y == V_ACTIVE - 1) ? 10'd0 : y + 10'd1;
                end else begin
                    x <= x + 10'd1;
                end

                // end of frame: move the block for the next frame
                if (last_pixel) begin
                    if (!x_neg) begin
                        if (bx + STEP > X_MAX) begin x_neg <= 1'b1; bx <= bx - STEP; end
                        else                         bx <= bx + STEP;
                    end else begin
                        if (bx < STEP)         begin x_neg <= 1'b0; bx <= bx + STEP; end
                        else                         bx <= bx - STEP;
                    end
                    if (!y_neg) begin
                        if (by + STEP > Y_MAX) begin y_neg <= 1'b1; by <= by - STEP; end
                        else                         by <= by + STEP;
                    end else begin
                        if (by < STEP)         begin y_neg <= 1'b0; by <= by + STEP; end
                        else                         by <= by - STEP;
                    end
                end
            end
        end
    end
endmodule
