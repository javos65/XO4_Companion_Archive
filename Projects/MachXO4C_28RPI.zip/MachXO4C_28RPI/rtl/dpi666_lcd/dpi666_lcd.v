// -----------------------------------------------------------------------------
// dpi666_lcd  -  DPI666 (18-bit parallel RGB) LCD driver IP block
//
// Target panel: Waveshare 2.8" DPI LCD 480x640 (ST7701S), RPi 40-pin header.
// Defaults: 480x640, HSW/HBP/HFP = 16/10/26, VSW/VBP/VFP = 10/15/25,
//           HSYNC/VSYNC active low, DE active high, 532 x 690 clocks per frame.
//
// Input side: an 18-bit RGB666 line buffer (2 banks, ping-pong).
//   - At h_cnt = 0 of each line the block pulses fill_req_o with fill_line_o,
//     the index of the next active line to be shown.
//   - The client writes pixels 0..H_ACTIVE-1 of that line (wr_en_i, wr_addr_i,
//     wr_data_i = {R[5:0],G[5:0],B[5:0]}) and pulses fill_done_i.
//   - The client has one full line period (H_TOTAL clocks) to do so.
//   - underrun_o (sticky) is set when a line starts before it was completed.
//
// Output side: all LCD signals come from registers (I/O cell candidates);
// LCD_CLK is forwarded through an ODDRXE so that it is phase-aligned with the
// data. PCLK_INV = 0: data changes on the rising edge, the panel samples on the
// falling edge (half a period of setup and hold). PCLK_INV = 1 inverts LCD_CLK.
//
// Pipeline (clocks after the timing counters):
//   T1 timing outputs registered (de, sync, read address)
//   T2 line buffer read data
//   T3 output registers -> pins
// -----------------------------------------------------------------------------
module dpi666_lcd #(
    parameter H_ACTIVE = 480,
    parameter H_SYNC   = 16,
    parameter H_BP     = 10,
    parameter H_FP     = 26,
    parameter V_ACTIVE = 640,
    parameter V_SYNC   = 10,
    parameter V_BP     = 15,
    parameter V_FP     = 25,
    parameter HS_POL   = 0,     // level of HSYNC during the sync pulse
    parameter VS_POL   = 0,     // level of VSYNC during the sync pulse
    parameter DE_POL   = 1,     // level of DE during active pixels
    parameter PCLK_INV = 0,     // 1 = invert the forwarded LCD clock
    parameter BL_ON    = 1      // backlight output level
)(
    input  wire        pclk_i,
    input  wire        rst_n_i,

    // 18-bit RGB666 line buffer write port
    input  wire        wr_en_i,
    input  wire [8:0]  wr_addr_i,
    input  wire [17:0] wr_data_i,

    // line handshake
    output wire        fill_req_o,
    output wire [9:0]  fill_line_o,
    input  wire        fill_done_i,

    // status
    output wire        frame_start_o,
    output wire        line_start_o,
    output wire        vblank_o,
    output reg         underrun_o,

    // LCD pins
    output wire        lcd_pclk_o,
    (* syn_useioff = 1 *) output reg         lcd_de_o,
    (* syn_useioff = 1 *) output reg         lcd_hsync_o,
    (* syn_useioff = 1 *) output reg         lcd_vsync_o,
    (* syn_useioff = 1 *) output reg  [5:0]  lcd_r_o,
    (* syn_useioff = 1 *) output reg  [5:0]  lcd_g_o,
    (* syn_useioff = 1 *) output reg  [5:0]  lcd_b_o,
    output wire        lcd_bl_o
);
    // ---------------------------------------------------------------- reset
    reg [1:0] rst_sync;
    always @(posedge pclk_i or negedge rst_n_i) begin
        if (!rst_n_i) rst_sync <= 2'b11;
        else          rst_sync <= {rst_sync[0], 1'b0};
    end
    wire rst = rst_sync[1];

    // ---------------------------------------------------------------- timing
    wire        t_hs, t_vs, t_de;
    wire [9:0]  t_line, t_x;
    wire [10:0] t_hcnt, t_vcnt;

    dpi666_timing #(
        .H_ACTIVE (H_ACTIVE), .H_SYNC (H_SYNC), .H_BP (H_BP), .H_FP (H_FP),
        .V_ACTIVE (V_ACTIVE), .V_SYNC (V_SYNC), .V_BP (V_BP), .V_FP (V_FP)
    ) u_timing (
        .clk_i         (pclk_i),
        .rst_i         (rst),
        .h_cnt_o       (t_hcnt),
        .v_cnt_o       (t_vcnt),
        .hsync_o       (t_hs),
        .vsync_o       (t_vs),
        .de_o          (t_de),
        .disp_line_o   (t_line),
        .disp_x_o      (t_x),
        .line_start_o  (line_start_o),
        .frame_start_o (frame_start_o),
        .vblank_o      (vblank_o),
        .fill_req_o    (fill_req_o),
        .fill_line_o   (fill_line_o)
    );

    // ---------------------------------------------------------------- line buffer
    // Bank of line L is L[0]: while line L is shown from bank L[0], line L+1 is
    // written into the other bank.
    reg       wr_bank;
    reg [1:0] bank_valid;

    always @(posedge pclk_i) begin
        if (rst) begin
            wr_bank    <= 1'b0;
            bank_valid <= 2'b00;
            underrun_o <= 1'b0;
        end else begin
            if (fill_req_o) begin
                wr_bank                    <= fill_line_o[0];
                bank_valid[fill_line_o[0]] <= 1'b0;
            end else if (fill_done_i) begin
                bank_valid[wr_bank]        <= 1'b1;
            end
            if (line_start_o && !bank_valid[t_line[0]])
                underrun_o <= 1'b1;
        end
    end

    wire [17:0] rd_data;

    dpi666_linebuf u_linebuf (
        .clk_i   (pclk_i),
        .we_i    (wr_en_i),
        .wbank_i (wr_bank),
        .waddr_i (wr_addr_i),
        .wdata_i (wr_data_i),
        .rbank_i (t_line[0]),
        .raddr_i (t_x[8:0]),
        .rdata_o (rd_data)
    );

    // ---------------------------------------------------------------- output pipeline
    // T2: aligned with rd_data. The pin polarity is applied HERE, in fabric
    // registers, so the T3 I/O registers below are plain copies with no logic
    // in front of them. (With the polarity applied in front of the I/O
    // register, Reveal pad read-back on the MachXO4 board showed HSYNC/VSYNC
    // at the pins with the wrong polarity: the inverter was lost after
    // synthesis.)
    localparam [0:0] DE_ON  = DE_POL ? 1'b1 : 1'b0;
    localparam [0:0] HS_ON  = HS_POL ? 1'b1 : 1'b0;
    localparam [0:0] VS_ON  = VS_POL ? 1'b1 : 1'b0;

    reg de_d;                       // 1 = active pixel (gates RGB)
    reg de_lvl, hs_lvl, vs_lvl;     // pin levels
    always @(posedge pclk_i) begin
        if (rst) begin
            de_d   <= 1'b0;
            de_lvl <= ~DE_ON;
            hs_lvl <= ~HS_ON;
            vs_lvl <= ~VS_ON;
        end else begin
            de_d   <= t_de;
            de_lvl <= t_de ? DE_ON : ~DE_ON;
            hs_lvl <= t_hs ? HS_ON : ~HS_ON;
            vs_lvl <= t_vs ? VS_ON : ~VS_ON;
        end
    end

    // T3: output registers, packed into the I/O cells (no reset, so they fit
    // the PIO output flip-flop; during reset the T2 registers hold the idle
    // levels, so the pins are idle one clock after reset asserts).
    always @(posedge pclk_i) begin
        lcd_de_o    <= de_lvl;
        lcd_hsync_o <= hs_lvl;
        lcd_vsync_o <= vs_lvl;
        lcd_r_o     <= de_d ? rd_data[17:12] : 6'd0;
        lcd_g_o     <= de_d ? rd_data[11:6]  : 6'd0;
        lcd_b_o     <= de_d ? rd_data[5:0]   : 6'd0;
    end

    // ---------------------------------------------------------------- clock forward
    ODDRXE u_pclk_oddr (
        .D0   (PCLK_INV ? 1'b0 : 1'b1),
        .D1   (PCLK_INV ? 1'b1 : 1'b0),
        .SCLK (pclk_i),
        .RST  (rst),
        .Q    (lcd_pclk_o)
    );

    assign lcd_bl_o = BL_ON ? 1'b1 : 1'b0;

endmodule
