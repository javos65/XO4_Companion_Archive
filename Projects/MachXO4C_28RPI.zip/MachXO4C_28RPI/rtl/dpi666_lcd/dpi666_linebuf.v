// -----------------------------------------------------------------------------
// dpi666_linebuf
// Ping-pong line buffer: 2 banks x 512 words x 18 bits (RGB666).
// Inferred as a pseudo dual-port RAM (one write port, one registered read port);
// maps to 2 x PDPW8KC (512x18) EBR blocks on MachXO4.
// Address = {bank, pixel[8:0]}. Read latency: 1 clock.
// -----------------------------------------------------------------------------
module dpi666_linebuf (
    input  wire        clk_i,
    // write port
    input  wire        we_i,
    input  wire        wbank_i,
    input  wire [8:0]  waddr_i,
    input  wire [17:0] wdata_i,
    // read port
    input  wire        rbank_i,
    input  wire [8:0]  raddr_i,
    output reg  [17:0] rdata_o
);
    (* syn_ramstyle = "block_ram" *)
    reg [17:0] mem [0:1023];

    always @(posedge clk_i) begin
        if (we_i)
            mem[{wbank_i, waddr_i}] <= wdata_i;
    end

    always @(posedge clk_i) begin
        rdata_o <= mem[{rbank_i, raddr_i}];
    end
endmodule
