// -----------------------------------------------------------------------------
// top_28rpi
// MachXO4 Companion Board Rev A (LFMXO4-110HC-6BBG256I) + Waveshare 2.8" DPI LCD
// (480x640, ST7701S) on the RPi 40-pin HAT header.
//
// Structure (connections only, no logic):
//
//   top_28rpi
//    |- u_test : lcd_test     test block: PLL (26.88 MHz), reset, LEDs and
//    |                        lcd_block_seq, the AXI4-Stream source of the
//    |                        bouncing red 8x8 block
//    '- u_lcd  : dpi666_axis  DPI666 LCD driver, AXI4-Stream slave
//
//   clk12_i, sw2_n_i -> u_test -> pclk, rst_n, AXI4-Stream -> u_lcd -> LCD pins
//                       u_test <- frame_start, underrun, sync_err <- u_lcd
// -----------------------------------------------------------------------------
module top_28rpi (
    input  wire       clk12_i,      // 12 MHz board clock (T9)
    input  wire       sw2_n_i,      // push button SW2, low when pressed

    output wire       lcd_pclk_o,
    output wire       lcd_de_o,
    output wire       lcd_hsync_o,
    output wire       lcd_vsync_o,
    output wire [5:0] lcd_r_o,
    output wire [5:0] lcd_g_o,
    output wire [5:0] lcd_b_o,
    output wire       lcd_bl_o,

    output wire [3:0] led_n_o
);
    // clock and reset
    wire        pclk;
    wire        rst_n;

    // AXI4-Stream video, u_test -> u_lcd
    wire [17:0] axis_tdata;
    wire        axis_tvalid;
    wire        axis_tready;
    wire        axis_tuser;
    wire        axis_tlast;

    // driver status, u_lcd -> u_test
    wire        frame_start;
    wire        vblank;
    wire        underrun;
    wire        sync_err;

    // ---------------------------------------------------------------- test block
    lcd_test u_test (
        .clk12_i       (clk12_i),
        .sw2_n_i       (sw2_n_i),
        .pclk_o        (pclk),
        .rst_n_o       (rst_n),
        .m_axis_tdata  (axis_tdata),
        .m_axis_tvalid (axis_tvalid),
        .m_axis_tready (axis_tready),
        .m_axis_tuser  (axis_tuser),
        .m_axis_tlast  (axis_tlast),
        .frame_start_i (frame_start),
        .underrun_i    (underrun),
        .sync_err_i    (sync_err),
        .led_n_o       (led_n_o)
    );

    // ---------------------------------------------------------------- DPI666 driver
    dpi666_axis #(
        .H_ACTIVE (480), .H_SYNC (30), .H_BP (65), .H_FP (65),
        .V_ACTIVE (640), .V_SYNC (10), .V_BP (25), .V_FP (25),
        .HS_POL (0), .VS_POL (0), .DE_POL (1), .PCLK_INV (1), .BL_ON (1)
    ) u_lcd (
        .pclk_i         (pclk),
        .rst_n_i        (rst_n),
        .s_axis_aclk    (pclk),
        .s_axis_aresetn (rst_n),
        .s_axis_tdata   (axis_tdata),
        .s_axis_tvalid  (axis_tvalid),
        .s_axis_tready  (axis_tready),
        .s_axis_tuser   (axis_tuser),
        .s_axis_tlast   (axis_tlast),
        .frame_start_o  (frame_start),
        .vblank_o       (vblank),
        .underrun_o     (underrun),
        .sync_err_o     (sync_err),
        .lcd_pclk_o     (lcd_pclk_o),
        .lcd_de_o       (lcd_de_o),
        .lcd_hsync_o    (lcd_hsync_o),
        .lcd_vsync_o    (lcd_vsync_o),
        .lcd_r_o        (lcd_r_o),
        .lcd_g_o        (lcd_g_o),
        .lcd_b_o        (lcd_b_o),
        .lcd_bl_o       (lcd_bl_o)
    );
endmodule
