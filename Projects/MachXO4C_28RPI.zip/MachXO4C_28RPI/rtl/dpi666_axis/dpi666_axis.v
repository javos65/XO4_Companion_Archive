// -----------------------------------------------------------------------------
// dpi666_axis  -  DPI666 (18-bit parallel RGB) LCD driver, AXI4-Stream input
//
// Library block. Verified on the MachXO4 Companion Board with the Waveshare
// 2.8" DPI LCD (480x640, ST7701S); the defaults are that panel's settings
// (Waveshare vc4-kms-dpi-2inch8 timing, 26.88 MHz pixel clock, 60 Hz).
//
// ---------------------------------------------------------------- interfaces
// AXI4-Stream slave (video), clock s_axis_aclk, reset s_axis_aresetn:
//   s_axis_tdata[17:0]  pixel {R[5:0], G[5:0], B[5:0]}
//   s_axis_tvalid / s_axis_tready
//   s_axis_tuser        start of frame (first pixel of line 0)
//   s_axis_tlast        end of line (pixel H_ACTIVE-1)
//   Lines are sent top to bottom, pixels left to right, H_ACTIVE x V_ACTIVE
//   per frame. s_axis_aclk may be asynchronous to pclk_i or the same clock.
//   The source must deliver one line (H_ACTIVE beats) per display line period
//   on average (480 px per 640 pixel clocks with the defaults).
//
// Pixel side, clock pclk_i, reset rst_n_i (active low, asynchronous):
//   frame_start_o  pulse at the start of each display frame
//   vblank_o       1 outside the active lines
//   underrun_o     sticky: a line was not available when it had to be shown
//                  (the line is shown black)
//   sync_err_o     sticky: stream framing error (line length != H_ACTIVE,
//                  start-of-frame in the wrong line, lines dropped to resync)
//   lcd_*          LCD pins (see parameters for polarity)
//
// ---------------------------------------------------------------- operation
// Two line banks (dual-clock EBR, 2 x 512 x 18). The stream side writes line
// k into bank k[0] when fewer than 2 lines are waiting, which is what
// s_axis_tready shows. The pixel side shows the oldest written line in each
// active display line and frees its bank after the line. Line counters cross
// the clock domains Gray-coded through 2-FF synchronisers; the per-bank
// "start of frame" flags and the line data are stable whenever the other
// domain reads them (guarded by those counters).
//
// Frame alignment: a line that carries tuser is shown only as display line 0.
// Outside the active lines, waiting lines without tuser are discarded, so the
// block locks to the stream at the next frame start after a framing error.
//
// Output stage: all LCD outputs come from I/O registers that are plain copies
// of fabric registers; the pin polarity is applied in the fabric register in
// front. Do not put logic between those two registers: on the MachXO4 build
// an inverter there was lost after synthesis (HSYNC/VSYNC came out with the
// wrong polarity). LCD_CLK is forwarded through an ODDRXE.
//
// Limits: H_ACTIVE <= 512, V_ACTIVE <= 1023.
// -----------------------------------------------------------------------------
module dpi666_axis #(
    parameter H_ACTIVE = 480,
    parameter H_SYNC   = 30,
    parameter H_BP     = 65,
    parameter H_FP     = 65,
    parameter V_ACTIVE = 640,
    parameter V_SYNC   = 10,
    parameter V_BP     = 25,
    parameter V_FP     = 25,
    parameter HS_POL   = 0,     // HSYNC level during the sync pulse
    parameter VS_POL   = 0,     // VSYNC level during the sync pulse
    parameter DE_POL   = 1,     // DE level during active pixels
    parameter PCLK_INV = 1,     // 1: panel samples on the LCD_CLK rising edge
    parameter BL_ON    = 1      // backlight output level
)(
    // pixel clock domain
    input  wire        pclk_i,
    input  wire        rst_n_i,

    // AXI4-Stream slave
    input  wire        s_axis_aclk,
    input  wire        s_axis_aresetn,
    input  wire [17:0] s_axis_tdata,
    input  wire        s_axis_tvalid,
    output wire        s_axis_tready,
    input  wire        s_axis_tuser,
    input  wire        s_axis_tlast,

    // status (pclk domain)
    output wire        frame_start_o,
    output wire        vblank_o,
    output reg         underrun_o,
    output wire        sync_err_o,

    // LCD pins
    output wire        lcd_pclk_o,
    (* syn_useioff = 1 *) output reg         lcd_de_o,
    (* syn_useioff = 1 *) output reg         lcd_hsync_o,
    (* syn_useioff = 1 *) output reg         lcd_vsync_o,
    (* syn_useioff = 1 *) output reg  [5:0]  lcd_r_o,
    (* syn_useioff = 1 *) output reg  [5:0]  lcd_g_o,
    (* syn_useioff = 1 *) output reg  [5:0]  lcd_b_o,
    output wire        lcd_bl_o
);
    localparam H_START = H_SYNC + H_BP;
    localparam H_END   = H_START + H_ACTIVE;
    localparam V_START = V_SYNC + V_BP;
    localparam V_END   = V_START + V_ACTIVE;

    function [3:0] bin2gray;
        input [3:0] b;
        bin2gray = b ^ (b >> 1);
    endfunction

    function [3:0] gray2bin;
        input [3:0] g;
        begin
            gray2bin[3] = g[3];
            gray2bin[2] = g[3] ^ g[2];
            gray2bin[1] = g[3] ^ g[2] ^ g[1];
            gray2bin[0] = g[3] ^ g[2] ^ g[1] ^ g[0];
        end
    endfunction

    // line counters crossing the clock domains (Gray coded)
    reg  [3:0] wr_gray;                 // lines written, aclk domain
    reg  [3:0] rd_gray;                 // lines consumed, pclk domain

    // =========================================================== stream side
    reg [1:0] arst_sync;
    always @(posedge s_axis_aclk or negedge s_axis_aresetn) begin
        if (!s_axis_aresetn) arst_sync <= 2'b11;
        else                 arst_sync <= {arst_sync[0], 1'b0};
    end
    wire arst = arst_sync[1];

    reg  [3:0] wr_cnt;                  // lines written (binary)
    reg  [3:0] rdg_a1, rdg_a2;          // rd_gray synchronised into aclk
    reg  [8:0] wx;                      // next pixel index in the line
    reg        cur_sof;                 // this line carries tuser
    reg  [1:0] sof_flag;                // per bank: line has start of frame
    reg        serr_a;                  // framing error (stream side)

    wire [3:0] rd_cnt_a  = gray2bin(rdg_a2);
    wire [3:0] waiting_a = wr_cnt - rd_cnt_a;
    wire       bank_free = (waiting_a < 4'd2);

    assign s_axis_tready = bank_free & ~arst;

    wire       beat  = s_axis_tvalid & s_axis_tready;
    wire [8:0] x_now = s_axis_tuser ? 9'd0 : wx;
    wire       wr_en = beat & (x_now < H_ACTIVE);

    always @(posedge s_axis_aclk) begin
        rdg_a1 <= rd_gray;
        rdg_a2 <= rdg_a1;
    end

    always @(posedge s_axis_aclk) begin
        if (arst) begin
            wr_cnt   <= 4'd0;
            wr_gray  <= 4'd0;
            wx       <= 9'd0;
            cur_sof  <= 1'b0;
            sof_flag <= 2'b00;
            serr_a   <= 1'b0;
        end else if (beat) begin
            if (s_axis_tlast) begin
                // commit the line: flag first, then the Gray counter
                sof_flag[wr_cnt[0]] <= s_axis_tuser | cur_sof;
                wr_cnt  <= wr_cnt + 4'd1;
                wr_gray <= bin2gray(wr_cnt + 4'd1);
                wx      <= 9'd0;
                cur_sof <= 1'b0;
                if (x_now != H_ACTIVE - 1)
                    serr_a <= 1'b1;             // line too short or too long
            end else begin
                cur_sof <= s_axis_tuser | cur_sof;
                if (s_axis_tuser && wx != 9'd0)
                    serr_a <= 1'b1;             // tuser restarted a line
                if (x_now < H_ACTIVE)
                    wx <= x_now + 9'd1;
                else
                    serr_a <= 1'b1;             // more than H_ACTIVE pixels
            end
        end
    end

    // =========================================================== line buffer
    wire [17:0] rd_data;
    reg         rd_bank;

    // pixel side timing outputs
    wire        t_hs, t_vs, t_de;
    wire [9:0]  t_line, t_x;
    wire [10:0] t_hcnt, t_vcnt;
    wire        t_line_start, t_fill_req;
    wire [9:0]  t_fill_line;

    dpi666_axis_buf u_buf (
        .wclk_i  (s_axis_aclk),
        .we_i    (wr_en),
        .waddr_i ({wr_cnt[0], x_now}),
        .wdata_i (s_axis_tdata),
        .rclk_i  (pclk_i),
        .raddr_i ({rd_bank, t_x[8:0]}),
        .rdata_o (rd_data)
    );

    // =========================================================== pixel side
    reg [1:0] prst_sync;
    always @(posedge pclk_i or negedge rst_n_i) begin
        if (!rst_n_i) prst_sync <= 2'b11;
        else          prst_sync <= {prst_sync[0], 1'b0};
    end
    wire rst = prst_sync[1];

    dpi666_timing #(
        .H_ACTIVE (H_ACTIVE), .H_SYNC (H_SYNC), .H_BP (H_BP), .H_FP (H_FP),
        .V_ACTIVE (V_ACTIVE), .V_SYNC (V_SYNC), .V_BP (V_BP), .V_FP (V_FP)
    ) u_timing (
        .clk_i         (pclk_i),
        .rst_i         (rst),
        .h_cnt_o       (t_hcnt),
        .v_cnt_o       (t_vcnt),
        .hsync_o       (t_hs),
        .vsync_o       (t_vs),
        .de_o          (t_de),
        .disp_line_o   (t_line),
        .disp_x_o      (t_x),
        .line_start_o  (t_line_start),
        .frame_start_o (frame_start_o),
        .vblank_o      (vblank_o),
        .fill_req_o    (t_fill_req),
        .fill_line_o   (t_fill_line)
    );

    reg  [3:0] rd_cnt;                  // lines consumed (binary)
    reg  [3:0] wrg_p1, wrg_p2;          // wr_gray synchronised into pclk
    reg        line_ok;                 // current display line has valid data
    reg        serr_p;                  // framing error seen on the pixel side
    reg  [1:0] serr_sync;               // serr_a synchronised into pclk

    wire [3:0] wr_cnt_p  = gray2bin(wrg_p2);
    wire       avail     = (wr_cnt_p != rd_cnt);
    wire       head_sof  = sof_flag[rd_cnt[0]];   // stable while avail
    wire       row_act   = (t_vcnt >= V_START) && (t_vcnt < V_END);
    wire       row_check = row_act && (t_hcnt == 11'd2);
    wire       row_done  = row_act && (t_hcnt == H_END + 2);
    wire       first_row = (t_line == 10'd0);
    wire       drop      = ~row_act & avail & ~head_sof;

    always @(posedge pclk_i) begin
        wrg_p1    <= wr_gray;
        wrg_p2    <= wrg_p1;
        serr_sync <= {serr_sync[0], serr_a};
    end

    always @(posedge pclk_i) begin
        if (rst) begin
            rd_cnt     <= 4'd0;
            rd_gray    <= 4'd0;
            rd_bank    <= 1'b0;
            line_ok    <= 1'b0;
            underrun_o <= 1'b0;
            serr_p     <= 1'b0;
        end else begin
            // decide at the start of each active row which line is shown
            if (row_check) begin
                line_ok <= avail & (head_sof == first_row);
                rd_bank <= rd_cnt[0];
                if (!avail)
                    underrun_o <= 1'b1;
                else if (head_sof != first_row)
                    serr_p <= 1'b1;
            end

            // free the bank after the row, or discard misaligned lines
            if (row_done && line_ok) begin
                rd_cnt  <= rd_cnt + 4'd1;
                rd_gray <= bin2gray(rd_cnt + 4'd1);
            end else if (drop) begin
                rd_cnt  <= rd_cnt + 4'd1;
                rd_gray <= bin2gray(rd_cnt + 4'd1);
                serr_p  <= 1'b1;
            end
        end
    end

    assign sync_err_o = serr_p | serr_sync[1];

    // =========================================================== output stage
    localparam [0:0] DE_ON = DE_POL ? 1'b1 : 1'b0;
    localparam [0:0] HS_ON = HS_POL ? 1'b1 : 1'b0;
    localparam [0:0] VS_ON = VS_POL ? 1'b1 : 1'b0;

    // T2: aligned with rd_data; pin polarity applied here (fabric registers)
    reg de_d, de_lvl, hs_lvl, vs_lvl;
    always @(posedge pclk_i) begin
        if (rst) begin
            de_d   <= 1'b0;
            de_lvl <= ~DE_ON;
            hs_lvl <= ~HS_ON;
            vs_lvl <= ~VS_ON;
        end else begin
            de_d   <= t_de & line_ok;
            de_lvl <= t_de ? DE_ON : ~DE_ON;
            hs_lvl <= t_hs ? HS_ON : ~HS_ON;
            vs_lvl <= t_vs ? VS_ON : ~VS_ON;
        end
    end

    // T3: I/O registers, plain copies (packed into the PIO cells)
    always @(posedge pclk_i) begin
        lcd_de_o    <= de_lvl;
        lcd_hsync_o <= hs_lvl;
        lcd_vsync_o <= vs_lvl;
        lcd_r_o     <= de_d ? rd_data[17:12] : 6'd0;
        lcd_g_o     <= de_d ? rd_data[11:6]  : 6'd0;
        lcd_b_o     <= de_d ? rd_data[5:0]   : 6'd0;
    end

    ODDRXE u_pclk_oddr (
        .D0   (PCLK_INV ? 1'b0 : 1'b1),
        .D1   (PCLK_INV ? 1'b1 : 1'b0),
        .SCLK (pclk_i),
        .RST  (rst),
        .Q    (lcd_pclk_o)
    );

    assign lcd_bl_o = BL_ON ? 1'b1 : 1'b0;

endmodule
