// -----------------------------------------------------------------------------
// dpi666_axis_buf
// Dual-clock line buffer: 2 banks x 512 words x 18 bits (RGB666).
// Write port on the AXI4-Stream clock, registered read port on the pixel clock.
// Inferred as a pseudo dual-port EBR (2 x 512x18 on MachXO4). Read latency 1.
// Address = {bank, pixel[8:0]}.
// -----------------------------------------------------------------------------
module dpi666_axis_buf (
    input  wire        wclk_i,
    input  wire        we_i,
    input  wire [9:0]  waddr_i,
    input  wire [17:0] wdata_i,

    input  wire        rclk_i,
    input  wire [9:0]  raddr_i,
    output reg  [17:0] rdata_o
);
    (* syn_ramstyle = "block_ram" *)
    reg [17:0] mem [0:1023];

    always @(posedge wclk_i) begin
        if (we_i)
            mem[waddr_i] <= wdata_i;
    end

    always @(posedge rclk_i) begin
        rdata_o <= mem[raddr_i];
    end
endmodule
