// -----------------------------------------------------------------------------
// dpi666_timing
// Horizontal/vertical timing generator for a parallel RGB (DPI) panel.
// Counters start at the sync pulse: h_cnt 0..H_TOTAL-1, v_cnt 0..V_TOTAL-1.
//   h: [0,H_SYNC) sync | [H_SYNC,H_START) back porch | [H_START,H_END) active | front porch
//   v: [0,V_SYNC) sync | [V_SYNC,V_START) back porch | [V_START,V_END) active | front porch
// All outputs are registered (aligned with h_cnt_o / v_cnt_o).
// fill_req_o pulses at h_cnt=0 of the line BEFORE each active line and names the
// active line index (0..V_ACTIVE-1) that the line buffer has to receive next.
// -----------------------------------------------------------------------------
module dpi666_timing #(
    parameter H_ACTIVE = 480,
    parameter H_SYNC   = 16,
    parameter H_BP     = 10,
    parameter H_FP     = 26,
    parameter V_ACTIVE = 640,
    parameter V_SYNC   = 10,
    parameter V_BP     = 15,
    parameter V_FP     = 25
)(
    input  wire        clk_i,
    input  wire        rst_i,          // synchronous, active high

    output reg  [10:0] h_cnt_o,
    output reg  [10:0] v_cnt_o,
    output reg         hsync_o,        // 1 = inside sync pulse (polarity applied later)
    output reg         vsync_o,
    output reg         de_o,           // 1 = active pixel
    output reg  [9:0]  disp_line_o,    // active line index of the current line
    output reg  [9:0]  disp_x_o,       // active pixel index (valid when de_o)
    output reg         line_start_o,   // pulse at h_cnt = H_START of an active line
    output reg         frame_start_o,  // pulse at h_cnt = 0, v_cnt = 0
    output reg         vblank_o,       // 1 outside the active lines
    output reg         fill_req_o,     // pulse: please load line fill_line_o
    output reg  [9:0]  fill_line_o
);
    localparam H_TOTAL = H_SYNC + H_BP + H_ACTIVE + H_FP;
    localparam V_TOTAL = V_SYNC + V_BP + V_ACTIVE + V_FP;
    localparam H_START = H_SYNC + H_BP;
    localparam H_END   = H_START + H_ACTIVE;
    localparam V_START = V_SYNC + V_BP;
    localparam V_END   = V_START + V_ACTIVE;

    reg [10:0] h_cnt;
    reg [10:0] v_cnt;

    wire h_last = (h_cnt == H_TOTAL - 1);
    wire v_last = (v_cnt == V_TOTAL - 1);

    always @(posedge clk_i) begin
        if (rst_i) begin
            h_cnt <= 11'd0;
            v_cnt <= 11'd0;
        end else if (h_last) begin
            h_cnt <= 11'd0;
            v_cnt <= v_last ? 11'd0 : v_cnt + 11'd1;
        end else begin
            h_cnt <= h_cnt + 11'd1;
        end
    end

    wire v_act  = (v_cnt >= V_START) && (v_cnt < V_END);
    wire h_act  = (h_cnt >= H_START) && (h_cnt < H_END);
    // Line before an active line: V_START-1 .. V_END-2
    wire v_fill = (v_cnt >= V_START - 1) && (v_cnt < V_END - 1);

    always @(posedge clk_i) begin
        if (rst_i) begin
            h_cnt_o       <= 11'd0;
            v_cnt_o       <= 11'd0;
            hsync_o       <= 1'b0;
            vsync_o       <= 1'b0;
            de_o          <= 1'b0;
            disp_line_o   <= 10'd0;
            disp_x_o      <= 10'd0;
            line_start_o  <= 1'b0;
            frame_start_o <= 1'b0;
            vblank_o      <= 1'b1;
            fill_req_o    <= 1'b0;
            fill_line_o   <= 10'd0;
        end else begin
            h_cnt_o       <= h_cnt;
            v_cnt_o       <= v_cnt;
            hsync_o       <= (h_cnt < H_SYNC);
            vsync_o       <= (v_cnt < V_SYNC);
            de_o          <= h_act && v_act;
            disp_line_o   <= v_cnt[9:0] - V_START[9:0];
            disp_x_o      <= h_cnt[9:0] - H_START[9:0];
            line_start_o  <= v_act && (h_cnt == H_START);
            frame_start_o <= (h_cnt == 11'd0) && (v_cnt == 11'd0);
            vblank_o      <= !v_act;
            fill_req_o    <= v_fill && (h_cnt == 11'd0);
            fill_line_o   <= v_cnt[9:0] - (V_START[9:0] - 10'd1);
        end
    end
endmodule
