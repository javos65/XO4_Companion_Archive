// -----------------------------------------------------------------------------
// tb_top - board-level simulation of top_28rpi (PLL model, reset, u_test with
// lcd_logo_seq, u_lcd = dpi666_axis). Checks 3 displayed frames pixel by pixel:
// the 49x40 logo (from rtl/lcd_test/logo_rgb666.mem) at (0,0), (2,2), (4,4),
// black everywhere else, 640 lines per frame, LED3 (underrun) and LED4 (sync
// error) off.
// -----------------------------------------------------------------------------
`timescale 1ns / 1ps

module tb_top;
    localparam LW = 49, LH = 40;

    reg clk12 = 1'b0;
    always #41.6667 clk12 = ~clk12;           // 12 MHz

    GSR GSR_INST (.GSR(1'b1), .CLK(1'b0), .GSROUT());
    PUR PUR_INST (.PUR(1'b1));

    wire       lcd_pclk, lcd_de, lcd_hs, lcd_vs, lcd_bl;
    wire [5:0] lcd_r, lcd_g, lcd_b;
    wire [3:0] led_n;

    top_28rpi dut (
        .clk12_i     (clk12),
        .sw2_n_i     (1'b1),
        .lcd_pclk_o  (lcd_pclk),
        .lcd_de_o    (lcd_de),
        .lcd_hsync_o (lcd_hs),
        .lcd_vsync_o (lcd_vs),
        .lcd_r_o     (lcd_r),
        .lcd_g_o     (lcd_g),
        .lcd_b_o     (lcd_b),
        .lcd_bl_o    (lcd_bl),
        .led_n_o     (led_n)
    );

    reg [17:0] logo [0:2047];
    initial $readmemh("../rtl/lcd_test/logo_rgb666.mem", logo);

    integer frame = -1, errors = 0, lines = 0, x = 0, pix = 0, visible = 0, ex;
    reg     vs_q = 1'b1, de_q = 1'b0;
    reg [17:0] exp_px;

    always @(negedge dut.pclk) if (dut.rst_n) begin
        if (vs_q && !lcd_vs) begin
            if (frame >= 0) begin
                $display("frame %0d: logo at (%0d,%0d), %0d visible pixels, %0d lines, LEDs %b, errors %0d",
                         frame, 2*frame, 2*frame, visible, lines, led_n, errors);
                if (lines != 640) errors = errors + 1;
                if (!led_n[2] || !led_n[3]) errors = errors + 1;   // underrun / sync error LED on
            end
            frame = frame + 1;
            lines = 0; visible = 0;
            if (frame == 3) begin
                $display("%0d pixel compares", pix);
                if (errors == 0) $display("TEST PASSED"); else $display("TEST FAILED (%0d errors)", errors);
                $finish;
            end
        end
        if (frame >= 0) begin
            ex = 2 * frame;
            if (lcd_de) begin
                if (!de_q) x = 0;
                if (x >= ex && x < ex + LW && lines >= ex && lines < ex + LH)
                    exp_px = logo[(lines - ex) * LW + (x - ex)];
                else
                    exp_px = 18'd0;
                pix = pix + 1;
                if ({lcd_r, lcd_g, lcd_b} !== exp_px) begin
                    errors = errors + 1;
                    if (errors <= 10)
                        $display("ERROR frame %0d pixel (%0d,%0d): got %h exp %h", frame, x, lines,
                                 {lcd_r, lcd_g, lcd_b}, exp_px);
                end
                if ({lcd_r, lcd_g, lcd_b} != 18'd0) visible = visible + 1;
                x = x + 1;
            end else if (de_q) lines = lines + 1;
        end
        vs_q = lcd_vs; de_q = lcd_de;
    end

    initial begin
        #80_000_000;
        $display("TEST FAILED (timeout), frame %0d", frame);
        $finish;
    end
endmodule
