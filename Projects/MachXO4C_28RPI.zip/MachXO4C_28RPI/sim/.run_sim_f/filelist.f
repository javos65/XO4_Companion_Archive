../ip/pll_pix/rtl/pll_pix.sv
../rtl/dpi666_axis/dpi666_timing.v
../rtl/dpi666_axis/dpi666_axis_buf.v
../rtl/dpi666_axis/dpi666_axis.v
../rtl/lcd_test/lcd_logo_seq.v
../rtl/lcd_test/lcd_test.v
../rtl/top_28rpi.v
tb_top.v
