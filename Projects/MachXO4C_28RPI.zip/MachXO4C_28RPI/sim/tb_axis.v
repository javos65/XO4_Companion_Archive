// -----------------------------------------------------------------------------
// tb_axis - self-checking testbench for dpi666_axis + lcd_block_seq
//
// pclk 26.88 MHz, AXI4-Stream clock 40 MHz (asynchronous), the source inserts
// random idle cycles (tvalid low about 25 % of the time).
// The LCD pins are sampled on the falling edge of pclk (outputs change on the
// rising edge). For every displayed frame:
//   - 640 active lines of 480 pixels, HSYNC/VSYNC active low
//   - exactly 64 red pixels forming the 8x8 block at the expected position
//     (frame 0 at (0,0), then +2/+2 per frame), every other pixel black
//   - underrun_o and sync_err_o stay 0
// A second, small sequencer (16x12 frame, 8x8 block, step 3) checks the
// bounce rule over 40 frames against an independent model.
// -----------------------------------------------------------------------------
`timescale 1ns / 1ps

module tb_axis;
    localparam H = 480, V = 640, SIZE = 8, STEP = 2;
    localparam N_FRAMES = 5;
    localparam [17:0] RED = {6'h3F, 6'h00, 6'h00};

    reg pclk = 1'b0, aclk = 1'b0;
    reg rst_n = 1'b0;
    reg en = 1'b1;
    always #18.601 pclk = ~pclk;          // 26.88 MHz
    always #12.5   aclk = ~aclk;          // 40 MHz, asynchronous

    GSR GSR_INST (.GSR(1'b1), .CLK(1'b0), .GSROUT());
    PUR PUR_INST (.PUR(1'b1));

    // random idle cycles on the stream
    integer seed = 7;
    always @(posedge aclk) en <= ($random(seed) & 3) != 0;

    // ------------------------------------------------------------ DUT
    wire [17:0] tdata;
    wire        tvalid, tready, tuser, tlast;
    wire        frame_start, vblank, underrun, sync_err;
    wire        lcd_pclk, lcd_de, lcd_hs, lcd_vs, lcd_bl;
    wire [5:0]  lcd_r, lcd_g, lcd_b;

    lcd_block_seq #(.H_ACTIVE(H), .V_ACTIVE(V), .SIZE(SIZE), .STEP(STEP)) u_seq (
        .aclk          (aclk),
        .aresetn       (rst_n),
        .en_i          (en),
        .m_axis_tdata  (tdata),
        .m_axis_tvalid (tvalid),
        .m_axis_tready (tready),
        .m_axis_tuser  (tuser),
        .m_axis_tlast  (tlast),
        .block_x_o     (),
        .block_y_o     ()
    );

    dpi666_axis u_lcd (
        .pclk_i         (pclk),
        .rst_n_i        (rst_n),
        .s_axis_aclk    (aclk),
        .s_axis_aresetn (rst_n),
        .s_axis_tdata   (tdata),
        .s_axis_tvalid  (tvalid),
        .s_axis_tready  (tready),
        .s_axis_tuser   (tuser),
        .s_axis_tlast   (tlast),
        .frame_start_o  (frame_start),
        .vblank_o       (vblank),
        .underrun_o     (underrun),
        .sync_err_o     (sync_err),
        .lcd_pclk_o     (lcd_pclk),
        .lcd_de_o       (lcd_de),
        .lcd_hsync_o    (lcd_hs),
        .lcd_vsync_o    (lcd_vs),
        .lcd_r_o        (lcd_r),
        .lcd_g_o        (lcd_g),
        .lcd_b_o        (lcd_b),
        .lcd_bl_o       (lcd_bl)
    );

    // ------------------------------------------------------------ checker
    integer errors = 0, checks = 0, pix_checks = 0;
    integer frame = -1;
    integer lines, pixels, red_cnt, other_cnt, x, hs_low, max_hs_low;
    integer min_x, max_x, min_y, max_y;
    integer ex = 0, ey = 0, ex_neg = 0, ey_neg = 0;    // expected block position
    reg     vs_q = 1'b1, de_q = 1'b0, hs_q = 1'b1;

    task fail;
        input [8*64-1:0] msg;
        begin
            errors = errors + 1;
            if (errors <= 20) $display("ERROR @%0t frame %0d: %0s", $time, frame, msg);
        end
    endtask

    task next_pos;      // independent model of the bounce rule
        begin
            if (!ex_neg) begin if (ex + STEP > H - SIZE) begin ex_neg = 1; ex = ex - STEP; end else ex = ex + STEP; end
            else         begin if (ex < STEP)            begin ex_neg = 0; ex = ex + STEP; end else ex = ex - STEP; end
            if (!ey_neg) begin if (ey + STEP > V - SIZE) begin ey_neg = 1; ey = ey - STEP; end else ey = ey + STEP; end
            else         begin if (ey < STEP)            begin ey_neg = 0; ey = ey + STEP; end else ey = ey - STEP; end
        end
    endtask

    task start_frame;
        begin
            lines = 0; pixels = 0; red_cnt = 0; other_cnt = 0; max_hs_low = 0;
            min_x = 9999; max_x = -1; min_y = 9999; max_y = -1;
        end
    endtask

    task end_frame;
        begin
            checks = checks + 6;
            $display("frame %0d: red block at x %0d..%0d, y %0d..%0d (%0d px), expected (%0d,%0d)",
                     frame, min_x, max_x, min_y, max_y, red_cnt, ex, ey);
            if (lines  != V)            fail("active lines != 640");
            if (pixels != H * V)        fail("active pixels != 480*640");
            if (red_cnt != SIZE * SIZE) fail("red pixel count != 64");
            if (other_cnt != 0)         fail("non-black pixel outside the block");
            if (min_x != ex || max_x != ex + SIZE - 1) fail("block x position wrong");
            if (min_y != ey || max_y != ey + SIZE - 1) fail("block y position wrong");
            next_pos;
        end
    endtask

    always @(negedge pclk) if (rst_n) begin
        // VSYNC falling edge = start of a display frame
        if (vs_q && !lcd_vs) begin
            if (frame >= 0) end_frame;
            frame = frame + 1;
            start_frame;
            if (frame == N_FRAMES) begin
                checks = checks + 2;
                if (underrun) fail("underrun_o set");
                if (sync_err) fail("sync_err_o set");
                $display("SCOREBOARD: %0d checks (%0d pixel compares), %0d errors", checks, pix_checks, errors);
                bounce_check;
                if (errors == 0) $display("TEST PASSED"); else $display("TEST FAILED");
                $finish;
            end
        end
        // HSYNC must be active low (short low pulse)
        if (!lcd_hs) hs_low = hs_low + 1;
        if (!hs_q && lcd_hs) begin
            if (hs_low != 30) fail("HSYNC low width != 30");
            checks = checks + 1;
        end
        if (hs_q && !lcd_hs) hs_low = 1;

        if (frame >= 0) begin
            if (lcd_de) begin
                if (!de_q) x = 0;
                pixels = pixels + 1;
                pix_checks = pix_checks + 1;
                if ({lcd_r, lcd_g, lcd_b} == RED) begin
                    red_cnt = red_cnt + 1;
                    if (x < min_x) min_x = x;
                    if (x > max_x) max_x = x;
                    if (lines < min_y) min_y = lines;
                    if (lines > max_y) max_y = lines;
                end else if ({lcd_r, lcd_g, lcd_b} !== 18'd0) begin
                    other_cnt = other_cnt + 1;
                end
                x = x + 1;
            end else if (de_q) begin
                lines = lines + 1;
            end
        end
        vs_q = lcd_vs; de_q = lcd_de; hs_q = lcd_hs;
    end

    // ------------------------------------------------------------ bounce rule
    // Small sequencer, always ready: 16x12 frame, 8x8 block, step 3.
    wire [9:0] sbx, sby;
    wire       s_last;
    lcd_block_seq #(.H_ACTIVE(16), .V_ACTIVE(12), .SIZE(8), .STEP(3)) u_small (
        .aclk (aclk), .aresetn (rst_n), .en_i (1'b1),
        .m_axis_tdata (), .m_axis_tvalid (), .m_axis_tready (1'b1),
        .m_axis_tuser (), .m_axis_tlast (s_last),
        .block_x_o (sbx), .block_y_o (sby)
    );
    integer sx = 0, sy = 0, sxn = 0, syn = 0, sframes = 0, s_err = 0;
    always @(posedge aclk) if (rst_n && u_small.run && u_small.m_axis_tuser) begin
        if (sframes < 40) begin
            if (sbx != sx || sby != sy) s_err = s_err + 1;
            // model: frame 8 wide (X_MAX = 8), 12 high (Y_MAX = 4), step 3
            if (!sxn) begin if (sx + 3 > 8) begin sxn = 1; sx = sx - 3; end else sx = sx + 3; end
            else      begin if (sx < 3)     begin sxn = 0; sx = sx + 3; end else sx = sx - 3; end
            if (!syn) begin if (sy + 3 > 4) begin syn = 1; sy = sy - 3; end else sy = sy + 3; end
            else      begin if (sy < 3)     begin syn = 0; sy = sy + 3; end else sy = sy - 3; end
            sframes = sframes + 1;
        end
    end
    task bounce_check;
        begin
            checks = checks + 1;
            $display("bounce check: %0d small frames, %0d position errors", sframes, s_err);
            if (sframes < 40 || s_err != 0) fail("bounce rule mismatch");
        end
    endtask

    // ------------------------------------------------------------ stimulus
    initial begin
        hs_low = 0;
        start_frame;
        $display("tb_axis: start");
        #500 rst_n = 1'b1;
        #((N_FRAMES + 2) * 640.0 * 700.0 * 37.202);
        $display("TEST FAILED (timeout), frame %0d", frame);
        $finish;
    end
endmodule
