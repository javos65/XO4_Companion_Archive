// -----------------------------------------------------------------------------
// tb_logo - self-checking testbench for dpi666_axis + lcd_logo_seq
//
// pclk 26.88 MHz, AXI4-Stream clock 40 MHz (asynchronous) with random idle
// cycles. Every displayed pixel of every frame is compared with a reference
// built from the same ROM file: the 49x40 logo at the expected position,
// black everywhere else. Expected positions: frame 0 at (0,0), then the
// bounce rule with step 2 (X_MAX = 431, Y_MAX = 600). Also checked: 640
// active lines of 480 pixels, HSYNC active low (30 clocks), no underrun and
// no sync error.
// -----------------------------------------------------------------------------
`timescale 1ns / 1ps

module tb_logo;
    localparam H = 480, V = 640, LW = 49, LH = 40, STEP = 2;
    localparam N_FRAMES = 4;

    reg pclk = 1'b0, aclk = 1'b0;
    reg rst_n = 1'b0;
    reg en = 1'b1;
    always #18.601 pclk = ~pclk;          // 26.88 MHz
    always #12.5   aclk = ~aclk;          // 40 MHz, asynchronous

    GSR GSR_INST (.GSR(1'b1), .CLK(1'b0), .GSROUT());
    PUR PUR_INST (.PUR(1'b1));

    integer seed = 11;
    always @(posedge aclk) en <= ($random(seed) & 3) != 0;

    wire [17:0] tdata;
    wire        tvalid, tready, tuser, tlast;
    wire        frame_start, vblank, underrun, sync_err;
    wire        lcd_pclk, lcd_de, lcd_hs, lcd_vs, lcd_bl;
    wire [5:0]  lcd_r, lcd_g, lcd_b;

    lcd_logo_seq #(
        .H_ACTIVE (H), .V_ACTIVE (V), .LOGO_W (LW), .LOGO_H (LH), .LOGO_DEPTH (2048),
        .LOGO_FILE ("../rtl/lcd_test/logo_rgb666.mem"), .STEP (STEP)
    ) u_seq (
        .aclk (aclk), .aresetn (rst_n), .en_i (en),
        .m_axis_tdata (tdata), .m_axis_tvalid (tvalid), .m_axis_tready (tready),
        .m_axis_tuser (tuser), .m_axis_tlast (tlast),
        .logo_x_o (), .logo_y_o ()
    );

    dpi666_axis u_lcd (
        .pclk_i (pclk), .rst_n_i (rst_n),
        .s_axis_aclk (aclk), .s_axis_aresetn (rst_n),
        .s_axis_tdata (tdata), .s_axis_tvalid (tvalid), .s_axis_tready (tready),
        .s_axis_tuser (tuser), .s_axis_tlast (tlast),
        .frame_start_o (frame_start), .vblank_o (vblank),
        .underrun_o (underrun), .sync_err_o (sync_err),
        .lcd_pclk_o (lcd_pclk), .lcd_de_o (lcd_de), .lcd_hsync_o (lcd_hs), .lcd_vsync_o (lcd_vs),
        .lcd_r_o (lcd_r), .lcd_g_o (lcd_g), .lcd_b_o (lcd_b), .lcd_bl_o (lcd_bl)
    );

    // reference logo
    reg [17:0] logo [0:2047];
    integer logo_px = 0, k;
    initial begin
        $readmemh("../rtl/lcd_test/logo_rgb666.mem", logo);
        for (k = 0; k < LW * LH; k = k + 1) if (logo[k] != 0) logo_px = logo_px + 1;
    end

    integer errors = 0, pix = 0, frame = -1, lines, x, hs_low = 0, visible;
    integer ex = 0, ey = 0, ex_neg = 0, ey_neg = 0;
    reg     vs_q = 1'b1, de_q = 1'b0, hs_q = 1'b1;
    reg [17:0] exp_px;

    task next_pos;
        begin
            if (!ex_neg) begin if (ex + STEP > H - LW) begin ex_neg = 1; ex = ex - STEP; end else ex = ex + STEP; end
            else         begin if (ex < STEP)          begin ex_neg = 0; ex = ex + STEP; end else ex = ex - STEP; end
            if (!ey_neg) begin if (ey + STEP > V - LH) begin ey_neg = 1; ey = ey - STEP; end else ey = ey + STEP; end
            else         begin if (ey < STEP)          begin ey_neg = 0; ey = ey + STEP; end else ey = ey - STEP; end
        end
    endtask

    always @(negedge pclk) if (rst_n) begin
        if (vs_q && !lcd_vs) begin
            if (frame >= 0) begin
                $display("frame %0d: logo expected at (%0d,%0d), %0d lines, %0d visible logo pixels (ROM: %0d), errors so far %0d",
                         frame, ex, ey, lines, visible, logo_px, errors);
                if (lines != V)          begin errors = errors + 1; $display("ERROR: line count"); end
                if (visible != logo_px)  begin errors = errors + 1; $display("ERROR: visible pixel count"); end
                next_pos;
            end
            frame = frame + 1;
            lines = 0; visible = 0;
            if (frame == N_FRAMES) begin
                if (underrun) begin errors = errors + 1; $display("ERROR: underrun"); end
                if (sync_err) begin errors = errors + 1; $display("ERROR: sync error"); end
                $display("SCOREBOARD: %0d pixel compares, %0d errors", pix, errors);
                if (errors == 0) $display("TEST PASSED"); else $display("TEST FAILED");
                $finish;
            end
        end
        if (!lcd_hs) hs_low = hs_low + 1;
        if (!hs_q && lcd_hs) begin
            if (hs_low != 30) begin errors = errors + 1; $display("ERROR: HSYNC low %0d", hs_low); end
        end
        if (hs_q && !lcd_hs) hs_low = 1;

        if (frame >= 0) begin
            if (lcd_de) begin
                if (!de_q) x = 0;
                if (x >= ex && x < ex + LW && lines >= ey && lines < ey + LH)
                    exp_px = logo[(lines - ey) * LW + (x - ex)];
                else
                    exp_px = 18'd0;
                pix = pix + 1;
                if ({lcd_r, lcd_g, lcd_b} !== exp_px) begin
                    errors = errors + 1;
                    if (errors <= 10)
                        $display("ERROR frame %0d pixel (%0d,%0d): got %h exp %h", frame, x, lines,
                                 {lcd_r, lcd_g, lcd_b}, exp_px);
                end
                if ({lcd_r, lcd_g, lcd_b} != 18'd0) visible = visible + 1;
                x = x + 1;
            end else if (de_q) lines = lines + 1;
        end
        vs_q = lcd_vs; de_q = lcd_de; hs_q = lcd_hs;
    end

    initial begin
        #500 rst_n = 1'b1;
        #((N_FRAMES + 2) * 640.0 * 700.0 * 37.202);
        $display("TEST FAILED (timeout), frame %0d", frame);
        $finish;
    end
endmodule
