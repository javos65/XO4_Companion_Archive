@echo off
REM Remove run_sim.cmd / qrun artifacts from the current directory.
REM Do not delete SOFT_IP / soft_ip.* — those names are Propel Soft-IP trees,
REM not this runner's workdir (qrun.out).
for %%D in (qrun.out lib_pmi .run_sim_f work csrc simv.daidir DVEfiles xcelium.d) do (
    if exist "%%D\" rmdir /s /q "%%D"
)
del /q /f *.log *.diag *.history *.dbg 2>nul
del /q /f transcript vsim.wlf modelsim.ini qrun.out 2>nul
del /q /f synopsys_sim.setup vc_hdrs.h ucli.key *.vpd *.fsdb *.vcd 2>nul
for /d %%D in (lib_*) do rmdir /s /q "%%D" 2>nul
exit /b 0
