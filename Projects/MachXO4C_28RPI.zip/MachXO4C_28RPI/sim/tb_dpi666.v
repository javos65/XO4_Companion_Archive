// -----------------------------------------------------------------------------
// tb_dpi666 - self-checking testbench for dpi666_lcd + lcd_test_pattern
//
// The LCD outputs are sampled on the falling edge of the forwarded LCD clock,
// exactly as the ST7701S does. Checks:
//   - HSYNC period 532 clocks, low for 16 clocks
//   - VSYNC period 690 lines, low for 10 lines (5320 clocks)
//   - DE: 480 contiguous clocks per active line, first DE 26 clocks after
//     HSYNC falls, 640 active lines per frame, first active line 25 lines
//     after VSYNC falls
//   - every pixel equals the reference colour of its line (lcd_line_color)
//   - RGB = 0 outside DE, underrun never set
// Frames 0..7; the pattern mode changes at frames 2, 4 and 6 (modes 1, 2, 3).
// Frames whose mode was changed during the previous frame boundary are only
// checked for timing; pixel checks run on frames 1, 3, 5 and 7.
// -----------------------------------------------------------------------------
`timescale 1ns / 1ps

module tb_dpi666;
    localparam H_TOTAL = 532, V_TOTAL = 690;
    localparam HSW = 16, HBP = 10, HACT = 480;
    localparam VSW = 10, VBP = 15, VACT = 640;
    localparam N_FRAMES = 8;

    reg        pclk = 1'b0;
    reg        rst_n = 1'b0;
    reg  [1:0] mode = 2'd0;

    always #15.625 pclk = ~pclk;           // 32 MHz

    // Global set/reset and power-up reset, referenced by the MachXO4 I/O models
    // (GSR_INST.GSROUT, PUR_INST.PURNET). Both inactive after the PUR pulse.
    GSR GSR_INST (.GSR(1'b1), .CLK(1'b0), .GSROUT());
    PUR PUR_INST (.PUR(1'b1));

    // ------------------------------------------------------------ DUT
    wire        fill_req, fill_done;
    wire [9:0]  fill_line;
    wire        wr_en;
    wire [8:0]  wr_addr;
    wire [17:0] wr_data;
    wire        frame_start, line_start, vblank, underrun;
    wire        lcd_pclk, lcd_de, lcd_hs, lcd_vs, lcd_bl;
    wire [5:0]  lcd_r, lcd_g, lcd_b;

    dpi666_lcd u_lcd (
        .pclk_i        (pclk),
        .rst_n_i       (rst_n),
        .wr_en_i       (wr_en),
        .wr_addr_i     (wr_addr),
        .wr_data_i     (wr_data),
        .fill_req_o    (fill_req),
        .fill_line_o   (fill_line),
        .fill_done_i   (fill_done),
        .frame_start_o (frame_start),
        .line_start_o  (line_start),
        .vblank_o      (vblank),
        .underrun_o    (underrun),
        .lcd_pclk_o    (lcd_pclk),
        .lcd_de_o      (lcd_de),
        .lcd_hsync_o   (lcd_hs),
        .lcd_vsync_o   (lcd_vs),
        .lcd_r_o       (lcd_r),
        .lcd_g_o       (lcd_g),
        .lcd_b_o       (lcd_b),
        .lcd_bl_o      (lcd_bl)
    );

    lcd_test_pattern u_pat (
        .clk_i         (pclk),
        .rst_n_i       (rst_n),
        .mode_i        (mode),
        .frame_start_i (frame_start),
        .fill_req_i    (fill_req),
        .fill_line_i   (fill_line),
        .fill_done_o   (fill_done),
        .wr_en_o       (wr_en),
        .wr_addr_o     (wr_addr),
        .wr_data_o     (wr_data)
    );

    // ------------------------------------------------------------ reference model
    reg  [1:0]  ref_mode;
    reg  [9:0]  ref_line;
    reg  [9:0]  ref_scroll;
    reg  [2:0]  ref_ofs;
    reg  [2:0]  prev_ofs;
    wire [17:0] ref_color;

    lcd_line_color u_ref (
        .mode_i       (ref_mode),
        .line_i       (ref_line),
        .scroll_i     (ref_scroll),
        .stripe_ofs_i (ref_ofs),
        .color_o      (ref_color)
    );

    // ------------------------------------------------------------ scoreboard
    integer errors = 0;
    integer checks = 0;
    integer pix_checks = 0;

    integer clk_cnt = 0;          // panel clocks since last HSYNC fall
    integer hs_low  = 0;
    integer line_cnt = 0;         // lines since last VSYNC fall
    integer vs_low_clks = 0;
    integer frame = -1;
    integer de_run = 0;
    integer de_lines = 0;
    integer act_line = 0;         // active line index inside the frame
    integer first_de_line = -1;
    reg     hs_q = 1'b1, vs_q = 1'b1, de_q = 1'b0;
    reg     pix_check_frame = 1'b0;
    reg     timing_valid = 1'b0;  // after the first full line / frame
    reg     frame_valid = 1'b0;

    task fail;
        input [8*80-1:0] msg;
        begin
            errors = errors + 1;
            if (errors <= 20)
                $display("ERROR @%0t frame %0d line %0d clk %0d: %0s",
                         $time, frame, line_cnt, clk_cnt, msg);
        end
    endtask

    always @(negedge lcd_pclk) if (rst_n) begin
        clk_cnt = clk_cnt + 1;

        // ---------------- HSYNC
        if (!lcd_hs) hs_low = hs_low + 1;
        if (hs_q && !lcd_hs) begin                     // HSYNC falling
            if (timing_valid) begin
                checks = checks + 1;
                if (clk_cnt != H_TOTAL) fail("HSYNC period != 532");
            end
            timing_valid = 1'b1;
            clk_cnt  = 0;
            hs_low   = 1;
            line_cnt = line_cnt + 1;
        end
        if (!hs_q && lcd_hs && timing_valid) begin     // HSYNC rising
            checks = checks + 1;
            if (hs_low != HSW) fail("HSYNC low width != 16");
        end

        // ---------------- VSYNC
        if (!lcd_vs) vs_low_clks = vs_low_clks + 1;
        if (vs_q && !lcd_vs) begin                     // VSYNC falling
            if (frame_valid) begin
                checks = checks + 2;
                if (line_cnt != V_TOTAL) fail("VSYNC period != 690 lines");
                if (de_lines != VACT)    fail("active lines != 640");
            end
            if (frame >= 0) frame_valid = 1'b1;
            frame       = frame + 1;
            line_cnt    = 0;
            vs_low_clks = 1;
            de_lines    = 0;
            act_line    = 0;
            first_de_line = -1;
            // mode schedule (applied by the DUT from the next frame on)
            if (frame == 2) mode = 2'd1;
            if (frame == 4) mode = 2'd2;
            if (frame == 6) mode = 2'd3;
            pix_check_frame = (frame % 2 == 1);
            ref_mode   = mode;
            ref_line   = 10'd0;
            ref_scroll = u_pat.scroll;   // updated by the DUT at frame_start, a few clocks earlier
            prev_ofs   = ref_ofs;
            ref_ofs    = u_pat.stripe_ofs;
            if (frame_valid) begin       // stripes must move by exactly one stripe per frame
                checks = checks + 1;
                if (ref_ofs !== prev_ofs + 3'd1) fail("stripe offset did not advance by 1");
            end
            if (frame == N_FRAMES) begin
                $display("SCOREBOARD: %0d checks (%0d pixel compares), %0d errors",
                         checks, pix_checks, errors);
                if (errors == 0 && pix_checks > 0 && !underrun)
                    $display("TEST PASSED");
                else
                    $display("TEST FAILED");
                $finish;
            end
        end
        if (!vs_q && lcd_vs && frame_valid) begin      // VSYNC rising
            checks = checks + 1;
            if (vs_low_clks != VSW * H_TOTAL) fail("VSYNC low width != 10 lines");
        end

        // ---------------- DE and pixels
        if (lcd_de) begin
            if (!de_q) begin                            // DE rising
                de_run = 0;
                if (first_de_line < 0) first_de_line = line_cnt;
                if (frame_valid) begin
                    checks = checks + 2;
                    if (clk_cnt != HSW + HBP) fail("DE start != 26 clocks after HSYNC");
                    if (line_cnt - first_de_line != act_line)
                        fail("active lines not contiguous");
                    if (act_line == 0 && line_cnt != VSW + VBP)
                        fail("first active line != 25 lines after VSYNC");
                end
            end
            de_run = de_run + 1;
            if (frame_valid && pix_check_frame) begin
                pix_checks = pix_checks + 1;
                if ({lcd_r, lcd_g, lcd_b} !== ref_color) begin
                    fail("pixel colour mismatch");
                    if (errors <= 20)
                        $display("        line %0d x %0d mode %0d got %h exp %h",
                                 act_line, de_run - 1, ref_mode,
                                 {lcd_r, lcd_g, lcd_b}, ref_color);
                end
            end
        end else begin
            if (frame_valid && {lcd_r, lcd_g, lcd_b} !== 18'd0) fail("RGB not 0 outside DE");
            if (de_q) begin                             // DE falling
                de_lines = de_lines + 1;
                act_line = act_line + 1;
                ref_line = act_line;                    // settles before next line
                if (frame_valid) begin
                    checks = checks + 1;
                    if (de_run != HACT) fail("DE width != 480");
                end
            end
        end

        if (underrun) fail("line buffer underrun");
        hs_q = lcd_hs;
        vs_q = lcd_vs;
        de_q = lcd_de;
    end

    // ------------------------------------------------------------ stimulus
    initial begin
        $display("tb_dpi666: start");
        repeat (20) @(posedge pclk);
        rst_n = 1'b1;
        // watchdog: (N_FRAMES + 2) frames
        repeat ((N_FRAMES + 2) * H_TOTAL * V_TOTAL) @(posedge pclk);
        $display("SCOREBOARD: %0d checks, %0d errors", checks, errors);
        $display("TEST FAILED (timeout)");
        $finish;
    end
endmodule
