@echo off
REM Resolve OEM reflibs only; do not simulate.
call "%~dp0run_sim.cmd" --lib-only %*
exit /b %ERRORLEVEL%
