@echo off
setlocal EnableDelayedExpansion
REM run_sim.cmd — Windows OEM Questa (Radiant/Propel bundled qrun.exe)
REM Default: --tool oem --oem_lib. Xcelium, VCS, standalone Questa, and
REM from-source CAE compile are not supported on Windows.
REM
REM Product root has questasim\win64\qrun.exe and cae_library\simulation\verilog.
REM No install-tree defaults: --radiant or RADIANT_ROOT / LATTICE_RADIANT /
REM LATTICE_RADIANT_BASE.

set "DEVICE=%DEVICE%"
set "CLI_RADIANT="
set "FILELIST=%FILELIST%"
if "!FILELIST!"=="" set "FILELIST=.\sim_rtl.f"
set "SIM_TOP=%SIM_TOP%"
set "TIMESCALE=%TIMESCALE%"
if "!TIMESCALE!"=="" set "TIMESCALE=1ns/1ps"
set "OEM_LIBS=1"
set "LIB_ONLY=0"
rem Stop after elaboration (qrun -elab). Windows is OEM Questa only, so there is
rem one branch here where the Linux script has three (R5.39).
set "ELAB_FLAG="
rem NAME=DIR pairs to vmap before qrun: -reflib binds modules, not the
rem logical name that +noacc+NAME.* needs (R5.44).
set "VMAP_SPECS="
if not defined CLEAN set "CLEAN=0"
set "SHOW_RADIANT=0"
set "GUI_DEBUG="
set "WAVE_ACC="
REM Debug option set is opt-in: it is +acc plus a debug database, and it cost
REM one batch run ~88s -> >10min. --wave alone is +acc without it (C-13).
set "OPTSET_DEBUG="
if /I "%DEBUGDB%"=="1" set "OPTSET_DEBUG=-optionset VOPTDEBUG"
REM Compilation unit for the design compile: macro (default; macros shared,
REM each file keeps its own `timescale), full (one unit, timebase shared too),
REM off (per-file). The CAE library compile is not affected (C-14).
if not defined MFCU set "MFCU=macro"
set "DEFINE_FLAGS="
set "SIM_TOOL=oem"

goto :parse

:usage
echo Usage: run_sim.cmd [--device NAME] [--radiant PATH]
echo                    [--filelist FILE] [--top NAME] [--timescale UNIT/PREC] [--define NAME]
echo                    [--oem_lib] [--lib-only] [--elab-only] [--clean] [--gui] [--wave] [--debugdb]
echo                    [--mfcu macro^|full^|off]
echo                    [--list] [--show-radiant]
echo.
echo Windows is Radiant OEM Questa only (questasim\win64\qrun.exe^).
echo Default libraries: --oem_lib (pmi_work + ovi_* under cae_library\simulation\libs^).
echo --src, --tool full/xcelium/vcs are Linux-only (bash run_sim^).
exit /b 0

:list_devices
echo lfcpnx (jedid1^)     lfcpnx-rcs
echo lifcl (jedi^)        lfd2nx lfd2nx1 lfd2nx2
echo lfmxo5 lfmxo5t lfmxo5t1
echo lfmxo4 lfmxo4d
echo ut24c ut24cp        jd5r00
echo iCE40UP (ice40^)
echo ap6a00b (apollo^)    ap6a00c (apollo_c^)    kr6a00
exit /b 0

:parse
if "%~1"=="" goto :parsed
if /I "%~1"=="-h" goto :usage
if /I "%~1"=="--help" goto :usage
if /I "%~1"=="--list" goto :list_devices
if /I "%~1"=="--device" goto :arg_device
if /I "%~1"=="--radiant" goto :arg_radiant
if /I "%~1"=="--filelist" goto :arg_filelist
if /I "%~1"=="-f" goto :arg_filelist
if /I "%~1"=="--top" goto :arg_top
if /I "%~1"=="--define" goto :arg_define
if /I "%~1"=="--oem_lib" goto :arg_oem_lib
if /I "%~1"=="--oem-lib" goto :arg_oem_lib
if /I "%~1"=="--oem-libs" goto :arg_oem_lib
if /I "%~1"=="--ovi" goto :arg_oem_lib
if /I "%~1"=="--src" goto :err_src
if /I "%~1"=="--from-source" goto :err_src
if /I "%~1"=="--from_source" goto :err_src
if /I "%~1"=="--tool" goto :arg_tool
if /I "%~1"=="--questa" goto :err_linux_only
if /I "%~1"=="--xcelium" goto :err_linux_only
if /I "%~1"=="--vcs" goto :err_linux_only
if /I "%~1"=="--lib-only" (set "LIB_ONLY=1" & shift & goto :parse)
if /I "%~1"=="--elab-only" (set "ELAB_FLAG=-elab elab_only.snapshot" & shift & goto :parse)
if /I "%~1"=="--vmap" (set "VMAP_SPECS=!VMAP_SPECS! %~2" & shift & shift & goto :parse)
if /I "%~1"=="--clean" (set "CLEAN=1" & shift & goto :parse)
if /I "%~1"=="--gui" (set "GUI_DEBUG=-gui" & shift & goto :parse)
if /I "%~1"=="--wave" (set "WAVE_ACC=+acc" & shift & goto :parse)
if /I "%~1"=="--debugdb" (set "OPTSET_DEBUG=-optionset VOPTDEBUG" & shift & goto :parse)
if /I "%~1"=="--mfcu" (set "MFCU=%~2" & shift & shift & goto :parse)
if /I "%~1"=="--show-radiant" (set "SHOW_RADIANT=1" & shift & goto :parse)
if /I "%~1"=="--force-lib" (shift & goto :parse)
if /I "%~1"=="--timescale" goto :arg_timescale
if /I "%~1"=="--radiant-version" goto :err_linux_only
echo unknown arg: %~1 >&2
call :usage
exit /b 1

:arg_device
if "%~2"=="" (echo --device requires a value. See --help. >&2 & exit /b 1)
set "DEVICE=%~2"
shift & shift & goto :parse

:arg_radiant
if "%~2"=="" (echo --radiant requires a value. See --help. >&2 & exit /b 1)
set "CLI_RADIANT=%~2"
shift & shift & goto :parse

:arg_filelist
if "%~2"=="" (echo --filelist requires a value. See --help. >&2 & exit /b 1)
set "FILELIST=%~2"
shift & shift & goto :parse

:arg_top
if "%~2"=="" (echo --top requires a value. See --help. >&2 & exit /b 1)
set "SIM_TOP=%~2"
shift & shift & goto :parse

:arg_timescale
if "%~2"=="" (echo --timescale requires UNIT/PREC (e.g. 1ns/1ps^). See --help. >&2 & exit /b 1)
set "TIMESCALE=%~2"
shift & shift & goto :parse

:arg_define
if "%~2"=="" (echo --define requires a value. See --help. >&2 & exit /b 1)
set "DEFINE_FLAGS=!DEFINE_FLAGS! +define+%~2"
shift & shift & goto :parse

:arg_oem_lib
set "OEM_LIBS=1"
shift & goto :parse

:arg_tool
if "%~2"=="" (echo --tool requires oem. See --help. >&2 & exit /b 1)
if /I not "%~2"=="oem" if /I not "%~2"=="lattice" goto :err_linux_only
set "SIM_TOOL=oem"
shift & shift & goto :parse

:err_src
echo Windows uses Radiant precompiled OEM libs (--oem_lib^). --src is Linux-only. >&2
exit /b 1

:err_linux_only
echo Windows supports Radiant OEM Questa only (--tool oem --oem_lib^). >&2
echo Xcelium, VCS, and standalone Questa are not supported on Windows. >&2
exit /b 1

:parsed
if "!DEVICE!"=="" (
    echo --device is required (or set DEVICE^). See --list. >&2
    exit /b 1
)
if /I "%GUI%"=="1" set "GUI_DEBUG=-gui"
if /I "%WAVE%"=="1" set "WAVE_ACC=+acc"
if /I "%DEBUGDB%"=="1" set "OPTSET_DEBUG=-optionset VOPTDEBUG"
set "MFCU_FLAG="
if /I "%MFCU%"=="macro" (
    set "MFCU_FLAG=-mfcu=macro"
) else if /I "%MFCU%"=="full" (
    set "MFCU_FLAG=-mfcu"
) else if /I "%MFCU%"=="off" (
    set "MFCU_FLAG="
) else (
    echo run_sim.cmd: --mfcu expects macro, full or off ^(got "%MFCU%"^)>&2
    exit /b 2
)
rem Drop qrun's incremental library only; compiled device libs are kept.
if /I "!CLEAN!"=="1" (
    echo Clean: removing qrun.out and .run_sim_f
    if exist qrun.out rmdir /s /q qrun.out
    if exist .run_sim_f rmdir /s /q .run_sim_f
)

call :canon_device "!DEVICE!" || exit /b 1
call :find_radiant || exit /b 1

set "QRUN="
if exist "!RADIANT_ROOT!\questasim\win64\qrun.exe" set "QRUN=!RADIANT_ROOT!\questasim\win64\qrun.exe"
if "!QRUN!"=="" if exist "!RADIANT_ROOT!\questasim\win64\qrun" set "QRUN=!RADIANT_ROOT!\questasim\win64\qrun"
if "!QRUN!"=="" (
    echo No OEM qrun.exe under !RADIANT_ROOT!\questasim\win64\ >&2
    exit /b 1
)

echo Radiant: !RADIANT_ROOT!
echo Sim:     oem  !QRUN!
echo Libs:    OEM precompiled pmi_work + ovi_*  (!RADIANT_ROOT!\cae_library\simulation\libs^)
if "!SHOW_RADIANT!"=="1" exit /b 0

set "FOUNDRY=!RADIANT_ROOT!\ispfpga"
set "PATH=!RADIANT_ROOT!\questasim\win64;!PATH!"

set "LIBS_DIR=!RADIANT_ROOT!\cae_library\simulation\libs"
set "LIB_PMI=!LIBS_DIR!\pmi_work"
call :ovi_lib_dir "!DEVICE_CANON!"
set "LIB_DEV=!LIBS_DIR!\!OVI!"
if "!OVI!"=="" goto :err_ovi
if not exist "!LIB_DEV!\" goto :err_ovi
if not exist "!LIB_PMI!\" (
    echo Missing !LIB_PMI! >&2
    exit /b 1
)
echo Reflib:  !LIB_PMI!
echo Reflib:  !LIB_DEV!
if "!LIB_ONLY!"=="1" exit /b 0

if not exist "!FILELIST!" (
    echo filelist not found: !FILELIST! >&2
    exit /b 1
)
if "!SIM_TOP!"=="" (
    for /f "tokens=2" %%A in ('findstr /R /C:"^[ ]*-top " "!FILELIST!"') do set "SIM_TOP=%%A"
)
if "!SIM_TOP!"=="" (
    echo --top is required (or set SIM_TOP, or put -top in the filelist^). >&2
    exit /b 1
)
if not exist .run_sim_f mkdir .run_sim_f
findstr /V /R /C:"^[ ]*-top " "!FILELIST!" > ".run_sim_f\filelist.f"
set "FILELIST=.run_sim_f\filelist.f"
echo Filelist: !FILELIST!
echo Top:      !SIM_TOP!
echo Timescale: !TIMESCALE!

rem vopt needs the mapping at optimize time, so this runs before qrun.
for %%V in (!VMAP_SPECS!) do (
    for /f "tokens=1,* delims==" %%A in ("%%V") do (
        echo vmap %%A -^> %%B
        "!RADIANT_ROOT!\questasim\win64\vmap.exe" %%A "%%B" || exit /b 1
    )
)

"!QRUN!" !MFCU_FLAG! -sv -L work !WAVE_ACC! +libext+.v+.sv !DEFINE_FLAGS! -l sim.log -reflib "!LIB_PMI!" -reflib "!LIB_DEV!" !OPTSET_DEBUG! -vlog.options -timescale !TIMESCALE! -end -vopt.options -suppress vopt-7033,vopt-14436 -end !GUI_DEBUG! -vsim.options -suppress vsim-7033,vsim-8630,3009,3389,vsim-16213 -end !ELAB_FLAG! -top !SIM_TOP! -f "!FILELIST!"
exit /b !ERRORLEVEL!

:err_ovi
echo No OEM ovi lib for DEVICE=!DEVICE_CANON! under !LIBS_DIR! >&2
echo Available: >&2
dir /b "!LIBS_DIR!" 2>nul
exit /b 1

:find_radiant
if not "!CLI_RADIANT!"=="" set "RADIANT_ROOT=!CLI_RADIANT!"
if "!RADIANT_ROOT!"=="" if defined LATTICE_RADIANT set "RADIANT_ROOT=!LATTICE_RADIANT!"
if "!RADIANT_ROOT!"=="" if defined LATTICE_RADIANT_BASE set "RADIANT_ROOT=!LATTICE_RADIANT_BASE!"
if "!RADIANT_ROOT!"=="" (
    echo No Radiant install found. Set --radiant, RADIANT_ROOT, LATTICE_RADIANT, or LATTICE_RADIANT_BASE. >&2
    exit /b 1
)
if not exist "!RADIANT_ROOT!\cae_library\simulation\verilog\" (
    echo Radiant is not a product root: !RADIANT_ROOT! >&2
    echo Expected questasim\win64\qrun.exe and cae_library\simulation\verilog >&2
    exit /b 1
)
if exist "!RADIANT_ROOT!\questasim\win64\qrun.exe" exit /b 0
if exist "!RADIANT_ROOT!\questasim\win64\qrun" exit /b 0
echo Radiant is not a product root: !RADIANT_ROOT! >&2
echo Expected questasim\win64\qrun.exe and cae_library\simulation\verilog >&2
exit /b 1

:canon_device
set "DEVICE_CANON="
if /I "%~1"=="lfcpnx" set "DEVICE_CANON=lfcpnx"
if /I "%~1"=="jedid1" set "DEVICE_CANON=lfcpnx"
if /I "%~1"=="lfcpnx-rcs" set "DEVICE_CANON=lfcpnx-rcs"
if /I "%~1"=="lifcl" set "DEVICE_CANON=lifcl"
if /I "%~1"=="jedi" set "DEVICE_CANON=lifcl"
if /I "%~1"=="lfd2nx" set "DEVICE_CANON=lfd2nx"
if /I "%~1"=="lfd2nx1" set "DEVICE_CANON=lfd2nx1"
if /I "%~1"=="lfd2nx2" set "DEVICE_CANON=lfd2nx2"
if /I "%~1"=="lfmxo5" set "DEVICE_CANON=lfmxo5"
if /I "%~1"=="machxo5" set "DEVICE_CANON=lfmxo5"
if /I "%~1"=="lfmxo5t" set "DEVICE_CANON=lfmxo5t"
if /I "%~1"=="machxo5t" set "DEVICE_CANON=lfmxo5t"
if /I "%~1"=="lfmxo5t1" set "DEVICE_CANON=lfmxo5t1"
if /I "%~1"=="machxo5t1" set "DEVICE_CANON=lfmxo5t1"
if /I "%~1"=="ut24c" set "DEVICE_CANON=ut24c"
if /I "%~1"=="ut24cp" set "DEVICE_CANON=ut24cp"
if /I "%~1"=="jd5r00" set "DEVICE_CANON=jd5r00"
if /I "%~1"=="lfmxo4" set "DEVICE_CANON=lfmxo4"
if /I "%~1"=="machxo4" set "DEVICE_CANON=lfmxo4"
if /I "%~1"=="lfmxo4d" set "DEVICE_CANON=lfmxo4d"
if /I "%~1"=="machxo4d" set "DEVICE_CANON=lfmxo4d"
if /I "%~1"=="iCE40UP" set "DEVICE_CANON=iCE40UP"
if /I "%~1"=="ice40" set "DEVICE_CANON=iCE40UP"
if /I "%~1"=="ICE40" set "DEVICE_CANON=iCE40UP"
if /I "%~1"=="ap6a00b" set "DEVICE_CANON=ap6a00b"
if /I "%~1"=="apollo" set "DEVICE_CANON=ap6a00b"
if /I "%~1"=="ap6a00c" set "DEVICE_CANON=ap6a00c"
if /I "%~1"=="apollo_c" set "DEVICE_CANON=ap6a00c"
if /I "%~1"=="kr6a00" set "DEVICE_CANON=kr6a00"
if "!DEVICE_CANON!"=="" (
    echo unknown DEVICE='%~1' (try --list^) >&2
    exit /b 1
)
exit /b 0

:ovi_lib_dir
set "OVI="
if /I "%~1"=="lfcpnx" set "OVI=lfcpnx"
if /I "%~1"=="lfcpnx-rcs" set "OVI=lfcpnx"
if /I "%~1"=="ut24cp" set "OVI=lfcpnx"
if /I "%~1"=="lifcl" set "OVI=lifcl"
if /I "%~1"=="lfd2nx" set "OVI=lifcl"
if /I "%~1"=="ut24c" set "OVI=lifcl"
if /I "%~1"=="lfd2nx1" set "OVI=lfmxo5"
if /I "%~1"=="lfmxo5" set "OVI=lfmxo5"
if /I "%~1"=="lfd2nx2" set "OVI=lfmxo5t1"
if /I "%~1"=="lfmxo5t1" set "OVI=lfmxo5t1"
if /I "%~1"=="lfmxo5t" set "OVI=lfmxo5t"
if /I "%~1"=="lfmxo4" set "OVI=lfmxo4"
if /I "%~1"=="lfmxo4d" set "OVI=lfmxo4d"
if /I "%~1"=="iCE40UP" set "OVI=iCE40UP"
if /I "%~1"=="ap6a00b" set "OVI=ovi_ap6a00b"
if /I "%~1"=="ap6a00c" set "OVI=ovi_ap6a00c"
if /I "%~1"=="kr6a00" set "OVI=ovi_kr6a00"
exit /b 0
