if {[catch {

# define run engine funtion
source [file join {C:/lscc/radiant/2026.1.1} scripts tcl flow run_engine.tcl]
# define global variables
global para
set para(gui_mode) "0"
set para(prj_dir) "C:/lscc/workspace/MachXO4C_28RPI"
if {![file exists {C:/lscc/workspace/MachXO4C_28RPI/impl_1}]} {
  file mkdir {C:/lscc/workspace/MachXO4C_28RPI/impl_1}
}
cd {C:/lscc/workspace/MachXO4C_28RPI/impl_1}
# synthesize IPs
# synthesize VMs
# propgate constraints
file delete -force -- MachXO4C_28RPI_impl_1_cpe.ldc
::radiant::runengine::run_engine_newmsg cpe -syn synpro -f "MachXO4C_28RPI_impl_1.cprj" "pll_pix.cprj" -a "LFMXO4"  -o MachXO4C_28RPI_impl_1_cpe.ldc
# synthesize top design
file delete -force -- MachXO4C_28RPI_impl_1.vm MachXO4C_28RPI_impl_1.ldc
if {[file normalize "C:/lscc/workspace/MachXO4C_28RPI/impl_1/MachXO4C_28RPI_impl_1_synplify.tcl"] != [file normalize "./MachXO4C_28RPI_impl_1_synplify.tcl"]} {
  file copy -force "C:/lscc/workspace/MachXO4C_28RPI/impl_1/MachXO4C_28RPI_impl_1_synplify.tcl" "./MachXO4C_28RPI_impl_1_synplify.tcl"
}
if {[ catch {::radiant::runengine::run_engine synpwrap -prj "MachXO4C_28RPI_impl_1_synplify.tcl" -log "MachXO4C_28RPI_impl_1.srf"} result options ]} {
    file delete -force -- MachXO4C_28RPI_impl_1.vm MachXO4C_28RPI_impl_1.ldc
    return -options $options $result
}
::radiant::runengine::run_postsyn [list -a LFMXO4 -p LFMXO4-110HC -t BBG256 -sp 6 -oc Industrial -top -w -o MachXO4C_28RPI_impl_1_syn.udb MachXO4C_28RPI_impl_1.vm] [list MachXO4C_28RPI_impl_1.ldc]

} out]} {
   ::radiant::runengine::runtime_log $out
   exit 1
}
