`timescale 100 ps/100 ps
module EHXPLLJ (
  CLKI,
  CLKFB,
  PHASESEL1,
  PHASESEL0,
  PHASEDIR,
  PHASESTEP,
  LOADREG,
  STDBY,
  PLLWAKESYNC,
  RST,
  RESETM,
  RESETC,
  RESETD,
  ENCLKOP,
  ENCLKOS,
  ENCLKOS2,
  ENCLKOS3,
  PLLCLK,
  PLLRST,
  PLLSTB,
  PLLWE,
  PLLDATI7,
  PLLDATI6,
  PLLDATI5,
  PLLDATI4,
  PLLDATI3,
  PLLDATI2,
  PLLDATI1,
  PLLDATI0,
  PLLADDR4,
  PLLADDR3,
  PLLADDR2,
  PLLADDR1,
  PLLADDR0,
  CLKOP,
  CLKOS,
  CLKOS2,
  CLKOS3,
  LOCK,
  INTLOCK,
  REFCLK,
  PLLDATO7,
  PLLDATO6,
  PLLDATO5,
  PLLDATO4,
  PLLDATO3,
  PLLDATO2,
  PLLDATO1,
  PLLDATO0,
  PLLACK,
  DPHSRC,
  CLKINTFB
)
;
input CLKI ;
input CLKFB ;
input PHASESEL1 ;
input PHASESEL0 ;
input PHASEDIR ;
input PHASESTEP ;
input LOADREG ;
input STDBY ;
input PLLWAKESYNC ;
input RST ;
input RESETM ;
input RESETC ;
input RESETD ;
input ENCLKOP ;
input ENCLKOS ;
input ENCLKOS2 ;
input ENCLKOS3 ;
input PLLCLK ;
input PLLRST ;
input PLLSTB ;
input PLLWE ;
input PLLDATI7 ;
input PLLDATI6 ;
input PLLDATI5 ;
input PLLDATI4 ;
input PLLDATI3 ;
input PLLDATI2 ;
input PLLDATI1 ;
input PLLDATI0 ;
input PLLADDR4 ;
input PLLADDR3 ;
input PLLADDR2 ;
input PLLADDR1 ;
input PLLADDR0 ;
output CLKOP ;
output CLKOS ;
output CLKOS2 ;
output CLKOS3 ;
output LOCK ;
output INTLOCK ;
output REFCLK ;
output PLLDATO7 ;
output PLLDATO6 ;
output PLLDATO5 ;
output PLLDATO4 ;
output PLLDATO3 ;
output PLLDATO2 ;
output PLLDATO1 ;
output PLLDATO0 ;
output PLLACK ;
output DPHSRC ;
output CLKINTFB ;
endmodule /* EHXPLLJ */

module ODDRXE (
  D0,
  D1,
  SCLK,
  RST,
  Q
)
;
input D0 ;
input D1 ;
input SCLK ;
input RST ;
output Q ;
endmodule /* ODDRXE */

