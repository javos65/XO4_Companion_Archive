run_tcl -fg MachXO4C_28RPI_impl_1_synplify.tcl
