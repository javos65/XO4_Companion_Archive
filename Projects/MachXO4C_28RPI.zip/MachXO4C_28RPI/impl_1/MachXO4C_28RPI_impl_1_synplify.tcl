#-- Lattice Semiconductor Corporation Ltd.
#-- Synplify OEM project file

#device options
set_option -technology MachXO4
set_option -part LFMXO4_110HC
set_option -package BBG256I
set_option -speed_grade -6
#compilation/mapping options
set_option -symbolic_fsm_compiler true
set_option -resource_sharing true

#use verilog standard option
set_option -vlog_std v2001

#map options
set_option -frequency 200
set_option -maxfan 1000
set_option -auto_constrain_io 0
set_option -retiming false; set_option -pipe true
set_option -force_gsr false
set_option -compiler_compatible 0


set_option -default_enum_encoding default

#timing analysis options



#automatic place and route (vendor) options
set_option -write_apr_constraint 1

#synplifyPro options

set_option -syn_reduce_controlset_size 0
set_option -stop_shift_reset_merging 0
set_option -fix_gated_and_generated_clocks 0
set_option -update_models_cp 0
set_option -resolve_multiple_driver 0


set_option -rw_check_on_ram 0



#-- set any command lines input by customer

set_option -dup false
set_option -disable_io_insertion false
add_file -constraint {C:/lscc/radiant/2026.1.1/scripts/tcl/flow/radiant_synplify_vars.tcl}
add_file -constraint {MachXO4C_28RPI_impl_1_cpe.ldc}
add_file -verilog {C:/lscc/radiant/2026.1.1/ip/pmi/pmi_lfmxo4.v}
add_file -vhdl -lib pmi {C:/lscc/radiant/2026.1.1/ip/pmi/pmi_lfmxo4.vhd}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_28RPI/rtl/top_28rpi.v}
add_file -verilog -vlog_std sysv {C:/lscc/workspace/MachXO4C_28RPI/ip/pll_pix/rtl/pll_pix.sv}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_28RPI/rtl/dpi666_axis/dpi666_timing.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_28RPI/rtl/dpi666_axis/dpi666_axis_buf.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_28RPI/rtl/dpi666_axis/dpi666_axis.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_28RPI/rtl/lcd_test/lcd_logo_seq.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_28RPI/rtl/lcd_test/lcd_test.v}
#-- top module name
set_option -top_module top_28rpi
set_option -include_path {C:/lscc/workspace/MachXO4C_28RPI}
set_option -include_path {C:/lscc/workspace/MachXO4C_28RPI}
set_option -include_path {C:/lscc/workspace/MachXO4C_28RPI/ip/pll_pix}

#-- set result format/file last
project -result_format "vm"
project -result_file "./MachXO4C_28RPI_impl_1.vm"

#-- error message log file
project -log_file {MachXO4C_28RPI_impl_1.srf}

project -run -clean
