# Packages DPI666_AXIS 1.0.0 (LCD driver only) with the IP Packager engine on the command line.
# RTL is taken directly from rtl\dpi666_axis (the sources the project builds), so the package
# cannot drift from the verified design. The test sequencer (rtl\lcd_block_seq.v) is NOT packaged.
# Output: custom_module_dpi666_axis_1.0.0.ipk in this folder, plus ippkg_out.txt / ippkg_err.txt.
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$blk  = (Resolve-Path (Join-Path $here '..\custom_module_dpi666_axis_1.0.0')).Path
$src  = (Resolve-Path (Join-Path $here '..\..\rtl\dpi666_axis')).Path
$env:FOUNDRY = 'C:\lscc\propel\2026.1.1\builder\rtf\ispfpga'
$pkg  = "$env:FOUNDRY\bin\nt64\ippkg.exe"
$meta = @("$blk\metadata.xml", "$blk\bus_interface.xml")
$rtl  = @('dpi666_axis.v', 'dpi666_axis_buf.v', 'dpi666_timing.v') | % { "$src\$_" }
$out  = "$here\custom_module_dpi666_axis_1.0.0.ipk"
if (Test-Path $out) { Remove-Item $out }
$enc = New-Object Text.UTF8Encoding($false)
[IO.File]::WriteAllLines("$here\metadata_list.txt", [string[]]$meta, $enc)
[IO.File]::WriteAllLines("$here\rtl_list.txt",      [string[]]$rtl,  $enc)
& $pkg -metadata_files "$here\metadata_list.txt" -rtl_files "$here\rtl_list.txt" `
    -help_file "$blk\doc\introduction.html" -o $out `
    1> "$here\ippkg_out.txt" 2> "$here\ippkg_err.txt"
"exit=$LASTEXITCODE"
Get-Content "$here\ippkg_out.txt","$here\ippkg_err.txt"
if (Test-Path $out) {
    Add-Type -A System.IO.Compression.FileSystem
    $z = [IO.Compression.ZipFile]::OpenRead($out); $z.Entries | % { "{0,8}  {1}" -f $_.Length, $_.FullName }; $z.Dispose()
}
