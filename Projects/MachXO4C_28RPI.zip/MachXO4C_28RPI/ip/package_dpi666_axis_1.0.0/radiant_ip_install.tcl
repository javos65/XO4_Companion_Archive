# Auto-generated Radiant IP install script
# IPs land in RadiantIPLocal (user-configurable via the DiamondNG
# .setting.ini [IP_Tool] local_install key), NOT in the bundled ip/ tree.

ip_catalog_install -file {C:\lscc\workspace\MachXO4C_28RPI\ip\package_dpi666_axis_1.0.0\custom_module_dpi666_axis_1.0.0.ipk}

exit