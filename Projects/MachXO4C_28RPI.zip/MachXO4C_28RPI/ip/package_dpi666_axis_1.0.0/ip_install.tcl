# Auto-generated IP install script
# IPs are installed into PropelIPLocal (user-configurable),
# NOT into rtf/ip/ (the built-in Propel IP directory).
#
# Every install is caught and its outcome printed, so one bad reference
# cannot cancel the ones after it and the result can say which is which.

if {[catch {ip_catalog_install -file {C:\lscc\workspace\MachXO4C_28RPI\ip\package_dpi666_axis_1.0.0\custom_module_dpi666_axis_1.0.0.ipk}} msg]} {
    puts "LATTICE_MCP_IP_FAIL file {C:\lscc\workspace\MachXO4C_28RPI\ip\package_dpi666_axis_1.0.0\custom_module_dpi666_axis_1.0.0.ipk}"
    puts $msg
    puts "LATTICE_MCP_IP_END"
} else {
    puts "LATTICE_MCP_IP_OK file {C:\lscc\workspace\MachXO4C_28RPI\ip\package_dpi666_axis_1.0.0\custom_module_dpi666_axis_1.0.0.ipk}"
}

exit