    pll_pix __(.clki_i( ),
        .clkop_o( ),
        .lock_o( ));
