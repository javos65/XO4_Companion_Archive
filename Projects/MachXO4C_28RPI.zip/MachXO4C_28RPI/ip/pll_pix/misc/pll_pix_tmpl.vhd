component pll_pix is
    port(
        clki_i: in std_logic;
        clkop_o: out std_logic;
        lock_o: out std_logic
    );
end component;

__: pll_pix port map(
    clki_i=>,
    clkop_o=>,
    lock_o=>
);
