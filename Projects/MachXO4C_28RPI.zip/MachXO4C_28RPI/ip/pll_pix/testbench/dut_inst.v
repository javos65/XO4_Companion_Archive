    pll_pix u_pll_pix(.clki_i(clki_i),
        .clkop_o(clkop_o),
        .lock_o(lock_o));
