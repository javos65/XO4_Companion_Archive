`ifndef __TESTBENCH__TB_TOP__
`define __TESTBENCH__TB_TOP__
`timescale 1ps/100fs


//==========================================================================
// Module : top_tb
// Description: Top level module for testbench
//==========================================================================
module tb_top ();

    //--------------------------------------------------------------------------
    //--- Local Parameters and pre-process  ---
    //--------------------------------------------------------------------------
    `include "dut_params.v" // This contain user defined parameters

    // Convert string to real without using system tasks (for elaboration-time evaluation)
    function automatic real str_to_real(input string str);
        real result;
        real fraction;
        int i;
        int len;
        int decimal_pos;
        int frac_digits;
        byte ch;
        real sign;
        int int_part;
        
        result = 0.0;
        fraction = 0.0;
        sign = 1.0;
        decimal_pos = -1;
        len = str.len();
        int_part = 0;
        frac_digits = 0;
        
        // Handle empty string
        if (len == 0) return 0.0;
        
        // Check for sign
        i = 0;
        if (str[0] == "-") begin
            sign = -1.0;
            i = 1;
        end else if (str[0] == "+") begin
            i = 1;
        end
        
        // Find decimal point position
        for (int j = i; j < len; j++) begin
            if (str[j] == ".") begin
                decimal_pos = j;
                break;
            end
        end
        
        // Parse integer part
        if (decimal_pos == -1) decimal_pos = len;
        for (int j = i; j < decimal_pos; j++) begin
            ch = str[j];
            if (ch >= "0" && ch <= "9") begin
                int_part = int_part * 10 + (ch - "0");
            end
        end
        result = int_part;
        
        // Parse fractional part
        if (decimal_pos < len - 1) begin
            frac_digits = 0;
            for (int j = decimal_pos + 1; j < len; j++) begin
                ch = str[j];
                if (ch >= "0" && ch <= "9") begin
                    fraction = fraction * 10.0 + (ch - "0");
                    frac_digits++;
                end
            end
            // Divide by 10^frac_digits
            for (int j = 0; j < frac_digits; j++) begin
                fraction = fraction / 10.0;
            end
            result = result + fraction;
        end
        
        return sign * result;
    endfunction

    // Reference clock period for input clock generation
    localparam TB_REFCLK_PERIOD = 1000000/FIN; // Change to ps, follow the timescale time unit
    
    // Get the VCO frequency
    localparam TB_FBK_OUT_FREQ  = FIN * (CLKFB_DIV + (FRACN_DIV / 65_536)) / CLKI_DIV;
    localparam TB_FBK_OUT_DIV   =   (FEEDBK_PATH == "CLKOS3" || FEEDBK_PATH == "CLKOS3_INT") ? CLKOS3_DIV :
                                    (FEEDBK_PATH == "CLKOS2" || FEEDBK_PATH == "CLKOS2_INT") ? CLKOS2_DIV :
                                    (FEEDBK_PATH == "CLKOS" || FEEDBK_PATH == "CLKOS_INT") ? CLKOS_DIV :
                                    CLKOP_DIV;
    localparam TB_VCO_FREQ      = TB_FBK_OUT_FREQ * TB_FBK_OUT_DIV;

    // Get the output frequency - Parse from string parameters provided by GUI
    localparam  TB_CLKOP_FREQ      = str_to_real(CLKOP_FREQ_STR);
    localparam  TB_CLKOS_FREQ      = str_to_real(CLKOS_FREQ_STR);
    localparam  TB_CLKOS2_FREQ     = str_to_real(CLKOS2_FREQ_STR);
    localparam  TB_CLKOS3_FREQ     = str_to_real(CLKOS3_FREQ_STR);

    // To get back the GUI static phase shift setting
    localparam TB_CLKOP_PHASE_SHIFT = ((CLKOP_CPHASE - CLKOP_DIV + 1) * 360) / CLKOP_DIV;
    localparam TB_CLKOS_PHASE_SHIFT = ((CLKOS_CPHASE - CLKOS_DIV + 1) * 360) / CLKOS_DIV;
    localparam TB_CLKOS2_PHASE_SHIFT = ((CLKOS2_CPHASE - CLKOS2_DIV + 1) * 360) / CLKOS2_DIV;
    localparam TB_CLKOS3_PHASE_SHIFT = ((CLKOS3_CPHASE - CLKOS3_DIV + 1) * 360) / CLKOS3_DIV;

    // Use to prevent "hung" when lock fail
    localparam  LOCK_TIMEOUT_CNT    = 100000;
    localparam  CONTROL_SIG_TOOGLE  = 50_000;

    //--------------------------------------------------------------------------
    //--- DUT instantiation and connection---
    //--------------------------------------------------------------------------
    // Wire and reg declarations for DUT connectivity
    reg clki_i, clki2_i;
    reg sel_i;
    wire clkfb_i;
    wire clkop_o, clkos_o, clkos2_o, clkos3_o;
    reg enclkop_i, enclkos_i, enclkos2_i, enclkos3_i;
    reg rst_i, resetm_i, resetc_i, resetd_i;
    reg stdby_i;
    wire lock_o;
    reg [1:0] phasesel_i;
    reg phasedir_i, phasestep_i;
    wire dphsrc_o;

    reg pllclk_i, pllrst_i, pllstb_i, pllwe_i;
    reg [7:0] plldati_i;
    reg [4:0] plladdr_i;
    wire [7:0] plldato_o;
    wire pllack_o;

    // Include DUT
     `include "dut_inst.v"

    //--------------------------------------------------------------------------
    //--- GSR Reset handling ---
    //--------------------------------------------------------------------------
    reg tb_gsr_clk;
    reg tb_rst_n;
    initial begin
        tb_gsr_clk = 0;
        forever tb_gsr_clk = #5000 ~tb_gsr_clk;
    end

    // GSR GSR_INST (.GSR_N(tb_rst_n), .CLK(tb_gsr_clk));
    GSRB GSRB_INST (.GSR(tb_rst_n));

    //--------------------------------------------------------------------------
    //--- Testbench wire and reg ---
    //--------------------------------------------------------------------------
    // @todo - port over all necessary checker and flag on bellow
    reg     [31:0]  tb_lock_timer;
    reg             tb_exp_lock;
    wire            tb_test_done;

    wire    [3:0]   tb_clk_error_detected;
    wire    [3:0]   tb_clk_test_done;
    wire    [3:0]   tb_clk_toggle_detected;

    wire            tb_pll_lock;
    wire            tb_refclk;


    //--------------------------------------------------------------------------
    //--- Testbench signal generation and handling ---
    //--------------------------------------------------------------------------

    // ----
    // Initialization
    initial begin
        // Initialize all DUT input
        clki_i = 0;
        clki2_i = 0;
        sel_i = 0;
        enclkop_i = 0;
        enclkos_i = 0;
        enclkos2_i = 0;
        enclkos3_i = 0;
        rst_i = 0;
        resetm_i = 0;
        resetc_i = 0;
        resetd_i = 0;
        stdby_i = 0;
        phasesel_i = 0;
        phasedir_i = 0;
        phasestep_i = 0;
        pllclk_i = 0;
        pllrst_i = 0;
        pllstb_i = 0;
        pllwe_i = 0;
        plldati_i = 0;
        plladdr_i = 0;

        // Initialize lock check timer
        tb_lock_timer      = 0;

        // To mimic lock signal when design doesn't enable the PLL lock signal
        tb_exp_lock        = 1'b0;
        #(1000*1000*100);  // delay 100us
        tb_exp_lock        = 1'b1;
    end

    // --- feedback path handle ---
    assign clkfb_i = (FEEDBK_PATH == "USERCLOCK")? clkop_o : 1'b0;

    // ----
    // DUT reference clock generator and selector handling
    initial begin
        forever clki_i = #(TB_REFCLK_PERIOD/2) ~clki_i;
    end

    // @todo - to handle the refclk switch scenario
    // if (REFCLK_SELECT == "ENABLED") begin
    //     assign tb_refclk = sel_i? clki2_i : clki_i;

    //     initial begin
    //         forever clki2_i = #(TB_REFCLK_PERIOD/2/2) ~clki2_i; // to make clk2 different, which inject faster speed
    //     end

    //     initial begin
    //         // wait till clk_test_done complete

    //     end
    // end
    // else begin
        assign tb_refclk = clki_i;
    // end

    // ----
    // Reset generator
    initial begin
        tb_rst_n    = 0;
        #300000
        $display(" ---------------------------------------------- ");
        $display("\tINFO: RESET DONE: --" );
        $display(" ---------------------------------------------- ");
        tb_rst_n    = 1;
    end

    // ----
    // Batch Output enable and clear handling
    always @* begin
        if(tb_rst_n) begin
            @(posedge tb_gsr_clk);
            enclkop_i   <= 1;
            enclkos_i   <= 1;
            enclkos2_i  <= 1;
            enclkos3_i  <= 1;
            
            // Ensure basic simulation run completed
            wait(tb_test_done);
            repeat (60) @(posedge tb_gsr_clk);

            // Show case enable ports
            enclkop_i       <= 0;
            #CONTROL_SIG_TOOGLE
            enclkop_i       <= 1;
            #CONTROL_SIG_TOOGLE
            enclkos_i       <= 0;
            #CONTROL_SIG_TOOGLE
            enclkos_i       <= 1;
            #CONTROL_SIG_TOOGLE
            enclkos2_i       <= 0;
            #CONTROL_SIG_TOOGLE
            enclkos2_i       <= 1;
            #CONTROL_SIG_TOOGLE
            enclkos3_i       <= 0;
            #CONTROL_SIG_TOOGLE
            enclkos3_i       <= 1;
        end
        else begin
            @(posedge tb_gsr_clk);
            enclkop_i   <= 0;
            enclkos_i   <= 0;
            enclkos2_i  <= 0;
            enclkos3_i  <= 0;
            rst_i       <= 0;
            resetm_i    <= 0;
            resetc_i    <= 0;
            resetd_i    <= 0;
            pllrst_i    <= 0;
        end
    end

    // ----
    // Counter operation for lock timer, which use to prevent simulation "hung" if PLL fail to lock
    always @* begin
        if(tb_rst_n) begin
            if(tb_pll_lock) begin
                @(posedge tb_gsr_clk);
                tb_lock_timer <= 0;
            end
            else begin
                @(posedge tb_gsr_clk);
                tb_lock_timer <= tb_lock_timer + 1;
            end
        end
        else begin
            @(posedge tb_gsr_clk);
            tb_lock_timer <= 0;
        end
    end 

    // ----
    // Assignment for signal selection
    assign tb_pll_lock = (LOCK_PORT_EN)? lock_o : tb_exp_lock;

    //--------------------------------------------------------------------------
    //--- Debug related operation ---
    //--------------------------------------------------------------------------
    initial begin
    `ifdef CADENCE_DUMP
        $timeformat (-15 ,1 , "ps", 15);
        $recordfile("simwave_pll.trn");

        `ifdef TRN_INSTANCE
            $recordvars(`TRN_INSTANCE);
        `else
            $recordvars(tb_top);
        `endif
    `endif
    end

    //--------------------------------------------------------------------------
    //--- Output Result Checker ---
    //--------------------------------------------------------------------------
    // Assignment to ease the operation
    wire    [3:0]   tb_clk_out;
    assign  tb_clk_out[0] = clkop_o;
    assign  tb_clk_out[1] = clkos_o;
    assign  tb_clk_out[2] = clkos2_o;
    assign  tb_clk_out[3] = clkos3_o;

    real    tb_clk_phase[3:0];
    assign  tb_clk_phase[0] = TB_CLKOP_PHASE_SHIFT;
    assign  tb_clk_phase[1] = TB_CLKOS_PHASE_SHIFT;
    assign  tb_clk_phase[2] = TB_CLKOS2_PHASE_SHIFT;
    assign  tb_clk_phase[3] = TB_CLKOS3_PHASE_SHIFT;

    real    tb_clk_freq[3:0];
    assign  tb_clk_freq[0] = TB_CLKOP_FREQ;
    assign  tb_clk_freq[1] = TB_CLKOS_FREQ;
    assign  tb_clk_freq[2] = TB_CLKOS2_FREQ;
    assign  tb_clk_freq[3] = TB_CLKOS3_FREQ;
    
    // Checker caller
    genvar i;
    generate
    for(i=0; i<4; i=i+1) begin : gen_clk
        localparam TB_IDX_CK    = i;
        localparam TB_EN_CLK    =   (TB_IDX_CK == 3) ? (CLKOS3_ENABLE) :
                                    (TB_IDX_CK == 2) ? (CLKOS2_ENABLE) :
                                    (TB_IDX_CK == 1) ? (CLKOS_ENABLE) :
                                                       (CLKOP_ENABLE);                                          
                        

        if (TB_EN_CLK) begin : gen_en_clk
            localparam TB_CLK_NAME          =   (TB_IDX_CK == 3) ?  "CLKOS3":
                                                (TB_IDX_CK == 2) ?  "CLKOS2":
                                                (TB_IDX_CK == 1) ?  "CLKOS" :
                                                                    "CLKOP" ;

            localparam TB_CLK_BYP           =   (TB_IDX_CK == 3) ?  (VCO_BYPASS_D0 & OUTDIVIDER_MUXD2 != "CLKOS3") :
                                                (TB_IDX_CK == 2) ?  (VCO_BYPASS_C0 & OUTDIVIDER_MUXC2 != "CLKOS2") :
                                                (TB_IDX_CK == 1) ?  (VCO_BYPASS_B0 & OUTDIVIDER_MUXB2 != "CLKOS") :
                                                                    (VCO_BYPASS_A0 & OUTDIVIDER_MUXA2 != "CLKOP");

            localparam TB_CLK_FREQ = (TB_IDX_CK == 3) ? TB_CLKOS3_FREQ :
                                     (TB_IDX_CK == 2) ? TB_CLKOS2_FREQ :
                                     (TB_IDX_CK == 1) ? TB_CLKOS_FREQ  :
                                                        TB_CLKOP_FREQ;
            localparam TB_EXP_PHASE_SHIFT = (TB_IDX_CK == 3) ? TB_CLKOS3_PHASE_SHIFT :
                                           (TB_IDX_CK == 2) ? TB_CLKOS2_PHASE_SHIFT :
                                           (TB_IDX_CK == 1) ? TB_CLKOS_PHASE_SHIFT  :
                                                              TB_CLKOP_PHASE_SHIFT;


            wire                    tb_phase_0_clk;
            reg   [31:0]            tb_clk_counter;
            wire  [2:0]             tb_phase_0_clk_idx;
            wire                    tb_phase_check_en;

            // @todo - Suspect this reference can't test the clk phase shift, as this is to decide the golden
            // To determine reference clock for the static phase shift
            assign tb_phase_0_clk_idx     = ((TB_CLK_FREQ == tb_clk_freq[(i+1)%4]) && (tb_clk_phase[(i+1)%4] == 0))? ((i+1)%4) :
                                        ((TB_CLK_FREQ == tb_clk_freq[(i+2)%4]) && (tb_clk_phase[(i+2)%4] == 0))? ((i+2)%4) :
                                        ((TB_CLK_FREQ == tb_clk_freq[(i+3)%4]) && (tb_clk_phase[(i+3)%4] == 0))? ((i+3)%4) : i;
                                        
            assign tb_phase_check_en = (TB_EXP_PHASE_SHIFT != 0) && (i != tb_phase_0_clk_idx);

            // @todo - fix the refclk generation
            assign tb_phase_0_clk         = (TB_CLK_BYP)? tb_refclk : tb_clk_out[tb_phase_0_clk_idx];

            initial begin
                tb_clk_counter = 0;
                forever begin
                @(posedge tb_refclk);
                if(tb_pll_lock) begin
                    @(posedge tb_clk_out[i]);
                    @(negedge tb_clk_out[i]);
                    tb_clk_counter = tb_clk_counter + 1;
                end
                else begin
                    tb_clk_counter = 0;
                end
                end
            end

            assign tb_clk_toggle_detected[i] = (tb_clk_counter > 16);

            clock_checker #
            (
                .CLK_NAME                              (TB_CLK_NAME)
            ) u_clk_freq_checker (
                // Inputs
                .rst_n                                 (tb_rst_n),
                .pllpd_en_n                            (1'b1),
                .testclk                               (tb_clk_out[i]),
                .phase_0_testclk                       (tb_phase_0_clk),
                .lock                                  (tb_pll_lock),
                // Outputs
                .error_detected                        (tb_clk_error_detected[i]),
                .test_done                             (tb_clk_test_done[i]),
                //Settings
                .EXP_CLK_FREQ                          (TB_CLK_FREQ),
                .EXP_PHASE_SHIFT                       (TB_EXP_PHASE_SHIFT),
                .EN_PHASE_CHECK                        (tb_phase_check_en)
            );
        end // gen_en_clk
        // This apply for output that is not enabled
        else begin : gen_dis_clk
            assign tb_clk_error_detected[i]  = 1'b0;
            assign tb_clk_test_done[i]       = 1'b1;
            assign tb_clk_toggle_detected[i] = 1'b1;
        end // gen_dis_clk
    end // for

    endgenerate

    //--------------------------------------------------------------------------
    //--- Final Check and Result Printing ---
    //--------------------------------------------------------------------------
    assign tb_test_done = &tb_clk_test_done | (tb_lock_timer > LOCK_TIMEOUT_CNT);

    initial begin
        wait(tb_test_done);
        repeat (50) @(posedge tb_gsr_clk);

        if(~&(tb_clk_test_done & tb_clk_toggle_detected)) begin
            $display("\t \t ****** SOME CLOCK NOT DETECTED (clock detected = %0b) ******\n",tb_clk_toggle_detected);
            $display("\t \t ************ TEST CASE FAIL ***********\n");
        end
        else if(tb_clk_error_detected) begin
            $display("\t \t ****** CLOCK MISMATCH ******\n");
            $display("\t \t ************ TEST CASE FAIL ***********\n");
        end
        else if(tb_lock_timer > LOCK_TIMEOUT_CNT) begin
            $display("\t \t ****** PLL LOCK TIMEOUT ******\n");
            $display("\t \t ************ TEST CASE FAIL ***********\n");
        end
        else begin
            $display("\t \t ********** CLOCK MATCH **********\n");
            $display("\t \t *ALL TESTS PASSED*\n");
            $display("\t \t *SIMULATION PASSED*\n");
        end
        
        // Prolong the simulation to show case addition ena nad reset behavioural
        repeat (200) @(posedge tb_gsr_clk);
        $stop;
    end    


endmodule //--tb_top--
`endif // __TESTBENCH__TB_TOP__


`ifndef __RTL_MODULE__CLOCK_CHECKER__
`define __RTL_MODULE__CLOCK_CHECKER__
`timescale 1ps / 1fs
//==========================================================================
// Module : clock_checker
//==========================================================================
module clock_checker #

( 
    //--begin_param--
    //----------------------------
    // Parameters
    //----------------------------
    parameter                     CLK_NAME = "CLK",
    // parameter                     EXP_CLK_FREQ = 100.0,
    // parameter                     EXP_PHASE_SHIFT = 0.0,
    // parameter                     EN_PHASE_CHECK = 0,
    parameter                     MAX_SAMPLE_CNT = 255

) //--end_param--

( //--begin_ports--
    //----------------------------
    // Inputs
    //----------------------------

    input                         rst_n,
    input                         pllpd_en_n,   // power down active low
    input                         testclk,
    input                         phase_0_testclk,
    input                         lock,

    //----------------------------
    // Outputs
    //----------------------------
    output wire                   error_detected,
    output reg                    test_done,

    //----------------------------
    // Settings
    //----------------------------
    input real EXP_CLK_FREQ = 100.0,
    input real EXP_PHASE_SHIFT = 0.0,
    input real EN_PHASE_CHECK = 0

); //--end_ports--


    function [31:0] clog2 ;
        input [31:0] value ;
        reg [31:0] num ;
        begin
            num = (value - 1) ;
            for (clog2 = 0 ; (num > 0) ; clog2 = (clog2 + 1))
                num = (num >> 1) ;
        end
    endfunction

    //--------------------------------------------------------------------------
    //--- Local Parameters/Defines ---
    //--------------------------------------------------------------------------
    localparam                    CNTWID = clog2(MAX_SAMPLE_CNT+1);

    //--------------------------------------------------------------------------
    //--- Combinational Wire/Reg ---
    //--------------------------------------------------------------------------

    //--------------------------------------------------------------------------
    //--- Registers ---
    //--------------------------------------------------------------------------

    reg                           lock_testclk;
    reg                           testclk_div2_pos;
    reg                           testclk_div2_neg;
    reg                           testclk_div4_pos;
    reg         [CNTWID-1:0]      testclk_sample_cntr;
    reg                           freq_error;
    reg                           phase_error;

    realtime                      pos_time_testclk;
    realtime                      neg_time_testclk;
    realtime                      phase_0_time;
    realtime                      phase_testclk_time;

    real                          obs_testclk_timediff;
    real                          obs_testclk_freq;
    real                          obs_phase_shift;
    real                          obs_phase_timediff;

    assign                        error_detected = freq_error | phase_error;

    initial begin
    lock_testclk = 1'd0;
    testclk_div2_pos = 1'b0;
    testclk_div2_neg = 1'b0;
    testclk_div4_pos = 1'b0;
    testclk_sample_cntr = {CNTWID{1'b0}};
    test_done = 0;
    pos_time_testclk = 0;
    neg_time_testclk = 0;
    phase_0_time = 0;
    phase_testclk_time = 0;
    freq_error = 1'd0;
    phase_error = 1'd0;
    obs_phase_shift = 0;
    obs_phase_timediff = 0;
    end

    //    +----+    +----+    +----+    +----+    +----+    +----+    +----+    +----+    +--
    //    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |  phase 0 clock
    //----+    +----+    +----+    +----+    +----+    +----+    +----+    +----+    +----+
    //
    //              |                   |                   |                   |
    //              |                   |                   |                   |
    //              V                   V                   V                   V
    //      phase time1               time1               time1               time1
    //
    //       +----+    +----+    +----+    +----+    +----+    +----+    +----+    +----+
    //       |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    testclk
    //   ----+    +----+    +----+    +----+    +----+    +----+    +----+    +----+    +----
    //
    //                 |                   |                   |                   |
    //                 |                   |                   |                   |
    //                 V                   V                   V                   V
    //         phase time2               time2               time2               time2
    //
    //    phase shift = 360*EXP_CLK_FREQ*(time2-time1)*(1e-6)
    //
    //       +---------+         +---------+         +---------+         +---------+
    //       |         |         |         |         |         |         |         |         divide by 2 clock
    //   ----+         +---------+         +---------+         +---------+         +---------
    //
    //
    //       +-------------------+                   +-------------------+                   divide by 4 clock will serve as
    //       |                   |                   |                   |                   enable for checking
    //   ----+                   +-------------------+                   +-------------------
    //
    //
    //            +---------+         +---------+         +---------+         +---------+    divide by 2 clock
    //            |         |         |         |         |         |         |         |    shifted by 90
    //   ---------+         +---------+         +---------+         +---------+         +----
    //
    //            |         |         |         |         |         |         |         |
    //            |         |         |         |         |         |         |         |
    //            |         V         |         V         |         V         |         V
    //            |       time2       |       time2       |       time2       |       time2
    //            V                   V                   V                   V
    //          time1               time1               time1               time1
    //
    //    clock frequency = (1e6 MHz) / abs(time2-time1)

    always @(posedge phase_0_testclk or negedge rst_n) begin
    if(~rst_n) begin
        phase_0_time <= 0;
    end
    else begin
        if(lock_testclk & pllpd_en_n) begin
        if(testclk_div2_pos & testclk_div4_pos)
            phase_0_time <= $time;
        end
    end
    end

    always @(posedge testclk or negedge rst_n) begin
    if(~rst_n) begin
        lock_testclk <= 1'd0;
    end
    else begin
        lock_testclk <= lock;
    end
    end

    // Generate a divide by 2 version of the clock
    always @(posedge testclk or negedge rst_n) begin
    if(~rst_n) begin
        testclk_div2_pos <= 1'd0;
        phase_testclk_time <= 0;
    end
    else begin
        if(lock_testclk & pllpd_en_n) begin
        testclk_div2_pos <= ~testclk_div2_pos;
        if(testclk_div2_neg & testclk_div4_pos)
            phase_testclk_time <= $time;
        end
    end
    end

    // Generate a divide by 4 version of the clock
    // This will be used as enable signal for checking the timestamp
    always @(posedge testclk_div2_pos or negedge rst_n) begin
    if(~rst_n) begin
        testclk_div4_pos <= 1'd0;
    end
    else begin
        if(lock_testclk & pllpd_en_n & ~test_done) begin
        testclk_div4_pos <= ~testclk_div4_pos;
        end
    end
    end

    // counter for ending simulation
    always @(posedge testclk_div4_pos or negedge rst_n) begin
    if(~rst_n) begin
        testclk_sample_cntr <= {CNTWID{1'b0}};
        test_done <= 1'd0;
    end
    else begin
        if(lock_testclk & pllpd_en_n) begin
        testclk_sample_cntr <= (testclk_sample_cntr==MAX_SAMPLE_CNT)? testclk_sample_cntr : testclk_sample_cntr + 1;
        test_done <= (testclk_sample_cntr==MAX_SAMPLE_CNT);
        end
    end
    end

    // Generate a divide by 2 version of the clock with 90 degress shift
    // The timestamp will be sampled at posedge and negedge of this div2 clock
    always @(negedge testclk or negedge rst_n) begin
    if(~rst_n) begin
        testclk_div2_neg <= 1'd0;
    end
    else begin
        if(lock_testclk & pllpd_en_n) begin
        testclk_div2_neg <= ~testclk_div2_neg & testclk_div2_pos;
        end
    end
    end

    // Sample time at posedge and negedge of divide by 2 clock
    always @(posedge testclk_div2_neg or negedge rst_n) begin
    if(~rst_n) begin
        pos_time_testclk <= 0;
    end
    else begin
        if(testclk_div4_pos)
        pos_time_testclk <= $time;
    end
    end

    always @(negedge testclk_div2_neg or negedge rst_n) begin
    if(~rst_n) begin
        neg_time_testclk <= 0;
    end
    else begin
        if(testclk_div4_pos)
        neg_time_testclk <= $time;
    end
    end

    // Check timestamp difference
    always @(negedge testclk_div4_pos or negedge rst_n) begin
    if(rst_n & lock_testclk & pllpd_en_n) begin
        obs_testclk_timediff = (neg_time_testclk > pos_time_testclk)? (neg_time_testclk - pos_time_testclk) :
                                                                    (pos_time_testclk - neg_time_testclk);
        obs_testclk_freq     = 1000000.0/obs_testclk_timediff;
        `ifdef PLL_DEBUG
        $display("%t:[DEBUG] %s observed period : %f ps (Freq: %f MHz)  (POS1:%t, POS2:%t) ",
                $time,CLK_NAME,obs_testclk_timediff,obs_testclk_freq,neg_time_testclk,pos_time_testclk);
        `endif
        if(( ((EXP_CLK_FREQ > obs_testclk_freq) && ((EXP_CLK_FREQ - obs_testclk_freq)/EXP_CLK_FREQ) > 0.1) ||
            ((EXP_CLK_FREQ < obs_testclk_freq) && ((obs_testclk_freq - EXP_CLK_FREQ)/EXP_CLK_FREQ) > 0.1)
        ) && lock_testclk == 1 && test_done == 0) begin
        freq_error = 1'b1;
        $display("%t:[ERROR] Frequency Mismatch. %s observed period : %f ps (Freq: %f MHz)  (POS1:%t, POS2:%t) : Expected Frequency = %f ",
                $time,CLK_NAME,obs_testclk_timediff,obs_testclk_freq,neg_time_testclk,pos_time_testclk,EXP_CLK_FREQ);
        end

        if(EN_PHASE_CHECK && EXP_PHASE_SHIFT > 0) begin
        obs_phase_timediff = phase_testclk_time-phase_0_time;
        obs_phase_shift    = (360*EXP_CLK_FREQ*obs_phase_timediff)/1000000.0;
        `ifdef PLL_DEBUG
            $display("%t:[DEBUG] %s observed phase shift : %f degrees (TimeDiff: %f ps)  (POS1:%t, POS2:%t) ",
                    $time,CLK_NAME,obs_phase_shift,obs_phase_timediff,phase_0_time,phase_testclk_time);
        `endif
        if(( ((EXP_PHASE_SHIFT > obs_phase_shift) && ((EXP_PHASE_SHIFT-obs_phase_shift)/EXP_PHASE_SHIFT) > 0.1) ||
            ((EXP_PHASE_SHIFT < obs_phase_shift) && ((obs_phase_shift-EXP_PHASE_SHIFT)/EXP_PHASE_SHIFT) > 0.1)
            ) && lock_testclk == 1 && test_done == 0) begin
            phase_error = 1'b1;
            $display("%t:[ERROR] Phase Mismatch. %s observed phase shift : %f degrees (TimeDiff: %f ps)  (POS1:%t, POS2:%t) : Expected Phase Shift = %f ",
                    $time,CLK_NAME,obs_phase_shift,obs_phase_timediff,phase_0_time,phase_testclk_time,EXP_PHASE_SHIFT);
        end
        end
    end
    end

    // End of clock test
    always @* begin
    if(test_done) begin
        $display("%t:[INFO] Maximum sampling count reached (%d).Done test for clock %s.",$time,testclk_sample_cntr,CLK_NAME);
    end
    end

endmodule //--clock_checker--
`endif // __RTL_MODULE__CLOCK_CHECKER__