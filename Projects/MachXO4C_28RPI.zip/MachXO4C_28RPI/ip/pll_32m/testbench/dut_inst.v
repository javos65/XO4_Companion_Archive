    pll_32m u_pll_32m(.clki_i(clki_i),
        .clkop_o(clkop_o),
        .lock_o(lock_o));
