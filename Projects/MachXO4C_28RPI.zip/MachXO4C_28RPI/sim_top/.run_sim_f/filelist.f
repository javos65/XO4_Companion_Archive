../ip/pll_32m/rtl/pll_32m.sv
../rtl/dpi666_lcd/dpi666_timing.v
../rtl/dpi666_lcd/dpi666_linebuf.v
../rtl/dpi666_lcd/dpi666_lcd.v
../rtl/lcd_line_color.v
../rtl/lcd_test_pattern.v
../rtl/top_28rpi.v
tb_top.v
