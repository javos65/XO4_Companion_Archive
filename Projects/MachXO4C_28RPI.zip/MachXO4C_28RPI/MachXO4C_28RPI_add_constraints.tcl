prj_open {C:/lscc/workspace/MachXO4C_28RPI/MachXO4C_28RPI.rdf}
prj_add_source {C:/lscc/workspace/MachXO4C_28RPI/constraints/top_28rpi.sdc}
prj_add_source {C:/lscc/workspace/MachXO4C_28RPI/constraints/top_28rpi.pdc}
prj_save
prj_close
