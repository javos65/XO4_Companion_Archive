set current_path "C:/lscc/workspace/MachXO4C_28RPI"
cd $current_path

set radiant_project "C:/lscc/workspace/MachXO4C_28RPI/MachXO4C_28RPI.rdf"
set DEVICE "LFMXO4-110HC-6BBG256I"
set PERFORMANCE "6"

# Design: top_28rpi = u_test (lcd_test) + u_lcd (dpi666_axis, AXI4-Stream slave)
array set VFILE_LIST ""
set VFILE_LIST(1) "C:/lscc/workspace/MachXO4C_28RPI/ip/pll_pix/pll_pix.ipx"
set VFILE_LIST(2) "C:/lscc/workspace/MachXO4C_28RPI/rtl/dpi666_axis/dpi666_timing.v"
set VFILE_LIST(3) "C:/lscc/workspace/MachXO4C_28RPI/rtl/dpi666_axis/dpi666_axis_buf.v"
set VFILE_LIST(4) "C:/lscc/workspace/MachXO4C_28RPI/rtl/dpi666_axis/dpi666_axis.v"
set VFILE_LIST(5) "C:/lscc/workspace/MachXO4C_28RPI/rtl/lcd_test/lcd_logo_seq.v"
set VFILE_LIST(6) "C:/lscc/workspace/MachXO4C_28RPI/rtl/lcd_test/lcd_test.v"
set VFILE_LIST(7) "C:/lscc/workspace/MachXO4C_28RPI/rtl/top_28rpi.v"

if { [file exists $radiant_project] == 1 } {
    prj_open $radiant_project
} else {
    prj_create -name "MachXO4C_28RPI" -impl "impl_1" -dev $DEVICE -performance $PERFORMANCE -synthesis "synplify"
    prj_save
}

# Superseded sources (kept on disk, removed from the build)
foreach old {
    "C:/lscc/workspace/MachXO4C_28RPI/ip/pll_32m/pll_32m.ipx"
    "MachXO4C_28RPI_reveal.rvl"
    "C:/lscc/workspace/MachXO4C_28RPI/MachXO4C_28RPI_reveal.rvl"
    "C:/lscc/workspace/MachXO4C_28RPI/rtl/dpi666_lcd/dpi666_timing.v"
    "C:/lscc/workspace/MachXO4C_28RPI/rtl/dpi666_lcd/dpi666_linebuf.v"
    "C:/lscc/workspace/MachXO4C_28RPI/rtl/dpi666_lcd/dpi666_lcd.v"
    "C:/lscc/workspace/MachXO4C_28RPI/rtl/lcd_line_color.v"
    "C:/lscc/workspace/MachXO4C_28RPI/rtl/lcd_test_pattern.v"
    "C:/lscc/workspace/MachXO4C_28RPI/rtl/lcd_block_seq.v"
    "rtl/lcd_block_seq.v"
    "C:/lscc/workspace/MachXO4C_28RPI/rtl/lcd_test/lcd_block_seq.v"
    "rtl/lcd_test/lcd_block_seq.v"
} {
    catch {prj_remove_source $old}
}

foreach i [lsort -integer [array names VFILE_LIST]] {
    if { [catch {prj_add_source $VFILE_LIST($i)} fid] } {
        puts "file already exists in project."
    }
}

prj_set_impl_opt -impl "impl_1" "include path" "."
prj_set_impl_opt -impl "impl_1" "top" "top_28rpi"
prj_save
