# Timing constraints for top_28rpi
# 12 MHz board clock; the 32 MHz pixel clock (PLL CLKOP) is derived by the tools.
create_clock -name clk12 -period 83.333 [get_ports clk12_i]

# Asynchronous / quasi-static board I/O (synchronised or debounced in RTL)
set_false_path -from [get_ports sw2_n_i]
set_false_path -to   [get_ports {led_n_o[*] lcd_bl_o}]