"""Draws the diagrams for doc/MachXO4C_28RPI_Report.docx (PNG, 200 dpi) into this folder."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

OUT = os.path.dirname(os.path.abspath(__file__))
plt.rcParams.update({"font.family": "Arial", "font.size": 9})

C_TEST = "#DCEFD9"   # test block
C_DRV = "#D6E6F7"    # driver
C_HW = "#EEEEEE"     # hardware / pins
C_DBG = "#FCE7C8"    # debug
C_BAD = "#F6CFCF"
C_EDGE = "#333333"


def box(ax, x, y, w, h, text, fc, fs=9, bold=False, ec=C_EDGE, lw=1.2, ls="-", va="center"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc=fc, ec=ec, lw=lw, ls=ls))
    ty = y + h / 2 if va == "center" else y + h - 0.18
    ax.text(x + w / 2, ty, text, ha="center", va="center" if va == "center" else "top",
            fontsize=fs, fontweight="bold" if bold else "normal")


def arrow(ax, x0, y0, x1, y1, text="", fs=8, color=C_EDGE, both=False, toff=(0, 0.1), ha="center", lw=1.2):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="<|-|>" if both else "-|>", color=color, lw=lw,
                                shrinkA=0, shrinkB=0, mutation_scale=10))
    if text:
        ax.text((x0 + x1) / 2 + toff[0], (y0 + y1) / 2 + toff[1], text, ha=ha, va="bottom",
                fontsize=fs, color=color)


def canvas(w, h):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, w)
    ax.set_ylim(0, h)
    ax.axis("off")
    return fig, ax


def save(fig, name):
    fig.savefig(os.path.join(OUT, name), dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)


# ---------------------------------------------------------------- 1 system overview
def system_overview():
    fig, ax = canvas(10, 4.2)
    box(ax, 0.2, 0.3, 6.3, 3.6, "", "#F7F7F7", lw=1.5)
    ax.text(0.35, 3.72, "MachXO4 Companion Board Rev A", fontsize=10, fontweight="bold", va="center")
    box(ax, 0.45, 2.75, 1.35, 0.6, "12 MHz\noscillator (T9)", C_HW)
    box(ax, 0.45, 1.85, 1.35, 0.6, "SW2 (D10)", C_HW)
    box(ax, 0.45, 0.55, 1.35, 0.9, "FTDI USB\n(JTAG)", C_HW)
    box(ax, 2.2, 0.55, 3.0, 2.95, "", "#FFFFFF", lw=1.5)
    ax.text(3.7, 3.25, "LFMXO4-110HC-6BBG256I", ha="center", fontsize=9, fontweight="bold")
    box(ax, 2.4, 2.05, 2.6, 0.95, "u_test : lcd_test\nPLL, reset, LEDs,\nbouncing-block source", C_TEST, fs=8)
    box(ax, 2.4, 0.75, 2.6, 0.95, "u_lcd : dpi666_axis\nDPI666 LCD driver", C_DRV, fs=8)
    arrow(ax, 3.7, 2.05, 3.7, 1.7, "AXI4-Stream", fs=7, toff=(0.05, -0.05), ha="left")
    box(ax, 5.45, 2.05, 0.9, 0.95, "LED1..4", C_HW, fs=8)
    arrow(ax, 1.8, 3.05, 2.4, 2.7)
    arrow(ax, 1.8, 2.15, 2.4, 2.3)
    arrow(ax, 1.8, 1.0, 2.2, 1.0, "", both=True)
    arrow(ax, 5.0, 2.5, 5.45, 2.5)
    # HAT40
    box(ax, 6.55, 0.55, 0.6, 2.95, "HAT40\n(JP5)", C_HW, fs=8)
    arrow(ax, 5.0, 1.2, 6.55, 1.2, "22 LCD signals\nLVCMOS33", fs=7, toff=(0, 0.05))
    # LCD board
    box(ax, 7.4, 0.3, 2.45, 3.6, "", "#F7F7F7", lw=1.5)
    ax.text(8.62, 3.72, "Waveshare 2.8\" DPI LCD", ha="center", fontsize=10, fontweight="bold", va="center")
    box(ax, 7.6, 2.3, 2.05, 0.85, "On-board start-up\ncontroller\n(about 5 s at power-on)", C_HW, fs=8)
    box(ax, 7.6, 0.6, 2.05, 1.35, "ST7701S\n480 x 640 panel\nRGB666", "#FFFFFF", fs=9)
    arrow(ax, 7.15, 1.2, 7.6, 1.2)
    arrow(ax, 8.62, 2.3, 8.62, 1.95, "init", fs=7, toff=(0.08, -0.08), ha="left")
    arrow(ax, 7.15, 3.2, 7.6, 3.2, "5 V", fs=7)
    save(fig, "fig1_system.png")


# ---------------------------------------------------------------- 2 top-level block diagram
def top_block_diagram():
    fig, ax = canvas(10.6, 5.6)
    box(ax, 0.9, 0.2, 8.2, 5.2, "", "#FAFAFA", lw=1.8)
    ax.text(1.05, 5.2, "top_28rpi", fontsize=11, fontweight="bold", va="center")
    # u_test
    box(ax, 1.2, 0.5, 2.9, 4.4, "", C_TEST, lw=1.4)
    ax.text(2.65, 4.65, "u_test : lcd_test", ha="center", fontsize=10, fontweight="bold")
    box(ax, 1.4, 3.6, 2.5, 0.75, "u_pll : pll_pix\n12 -> 26.88 MHz", "#FFFFFF", fs=8)
    box(ax, 1.4, 2.65, 2.5, 0.75, "Reset: lock, SW2 debounce,\npower-on 2.4 ms", "#FFFFFF", fs=8)
    box(ax, 1.4, 1.55, 2.5, 0.9, "u_seq : lcd_block_seq\nAXI4-Stream master\nred 8x8 bouncing block", "#FFFFFF", fs=8)
    box(ax, 1.4, 0.7, 2.5, 0.65, "LED logic", "#FFFFFF", fs=8)
    # u_lcd
    box(ax, 5.9, 0.5, 2.9, 4.4, "", C_DRV, lw=1.4)
    ax.text(7.35, 4.65, "u_lcd : dpi666_axis", ha="center", fontsize=10, fontweight="bold")
    box(ax, 6.1, 3.45, 2.5, 0.9, "dpi666_timing\nHSYNC, VSYNC, DE", "#FFFFFF", fs=8)
    box(ax, 6.1, 2.2, 2.5, 1.0, "AXI4-Stream slave +\ndual-clock line buffer\n(2 x 512 x 18)", "#FFFFFF", fs=8)
    box(ax, 6.1, 0.7, 2.5, 1.3, "Output stage\nfabric polarity regs ->\nI/O registers,\nODDRXE for LCD_CLK", "#FFFFFF", fs=8)
    # inter-block
    arrow(ax, 3.9, 3.95, 5.9, 3.95, "pclk (26.88 MHz)", fs=7.5)
    arrow(ax, 3.9, 3.0, 5.9, 3.0, "rst_n", fs=7.5)
    arrow(ax, 3.9, 2.05, 5.9, 2.05, "tdata[17:0]\ntvalid, tuser, tlast", fs=7)
    arrow(ax, 5.9, 1.7, 3.9, 1.7, "tready", fs=7.5)
    arrow(ax, 5.9, 0.9, 3.9, 0.9, "frame_start\nunderrun, sync_err", fs=7)
    # pins
    for y, t in [(4.0, "clk12_i"), (3.0, "sw2_n_i")]:
        arrow(ax, 0.1, y, 1.4, y)
        ax.text(0.1, y + 0.08, t, fontsize=8, va="bottom")
    arrow(ax, 1.4, 1.0, 0.1, 1.0)
    ax.text(0.1, 1.08, "led_n_o[3:0]", fontsize=8, va="bottom")
    pins = ["lcd_pclk_o", "lcd_de_o", "lcd_hsync_o", "lcd_vsync_o", "lcd_r/g/b_o[5:0]", "lcd_bl_o"]
    for i, t in enumerate(pins):
        y = 1.85 - i * 0.22
        arrow(ax, 8.6, y, 9.6, y, lw=1.0)
        ax.text(9.65, y, t, fontsize=7.5, va="center")
    save(fig, "fig2_top.png")


# ---------------------------------------------------------------- 3 driver internals
def driver_internals():
    fig, ax = canvas(10.9, 4.6)
    ax.add_patch(Rectangle((0.15, 0.25), 4.4, 3.95, fc="#EEF5EC", ec="none"))
    ax.add_patch(Rectangle((4.55, 0.25), 5.3, 3.95, fc="#EAF1FA", ec="none"))
    ax.plot([4.55, 4.55], [0.25, 4.2], ls="--", color="#777777", lw=1.2)
    ax.text(2.35, 4.05, "s_axis_aclk domain (stream)", ha="center", fontsize=9, fontweight="bold")
    ax.text(7.2, 4.05, "pclk_i domain (pixel)", ha="center", fontsize=9, fontweight="bold")
    box(ax, 0.35, 2.3, 1.7, 1.2, "Stream writer\npixel counter,\nline commit,\nSOF flag per bank", "#FFFFFF", fs=8)
    box(ax, 2.6, 2.3, 1.5, 1.2, "wr_cnt\n(Gray)", "#FFFFFF", fs=8)
    box(ax, 3.45, 0.55, 2.25, 1.35, "Line buffer EBR\nbank 0 | bank 1\n2 x 512 x 18\nwrite aclk / read pclk", "#FFFFFF", fs=8)
    box(ax, 5.05, 2.3, 1.5, 1.2, "2-FF sync\n+ rd_cnt\n(Gray)", "#FFFFFF", fs=8)
    box(ax, 6.95, 2.3, 1.6, 1.2, "Line select\navailable? SOF on\nline 0? free bank\nafter the row", "#FFFFFF", fs=8)
    box(ax, 6.95, 0.55, 1.6, 1.35, "dpi666_timing\nh_cnt, v_cnt\nHSYNC VSYNC DE", "#FFFFFF", fs=8)
    box(ax, 8.85, 0.55, 0.95, 2.95, "Output\nstage\n\npolarity\nregs\n->\nI/O\nregs\n+\nODDRXE", "#FFFFFF", fs=7.5)
    arrow(ax, -0.3, 2.9, 0.35, 2.9)
    ax.text(-0.3, 3.0, "AXI4-\nStream", fontsize=7.5, va="bottom")
    arrow(ax, 2.05, 2.9, 2.6, 2.9)
    arrow(ax, 4.1, 2.9, 5.05, 2.9, "wr_gray", fs=7)
    arrow(ax, 5.05, 2.55, 4.1, 2.55, "rd_gray", fs=7, toff=(0, -0.28))
    arrow(ax, 6.55, 2.9, 6.95, 2.9)
    # write: writer -> buffer (elbow, left of the buffer)
    ax.plot([1.2, 1.2], [2.3, 1.22], color=C_EDGE, lw=1.2)
    arrow(ax, 1.2, 1.22, 3.45, 1.22, "write pixels", fs=7)
    # read address: timing -> buffer, read data: buffer -> output stage (below the timing box)
    arrow(ax, 6.95, 1.5, 5.7, 1.5, "read addr", fs=7)
    ax.plot([5.7, 6.2, 6.2], [0.8, 0.8, 0.38], color=C_EDGE, lw=1.2)
    ax.plot([6.2, 9.3], [0.38, 0.38], color=C_EDGE, lw=1.2)
    arrow(ax, 9.3, 0.38, 9.3, 0.55)
    ax.text(7.75, 0.4, "pixel data", fontsize=7, ha="center", va="bottom")
    arrow(ax, 8.55, 1.2, 8.85, 1.2)
    arrow(ax, 8.55, 2.9, 8.85, 2.9)
    arrow(ax, 7.75, 2.3, 7.75, 1.9)
    arrow(ax, 9.8, 2.0, 10.3, 2.0)
    ax.text(10.35, 2.0, "LCD\npins", fontsize=8, va="center")
    ax.text(1.2, 0.75, "tready = fewer than\n2 lines waiting", fontsize=7.5, ha="center", style="italic")
    save(fig, "fig3_driver.png")


# ---------------------------------------------------------------- 4 timing
def wave(ax, y, segs, label, h=0.6, color="#1F4E79"):
    """segs: list of (t0, t1, level)."""
    xs, ys = [], []
    for t0, t1, lv in segs:
        xs += [t0, t1]
        ys += [y + lv * h, y + lv * h]
    ax.plot(xs, ys, color=color, lw=1.6, drawstyle="default")
    ax.text(-8, y + h / 2, label, ha="right", va="center", fontsize=8.5)


def timing():
    fig, axs = plt.subplots(2, 1, figsize=(10, 5.0))
    # horizontal (pixel clocks), one line + start of next
    ax = axs[0]
    ax.set_xlim(-95, 700)
    ax.set_ylim(-0.6, 3.2)
    ax.axis("off")
    ax.set_title("One line: 640 pixel clocks (26.88 MHz)", fontsize=10, loc="left")
    wave(ax, 2.2, [(0, 0, 1), (0, 30, 0), (30, 640, 1), (640, 670, 0), (670, 690, 1)], "HSYNC (low)")
    wave(ax, 1.2, [(0, 95, 0), (95, 575, 1), (575, 690, 0)], "DE (high)")
    ax.add_patch(Rectangle((95, 0.2), 480, 0.6, fc="#F6CFCF", ec="#1F4E79", lw=1))
    ax.text(335, 0.5, "RGB: pixels 0 .. 479", ha="center", va="center", fontsize=8)
    ax.text(-8, 0.5, "RGB", ha="right", va="center", fontsize=8.5)
    for x0, x1, t in [(0, 30, "sync 30"), (30, 95, "back porch 65"), (95, 575, "active 480"),
                      (575, 640, "front porch 65")]:
        ax.annotate("", xy=(x1, -0.3), xytext=(x0, -0.3), arrowprops=dict(arrowstyle="<->", lw=0.8))
        ax.text((x0 + x1) / 2, -0.25, t, ha="center", va="bottom", fontsize=7.5)
    # vertical (lines)
    ax = axs[1]
    ax.set_xlim(-104, 760)
    ax.set_ylim(-0.6, 2.2)
    ax.axis("off")
    ax.set_title("One frame: 700 lines (60 Hz)", fontsize=10, loc="left")
    wave(ax, 1.2, [(0, 0, 1), (0, 10, 0), (10, 700, 1), (700, 712, 0)], "VSYNC (low)")
    wave(ax, 0.2, [(0, 35, 0), (35, 675, 1), (675, 712, 0)], "active lines")
    for x0, x1, t, dy in [(0, 10, "sync 10", 0.0), (10, 35, "BP 25", 0.22), (35, 675, "active 640 lines", 0.0),
                          (675, 700, "FP 25", 0.0)]:
        ax.annotate("", xy=(x1, -0.35), xytext=(x0, -0.35), arrowprops=dict(arrowstyle="<->", lw=0.8))
        ax.text((x0 + x1) / 2 + (-12 if x1 == 10 else 0), -0.3 + dy, t,
                ha="right" if x1 == 10 else "center", va="bottom", fontsize=7.5)
    fig.tight_layout()
    save(fig, "fig4_timing.png")


# ---------------------------------------------------------------- 5 reveal setup
def reveal_setup():
    fig, ax = canvas(10, 4.4)
    box(ax, 0.2, 0.3, 7.3, 3.9, "", "#FAFAFA", lw=1.5)
    ax.text(0.35, 4.0, "FPGA (debug build)", fontsize=10, fontweight="bold", va="center")
    box(ax, 0.45, 2.55, 1.9, 1.1, "dpi666 timing\nHSYNC VSYNC DE\nh_cnt v_cnt", C_DRV, fs=8)
    box(ax, 2.75, 2.55, 1.4, 1.1, "Output\nstage\n(I/O regs)", C_DRV, fs=8)
    box(ax, 4.55, 2.55, 1.0, 1.1, "BB pad\nT = 0", C_HW, fs=8)
    box(ax, 4.45, 1.05, 1.2, 0.8, "pad_rb\n[21:0] reg", C_DBG, fs=8)
    box(ax, 0.45, 0.55, 1.9, 1.3, "12 MHz ->\n1 us toggle ->\n2-FF sync\n(dbg_ref_1us)", C_DBG, fs=8)
    box(ax, 2.75, 0.55, 1.4, 1.3, "Reveal core\nsample clk\n= pclk\n8192 / 4096", C_DBG, fs=8)
    box(ax, 6.0, 0.55, 1.3, 1.3, "Reveal\nJTAG hub", C_DBG, fs=8)
    arrow(ax, 2.35, 3.1, 2.75, 3.1)
    arrow(ax, 4.15, 3.1, 4.55, 3.1)
    arrow(ax, 5.55, 3.1, 8.0, 3.1, "LCD pins", fs=8)
    arrow(ax, 5.05, 2.55, 5.05, 1.85, "pad input", fs=7, toff=(0.08, -0.1), ha="left")
    arrow(ax, 4.45, 1.45, 4.15, 1.45)
    arrow(ax, 1.4, 2.55, 3.1, 1.85, "internal signals", fs=7, toff=(-0.45, -0.1))
    arrow(ax, 2.35, 1.2, 2.75, 1.2)
    arrow(ax, 4.15, 0.75, 6.0, 0.75, "capture", fs=7, toff=(0.2, 0))
    box(ax, 8.0, 0.4, 1.9, 1.6, "PC\nReveal Analyzer\n(.rva / .trc)", C_HW, fs=8.5)
    arrow(ax, 7.3, 1.2, 8.0, 1.2, "USB/\nJTAG", fs=7, both=True, toff=(0, 0.08))
    box(ax, 8.0, 2.6, 1.9, 1.0, "LCD panel", C_HW, fs=8.5)
    save(fig, "fig5_reveal.png")


# ---------------------------------------------------------------- 6 test3 result
def pad_result():
    fig, ax = plt.subplots(figsize=(10, 3.4))
    ax.set_xlim(-210, 1300)
    ax.set_ylim(-0.4, 4.2)
    ax.axis("off")
    ax.set_title("test3 pad read-back: HSYNC over two lines (pixel clocks)", fontsize=10, loc="left")
    wave(ax, 3.2, [(0, 0, 0), (0, 30, 1), (30, 640, 0), (640, 670, 1), (670, 1280, 0)],
         "internal hsync_o (1 = sync)")
    wave(ax, 1.9, [(0, 0, 1), (0, 30, 0), (30, 640, 1), (640, 670, 0), (670, 1280, 1)],
         "intended pin (active low)", color="#2E7D32")
    wave(ax, 0.6, [(0, 0, 0), (0, 30, 1), (30, 640, 0), (640, 670, 1), (670, 1280, 0)],
         "MEASURED pin (pad_rb)", color="#C62828")
    ax.text(700, 0.0, "pin high 30 / low 610 -> polarity inverted (same for VSYNC)", fontsize=8.5,
            color="#C62828")
    save(fig, "fig6_test3.png")


# ---------------------------------------------------------------- 7 root cause and fix
def root_cause():
    fig, ax = canvas(10, 3.6)
    ax.text(0.2, 3.35, "Before (fault)", fontsize=10, fontweight="bold", color="#C62828")
    box(ax, 0.2, 2.2, 1.6, 0.8, "hs_d\n(fabric reg)", "#FFFFFF", fs=8)
    box(ax, 2.3, 2.2, 1.1, 0.8, "INV", C_BAD, fs=9, bold=True)
    box(ax, 3.9, 2.2, 1.8, 0.8, "OFS1P3DX\nI/O register", C_DRV, fs=8)
    box(ax, 6.2, 2.2, 1.0, 0.8, "pad", C_HW, fs=8)
    arrow(ax, 1.8, 2.6, 2.3, 2.6)
    arrow(ax, 3.4, 2.6, 3.9, 2.6)
    arrow(ax, 5.7, 2.6, 6.2, 2.6)
    ax.text(7.4, 2.6, "netlist: correct\nhardware: INV missing,\nsync active HIGH", fontsize=8.5,
            va="center", color="#C62828")
    ax.plot([2.3, 3.4], [2.2, 3.0], color="#C62828", lw=2)
    ax.plot([2.3, 3.4], [3.0, 2.2], color="#C62828", lw=2)
    ax.text(0.2, 1.45, "After (fix)", fontsize=10, fontweight="bold", color="#2E7D32")
    box(ax, 0.2, 0.3, 1.6, 0.8, "t_hs\n(timing)", "#FFFFFF", fs=8)
    box(ax, 2.3, 0.3, 1.1, 0.8, "hs_lvl\nfabric reg\n+ polarity", C_TEST, fs=7.5)
    box(ax, 3.9, 0.3, 1.8, 0.8, "OFS1P3DX\nI/O register\n(plain copy)", C_DRV, fs=8)
    box(ax, 6.2, 0.3, 1.0, 0.8, "pad", C_HW, fs=8)
    arrow(ax, 1.8, 0.7, 2.3, 0.7)
    arrow(ax, 3.4, 0.7, 3.9, 0.7)
    arrow(ax, 5.7, 0.7, 6.2, 0.7)
    ax.text(7.4, 0.7, "no logic between the last\nfabric register and the\nI/O register: correct on pins", fontsize=8.5,
            va="center", color="#2E7D32")
    save(fig, "fig7_rootcause.png")


if __name__ == "__main__":
    system_overview()
    top_block_diagram()
    driver_internals()
    timing()
    reveal_setup()
    pad_result()
    root_cause()
    print("done:", sorted(f for f in os.listdir(OUT) if f.endswith(".png")))
