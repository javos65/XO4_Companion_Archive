"""Converts doc/MachXO4C_28RPI_Report.md + the PNG diagrams into an HTML file that Word
turns into the .docx report. Usage: python make_report_html.py <out.html>"""
import html
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
MD = os.path.join(HERE, "..", "MachXO4C_28RPI_Report.md")
OUT = sys.argv[1]

# figure placement: (trigger, where, file, caption)
FIGS = [
    ("## 2. Hardware", "after", "fig1_system.png",
     "Figure 1: System overview - MachXO4 Companion Board, HAT40 connector and Waveshare 2.8\" DPI LCD"),
    ("### 2.2 Display timing used", "after", "fig4_timing.png",
     "Figure 2: Display timing - one line (640 pixel clocks) and one frame (700 lines)"),
    ("### 3.2 Block diagram", "after", "fig2_top.png",
     "Figure 3: top_28rpi with the test block u_test and the driver u_lcd, and their connections"),
    ("**Internal structure**", "before", "fig3_driver.png",
     "Figure 4: Internal structure of dpi666_axis and its two clock domains"),
    ("### 7.3 Reveal setup", "after", "fig5_reveal.png",
     "Figure 5: Reveal debug set-up with the 1 us clock reference and the pad read-back path"),
    ("### 7.6 Root cause", "before", "fig6_test3.png",
     "Figure 6: test3 result - HSYNC inside the FPGA, intended at the pin, and measured at the pin"),
    ("### 7.7 Fix", "after", "fig7_rootcause.png",
     "Figure 7: Output stage before (inverter lost after synthesis) and after the fix"),
]
SKIP_CODE_AFTER = "### 3.2 Block diagram"   # the ASCII block diagram is replaced by Figure 3


def inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r"`([^`]+)`", r'<span class="code">\1</span>', t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", t)
    return t


def fig_html(fname, caption):
    src = os.path.join(HERE, fname).replace("\\", "/")
    return (f'<p class="fig"><img src="file:///{src}" width="620"></p>'
            f'<p class="caption">{html.escape(caption)}</p>')


lines = open(MD, encoding="utf-8").read().splitlines()
out = []
i = 0
in_list = None
skip_next_code = False


def close_list():
    global in_list
    if in_list:
        out.append(f"</{in_list}>")
        in_list = None


while i < len(lines):
    ln = lines[i]
    s = ln.strip()
    for trig, where, f, cap in FIGS:
        if s == trig and where == "before":
            close_list()
            out.append(fig_html(f, cap))
    if s.startswith("```"):
        close_list()
        code = []
        i += 1
        while i < len(lines) and not lines[i].strip().startswith("```"):
            code.append(lines[i])
            i += 1
        i += 1
        if skip_next_code:
            skip_next_code = False
            continue
        out.append("<pre>" + html.escape("\n".join(code)) + "</pre>")
        continue
    if s.startswith("|"):
        close_list()
        rows = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            rows.append(lines[i].strip())
            i += 1
        cells = [[c.strip() for c in r.strip("|").split("|")] for r in rows]
        body = [r for r in cells if not all(re.fullmatch(r":?-{3,}:?", c) for c in r)]
        t = ['<table>']
        for k, r in enumerate(body):
            tag = "th" if k == 0 else "td"
            t.append("<tr>" + "".join(f"<{tag}>{inline(c)}</{tag}>" for c in r) + "</tr>")
        t.append("</table>")
        out.append("".join(t))
        continue
    m = re.match(r"^(#{1,3}) (.*)", s)
    if m:
        close_list()
        lvl = len(m.group(1))
        out.append(f"<h{lvl}>{inline(m.group(2))}</h{lvl}>")
        if s == SKIP_CODE_AFTER:
            skip_next_code = True
        for trig, where, f, cap in FIGS:
            if s == trig and where == "after":
                out.append(fig_html(f, cap))
        i += 1
        continue
    if s == "---":
        close_list()
        i += 1
        continue
    def item_text(first, indent):
        """Join continuation lines (indented deeper, not a new item) to a list item."""
        global i
        parts = [first]
        i += 1
        while i < len(lines):
            nxt = lines[i]
            ns = nxt.strip()
            lead = len(nxt) - len(nxt.lstrip())
            if not ns or lead <= indent or re.match(r"^(- |\d+\. )", ns) or ns.startswith(("|", "```")):
                break
            parts.append(ns)
            i += 1
        return " ".join(parts)

    m = re.match(r"^(\s*)- (.*)", ln)
    if m:
        if in_list != "ul":
            close_list()
            out.append("<ul>")
            in_list = "ul"
        cls = ' class="sub"' if len(m.group(1)) >= 2 else ""
        out.append(f"<li{cls}>{inline(item_text(m.group(2), len(m.group(1))))}</li>")
        continue
    m = re.match(r"^(\s*)\d+\. (.*)", ln)
    if m:
        if in_list != "ol":
            close_list()
            out.append("<ol>")
            in_list = "ol"
        out.append(f"<li>{inline(item_text(m.group(2), len(m.group(1))))}</li>")
        continue
    if not s:
        close_list()
        i += 1
        continue
    # paragraph: join following plain lines
    close_list()
    para = [s]
    i += 1
    while i < len(lines):
        n = lines[i].strip()
        if not n or n.startswith(("|", "#", "```", "- ", "---")) or re.match(r"^\d+\. ", n):
            break
        para.append(n)
        i += 1
    out.append("<p>" + inline(" ".join(para)) + "</p>")
close_list()

css = """
body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; }
h1 { font-family: Calibri, Arial; font-size: 20pt; color: #1F3864; }
h2 { font-family: Calibri, Arial; font-size: 15pt; color: #1F3864; margin-top: 18pt; }
h3 { font-family: Calibri, Arial; font-size: 12.5pt; color: #2F5496; margin-top: 12pt; }
p { margin: 4pt 0 6pt 0; }
table { border-collapse: collapse; margin: 4pt 0 10pt 0; }
th { background: #D9E2F3; font-weight: bold; }
th, td { border: 1px solid #8EA9DB; padding: 2pt 5pt; font-size: 9.5pt; vertical-align: top; }
pre { font-family: Consolas, monospace; font-size: 8.5pt; background: #F2F2F2; padding: 4pt; }
.code { font-family: Consolas, monospace; font-size: 10pt; }
.fig { text-align: center; margin-top: 8pt; }
.caption { text-align: center; font-style: italic; font-size: 9.5pt; color: #404040; margin-bottom: 10pt; }
li { margin-bottom: 2pt; }
li.sub { margin-left: 18pt; }
"""
doc = ("<html><head><meta charset='utf-8'><title>MachXO4C_28RPI - DPI666 LCD Driver: Project Report</title>"
       f"<style>{css}</style></head><body>" + "\n".join(out) + "</body></html>")
with open(OUT, "w", encoding="utf-8") as fh:
    fh.write(doc)
print("written", OUT, len(out), "blocks")
