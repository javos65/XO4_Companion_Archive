# Builds doc\MachXO4C_28RPI_Report.docx with Microsoft Word from the HTML made by make_report_html.py.
# Usage: powershell -File make_report_docx.ps1 <report.html> <out.docx> [<check.pdf>]
param([string]$Html, [string]$Docx, [string]$Pdf = "")
$ErrorActionPreference = 'Stop'
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
try {
    $doc = $word.Documents.Open($Html, $false, $true)       # ConfirmConversions=false, ReadOnly=true
    $word.ActiveWindow.View.Type = 3                          # print layout

    # page: A4, 2 cm margins
    $ps = $doc.PageSetup
    $ps.PaperSize = 7
    $ps.TopMargin = 56.7; $ps.BottomMargin = 56.7; $ps.LeftMargin = 56.7; $ps.RightMargin = 56.7

    "step: opened, $($doc.InlineShapes.Count) pictures, $($doc.Tables.Count) tables"
    # embed the pictures (HTML import links them)
    foreach ($s in @($doc.InlineShapes)) {
        try {
            $s.LinkFormat.SavePictureWithDocument = $true
            $s.LinkFormat.BreakLink()
        } catch { "  picture not linked (already embedded)" }
        if ($s.Width -gt 481) {                                # fit 17 cm text width
            $r = 481 / $s.Width; $s.Width = 481; $s.Height = $s.Height * $r
        }
    }

    # tables: full text width, header row repeats on new pages
    foreach ($t in @($doc.Tables)) {
        $t.AutoFitBehavior(1)                                 # fit contents
        $t.AutoFitBehavior(2)                                 # then fit window
        $t.Rows.Item(1).HeadingFormat = -1
        $t.Rows.AllowBreakAcrossPages = 0
    }

    # list paragraphs: hanging indent so wrapped lines align with the text;
    # headings and figure pictures stay on the page of what follows them
    foreach ($p in @($doc.Paragraphs)) {
        if ($p.OutlineLevel -le 3 -or $p.Range.InlineShapes.Count -gt 0) { $p.KeepWithNext = -1 }
        if ($p.Range.ListFormat.ListType -ne 0) {
            $lvl = $p.Range.ListFormat.ListLevelNumber
            $p.LeftIndent = 18 + 18 * $lvl
            $p.FirstLineIndent = -14
        }
    }
    "step: pictures, tables and lists done"
    # table of contents before "1. Summary": "Contents" line, TOC, page break
    $start = -1
    foreach ($p in @($doc.Paragraphs)) {
        if ($p.Range.Text.Trim() -eq '1. Summary') { $start = $p.Range.Start; break }
    }
    "step: '1. Summary' at $start"
    if ($start -ge 0) {
        $doc.Range($start, $start).InsertBefore("Contents`r`r")
        $cp = $doc.Range($start, $start + 8)                 # "Contents"
        $cp.Paragraphs.Item(1).Style = $doc.Styles.Item(-1)  # Normal, so it is not in the TOC
        $doc.Range($start + 9, $start + 9).Paragraphs.Item(1).Style = $doc.Styles.Item(-1)
        $cp.Font.Size = 15; $cp.Font.Bold = $true; $cp.Font.Color = 0x64381F
        $tocRange = $doc.Range($start + 9, $start + 9)       # the empty paragraph after it
        $doc.TablesOfContents.Add($tocRange, $true, 2, 3) | Out-Null
        $afterToc = $doc.TablesOfContents.Item(1).Range.End
        $doc.Range($afterToc, $afterToc).InsertBreak(7)      # page break before "1. Summary"
        "step: TOC added"
    }

    # page numbers in the footer, centred
    try { $doc.Sections.Item(1).Footers.Item(1).PageNumbers.Add(1, $true) | Out-Null; "step: page numbers" }
    catch { "step: page numbers FAILED: $($_.Exception.Message)" }

    # document title property (late-bound COM object)
    try {
        $props = $doc.BuiltInDocumentProperties
        $title = [System.__ComObject].InvokeMember('Item', 'GetProperty', $null, $props, @('Title'))
        [System.__ComObject].InvokeMember('Value', 'SetProperty', $null, $title, @('MachXO4C_28RPI - DPI666 LCD Driver: Project Report')) | Out-Null
        "step: title property"
    } catch { "step: title property skipped" }

    if ($doc.TablesOfContents.Count -gt 0) { $doc.TablesOfContents.Item(1).Update() }
    $doc.SaveAs2($Docx, 12)                                   # .docx
    if ($Pdf) { $doc.ExportAsFixedFormat($Pdf, 17) }          # .pdf for checking
    $doc.Close(0)
    "saved $Docx"
} finally {
    $word.Quit()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
}
