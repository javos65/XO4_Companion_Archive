 2.8-inch 480×640 DPI LCD (commonly the Waveshare 2.8inch DPI LCD using a DPI666 interface and I2C capacitive touch),

How "DPI666" Works

- Parallel RGB Transmission. The interface sends a continuous stream of raw pixel data alongside synchronization clocks directly from the Raspberry Pi's GPU to the screen.
- 18-Bit Color Depth (RGB666). The "666" indicates that the color channels are split into 6 bits for Red, 6 bits for Green, and 6 bits for Blue (18 data lines total), capable of displaying up to 262,144 colors.
- Timing & Control Signals.

In addition to the 18 color pins, DPI requires up to 4 synchronization signals: 
Pixel Clock (PCLK), 
Data Enable (DE), 
Horizontal Sync (HSYNC),
Vertical Sync (VSYNC). 
(Some LCD panels omit HSYNC and VSYNC and rely strictly on PCLK and DE).

- Capacitive Touchscreens. Providing an I2C bus (GPIO 2 and GPIO 3) to read touch input.
- Backlight Control. Using a PWM-capable pin (like GPIO 18) to dim or toggle the screen backlight.

The DPI666 timing diagram follows the standard parallel RGB video timing protocol, synchronizing 18 parallel color lines (R[5:0], G[5:0], B[5:0]) with a pixel clock (PCLK), data enable (DE), and horizontal/vertical sync pulses (HSYNC, VSYNC).
While the bit depth (18-bit) differs from DPI888 (24-bit), the timing waveform structure is identical. Every frame is drawn left-to-right, line-by-line, surrounded by non-visible "blanking" intervals called porches.

1. Pixel-Level Timing (PCLK & RGB666)

• Pixel Clock (PCLK). Acts as the heartbeat of the interface. One pixel (18 bits of color data) is latched on every rising or falling edge of PCLK.
• Data Enable (DE). Goes active (typically high) only when valid pixel data is being transmitted. During blanking periods (porches and sync pulses), DE stays low and the display ignores the RGB666 data lines.

2. Horizontal Line Timing (HSYNC)

Measured in pixel clock cycles (PCLK), each horizontal scanline consists of four sequential phases:
• Horizontal Sync Width (HSW). A pulse indicating the start of a new horizontal line.
• Horizontal Back Porch (HBP). A brief pause after HSYNC before visible pixels begin, allowing the display's row drivers to settle.
• Horizontal Active Width. The actual horizontal resolution of your screen (e.g., 800 clock cycles for an 800px wide display), during which DE is high.
• Horizontal Front Porch (HFP). A short buffer period after the last visible pixel before the next HSYNC pulse fires.

3. Vertical Frame Timing (VSYNC)

Measured in horizontal line counts (HSYNC cycles), each complete screen refresh consists of four phases:
• Vertical Sync Width (VSW). A pulse signaling the start of a brand-new frame at the top-left of the screen.
• Vertical Back Porch (VBP). Blank lines sent at the top of the frame before the first visible row of pixels.
• Vertical Active Height. The vertical resolution of your screen (e.g., 480 lines for a 480px tall display).
• Vertical Front Porch (VFP). Blank lines sent at the bottom of the frame before the next VSYNC pulse resets the frame.

Operating Modes: HV Mode vs. DE-Only Mode

Depending on your LCD controller's datasheet, DPI666 runs in one of two timing configurations:
• HV Mode (Sync Mode). Uses PCLK, HSYNC, and VSYNC to track pixel and line positions (DE is unused or tied low).
• DE Mode. Relies strictly on PCLK and DE to frame the active display area, allowing you to leave HSYNC and VSYNC disconnected to save two extra GPIO pins.
If you are translating a display datasheet into Raspberry Pi dpi_timings, share:
• Your panel's resolution and refresh rate
• The datasheet's timing table values (sync widths, porches, and clock polarity)

1. On-Board Controllers & Initialization

• Display Driver (ST7701 / ST7701S). A chip-on-glass (COG) RGB/MIPI driver supporting 480×640 resolution in 18-bit RGB666 mode. Because this panel requires gamma and voltage register configuration before accepting parallel RGB video, the Waveshare board includes a small onboard microcontroller (or uses the Raspberry Pi's Device Tree overlay waveshare-28dpi on boot) to send a short 3-wire SPI initialization sequence to the ST7701, after which it switches purely to DPI666 mode.
• Touch Controller (GT911). A 5-point capacitive touch IC connected to the Raspberry Pi via bit-banged or hardware I2C (configured via the waveshare-touch-28dpi overlay).

2. Exact Timing Parameters (480×640 @ 60Hz)

From Waveshare's official hdmi_timings configuration (480 0 26 16 10 640 0 25 10 15 0 0 0 60 0 32000000 1) and dpi_output_format=0x7F216, the panel uses the following exact timing values:

```
Parameter	                    Horizontal (in PCLK cycles)	        Vertical (in HSYNC lines)
Active Display Area	            480 pixels	                        640 lines
Front Porch (HFP / VFP)	        26 clocks	                        25 lines
Sync Pulse Width (HSW / VSW)	16 clocks	                        10 lines
Back Porch (HBP / VBP)	        10 clocks	                        15 lines
Total Period	                532 clocks/line	                    690 lines/frame
Sync Polarity	                Active Low (Inverted)	            Active Low (Inverted)
```

• Pixel Clock (PCLK). 32 MHz (32,000,000 Hz), sampled on the falling edge (PCLK inverted), yielding ~87 Hz theoretical max or locked to 60 Hz with frame blanking.
• Color Format. RGB666 (mode 6 — 18-bit parallel RGB across GPIOs 4–9 for Blue, 12–17 for Green, and 20–25 for Red).

3. Timing Diagram for the Waveshare 2.8" DPI LCD

Because dpi_output_format=0x7F216 inverts HSYNC, VSYNC, and PCLK (while keeping DE Active High), the actual electrical waveform on the 40-pin header looks like this:
text

VSYNC  ‾‾‾\_______/‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\___

          |<10 ln>|<- 15 ln ->|<------- 640 Active Lines -------->|<-25 ln->|

          (VSW=10)  (VBP=15)                                        (VFP=25)

HSYNC  ‾‾‾\_______/‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\___

          |<16clk>|<- 10clk ->|<------- 480 Active Pixels ------->|<-26clk->|

          (HSW=16)  (HBP=10)                                        (HFP=26)

DE     _______________________/‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\___________

                              |   Valid RGB666 Pixel Data (480)   |

RGB666 XXXXXXXXXXXXXXXXXXXXXXX| P0 | P1 | P2 | ... | P478 | P479  |XXXXXXXXXXX

PCLK   ‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_

        ^ Data latched on falling edge (32 MHz)




1. 40-Pin Header Pinout (FPGA to LCD)

All logic signals operate at 3.3V LVCMOS. Connect your FPGA I/O bank directly to the Waveshare 40-pin female header:

RPi Header Pin	                Signal Name	            FPGA Direction	            Notes
2, 4	                        5V	Power Supply	                            Feeds onboard 3.3V LDO & backlight boost circuit
6, 9, 14, 20, 25, 30, 34, 39    GND	Ground	                                    Common ground reference
12	                            PWM (Backlight)	        Output	                Drive 1 (3.3V) for full brightness, or PWM for dimming
27	                            LCD_CLK (PCLK)	        Output	                32 MHz pixel clock (data latched on falling edge)
28	                            DE	                    Output	                Data Enable (Active High)
5	                            HSYNC	                Output	                Horizontal Sync (Active Low)
3	                            VSYNC	                Output	                Vertical Sync (Active Low)
38, 40, 15, 16, 18, 22	        R[2:7] (R[0:5])         Output	                Red 6-bit channel (Pin 38 = LSB R2, Pin 22 = MSB R7)
32, 33, 8, 10, 36, 11	        G[2:7] (G[0:5])	        Output	                Green 6-bit channel (Pin 32 = LSB G2, Pin 11 = MSB G7)
7, 29, 31, 26, 24, 21	        B[2:7] (B[0:5])	        Output	                Blue 6-bit channel (Pin 7 = LSB B2, Pin 21 = MSB B7)
19, 23, 13	                    TP_SDA, TP_SCL, TP_INT  Bidir/Input	        Optional I2C bus (0x5D or 0x14) for the GT911 touch controller

(Note: Pins 17, 35, and 37 are Not Connected (NC). Note also that Waveshare's silkscreen labels the 6 color bits per channel as [2..7] because they correspond to the upper 6 bits of an 8-bit RGB888 channel).

2. FPGA RTL Timing & Clocking Architecture

• PLL / MMCM Clock. Generate a 32.0 MHz pixel clock (pclk). If 32 MHz isn't exact on your oscillator, anything between 22 MHz and 32 MHz works cleanly (e.g., 532 × 690 × 60 Hz ≈ 22.025 MHz minimum for 60 Hz).
• Clock Phase / Edge Alignment. Because the ST7701 samples RGB data on the falling edge of LCD_CLK, update your RGB, DE, HSYNC, and VSYNC registers on the rising edge of your internal 32 MHz clock and forward that same clock out to LCD_CLK (or use an ODDR primitive with a 180° phase shift). This guarantees a full half-period (~15.6 ns) of setup and hold time.
• Counter Boundaries:
	• Horizontal Counter (h_cnt: 0 to 531):
		• 0 to 15: HSYNC = 0 (HSW = 16)
		• 16 to 25: Back Porch (HBP = 10)
		• 26 to 505: Active Video (480 pixels)
		• 506 to 531: Front Porch (HFP = 26)
	• Vertical Counter (v_cnt: 0 to 689):
		• 0 to 9: VSYNC = 0 (VSW = 10)
		• 10 to 24: Back Porch (VBP = 15)
		• 25 to 664: Active Video (640 lines)
		• 665 to 689: Front Porch (VFP = 25)
	• Data Enable (DE): Assert DE = 1 strictly when (h_cnt >= 26 && h_cnt <= 505) && (v_cnt >= 25 && v_cnt <= 664).

3. Hardware Gotchas to Watch Out For

• Startup Delay. On power-up, the onboard MCU takes roughly 100–200 ms to bit-bang the SPI initialization sequence into the ST7701. Your FPGA can immediately begin streaming DPI video at power-on; the panel will simply lock onto the sync stream once the onboard MCU finishes its init routine.
• Portrait Native Orientation. The panel's native scan order is 480 wide × 640 tall (portrait). If your FPGA framebuffer is landscape (640×480), you must rotate your memory read addresses by 90° in RTL.
• No 3.3V Pin Required. Unlike standard Raspberry Pi HATs, this board pulls all its logic power from the 5V pins (Pins 2 & 4) via an onboard regulator—do not back-power the 3.3V rail.

