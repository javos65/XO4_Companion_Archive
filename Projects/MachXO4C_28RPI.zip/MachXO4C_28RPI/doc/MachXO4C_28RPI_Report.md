# MachXO4C_28RPI - DPI666 LCD Driver: Project Report

| | |
|---|---|
| Date | 2026-11-21 |
| Project | MachXO4C_28RPI (RTL-only Radiant project) |
| Device | LFMXO4-110HC-6BBG256I on the MachXO4 Companion Board Rev A |
| Tools | Lattice Radiant 2026.1.1 (Synplify Pro, Questa OEM, Reveal) |
| Status | **Working on the board**: bouncing red 8x8 block on the Waveshare 2.8" DPI LCD, design in internal flash |

---

## 1. Summary

The project drives a Waveshare 2.8" DPI LCD (480 x 640, ST7701S, RGB666) from the
MachXO4 Companion Board through the Raspberry Pi 40-pin HAT connector. The design consists of:

- **`dpi666_axis`**: an LCD driver block with an AXI4-Stream video input, a dual-clock line
  buffer and the DPI666 timing and output stage.
- **`lcd_test`**: a test block that produces the pixel clock, the reset and an AXI4-Stream
  video source showing a red 8x8 block that starts at pixel (0,0) and bounces around the screen.
- **`top_28rpi`**: the top level, which only connects the two blocks and the pins.

The first bring-up failed: the panel never showed the FPGA picture. Changes to the clock edge,
the timing and the start-up order did not help. Measurements with the Reveal logic analyzer,
including a pad read-back technique, showed that **HSYNC and VSYNC left the FPGA with the wrong
polarity**, although the RTL, the simulation and the synthesized netlist were correct. The
inverter in front of the two sync output registers was lost after synthesis. Moving the polarity
inversion one register earlier fixed the problem.

---

## 2. Hardware

| Item | Value |
|---|---|
| Board | MachXO4 Companion Board Rev A |
| FPGA | LFMXO4-110HC-6BBG256I |
| Board clock | 12 MHz on ball T9 |
| LCD | Waveshare 2.8" DPI LCD, 480 x 640 portrait, ST7701S, RGB666, on HAT40 (JP5) |
| LCD supply | 5 V from HAT pins 2 and 4 |
| I/O standard | LVCMOS33, all LCD pins in bank 1 |
| Pinout source | `doc/28RPI_Pinout.xlsx`, Table 1 |

### 2.1 LCD pin assignment

| Signal | HAT40 pin(s) | FPGA balls |
|---|---|---|
| LCD_CLK | 27 | P15 |
| DE | 28 | R16 |
| HSYNC | 5 | K16 |
| VSYNC | 3 | J15 |
| Backlight (PWM) | 12 | G16 |
| R2..R7 (`lcd_r_o[0..5]`) | 38, 40, 15, 16, 18, 22 | K12, J11, N15, K14, L14, M14 |
| G2..G7 (`lcd_g_o[0..5]`) | 32, 33, 8, 10, 36, 11 | H13, D16, H15, J12, J13, N16 |
| B2..B7 (`lcd_b_o[0..5]`) | 7, 29, 31, 26, 24, 21 | K15, M15, L13, L16, N14, M16 |

Board signals: `clk12_i` T9, `sw2_n_i` D10 (SW2), `led_n_o[0..3]` G14, E14, G15, G13
(LED1..LED4, active low). The touch controller pins (TP_SDA, TP_SCL, TP_INT) are not used.
An automatic cross-check of `constraints/top_28rpi.pdc` against Table 1 gave 0 mismatches.

### 2.2 Display timing used

The working timing is the one in Waveshare's `vc4-kms-dpi-2inch8` Raspberry Pi overlay:

| Parameter | Horizontal (pixel clocks) | Vertical (lines) |
|---|---|---|
| Active | 480 | 640 |
| Front porch | 65 | 25 |
| Sync pulse | 30 | 10 |
| Back porch | 65 | 25 |
| Total | 640 | 700 |
| Sync polarity | active low | active low |

DE is active high. The pixel clock is 26.88 MHz, which gives 60 Hz. With `PCLK_INV = 1`,
LCD_CLK is inverted, so the data changes on its falling edge and the panel samples on its
rising edge (overlay setting `pixelclk-active = 0`).

---

## 3. Design structure and connectivity

### 3.1 Hierarchy

```
top_28rpi                         rtl/top_28rpi.v               connections only
 |- u_test : lcd_test             rtl/lcd_test/lcd_test.v       test block
 |    |- u_pll : pll_pix          ip/pll_pix (Radiant PLL 3.0.1)
 |    '- u_seq : lcd_block_seq    rtl/lcd_test/lcd_block_seq.v
 '- u_lcd  : dpi666_axis          rtl/dpi666_axis/dpi666_axis.v DPI666 LCD driver
      |- u_timing : dpi666_timing rtl/dpi666_axis/dpi666_timing.v
      |- u_buf    : dpi666_axis_buf rtl/dpi666_axis/dpi666_axis_buf.v
      '- u_pclk_oddr : ODDRXE     (MachXO4 primitive)
```

### 3.2 Block diagram

```
            +--------------------------------- top_28rpi ----------------------------------+
 clk12_i -->|  +------------- u_test : lcd_test --------------+                            |
 sw2_n_i -->|  | PLL 12->26.88 MHz --------------------------+---> pclk ------+           |
            |  | reset (POR 2.4 ms, SW2 debounce, lock) -----+---> rst_n -----+           |
            |  |                                             |                |           |
            |  | lcd_block_seq (AXI4-Stream master)           |   +-- u_lcd : dpi666_axis --+--> lcd_pclk_o
            |  |   m_axis_tdata[17:0] ------------------------+-->| s_axis_tdata            |--> lcd_de_o
            |  |   m_axis_tvalid  ----------------------------+-->| s_axis_tvalid           |--> lcd_hsync_o
            |  |   m_axis_tready  <---------------------------+---| s_axis_tready           |--> lcd_vsync_o
            |  |   m_axis_tuser (start of frame) -------------+-->| s_axis_tuser            |--> lcd_r_o[5:0]
            |  |   m_axis_tlast (end of line) ----------------+-->| s_axis_tlast            |--> lcd_g_o[5:0]
            |  |                                             |   |                         |--> lcd_b_o[5:0]
            |  | LEDs <-- frame_start, underrun, sync_err <---+---| status outputs          |--> lcd_bl_o
 led_n_o <--|  +---------------------------------------------+   +-------------------------+   |
            +-----------------------------------------------------------------------------------+
```

### 3.3 Connections in `top_28rpi`

| Net | From | To | Width | Description |
|---|---|---|---|---|
| `clk12_i` | pin T9 | u_test | 1 | 12 MHz board clock |
| `sw2_n_i` | pin D10 | u_test | 1 | SW2, active low |
| `pclk` | u_test.pclk_o | u_lcd.pclk_i, u_lcd.s_axis_aclk | 1 | 26.88 MHz pixel clock (stream uses the same clock) |
| `rst_n` | u_test.rst_n_o | u_lcd.rst_n_i, u_lcd.s_axis_aresetn | 1 | Reset, active low |
| `axis_tdata` | u_test.m_axis_tdata | u_lcd.s_axis_tdata | 18 | Pixel {R[5:0], G[5:0], B[5:0]} |
| `axis_tvalid` | u_test | u_lcd | 1 | Pixel valid |
| `axis_tready` | u_lcd | u_test | 1 | Driver accepts the pixel |
| `axis_tuser` | u_test | u_lcd | 1 | Start of frame (pixel 0 of line 0) |
| `axis_tlast` | u_test | u_lcd | 1 | End of line (pixel 479) |
| `frame_start` | u_lcd.frame_start_o | u_test.frame_start_i | 1 | Frame pulse, for the LED heartbeat |
| `underrun` | u_lcd.underrun_o | u_test.underrun_i | 1 | Sticky underrun flag, to LED3 |
| `sync_err` | u_lcd.sync_err_o | u_test.sync_err_i | 1 | Sticky framing-error flag, to LED4 |
| `vblank` | u_lcd.vblank_o | (unused) | 1 | Vertical blanking |
| `lcd_*` | u_lcd | pins | 22 | LCD clock, DE, HSYNC, VSYNC, RGB, backlight |
| `led_n_o[3:0]` | u_test | pins | 4 | LED1..LED4 |

---

## 4. Block descriptions

### 4.1 `dpi666_axis` - DPI666 LCD driver (AXI4-Stream input)

**Function:** converts an AXI4-Stream pixel stream into DPI666 video for a parallel RGB panel.

**Ports**

| Group | Port | Dir | Width | Description |
|---|---|---|---|---|
| Pixel clock side | `pclk_i` | in | 1 | Pixel clock |
| | `rst_n_i` | in | 1 | Reset, active low, synchronised internally |
| AXI4-Stream slave | `s_axis_aclk` | in | 1 | Stream clock; may be asynchronous to `pclk_i` |
| | `s_axis_aresetn` | in | 1 | Stream reset, active low |
| | `s_axis_tdata` | in | 18 | {R[5:0], G[5:0], B[5:0]} |
| | `s_axis_tvalid` / `s_axis_tready` | in / out | 1 / 1 | Handshake; `tready` is low while 2 lines are waiting |
| | `s_axis_tuser` | in | 1 | Start of frame |
| | `s_axis_tlast` | in | 1 | End of line |
| Status | `frame_start_o` | out | 1 | One-clock pulse per frame |
| | `vblank_o` | out | 1 | Outside the active lines |
| | `underrun_o` | out | 1 | Sticky: a line was not ready in time (shown black) |
| | `sync_err_o` | out | 1 | Sticky: line length, start-of-frame position, or lines discarded |
| LCD | `lcd_pclk_o` | out | 1 | LCD clock from ODDRXE |
| | `lcd_de_o`, `lcd_hsync_o`, `lcd_vsync_o` | out | 1 each | Control signals |
| | `lcd_r_o`, `lcd_g_o`, `lcd_b_o` | out | 6 each | Colour data, 0 outside DE |
| | `lcd_bl_o` | out | 1 | Backlight level |

**Parameters:** `H_ACTIVE`, `H_SYNC`, `H_BP`, `H_FP` (480/30/65/65), `V_ACTIVE`, `V_SYNC`,
`V_BP`, `V_FP` (640/10/25/25), `HS_POL`, `VS_POL` (0), `DE_POL` (1), `PCLK_INV` (1), `BL_ON` (1).
Limits: `H_ACTIVE` <= 512, `V_ACTIVE` <= 1023.

**Internal structure**

| Sub-block | Function |
|---|---|
| `dpi666_timing` | Horizontal and vertical counters; HSYNC, VSYNC and DE; frame and line pulses |
| `dpi666_axis_buf` | Dual-clock line buffer: 2 banks x 512 x 18 bits, write on `s_axis_aclk`, read on `pclk_i` (EBR) |
| Stream side | Writes line k into bank k[0] when fewer than 2 lines are waiting; counts pixels; marks lines that carry `tuser` |
| Clock-domain crossing | Line counters (written and consumed) cross as Gray code through 2-flip-flop synchronisers |
| Pixel side | At the start of each active row, checks that a line is ready and that the start-of-frame flag matches line 0; shows it or shows black; frees the bank after the row |
| Resynchronisation | Outside the active lines, waiting lines without the start-of-frame flag are discarded, so the block locks to the next frame start after a framing error |
| Output stage | Pin polarity applied in fabric registers (`de_lvl`, `hs_lvl`, `vs_lvl`); I/O-cell output registers are plain copies; LCD_CLK through `ODDRXE` |

Pipeline from the timing counters to the pins: 3 clocks (timing registers, line-buffer read,
I/O registers), equal for data and control signals.

### 4.2 `lcd_test` - test block

| Part | Function |
|---|---|
| `pll_pix` | Radiant PLL 3.0.1, fractional-N, 12 MHz to 26.88007 MHz (integer dividers cannot reach this frequency) |
| Reset | PLL lock synchroniser, SW2 debounce (2^18 clocks = 9.8 ms), power-on counter (2^16 clocks = 2.4 ms); `rst_n_o` released only with lock |
| `lcd_block_seq` | AXI4-Stream master (see 4.3) |
| LEDs | LED1 = PLL lock, LED2 = frame heartbeat (toggles every 32 frames), LED3 = underrun, LED4 = sync error |

### 4.3 `lcd_block_seq` - bouncing-block video source

- **Picture:** black frame of 480 x 640 pixels with one red 8x8 block (`{6'h3F, 0, 0}`).
- **Movement:** the block starts at pixel (0,0) in frame 0. After each frame it moves `STEP` = 2
  pixels in x and y, and reverses direction at the frame edges (x 0..472, y 0..632).
- **AXI4-Stream:** `tuser` on pixel (0,0), `tlast` on pixel 479 of every line. `tdata`, `tuser`
  and `tlast` change only after an accepted beat. `en_i` can gate `tvalid` (used by the testbench
  to insert idle cycles).

---

## 5. Constraints and implementation

| File | Content |
|---|---|
| `constraints/top_28rpi.sdc` | `create_clock` 83.333 ns on `clk12_i`; false paths for SW2 and the LEDs/backlight. The PLL output is derived by the tools (`pclk`, 26.88 MHz). |
| `constraints/top_28rpi.pdc` | Pin locations per section 2.1, LVCMOS33, 8 mA, fast slew on the LCD pins |

Build results (Synplify Pro, current design):

| Item | Result |
|---|---|
| Timing | 0 failing endpoints in all corners (setup 100 C and -40 C, hold -40 C) |
| Registers | 228 (9 in PIO output cells) |
| LUT4 | 469 |
| EBR | 1 (only red content; a full-colour source uses 2) |
| PLL | 1 of 2 |
| ODDR | 1 |
| Constraint coverage | 98.8 %; the uncovered paths are the LCD outputs, which are source-synchronous with LCD_CLK (output registers in the I/O cells, half a pixel clock of margin) |

Programming files: `constraints/program_sram.xcf` (SRAM) and `constraints/program_flash.xcf`
(internal flash; the JEDEC checksum must be updated after each rebuild, currently 0x0A82).

---

## 6. Verification

| Testbench | Scope | Result |
|---|---|---|
| `sim/tb_axis.v` | `dpi666_axis` + `lcd_block_seq`; stream clock 40 MHz asynchronous to the 26.88 MHz pixel clock; about 25 % random idle cycles on the stream | 5 frames, block at (0,0), (2,2), (4,4), (6,6), (8,8); 1 536 000 pixel compares, 0 errors; HSYNC active low, 30 clocks; no underrun or sync error |
| `sim/tb_axis.v` (bounce) | Small sequencer 16 x 12, step 3, 40 frames, against an independent model | 0 position errors |
| `sim/tb_top.v` | Full board top with the PLL simulation model | Block at (0,0), (2,2), (4,4); all other pixels black; 640 lines per frame; LED3 and LED4 off |
| `sim/tb_dpi666.v` | First driver version (line handshake), kept for reference | 24 509 checks, 1 228 800 pixel compares, 0 errors |

The MachXO4 `ODDRXE` simulation model requires `GSR GSR_INST` and `PUR PUR_INST` instances in
the testbench top.

---

## 7. Bring-up and the Reveal debug exercise

### 7.1 Symptom

After the first build (32 MHz timing from `WS_RPI28_LCD.md`), the panel showed static coloured
lines. These were first taken as a success, but they turned out to be the panel's own picture:

- **Orientation:** the lines ran along the 640-pixel (long) side, while the FPGA writes one colour
  per 480-pixel scanline. That picture cannot come from the FPGA data.
- **Before programming:** the same picture was there before the FPGA was programmed.

So the panel ignored the FPGA video completely.

### 7.2 Changes that did not help

| Attempt | Result |
|---|---|
| LCD_CLK inverted (`PCLK_INV` 0 to 1), as the document's "PCLK inverted" and Waveshare's overlay suggest | Same static picture |
| Design programmed into flash, full power-cycle, so video is present when the panel powers up | Same static picture |
| Pinout cross-checked against Table 1 | 0 mismatches |
| Waveshare KMS overlay timing: 26.88 MHz, porches 65/30/65 and 25/10/25 | Same static picture |

Research into Waveshare's material found no host-side start-up sequence for the ST7701S, so the
panel must start up by itself on the LCD board.

### 7.3 Reveal setup

A Reveal logic analyzer core was inserted with the pixel clock as sample clock.

| Item | Setting |
|---|---|
| Probes | `u_timing` HSYNC, VSYNC, DE, `h_cnt[10:0]`, `v_cnt[10:0]`; underrun, line-buffer request and done; reset; PLL lock |
| Clock reference | `dbg_ref_1us`: a toggle from the 12 MHz board clock, 1 us high and 1 us low, synchronised into the pixel-clock domain. Its high and low lengths in samples give the pixel-clock frequency. |
| Buffer | 8192 samples (about 12.8 lines) |
| Triggers | TU1 VSYNC, TU2 HSYNC, TU3 underrun |

The Reveal core needed extra constraints on this board:

- `ldc_set_sysconfig {JTAG_PORT=ENABLE}`
- `IO_TYPE=LVCMOS33` on TCK, TMS, TDI and TDO; without these, place and route could not place the JTAG pins
- the false path from the 12 MHz clock to `pclk` in the PDC, not the SDC, because the PLL clock exists only after synthesis

The trigger values (TU value, TE enable) are stored in `MachXO4C_28RPI_reveal.rvs`, and the
trigger position in the `.rva` file.

### 7.4 Captures of the internal timing

**test1** (trigger landed mid-frame, lines 139 to 151):

| Measurement | Measured | Expected |
|---|---|---|
| `dbg_ref_1us` half-period | 27 samples, every 8th one 26 (average 26.875 per us) | 26.88 MHz |
| `h_cnt` continuity | 7680 steps, all +1 | no gaps |
| HSYNC active | 30 samples at h 0 to 29 | 30 |
| Line period | 640 samples | 640 |
| DE | 480 samples, h 95 to 574 | 95 to 574 |
| Line buffer | request at h 0, done at h 482, every line | done before the next line |
| Underrun, lock, reset | 0, 1, 1 | 0, 1, 1 |

**test2** (trigger VSYNC = 1, trigger at the start of the window):

| Measurement | Measured | Expected |
|---|---|---|
| VSYNC active | 6400 samples = 10 lines, v 0 to 9 | 10 lines |
| HSYNC during VSYNC | continues, 30/640 | yes |
| DE in lines 0 to 12 | never | first active line 35 |

Conclusion of test1 and test2: **the logic inside the FPGA generated exactly the intended
timing.** The fault had to be after the logic: the output stage, the pins, or the panel.

### 7.5 Pad read-back (test3)

Reveal cannot see pins, so the LCD outputs were temporarily turned into bidirectional pads:

- every LCD data and control pin became a `BB` buffer with `T = 0` (always driving);
- the input side of each pad, which returns the level actually on the pin, was registered on the
  pixel clock into `pad_rb[21:0]` = {backlight, VSYNC, HSYNC, DE, B[5:0], G[5:0], R[5:0]};
- Reveal sampled `pad_rb` next to the internal timing signals; trigger DE = 1, 4096 samples.

Result (compared with the internal signals at the best-matching delay of 3 clocks):

| Pin | Measured at the pad | Intended | Result |
|---|---|---|---|
| DE | high exactly during active pixels | active high | correct |
| R, G, B (18 pins) | one colour per line, correct stripe order, 0 outside DE | as designed | correct |
| Backlight | 1 | 1 | correct |
| **HSYNC** | **high 30 clocks, low 610** | low 30, high 610 | **inverted** |
| **VSYNC** | **low outside the sync pulse** | high outside the pulse | **inverted** |

### 7.6 Root cause

The original output stage applied the sync polarity in the expression feeding the I/O register:

```verilog
lcd_hsync_o <= hs_d ? HS_POL : !HS_POL;     // HS_POL = 0 -> inverter in front of the I/O register
```

- **RTL simulation:** active-low syncs.
- **Synthesized netlist (`.vm`):** correct, `hs_d -> INV -> OFS1P3DX (I/O register) -> pad`.
- **Pins on the hardware:** non-inverted. The inverter in front of the HSYNC and VSYNC I/O
  registers was lost after synthesis (in map, place and route or bitstream generation).
- **Unaffected outputs:** DE and RGB have no inverter in front of their I/O registers and were
  correct.

So in every earlier build the panel received active-high syncs and could never lock. That also
explains why changes to the clock edge, the timing and the start-up order had no effect.

### 7.7 Fix

The polarity is now applied one register earlier, in fabric registers. The I/O registers only copy
a value that already has the right polarity:

```verilog
hs_lvl <= t_hs ? HS_ON : ~HS_ON;            // fabric register (T2)
...
lcd_hsync_o <= hs_lvl;                      // I/O register (T3): plain copy
```

The netlist confirms `OFS1P3DX .D(hs_lvl)` with no logic in between. After this change the panel
showed the picture immediately.

**Design rule kept in the driver:** no logic between the last fabric register and an I/O-packed
output register.

After the fix, the Reveal core, the pad read-back and the 1 us reference were removed again.

---

## 8. Other findings

| Topic | Finding |
|---|---|
| PLL | The MachXO4 PLL with a 12 MHz reference cannot make 32 MHz or 26.88 MHz with integer dividers (it picks 36 MHz); fractional-N gives 32.00006 MHz and 26.88007 MHz. |
| Start-up delay | From power-on, the first picture appears after about 5 seconds, with the block already halfway across the screen. The FPGA is running immediately; the delay is the LCD board starting its panel. SW2 (FPGA logic reset only) restarts the picture instantly. The header has no reset or start-up line for the panel, so the FPGA cannot shorten this. |
| Document `WS_RPI28_LCD.md` | Its 32 MHz timing gives 87 Hz, not 60 Hz. The verified timing is Waveshare's KMS overlay timing. |
| Synthesis notes | With red-only content, synthesis removes the constant green and blue data path (1 EBR instead of 2, 9 instead of 21 output registers). |
| LEDs | During debugging, the reported LED states did not match the design's LED logic in one case; the LEDs were not used for diagnosis. |
| IP package | An IP Packager `.ipk` (`custom:module:dpi666_axis:1.0.0`) was built, but Radiant reports it as corrupt. It is not used; the project uses the RTL directly. Copies remain in PropelIPLocal and RadiantIPLocal. |

---

## 9. Project files

| Path | Content |
|---|---|
| `rtl/top_28rpi.v` | Top level, connections only |
| `rtl/dpi666_axis/dpi666_axis.v`, `dpi666_axis_buf.v`, `dpi666_timing.v` | LCD driver |
| `rtl/lcd_test/lcd_test.v`, `lcd_block_seq.v` | Test block and bouncing-block source |
| `ip/pll_pix/` | PLL 12 to 26.88 MHz |
| `constraints/top_28rpi.sdc`, `top_28rpi.pdc` | Timing and pin constraints |
| `constraints/program_sram.xcf`, `program_flash.xcf` | Programming chain files |
| `sim/tb_axis.v`, `sim/tb_top.v` (+ file lists) | Testbenches |
| `radiant_setup.tcl`, `MachXO4C_28RPI.rdf` | Project setup and Radiant project |
| `test1/2/3.rva`, `.trc` | Reveal captures from the debug exercise |
| `doc/DPI666_LCD_Plan.md` | Original plan and status log |
| `rtl/dpi666_lcd/`, `rtl/lcd_test_pattern.v`, `rtl/lcd_line_color.v` | First driver version (line handshake), no longer in the project |

---

## 10. Open items

- The asynchronous stream clock and the resynchronisation after a framing error are verified in
  simulation only, not on hardware.
- The backlight could be kept off for the first seconds after power-on to hide the LCD board's
  start-up picture.
- The IP package is not usable in its current form.
