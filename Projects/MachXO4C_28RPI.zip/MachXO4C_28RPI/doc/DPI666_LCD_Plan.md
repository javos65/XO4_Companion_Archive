# DPI666 LCD Driver Block - Design Plan

Target: Waveshare 2.8" 480x640 DPI LCD (ST7701S) on the RPi 40-pin HAT connector of the
MachXO4 Companion Board Rev A, device LFMXO4-110HC-6BBG256I, Radiant 2026.1.1.

Sources: `doc/WS_RPI28_LCD.md` (timing), `doc/28RPI_Pinout.xlsx` Table 1 (pins),
`doc/XO4_Companion_Mapping.xlsx` (clock, LEDs, switches).

---

## 1. Architecture

```
 12 MHz (T9) -> PLL -> pclk 32 MHz ---------------------------------------------+
                                                                                 |
 +-------------------- top_28rpi -----------------------------------------------|---+
 |                                                                               v   |
 |  lcd_test_pattern (FSM)            dpi666_lcd (IP block)                          |
 |  +--------------------+  fill_req  +--------------------------------------+      |
 |  | WAIT_REQ -> FILL   |<-----------| dpi666_timing  (h_cnt 0..531,        |      |
 |  | -> DONE            | fill_line  |                 v_cnt 0..689)        |      |
 |  | color = f(line,    |<-----------|                                      |      |
 |  |          mode)     | wr_en/addr | line buffer: 2 x 512x18 EBR          |----> LCD_CLK (ODDR)
 |  |                    |----------->| (ping-pong, bank = line[0])          |----> DE, HSYNC, VSYNC
 |  |                    | wr_data18  |                                      |----> R/G/B[5:0]
 |  |                    | fill_done  | output pipeline (IO registers)       |      |
 |  +--------------------+----------->+--------------------------------------+      |
 |      ^ DIP_SW1/2 (pattern mode)        status: frame_start, underrun, vblank     |
 +-----------------------------------------------------------------------------------+
```

### 1.1 IP block `dpi666_lcd` (reusable)

| Port group | Signals | Notes |
|---|---|---|
| Clock/reset | `pclk_i`, `rst_n_i` | Pixel clock 32 MHz (parameterisable) |
| Buffer write (18-bit 666 input) | `wr_en_i`, `wr_addr_i[8:0]` (0..479), `wr_data_i[17:0]` = {R[5:0],G[5:0],B[5:0]} | Writes go to the *back* bank |
| Line handshake | `fill_req_o` (1-clk pulse), `fill_line_o[9:0]` (0..639), `fill_done_i` | Request for line N+1 issued at h_cnt=0 of the line that displays line N |
| Status | `frame_start_o`, `line_start_o`, `vblank_o`, `underrun_o` (sticky) | underrun = line displayed before `fill_done_i` |
| LCD pins | `lcd_pclk_o`, `lcd_de_o`, `lcd_hsync_o`, `lcd_vsync_o`, `lcd_r_o[5:0]`, `lcd_g_o[5:0]`, `lcd_b_o[5:0]`, `lcd_bl_o` | |

Parameters (defaults from `WS_RPI28_LCD.md`):

| Parameter | Default | Parameter | Default |
|---|---|---|---|
| H_ACTIVE | 480 | V_ACTIVE | 640 |
| H_SYNC | 16 | V_SYNC | 10 |
| H_BP | 10 | V_BP | 15 |
| H_FP | 26 | V_FP | 25 |
| HS_POL / VS_POL | 0 (active low) | DE_POL | 1 (active high) |
| PCLK_INV | 0 (data changes on rising, LCD samples on falling) | BL_ON | 1 |

Sub-modules:
- `dpi666_timing.v` - h/v counters, sync/DE generation, fill request generation.
- `dpi666_linebuf.v` - two 512x18 pseudo-dual-port EBRs (inferred RAM, one EBR per line), write port selects bank `~disp_line[0]`, read port bank `disp_line[0]`.
- `dpi666_lcd.v` - top of the IP: read address `h_cnt-26`, EBR read latency compensated by delaying DE/HSYNC/VSYNC the same number of clocks, all outputs in I/O registers, LCD clock forwarded through an `ODDRX1` with D0/D1 = 1/0 (swapped when PCLK_INV=1).

Line-buffer timing: the writer receives `fill_req` at h_cnt=0 and has the full 532-clock line to write 480 pixels (one pixel per clock); line 0 is requested during the last back-porch line (v_cnt=24).

### 1.2 Test state machine `lcd_test_pattern`

- States: `IDLE` -> `WAIT_REQ` -> `FILL` (480 writes, addr 0..479) -> `DONE` (pulse `fill_done`) -> `WAIT_REQ`.
- One solid color per line; color = f(`fill_line`, mode). Mode from DIP_SW1/DIP_SW2:

| Mode | Pattern |
|---|---|
| 00 | 8 horizontal bands of 80 lines: white, yellow, cyan, green, magenta, red, blue, black |
| 01 | Per-line gradient: each line a different color (R/G/B ramps derived from line number) |
| 10 | 8-color stripes cycling every line (`line[2:0]`), fine-pitch check of line alignment |
| 11 | Mode 00 scrolling by a frame counter (animation, proves frame sync) |

### 1.3 Board top `top_28rpi`

- PLL (Radiant IP `pll`): 12 MHz in -> CLKOP 32 MHz (12 x 8 / 3), lock output used as reset qualifier.
- Reset: power-on counter AND debounced SW2 (PB1, D10).
- LEDs (active low): LED1 = PLL lock, LED2 = frame heartbeat (~1 Hz), LED3 = underrun, LED4 = vblank activity.
- Backlight (pin 12) driven 1; touch pins (TP_SDA, TP_SCL, TP_INT) left as inputs with pull-ups, unused in v1.

---

## 2. Pin assignment (from `28RPI_Pinout.xlsx` Table 1, all Bank 1, LVCMOS33)

| Port | HAT pin -> Ball | Port | HAT pin -> Ball | Port | HAT pin -> Ball |
|---|---|---|---|---|---|
| lcd_r[0] (R2) | 38 -> K12 | lcd_g[0] (G2) | 32 -> H13 | lcd_b[0] (B2) | 7 -> K15 |
| lcd_r[1] (R3) | 40 -> J11 | lcd_g[1] (G3) | 33 -> D16 | lcd_b[1] (B3) | 29 -> M15 |
| lcd_r[2] (R4) | 15 -> N15 | lcd_g[2] (G4) | 8 -> H15 | lcd_b[2] (B4) | 31 -> L13 |
| lcd_r[3] (R5) | 16 -> K14 | lcd_g[3] (G5) | 10 -> J12 | lcd_b[3] (B5) | 26 -> L16 |
| lcd_r[4] (R6) | 18 -> L14 | lcd_g[4] (G6) | 36 -> J13 | lcd_b[4] (B6) | 24 -> N14 |
| lcd_r[5] (R7) | 22 -> M14 | lcd_g[5] (G7) | 11 -> N16 | lcd_b[5] (B7) | 21 -> M16 |
| lcd_pclk | 27 -> P15 | lcd_de | 28 -> R16 | lcd_bl | 12 -> G16 |
| lcd_hsync | 5 -> K16 | lcd_vsync | 3 -> J15 | tp_int | 13 -> K13 |
| tp_sda | 19 -> L15 | tp_scl | 23 -> P16 | | |

Board signals (from `XO4_Companion_Mapping.xlsx`): clk12_i T9, sw2_n_i D10, dip_i[0] B16, dip_i[1] C15,
led_n_o[0..3] G14, E14, G15, G13. HAT pins 35 (L12) and 37 (K11) are NC on the LCD and stay unused.

---

## 3. Project layout

```
MachXO4C_28RPI/
  rtl/dpi666_lcd/dpi666_lcd.v, dpi666_timing.v, dpi666_linebuf.v
  rtl/lcd_test_pattern.v
  rtl/top_28rpi.v
  ip/pll_32m/                      (Radiant IP generated PLL)
  constraints/top_28rpi.pdc        (pins, IO_TYPE, output register packing)
  constraints/top_28rpi.sdc        (create_clock 83.333 ns on clk12_i; PLL derived)
  sim/tb_dpi666.v                  (self-checking testbench)
  ip/package_dpi666/               (optional: IP Packager -> custom:module:dpi666_lcd:1.0.0 .ipk)
  MachXO4C_28RPI.rdf               (Radiant project)
```

---

## 4. Implementation steps

1. **RTL of the IP block** - timing generator, line buffer, output pipeline, parameters above; lint.
2. **Test pattern FSM** - four modes, `fill_done` handshake.
3. **Testbench** (`tb_dpi666`), self-checking, at least one full frame:
   - 532 PCLK per line, 690 lines per frame, HSYNC low 16 clocks, VSYNC low 10 lines.
   - DE high exactly 480 x 640 clocks, starting at h_cnt=26 / v_cnt=25.
   - Every pixel of display line L equals the expected color of L (catches latency/bank errors).
   - `underrun_o` stays 0.
4. **Top level + PLL** - generate PLL IP (12 -> 32 MHz), reset, LEDs, DIP mode.
5. **Constraints** - PDC per section 2, SDC clock; output registers packed into the I/O cells.
6. **Radiant build** - synthesis, map, PAR, bitstream; gates: 0 failing timing endpoints at 32 MHz, all I/O placed as listed, EBR use = 2.
7. **Hardware bring-up** - program SRAM, check bands (mode 00), stripes (mode 10), animation (mode 11); if the image is noisy/shifted, toggle `PCLK_INV` and rebuild.
8. **(Optional) Package as IP** - IP Packager `.ipk` (metadata, RTL, introduction.html) so the block appears in the Radiant/Propel IP catalog.

---

## 5. Implementation status (2026-11-20)
## 5. Implementation status (2026-11-20) - WORKING ON THE BOARD

| Item | Result |
|---|---|
| RTL | `rtl/dpi666_lcd/` (IP block), `rtl/lcd_line_color.v`, `rtl/lcd_test_pattern.v`, `rtl/top_28rpi.v` |
| Timing used | Waveshare `vc4-kms-dpi-2inch8` overlay: 26.88 MHz, h 480 / FP 65 / sync 30 / BP 65 (640), v 640 / FP 25 / sync 10 / BP 25 (700), 60 Hz; HSYNC/VSYNC active low, DE active high, `PCLK_INV = 1` (panel samples on the LCD_CLK rising edge) |
| PLL | `ip/pll_pix` (pll 3.0.1, fractional-N): 26.88007 MHz from 12 MHz. (`ip/pll_32m`, 32.00006 MHz, is no longer in the project.) |
| Test pattern | Fixed mode 1: 8 colours in stripes of 8 lines, moving down 8 lines per frame. No DIP switches. |
| Simulation | `sim/tb_dpi666.v` (IP + FSM): 24 509 checks, 1 228 800 pixel compares, 0 errors. `sim/tb_top.v` (board top with PLL model): 614 400 pixel compares, 0 errors, no underrun. |
| Build | `MachXO4C_28RPI.rdf`, Synplify; 0 failing endpoints in all corners; 149 registers (21 in PIO output cells), 218 LUT4, 2 EBR, 1 PLL, 1 ODDRX1 |
| Board | **Panel shows the moving stripes.** Clean build (no Reveal) in internal flash via `constraints/program_flash.xcf` (checksum 0x557B, update after every rebuild); SRAM via `constraints/program_sram.xcf`. |

### Root cause of the bring-up failure

The panel showed only its own static column pattern for every build until the
HSYNC/VSYNC polarity was fixed. Reveal pad read-back (`test3`) showed that HSYNC
and VSYNC reached the pins **active high** although the RTL, the simulation and
the synthesized netlist (`INV` in front of the `OFS1P3DX` I/O register) were all
active low; DE and RGB, with no logic in front of their I/O registers, were
correct. The inversion was lost after synthesis.

Fix in `dpi666_lcd.v`: the pin polarity is applied one register earlier
(`hs_lvl`, `vs_lvl`, `de_lvl` fabric registers), so the I/O registers are plain
copies. Rule for this IP: **never put logic between the last fabric register and
an I/O-packed output register.**

### Reveal measurements (debug build, now removed)

| Capture | Trigger | Result |
|---|---|---|
| test1 | (any) | pclk 26.875 samples/us = 26.88 MHz; HSYNC 30/640; DE h 95-574; fill done at h 482; no underrun |
| test2 | VSYNC = 1 | VSYNC v 0-9 (6400 samples); HSYNC continues; no DE in back porch |
| test3 | DE = 1 | pad read-back: DE, RGB, backlight correct; **HSYNC/VSYNC inverted** -> root cause |

Notes: the Reveal hub on MachXO4 needed `ldc_set_sysconfig {JTAG_PORT=ENABLE}`
and `IO_TYPE=LVCMOS33` on TCK/TMS/TDI/TDO; the 12 MHz -> pclk false path must be
in the PDC (the PLL clock does not exist when the SDC is read).

Differences from the original plan:
- LCD output registers have no reset, so that they pack into the PIO output flip-flops; they show idle levels one clock after reset asserts.
- The testbenches instantiate `GSR_INST` / `PUR_INST`, which the MachXO4 ODDRXE simulation model references.
- Touch pins TP_SDA / TP_SCL / TP_INT are not ports of the design.
- The LED mapping/polarity on the board did not match the reported LED states during debug; do not rely on the LEDs for diagnosis.

Constraint coverage waiver (95.2 %): the 21 LCD data/sync outputs have no `set_output_delay`. They are source-synchronous with LCD_CLK: every output register sits in its PIO cell, LCD_CLK comes from an ODDRX1 on the same clock in the same bank, and the panel samples on the opposite clock edge (about 18.6 ns window at 26.88 MHz). No ST7701S setup/hold figures are available in `doc/` to write a numeric constraint.

---

## 6. Open points

- **IP packaging**: the `.ipk` (step 8) is not done.
- **WS_RPI28_LCD.md accuracy**: its 32 MHz timing was not tested after the polarity fix; the Waveshare KMS timing is the verified one. The document's frame-rate note (60 Hz at 32 MHz) is wrong: 32 MHz gives 87.2 Hz.
- **Power**: the LCD takes 5 V from HAT pins 2/4; do not back-drive 3.3 V (JP10).

---

## 7. Library block with AXI4-Stream input (2026-11-20) - WORKING ON THE BOARD

| Item | Result |
|---|---|
| Block | `rtl/dpi666_axis/` (self-contained): `dpi666_axis.v`, `dpi666_axis_buf.v` (dual-clock 2 x 512 x 18 line buffer), `dpi666_timing.v` |
| Input | AXI4-Stream slave: `s_axis_tdata[17:0]` = {R,G,B}, `tvalid`, `tready`, `tuser` = start of frame, `tlast` = end of line, own clock `s_axis_aclk` (may be asynchronous) |
| Status | `frame_start_o`, `vblank_o`, `underrun_o` (sticky, line shown black), `sync_err_o` (sticky, framing error / resync) |
| Operation | Source may run up to 2 lines ahead (`tready` back-pressure); Gray-coded line counters cross the clock domains; a `tuser` line is shown only as display line 0, misaligned lines are discarded in blanking (self-resynchronising) |
| Test source | `rtl/lcd_block_seq.v`: black frame, red 8x8 block from pixel (0,0), +2/+2 per frame, bouncing |
| Simulation | `sim/tb_axis.v` (stream at async 40 MHz with ~25 % idle cycles): 5 frames, block at (0,0)..(8,8), 1 536 000 pixel compares, 0 errors; bounce rule 40 frames, 0 errors. `sim/tb_top.v` (board top with PLL): pass |
| Build | 0 failing endpoints; 228 registers, 469 LUT4, 1 EBR (red-only content; 2 EBR with full colour), 1 PLL |
| Board | In flash (`program_flash.xcf`, checksum 0x0F71): red block moves from the top-left corner as intended |

The old line-handshake block (`rtl/dpi666_lcd/`, `lcd_test_pattern.v`, `lcd_line_color.v`) is kept on disk but no longer in the project.

IP package (LCD driver only, no sequencer): `ip/package_dpi666_axis_1.0.0/custom_module_dpi666_axis_1.0.0.ipk`
= `custom:module:dpi666_axis:1.0.0`, built by `ip/package_dpi666_axis_1.0.0/package.ps1` (IP Packager `ippkg.exe`)
from the project RTL in `rtl/dpi666_axis/` plus `ip/custom_module_dpi666_axis_1.0.0/` (metadata.xml, bus_interface.xml,
doc/introduction.html). Bus interface AXIS_S0 = AXI4-Stream slave `amba.com:AMBA4:AXI4Stream:r0p0`; 13 settings
(timing, polarity, PCLK_INV, BL_ON); family LFMXO4. Not installed into the local IP catalog yet.

Still open: asynchronous stream clock and resynchronisation are verified in simulation only.
