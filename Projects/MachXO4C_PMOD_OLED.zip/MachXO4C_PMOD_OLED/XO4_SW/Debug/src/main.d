src/main.o: ../src/main.c \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/hal.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/pic.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/util.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/stack.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/reg_access.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/iob.h \
 ../src/utils.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/sys_platform.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/riscv_errors.h \
 ../src/platform_init.h ../src/device_info.h ../src/terminal.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/uart/uart.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/iob.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/ssd1306.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/utils.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/font_1bpp.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/ssd1306.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/gpio/gpio.h
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/hal.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/pic.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/util.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/stack.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/reg_access.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/iob.h:
../src/utils.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/sys_platform.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/riscv_errors.h:
../src/platform_init.h:
../src/device_info.h:
../src/terminal.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/uart/uart.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/iob.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/ssd1306.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/utils.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/font_1bpp.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/ssd1306.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/gpio/gpio.h:
