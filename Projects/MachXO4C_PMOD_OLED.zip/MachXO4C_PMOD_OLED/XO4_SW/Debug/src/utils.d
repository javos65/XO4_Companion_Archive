src/utils.o: ../src/utils.c ../src/utils.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/sys_platform.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/riscv_errors.h \
 ../src/platform_init.h
../src/utils.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/sys_platform.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/riscv_errors.h:
../src/platform_init.h:
