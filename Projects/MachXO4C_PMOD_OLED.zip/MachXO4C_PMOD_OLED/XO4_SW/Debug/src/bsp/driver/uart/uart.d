src/bsp/driver/uart/uart.o: ../src/bsp/driver/uart/uart.c \
 ../src/bsp/driver/uart/uart.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/hal.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/pic.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/util.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/stack.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/reg_access.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/iob.h
../src/bsp/driver/uart/uart.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/hal.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/pic.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/util.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/stack.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/reg_access.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/iob.h:
