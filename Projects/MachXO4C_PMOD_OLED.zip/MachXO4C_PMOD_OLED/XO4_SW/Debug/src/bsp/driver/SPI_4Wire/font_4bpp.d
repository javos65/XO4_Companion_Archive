src/bsp/driver/SPI_4Wire/font_4bpp.o: \
 ../src/bsp/driver/SPI_4Wire/font_4bpp.c \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/font_4bpp.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/ssd1351.h \
 ../src/bsp/driver/SPI_4Wire/ssd1351.h
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/font_4bpp.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/ssd1351.h:
../src/bsp/driver/SPI_4Wire/ssd1351.h:
