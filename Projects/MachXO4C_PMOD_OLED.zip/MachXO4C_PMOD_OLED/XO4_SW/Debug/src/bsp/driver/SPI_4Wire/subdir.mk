################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/bsp/driver/SPI_4Wire/font_1bpp.c \
../src/bsp/driver/SPI_4Wire/font_4bpp.c \
../src/bsp/driver/SPI_4Wire/ssd1306.c \
../src/bsp/driver/SPI_4Wire/ssd1351.c 

OBJS += \
./src/bsp/driver/SPI_4Wire/font_1bpp.o \
./src/bsp/driver/SPI_4Wire/font_4bpp.o \
./src/bsp/driver/SPI_4Wire/ssd1306.o \
./src/bsp/driver/SPI_4Wire/ssd1351.o 

C_DEPS += \
./src/bsp/driver/SPI_4Wire/font_1bpp.d \
./src/bsp/driver/SPI_4Wire/font_4bpp.d \
./src/bsp/driver/SPI_4Wire/ssd1306.d \
./src/bsp/driver/SPI_4Wire/ssd1351.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/SPI_4Wire/%.o: ../src/bsp/driver/SPI_4Wire/%.c src/bsp/driver/SPI_4Wire/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU RISC-V Cross C Compiler'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O0 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -Wframe-larger-than=2560  -g3 -DLSCC_STDIO_UART_APB -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/gpio" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/uart" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_INTEGER_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


