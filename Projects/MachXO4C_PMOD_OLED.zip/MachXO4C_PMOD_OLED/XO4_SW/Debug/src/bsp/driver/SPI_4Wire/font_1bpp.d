src/bsp/driver/SPI_4Wire/font_1bpp.o: \
 ../src/bsp/driver/SPI_4Wire/font_1bpp.c \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/font_1bpp.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/ssd1306.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/utils.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/sys_platform.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/riscv_errors.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/platform_init.h \
 ../src/bsp/driver/SPI_4Wire/ssd1306.h
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/font_1bpp.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire/ssd1306.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/utils.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/sys_platform.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/riscv_errors.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/platform_init.h:
../src/bsp/driver/SPI_4Wire/ssd1306.h:
