src/bsp/driver/gpio/gpio.o: ../src/bsp/driver/gpio/gpio.c \
 ../src/bsp/driver/gpio/gpio.h ../src/bsp/driver/gpio/gpio_regs.h \
 C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/reg_access.h
../src/bsp/driver/gpio/gpio.h:
../src/bsp/driver/gpio/gpio_regs.h:
C\:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm/reg_access.h:
