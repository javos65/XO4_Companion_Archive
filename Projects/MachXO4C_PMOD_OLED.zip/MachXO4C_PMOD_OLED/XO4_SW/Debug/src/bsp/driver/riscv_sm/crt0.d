src/bsp/driver/riscv_sm/crt0.o: ../src/bsp/driver/riscv_sm/crt0.S \
 ../src/bsp/driver/riscv_sm/stack.h
../src/bsp/driver/riscv_sm/stack.h:
