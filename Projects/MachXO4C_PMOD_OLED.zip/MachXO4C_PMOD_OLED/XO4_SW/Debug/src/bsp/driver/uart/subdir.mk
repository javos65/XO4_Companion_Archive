################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/bsp/driver/uart/uart.c 

OBJS += \
./src/bsp/driver/uart/uart.o 

C_DEPS += \
./src/bsp/driver/uart/uart.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/uart/%.o: ../src/bsp/driver/uart/%.c src/bsp/driver/uart/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU RISC-V Cross C Compiler'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O0 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -Wframe-larger-than=2560  -g3 -DLSCC_STDIO_UART_APB -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/SPI_4Wire" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/gpio" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/riscv_sm" -I"C:\lscc\workspace\MachXO4C_PMOD_OLED\XO4_SW/src/bsp/driver/uart" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_INTEGER_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


