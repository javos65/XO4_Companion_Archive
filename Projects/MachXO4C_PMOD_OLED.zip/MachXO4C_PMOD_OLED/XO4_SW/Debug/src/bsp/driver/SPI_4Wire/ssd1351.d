src/bsp/driver/SPI_4Wire/ssd1351.o: ../src/bsp/driver/SPI_4Wire/ssd1351.c \
 ../src/bsp/driver/SPI_4Wire/ssd1351.h
../src/bsp/driver/SPI_4Wire/ssd1351.h:
