# Simple serial terminal: COM13, 115200 8N1. Ctrl-C to quit.
# Typed keys are sent to the board. Press the board reset (rstn_i) to see the start-up message again.
param([string]$Port = 'COM13', [int]$Baud = 115200)

$sp = New-Object System.IO.Ports.SerialPort $Port, $Baud, 'None', 8, 'One'
$sp.ReadTimeout = 50
try {
    $sp.Open()
} catch {
    Write-Host "Cannot open $Port : $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "(port busy in another terminal, or the FTDI channel is different)"
    return
}
Write-Host "--- $Port $Baud 8N1 open. Ctrl-C to quit. ---" -ForegroundColor Green
try {
    while ($true) {
        try { $d = $sp.ReadExisting(); if ($d) { Write-Host -NoNewline $d } } catch {}
        if ([Console]::KeyAvailable) {
            $k = [Console]::ReadKey($true)
            $sp.Write([string]$k.KeyChar)
        }
        Start-Sleep -Milliseconds 20
    }
} finally {
    if ($sp.IsOpen) { $sp.Close() }
    Write-Host "`n--- closed ---"
}
