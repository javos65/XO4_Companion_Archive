"""Builds XO4_OLED_Project_Report.docx with the standard library only (OOXML by hand)."""
import os
import zipfile
from xml.sax.saxutils import escape
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, "fig")
OUT = os.path.join(HERE, "XO4_OLED_Project_Report.docx")

TEXT_W = 9026            # A4 with 1 inch margins, in dxa
NS = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
      'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
      'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"')

body = []
images = []          # (rid, filename)
_docpr = [100]


def run(text, bold=False, italic=False, size=None, color=None, mono=False):
    pr = ""
    if mono:
        pr += '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/>'
    if bold:
        pr += "<w:b/>"
    if italic:
        pr += "<w:i/>"
    if color:
        pr += f'<w:color w:val="{color}"/>'
    if size:
        pr += f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>'
    pr = f"<w:rPr>{pr}</w:rPr>" if pr else ""
    return f'<w:r>{pr}<w:t xml:space="preserve">{escape(text)}</w:t></w:r>'


def runs_from_markup(text, size=None):
    """Very small markup: **bold** and `mono` segments."""
    out, i = [], 0
    while i < len(text):
        if text.startswith("**", i):
            j = text.find("**", i + 2)
            out.append(run(text[i + 2:j], bold=True, size=size)); i = j + 2
        elif text[i] == "`":
            j = text.find("`", i + 1)
            out.append(run(text[i + 1:j], mono=True, size=size)); i = j + 1
        else:
            nxt = min([k for k in (text.find("**", i), text.find("`", i)) if k != -1] or [len(text)])
            out.append(run(text[i:nxt], size=size)); i = nxt
    return "".join(out)


def para(text="", style=None, align=None, keep_next=False, space_after=None, size=None):
    ppr = ""
    if style:
        ppr += f'<w:pStyle w:val="{style}"/>'
    if keep_next:
        ppr += "<w:keepNext/>"
    if space_after is not None:
        ppr += f'<w:spacing w:after="{space_after}"/>'
    if align:
        ppr += f'<w:jc w:val="{align}"/>'
    ppr = f"<w:pPr>{ppr}</w:pPr>" if ppr else ""
    body.append(f"<w:p>{ppr}{runs_from_markup(text, size)}</w:p>")


def h1(t): para(t, "Heading1")
def h2(t): para(t, "Heading2")
def h3(t): para(t, "Heading3")


def bullets(items, level=0):
    for t in items:
        body.append(f'<w:p><w:pPr><w:pStyle w:val="ListBullet"/><w:numPr><w:ilvl w:val="{level}"/>'
                    f'<w:numId w:val="1"/></w:numPr></w:pPr>{runs_from_markup(t)}</w:p>')


def page_break():
    body.append('<w:p><w:r><w:br w:type="page"/></w:r></w:p>')


def table(rows, widths, header=True, size=17, shade_first_col=False):
    assert sum(widths) == TEXT_W, (sum(widths), TEXT_W)
    grid = "".join(f'<w:gridCol w:w="{w}"/>' for w in widths)
    out = [f'<w:tbl><w:tblPr><w:tblW w:w="{TEXT_W}" w:type="dxa"/><w:tblBorders>'
           '<w:top w:val="single" w:sz="4" w:space="0" w:color="808080"/>'
           '<w:left w:val="single" w:sz="4" w:space="0" w:color="808080"/>'
           '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="808080"/>'
           '<w:right w:val="single" w:sz="4" w:space="0" w:color="808080"/>'
           '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/>'
           '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/></w:tblBorders>'
           '<w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="40" w:type="dxa"/>'
           '<w:left w:w="90" w:type="dxa"/><w:bottom w:w="40" w:type="dxa"/>'
           '<w:right w:w="90" w:type="dxa"/></w:tblCellMar></w:tblPr>'
           f"<w:tblGrid>{grid}</w:tblGrid>"]
    for ri, row in enumerate(rows):
        is_head = header and ri == 0
        trpr = "<w:trPr><w:cantSplit/>" + ("<w:tblHeader/>" if is_head else "") + "</w:trPr>"
        cells = []
        for ci, cell in enumerate(row):
            shade = ""
            if is_head:
                shade = '<w:shd w:val="clear" w:color="auto" w:fill="1F3864"/>'
            elif shade_first_col and ci == 0:
                shade = '<w:shd w:val="clear" w:color="auto" w:fill="EDEDED"/>'
            paras = []
            for line in str(cell).split("\n"):
                if is_head:
                    r = run(line, bold=True, size=size, color="FFFFFF")
                else:
                    r = runs_from_markup(line, size=size)
                paras.append(f'<w:p><w:pPr><w:spacing w:after="0"/></w:pPr>{r}</w:p>')
            cells.append(f'<w:tc><w:tcPr><w:tcW w:w="{widths[ci]}" w:type="dxa"/>{shade}</w:tcPr>{"".join(paras)}</w:tc>')
        out.append(f"<w:tr>{trpr}{''.join(cells)}</w:tr>")
    out.append("</w:tbl>")
    body.append("".join(out))
    body.append('<w:p><w:pPr><w:spacing w:after="60"/></w:pPr></w:p>')


def figure(filename, caption, alt, width_in=6.2):
    path = os.path.join(FIG, filename)
    with Image.open(path) as im:
        w, h = im.size
    cx = int(width_in * 914400)
    cy = int(cx * h / w)
    rid = f"rIdImg{len(images) + 1}"
    images.append((rid, filename))
    _docpr[0] += 1
    did = _docpr[0]
    drawing = (
        f'<w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/>'
        f'<wp:docPr id="{did}" name="{escape(filename)}" descr="{escape(alt)}"/>'
        '<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>'
        '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        f'<pic:pic><pic:nvPicPr><pic:cNvPr id="{did}" name="{escape(filename)}"/><pic:cNvPicPr/></pic:nvPicPr>'
        f'<pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
        f'<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>'
        '</a:graphicData></a:graphic></wp:inline></w:drawing>')
    body.append(f'<w:p><w:pPr><w:keepNext/><w:spacing w:before="120" w:after="60"/><w:jc w:val="center"/></w:pPr>'
                f"<w:r>{drawing}</w:r></w:p>")
    para(caption, "Caption", align="center")


# =====================================================================  CONTENT
def build_content():
    # ---- title block
    para("MachXO4 Companion Board", "Title")
    para("RISC-V SoC with UART, GPIO LEDs and a 4-Wire SPI OLED Interface", "Subtitle")
    para("Project report", "Subtitle")
    table([
        ["Item", "Value"],
        ["Document", "Project report, version 1.0, status: draft for review"],
        ["Date", "21 November 2026"],
        ["Target device", "Lattice LFMXO4-110HC-6BBG256I on the MachXO4 Companion board"],
        ["Design tools", "Lattice Propel 2026.1.1, Lattice Radiant 2026.1.1 (Synplify Pro X-2025.09LR-SP1), "
                         "Questa Lattice OEM 2025.2, RISC-V GNU toolchain 10.2.0"],
        ["Project folder", "Workspace folder MachXO4C_PMOD_OLED (Soc_HW, XO4_SW, custom_IP, doc)"],
        ["Internal policy references", "None. No company policy document was used in preparing this report."],
    ], [2200, 6826], shade_first_col=True, size=18)

    # ---- contents (static)
    h1("Contents")
    bullets([
        "1  Executive summary",
        "2  Scope and requirements",
        "3  Hardware platform and pin assignment",
        "4  System architecture",
        "5  Address map",
        "6  Custom IP: oled_4wire",
        "7  Firmware and BSP drivers",
        "8  Design flow and tools",
        "9  Verification and results",
        "10  Issues found in the original design and their resolution",
        "11  Open items and recommendations",
        "12  References and compliance",
    ])

    # ---- 1
    h1("1  Executive summary")
    bullets([
        "The project delivers a RISC-V system on chip for the MachXO4 Companion board with a serial console "
        "through the on-board FTDI device, four LEDs on GPIO and a 4-wire SPI interface to a Digilent Pmod OLED "
        "(SSD1306 controller, 128 x 32 pixels).",
        "A new custom IP, **oled_4wire** version 1.0.0, was written in VHDL, simulated, packaged as an .ipk file "
        "and installed in the Propel catalogue. It replaces the earlier SPI block, which could not be synthesised.",
        "The SoC was regenerated with the new IP, with the CPU reset gated by the PLL lock signal, and with the "
        "new firmware image embedded in the system memory.",
        "The Radiant flow (synthesis, map, place and route, bitstream) completes without errors. Setup and hold "
        "timing show no failing endpoints. The bitstream was programmed to SRAM and then to the internal flash.",
        "The LEDs run on the board (user observation). The OLED picture and the UART console output were not "
        "independently verified for this report; see section 9.4.",
        "Several faults in the original design were found and corrected, among them: a multiple-driver error in "
        "the FIFO, display power switches held permanently off, a wrong D/C# pin, and a delay routine calibrated "
        "for the wrong clock frequency (section 10).",
    ])

    # ---- 2
    h1("2  Scope and requirements")
    table([
        ["No.", "Requirement", "Implementation", "Status"],
        ["R1", "Serial console through the FTDI device", "uart0, 115200 baud, 8N1, pins B11 (RX) and A12 (TX)",
         "Built and programmed. Console output not confirmed."],
        ["R2", "Four LEDs on GPIO", "gpio0, four output lines on pins G14, E14, G15, G13",
         "LEDs run (user observation)."],
        ["R3", "4-wire SPI interface to an SSD1306 OLED", "Custom IP oled_4wire with FIFO, SPI shifter and "
         "software-controlled power pins", "Simulated and built. Display not confirmed."],
        ["R4", "Package the 4-wire SPI IP as an .ipk file", "oled_4wire 1.0.0 package, installed in the Propel catalogue",
         "Complete."],
        ["R5", "Driver set for the BSP and a main program", "ssd1306 and font_1bpp drivers, main.c, same call names "
         "as the earlier driver", "Complete. Compiles without errors."],
        ["R6", "Load the firmware and run Radiant, check errors", "System memory initialised from the firmware image; "
         "full Radiant flow run", "Complete. No errors."],
        ["R7", "Program the device", "SRAM test, then internal flash (Erase, Program, Verify)", "Complete."],
    ], [600, 2500, 3426, 2500], size=17)

    # ---- 3
    h1("3  Hardware platform and pin assignment")
    para("The design targets the LFMXO4-110HC-6BBG256I device on the MachXO4 Companion board. The Pmod OLED plugs "
         "directly into PMOD connector J14, so each Pmod OLED pin number equals the PMOD pin number. The pin "
         "assignment follows the board mapping sheet and the Digilent Pmod OLED schematic (document 500-222, "
         "revision A). All signals use the LVCMOS33 I/O standard.")
    table([
        ["Signal", "Dir.", "FPGA pin", "Board function", "Note"],
        ["12Mhz_i", "in", "T9", "12 MHz crystal (FTDI clock)", "Requires jumper JP2 closed"],
        ["rstn_i", "in", "D10", "Push button PB1 (SW2)", "Active low, pull-up"],
        ["rx_i", "in", "B11", "FTDI TX, FPGA RX (channel B)", "COM13 on the development PC"],
        ["tx_o", "out", "A12", "FTDI RX, FPGA TX (channel B)", "115200 baud"],
        ["led_o[0..3]", "out", "G14, E14, G15, G13", "LED1 to LED4 (green)", "Four GPIO outputs"],
        ["cs_o", "out", "H12", "PMOD pin 1, OLED CS#", ""],
        ["sdin_o", "out", "H11", "PMOD pin 2, OLED SDIN", ""],
        ["sclk_o", "out", "E16", "PMOD pin 4, OLED SCLK", "6 MHz at reset"],
        ["dc_o", "out", "G11", "PMOD pin 7, OLED D/C#", "Corrected from C11"],
        ["rst_o", "out", "G12", "PMOD pin 8, OLED RES#", "Software controlled"],
        ["vbat_o", "out", "F14", "PMOD pin 9, VBATC", "Active low, display supply"],
        ["vdd_o", "out", "F15", "PMOD pin 10, VDDC", "Active low, logic supply"],
        ["TCK, TMS, TDI, TDO", "-", "A7, B8, A6, C6", "Dedicated JTAG pins", "Tool placed, LVCMOS33"],
    ], [1500, 600, 1800, 2826, 2300], size=16)
    para("The VBATC and VDDC pins drive the gates of two P-channel switches on the Pmod OLED, each with a pull-up "
         "resistor to the supply. A high or undriven pin therefore leaves the supply switched off, and the "
         "supply is switched on by driving the pin low (Digilent Pmod OLED reference manual). The FPGA internal "
         "pull-up on these pins keeps both supplies off during configuration.")

    # ---- 4
    h1("4  System architecture")
    para("The SoC uses a single 24 MHz clock domain. The 12 MHz crystal feeds a PLL; the CPU is held in reset "
         "until both the reset button is released and the PLL has locked. The CPU fetches instructions from the "
         "32 KB system memory and reaches the peripherals through an AHB-Lite interconnect, an AHB-Lite to APB "
         "bridge and an APB interconnect.")
    figure("fig1_soc.png", "Figure 1: SoC architecture.",
           "Block diagram of the SoC: clock and reset, CPU, memory, buses, three peripherals and board devices.", 6.3)
    table([
        ["Instance", "Component", "Configuration"],
        ["pll0", "PLL module 3.0.1", "12 MHz in, 24 MHz CLKOP to the system, 12 MHz CLKOS unused, lock output enabled"],
        ["rst_and_0", "Glue logic (AND)", "rstn_i AND PLL lock drives the CPU reset input"],
        ["cpu0", "RISC-V SM 1.9.0", "rv32i, PIC and timer enabled, two interrupts, JTAG debug enabled"],
        ["system0", "System memory 2.6.0", "32 KB EBR, AHB-Lite, two ports, initialised from the firmware .mem file"],
        ["ahbl0", "AHB-Lite interconnect 1.6.0", "Slave 0 at 0x00000000 (0x8000), slave 1 at 0x10000000 (0xC00)"],
        ["ahbl2apb0", "AHB-Lite to APB bridge 1.2.0", "Single APB master"],
        ["apb0", "APB interconnect 1.5.0", "Three slaves of 0x400 bytes each"],
        ["uart0", "UART 1.6.0", "115200 baud, 8 data bits, 1 stop bit, 24 MHz system clock"],
        ["gpio0", "GPIO 1.8.1", "Four lines, all outputs (direction mask 0xF)"],
        ["oled_spi0_inst", "oled_4wire 1.0.0 (custom)", "APB slave, 4-wire SPI, power and reset control"],
    ], [1700, 2500, 4826], size=16)

    # ---- 5
    h1("5  Address map")
    figure("fig3_map.png", "Figure 2: Address map and oled_4wire registers.", "Address map of the SoC and the four registers of oled_4wire.", 6.0)
    table([
        ["Region", "Base address", "Size", "Description"],
        ["system0", "0x00000000", "0x8000 (32 KB)", "Code and data, initialised from the firmware image"],
        ["uart0", "0x10000000", "0x400", "UART registers"],
        ["gpio0", "0x10000400", "0x400", "GPIO registers (LEDs)"],
        ["oled_4wire", "0x10000800", "0x400 (16 bytes used)", "OLED SPI registers (section 6.3)"],
        ["PIC and timer", "0xFFFF0000", "CPU internal", "Interrupt controller and timer"],
    ], [1900, 1700, 2000, 3426], size=16)

    # ---- 6
    h1("6  Custom IP: oled_4wire")
    h2("6.1  Overview")
    bullets([
        "APB slave with an 8-bit address and 32-bit data. PREADY is always 1 (zero wait states) and PSLVERR is always 0.",
        "Single clock domain (PCLK). The earlier design used a second clock and a clock-domain crossing; this has been removed.",
        "16-entry FIFO of 9-bit words (D/C# and one data byte), with FULL, EMPTY, IDLE and a sticky OVERFLOW flag.",
        "SPI mode 0, MSB first. SCLK = PCLK / (2 x (CLKDIV + 1)); the reset value CLKDIV = 1 gives 6 MHz at 24 MHz.",
        "RES_N, VBATC_N and VDDC_N are software controlled. After reset the display is unpowered and held in reset.",
        "Implemented in VHDL-93 in three files: oled_4wire.vhd (top), oled4w_fifo.vhd and oled4w_spi.vhd.",
    ])
    h2("6.2  Internal structure")
    figure("fig2_ip.png", "Figure 3: Internal structure of oled_4wire.",
           "Block diagram of the IP: APB slave, register block, FIFO, SPI shifter and control outputs.", 6.2)
    h2("6.3  Register map")
    table([
        ["Offset", "Name", "Access", "Description"],
        ["0x00", "ID", "RO", "Constant 0x4F4C4401"],
        ["0x04", "STATUS", "RO, W1C bit 4", "[0] BUSY, [1] EMPTY, [2] FULL, [3] IDLE (FIFO empty and shifter idle), "
                                              "[4] OVERFLOW (write 1 to clear)"],
        ["0x08", "CONTROL", "RW", "[7:0] CLKDIV, [8] RES_N, [9] VBATC_N, [10] VDDC_N. Reset value 0x601."],
        ["0x0C", "DATA", "WO", "[8] D/C# (1 = data, 0 = command), [7:0] byte. A write while FULL is dropped and "
                               "sets OVERFLOW. A read returns the last value written."],
    ], [900, 1300, 1500, 5326], size=16)
    h2("6.4  SPI timing")
    para("One byte is shifted as follows: CS# falls, data is presented while SCLK is low, the display samples on the "
         "rising edge, and CS# is released one tick after the last bit. One tick equals CLKDIV + 1 PCLK cycles.")
    figure("fig6_timing.png", "Figure 4: SPI timing of one byte (0xA5 with D/C# = 1).",
           "Timing diagram of CS, SCLK, SDIN and D/C for one byte in SPI mode 0.", 6.2)
    h2("6.5  Power-up sequence")
    figure("fig4_seq.png", "Figure 5: Pmod OLED start-up sequence.",
           "Seven step flow from reset state to display on.", 6.2)
    para("The sequence is implemented by `oled_start_ssd1306()`. VDD is applied first and VBAT second, as required "
         "by the Digilent manual. The wait of 100 ms before display on is taken from the SSD1306 start-up "
         "procedure; see section 11.")
    h2("6.6  Package contents")
    table([
        ["File", "Purpose"],
        ["metadata.xml, bus_interface.xml, memory_map.xml", "Propel IP description, APB interface, register map"],
        ["rtl/oled_4wire.vhd, oled4w_fifo.vhd, oled4w_spi.vhd", "Synthesisable RTL"],
        ["driver/ssd1306.c and .h, font_1bpp.c and .h", "BSP driver files copied by Propel into the firmware project"],
        ["doc/introduction.html, doc/EULA.txt", "IP documentation and licence text"],
        ["sim/tb_oled_4wire.vhd (not in the package)", "Self-checking testbench used with Questa"],
    ], [4000, 5026], size=16)
    para("The package file is stored in the project at custom_IP\\oled_4wire.")

    # ---- 7
    h1("7  Firmware and BSP drivers")
    h2("7.1  Driver set")
    para("The driver keeps the call names of the earlier SPI driver, so existing application code continues to "
         "compile. Only the register details underneath changed. The Lattice logo and the 6 x 8 fixed font are reused.")
    table([
        ["Function", "Purpose"],
        ["base_ssd1306, getbase_ssd1306", "Set and read the peripheral base address"],
        ["command_ssd1306, data_ssd1306", "Send one command or data byte through the FIFO"],
        ["commandlist_ssd1306", "Send a list of command bytes"],
        ["oled_clear_ssd1306", "Fill the 128 x 32 screen with a pattern"],
        ["oled_lattice_ssd1306", "Draw the Lattice logo (120 x 24 pixels, 360 bytes) at a column and page"],
        ["oled_setblock_ssd1306, oled_clearblock_ssd1306", "Define or clear a write window"],
        ["draw_text_ssd1306, draw_font_ssd1306", "Draw text with the 1 bpp fixed font"],
        ["oled_reset_ssd1306 (new)", "Switch the logic supply on and pulse the display reset"],
        ["oled_vbat_ssd1306 (new)", "Switch the display supply on or off, with the 100 ms wait"],
        ["oled_clkdiv_ssd1306 (new)", "Set the SPI clock divider"],
        ["oled_flush_ssd1306 (new)", "Wait until the FIFO is empty and the shifter is idle"],
        ["oled_start_ssd1306, oled_stop_ssd1306 (new)", "Complete start-up and shut-down sequences"],
    ], [3900, 5126], size=16)
    h2("7.2  Main program")
    bullets([
        "Initialise the UART terminal and print a first message before any OLED access, so that a stalled "
        "display cannot silence the console.",
        "Initialise the interrupt controller and the LED GPIO, then the OLED with `oled_start_ssd1306()`, "
        "clear the screen and draw the Lattice logo.",
        "Print the start-up text, then loop: chase the LEDs, scroll the text \" XO4 Rules!\" across the display and "
        "wait 500 ms.",
        "The firmware image is 8,092 bytes (2,023 words), about 25 percent of the 32 KB system memory, compiled "
        "with the project flags (rv32i, -O0).",
    ])
    h2("7.3  Firmware faults found and corrected")
    table([
        ["Finding", "Effect", "Correction"],
        ["delay() calibrated for 100 MHz while the CPU runs at 24 MHz", "All delays about four times too long "
         "(500 ms became about 2 s)", "Calibration now follows the configured system clock"],
        ["FIFO-full wait used a 1 ms delay per byte", "A 512-byte screen clear took about 0.5 s",
         "Tight status poll with a bounded timeout"],
        ["Header guard names did not match", "Guard never active", "Names corrected"],
        ["Page address range one page too large", "Window larger than the 128 x 32 display",
         "Range matches the display and the logo size"],
        ["Both SSD1306 and SSD1351 drivers enabled by default", "Duplicate SPI_BASE symbol, link error",
         "SSD1351 disabled by default, only one driver may be defined"],
        ["Text scrolled beyond column 127", "Characters wrapped to wrong positions", "Scroll range limited to the screen"],
    ], [3000, 2900, 3126], size=16)

    # ---- 8
    h1("8  Design flow and tools")
    figure("fig5_flow.png", "Figure 6: Development, verification and programming flow.",
           "Flow from IP RTL through simulation, packaging, Propel, firmware, Radiant and programming.", 6.2)
    bullets([
        "**RTL and simulation:** VHDL-93, compiled and simulated with Questa Lattice OEM 2025.2.",
        "**SoC generation:** Propel 2026.1.1. Reset gating, the PLL lock port and the memory initialisation were "
        "applied through scripted Propel sessions, and the generated sources were not edited by hand.",
        "**Firmware:** RISC-V GNU toolchain 10.2.0, project flags rv32i, ilp32, -O0, linker script for the 32 KB memory.",
        "**Implementation:** Radiant 2026.1.1 with Synplify Pro X-2025.09LR-SP1, target LFMXO4-110HC-6BBG256I, speed grade 6.",
        "**Programming:** Lattice Programmer 2026.1.1 command line, JTAG at 7.5 MHz, device ID 0x712BE043.",
    ])

    # ---- 9
    h1("9  Verification and results")
    h2("9.1  Simulation of oled_4wire")
    para("A self-checking testbench with an SPI slave model ran at 24 MHz with the driver access pattern "
         "(poll FULL, write DATA). The run finished with no errors.")
    table([
        ["Check", "Result"],
        ["ID register reads 0x4F4C4401", "Pass"],
        ["Reset values: CONTROL 0x601, CS high, SCLK low, display unpowered", "Pass"],
        ["Power-control bits drive VDDC_N, RES_N and VBATC_N in the specified order", "Pass"],
        ["40 words received in order with correct D/C# and 8 clocks each", "Pass"],
        ["Write while FIFO full sets OVERFLOW; write 1 clears it", "Pass"],
        ["SCLK period 166.7 ns (6 MHz) with CLKDIV = 1", "Pass"],
        ["Total words received in the run", "59, no mismatch"],
    ], [6400, 2626], size=16)
    h2("9.2  Radiant implementation")
    table([
        ["Item", "Result"],
        ["Synthesis, map, place and route, bitstream", "Complete, no errors"],
        ["Registers", "1,959 of 10,015 (20 percent)"],
        ["LUT4", "3,768 of 9,400 (40 percent)"],
        ["Block RAM (EBR)", "36 of 48 (75 percent)"],
        ["PLL", "1 of 2"],
        ["PIO sites used", "21 of 205 (10 percent)"],
        ["JTAG block", "1 of 1 (debug enabled)"],
        ["Setup timing, slow corner at 100 degrees C", "0 failing endpoints, total negative slack 0.000 ns"],
        ["Setup timing, corner at -40 degrees C", "0 failing endpoints"],
        ["Hold timing, corner at -40 degrees C", "0 failing endpoints"],
        ["Constraint coverage", "99.78 percent"],
    ], [4700, 4326], size=16)
    para("Clock constraints: a 12 MHz clock on the crystal input (the PLL outputs are derived automatically) and "
         "10 MHz JTAG clocks declared asynchronous to the system clocks. The remaining 0.2 percent of the paths "
         "are the input and output ports of the LEDs, the UART input and the reset input, which carry no "
         "input or output delay constraint.")
    h2("9.3  Programming")
    table([
        ["Step", "Result"],
        ["SRAM, Fast Configuration", "JTAG chain verified, operation successful (3 s)"],
        ["Internal flash, Erase, Program, Verify", "Operation successful (53 s), JEDEC checksum 0xB149"],
    ], [4700, 4326], size=16)
    h2("9.4  Observation on the board")
    table([
        ["Function", "Status", "Basis"],
        ["LEDs", "Running", "Observed by the user after programming"],
        ["OLED picture", "Not confirmed", "Not reported in this review"],
        ["UART console (COM13, 115200)", "Not confirmed", "A 40 s capture during an earlier SRAM programming "
                                                          "run showed no data; the console was not re-tested "
                                                          "after the flash programming"],
    ], [2500, 1800, 4726], size=16)

    # ---- 10
    h1("10  Issues found in the original design and their resolution")
    table([
        ["No.", "Issue", "Resolution"],
        ["1", "Synthesis error: multiple drivers on the FIFO read index, caused by a stale copy of the FIFO source "
              "in the generated IP library", "FIFO rewritten with a single driver per register in the new IP"],
        ["2", "Display supplies tied high: the Pmod OLED switches are active low, so the display was never powered",
         "VBATC and VDDC are software controlled, reset state off, defined power sequence"],
        ["3", "D/C# assigned to pin C11, which is not a PMOD pin", "Assigned to G11 (PMOD pin 7)"],
        ["4", "Constraint errors: LED 3 port name, UART TX port name, missing I/O types on UART pins and JTAG pins",
         "Constraint file corrected"],
        ["5", "FIFO flags on the falling clock edge, FIFO started non-empty, second clock with unsynchronised signals",
         "Single clock domain, counter-based flags, FIFO empty after reset"],
        ["6", "No clock constraints, so timing results were not meaningful", "Clock and JTAG constraints added"],
        ["7", "CPU reset not gated by PLL lock; sibling design on the same board uses a gated reset",
         "Reset is now rstn_i AND PLL lock"],
        ["8", "Radiant project referenced an old version of the IP", "Project file points to oled_4wire 1.0.0"],
        ["9", "delay() calibrated for the wrong clock", "Calibrated to the 24 MHz system clock"],
    ], [600, 4800, 3626], size=16)
    para("Several corrections were made together while the board showed no activity. The individual contribution "
         "of each correction to the first working LED activity was not isolated.")

    # ---- 11
    h1("11  Open items and recommendations")
    bullets([
        "Confirm the OLED picture and the UART console on the board after a power cycle, and record the result in "
        "section 9.4.",
        "Verify the 100 ms wait before display on and the reset timing against the SSD1306 datasheet in the "
        "project documents; these values were not re-read from the datasheet during this work.",
        "Add input and output delay constraints for the LED, reset and UART ports to reach full constraint coverage.",
        "The JTAG block is fully used because CPU debug is enabled. This is acceptable as long as it does not "
        "block normal operation; it can be disabled if debug is not needed.",
        "Remove the obsolete oled_spi0 versions 3.0.2 and 3.0.3 from the project library when no longer needed.",
        "Consider compiling the firmware with -Os in the SDK project settings; the image shrinks from about 7.6 KB to "
        "about 5 KB and runs faster.",
        "The Eclipse firmware project regenerates its Debug artefacts on the next build; the memory initialisation "
        "file path in the SoC points to the same location.",
        "Archive the backups taken during the work (SoC project copies, firmware artefacts, constraint and project "
        "files) with the project.",
    ])

    # ---- 12
    h1("12  References and compliance")
    h2("12.1  Project documents")
    bullets([
        "MachXO4 Companion board mapping sheet (XO4_Companion_Mapping.xlsx) and board schematic and outline (doc folder).",
        "Digilent Pmod OLED reference manual and schematic, document 500-222, revision A, dated 6 September 2011.",
        "SSD1306 controller datasheet and UG-2832HSWEG04 display datasheet (doc folder).",
        "Lattice MachXO4 Development Board User Guide, FPGA-EB-02073-1-0.",
    ])
    h2("12.2  Standards and specifications")
    bullets([
        "ARM AMBA 3 APB Protocol Specification (ARM IHI 0024), implemented by the oled_4wire APB slave.",
        "ARM AMBA 3 AHB-Lite Protocol Specification (ARM IHI 0033), used by the system interconnect.",
        "IEEE Std 1076-1993, VHDL language reference, to which the RTL is written (VHDL-93 mode).",
        "IEEE Std 1149.1, boundary-scan (JTAG) architecture, used for programming and debug access.",
        "JEDEC JESD3, data transfer format for programmable logic device programmers, for the .jed file.",
    ])
    h2("12.3  Compliance statement")
    bullets([
        "No internal company policy was referenced in this report, therefore no internal policy number is cited.",
        "No personal data is contained in this report.",
        "Third-party material (Digilent documentation, SSD1306 datasheet) is cited by name only; no text was reproduced.",
        "The source files for the diagrams and for this report are stored in the doc/report folder of the project.",
    ])


# =====================================================================  PACKAGE PARTS
STYLES = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:eastAsia="Arial" w:cs="Arial"/>
<w:sz w:val="20"/><w:szCs w:val="20"/><w:lang w:val="en-GB"/></w:rPr></w:rPrDefault>
<w:pPrDefault><w:pPr><w:spacing w:after="100" w:line="264" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:spacing w:before="1200" w:after="120"/></w:pPr><w:rPr><w:b/><w:color w:val="1F3864"/><w:sz w:val="52"/><w:szCs w:val="52"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:spacing w:after="120"/></w:pPr><w:rPr><w:color w:val="404040"/><w:sz w:val="30"/><w:szCs w:val="30"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="360" w:after="120"/><w:outlineLvl w:val="0"/></w:pPr>
<w:rPr><w:b/><w:color w:val="1F3864"/><w:sz w:val="30"/><w:szCs w:val="30"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="240" w:after="80"/><w:outlineLvl w:val="1"/></w:pPr>
<w:rPr><w:b/><w:color w:val="2F5496"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="200" w:after="60"/><w:outlineLvl w:val="2"/></w:pPr>
<w:rPr><w:b/><w:color w:val="2F5496"/><w:sz w:val="21"/><w:szCs w:val="21"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="ListBullet"><w:name w:val="List Bullet"/><w:basedOn w:val="Normal"/><w:qFormat/>
<w:pPr><w:spacing w:after="60"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Caption"><w:name w:val="caption"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:spacing w:after="200"/></w:pPr><w:rPr><w:i/><w:color w:val="404040"/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Header"><w:name w:val="header"/><w:basedOn w:val="Normal"/>
<w:pPr><w:tabs><w:tab w:val="right" w:pos="{TEXT_W}"/></w:tabs><w:spacing w:after="0"/></w:pPr><w:rPr><w:color w:val="595959"/><w:sz w:val="16"/><w:szCs w:val="16"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Footer"><w:name w:val="footer"/><w:basedOn w:val="Normal"/>
<w:pPr><w:tabs><w:tab w:val="right" w:pos="{TEXT_W}"/></w:tabs><w:spacing w:after="0"/></w:pPr><w:rPr><w:color w:val="595959"/><w:sz w:val="16"/><w:szCs w:val="16"/></w:rPr></w:style>
</w:styles>"""

NUMBERING = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="hybridMultilevel"/>
<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="&#8226;"/><w:lvlJc w:val="left"/>
<w:pPr><w:ind w:left="500" w:hanging="260"/></w:pPr><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/></w:rPr></w:lvl>
<w:lvl w:ilvl="1"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="-"/><w:lvlJc w:val="left"/>
<w:pPr><w:ind w:left="900" w:hanging="260"/></w:pPr></w:lvl></w:abstractNum>
<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num></w:numbering>"""

HEADER = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:hdr {NS}><w:p><w:pPr><w:pStyle w:val="Header"/><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="1" w:color="A6A6A6"/></w:pBdr></w:pPr>
<w:r><w:t xml:space="preserve">MachXO4 Companion board: RISC-V SoC with 4-wire SPI OLED interface</w:t></w:r><w:r><w:tab/></w:r>
<w:r><w:t>Project report, draft for review</w:t></w:r></w:p></w:hdr>"""

FOOTER = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:ftr {NS}><w:p><w:pPr><w:pStyle w:val="Footer"/></w:pPr>
<w:r><w:t xml:space="preserve">21 November 2026</w:t></w:r><w:r><w:tab/></w:r>
<w:r><w:t xml:space="preserve">Page </w:t></w:r>
<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r>
<w:r><w:t xml:space="preserve"> of </w:t></w:r>
<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> NUMPAGES </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r>
</w:p></w:ftr>"""

CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Default Extension="png" ContentType="image/png"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>
<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>
<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>
<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>"""

ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

SETTINGS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:zoom w:percent="100"/><w:defaultTabStop w:val="720"/><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat>
</w:settings>"""

CORE = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>MachXO4 Companion board: RISC-V SoC with 4-wire SPI OLED interface</dc:title>
<dc:subject>Project report</dc:subject><dc:creator>Project team</dc:creator>
<dcterms:created xsi:type="dcterms:W3CDTF">2026-11-21T20:00:00Z</dcterms:created>
<dcterms:modified xsi:type="dcterms:W3CDTF">2026-11-21T20:00:00Z</dcterms:modified>
</cp:coreProperties>"""

APP = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Microsoft Office Word</Application></Properties>"""


def main():
    build_content()
    sect = (f'<w:sectPr><w:headerReference w:type="default" r:id="rIdHdr"/><w:footerReference w:type="default" r:id="rIdFtr"/>'
            '<w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1300" w:left="1440" '
            'w:header="620" w:footer="560" w:gutter="0"/></w:sectPr>')
    doc = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:document {NS}><w:body>'
           + "".join(body) + sect + "</w:body></w:document>")
    rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">',
            '<Relationship Id="rIdSty" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>',
            '<Relationship Id="rIdNum" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>',
            '<Relationship Id="rIdSet" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>',
            '<Relationship Id="rIdHdr" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>',
            '<Relationship Id="rIdFtr" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>']
    for rid, fn in images:
        rels.append(f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/{fn}"/>')
    rels.append("</Relationships>")
    if os.path.exists(OUT):
        os.remove(OUT)
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", CONTENT_TYPES)
        z.writestr("_rels/.rels", ROOT_RELS)
        z.writestr("word/document.xml", doc)
        z.writestr("word/_rels/document.xml.rels", "\n".join(rels))
        z.writestr("word/styles.xml", STYLES)
        z.writestr("word/numbering.xml", NUMBERING)
        z.writestr("word/settings.xml", SETTINGS)
        z.writestr("word/header1.xml", HEADER)
        z.writestr("word/footer1.xml", FOOTER)
        z.writestr("docProps/core.xml", CORE)
        z.writestr("docProps/app.xml", APP)
        for rid, fn in images:
            z.write(os.path.join(FIG, fn), f"word/media/{fn}")
    print("written", OUT, os.path.getsize(OUT), "bytes;", len(images), "images")


if __name__ == "__main__":
    main()
