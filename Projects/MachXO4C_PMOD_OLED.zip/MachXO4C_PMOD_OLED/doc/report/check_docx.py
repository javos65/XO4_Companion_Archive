import sys, zipfile, xml.dom.minidom as m
p = sys.argv[1]
z = zipfile.ZipFile(p)
bad = 0
for n in z.namelist():
    if n.endswith(".xml") or n.endswith(".rels"):
        try:
            m.parseString(z.read(n))
        except Exception as e:
            bad += 1
            print("XML ERROR", n, e)
print("parts:", len(z.namelist()), "xml errors:", bad)
doc = z.read("word/document.xml").decode("utf8")
print("paragraphs:", doc.count("<w:p>") + doc.count("<w:p "), "tables:", doc.count("<w:tbl>"), "images:", doc.count("<w:drawing>"))
print("folder entries:", [n for n in z.namelist() if n.endswith("/")])
