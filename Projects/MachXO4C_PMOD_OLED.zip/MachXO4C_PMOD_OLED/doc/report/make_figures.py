"""Block diagrams for the XO4 OLED project report (matplotlib only)."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fig")
os.makedirs(OUT, exist_ok=True)

C_CPU = "#cfe2f3"     # processor / bus
C_MEM = "#d9ead3"     # memory
C_PER = "#fff2cc"     # peripherals
C_NEW = "#f9cb9c"     # custom IP
C_EXT = "#e6e6e6"     # external / board
C_CLK = "#ead1dc"     # clock / reset
EDGE = "#333333"


def canvas(w, ymax, title=None):
    """Drawing area is 100 units wide and ymax units high (square units)."""
    h = w * ymax / 100.0
    fig, ax = plt.subplots(figsize=(w, h), dpi=200)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, ymax)
    ax.axis("off")
    return fig, ax


def box(ax, x, y, w, h, text, color, fs=8.5, bold=False, lw=1.2):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=0.8",
                       fc=color, ec=EDGE, lw=lw)
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
            fontweight="bold" if bold else "normal", linespacing=1.25)


def arrow(ax, p1, p2, text=None, both=False, fs=7, dx=0, dy=1.2, color=EDGE, ls="-"):
    a = FancyArrowPatch(p1, p2, arrowstyle="<|-|>" if both else "-|>", mutation_scale=10,
                        lw=1.2, color=color, linestyle=ls, shrinkA=0, shrinkB=0)
    ax.add_patch(a)
    if text:
        ax.text((p1[0] + p2[0]) / 2 + dx, (p1[1] + p2[1]) / 2 + dy, text, ha="center",
                va="bottom", fontsize=fs, color="#222222")


def save(fig, name):
    fig.savefig(os.path.join(OUT, name), bbox_inches="tight", facecolor="white")
    plt.close(fig)


# ---------------------------------------------------------------- Figure 1: SoC architecture
def fig_soc():
    fig, ax = canvas(16, 86, "Figure 1: SoC architecture (LFMXO4-110HC, Propel 2026.1.1)")
    # clock and reset (left)
    box(ax, 1, 66, 14, 10, "12 MHz crystal\n(pin T9, JP2)", C_EXT)
    box(ax, 21, 66, 15, 10, "pll0\n12 MHz to 24 MHz\nlock output on", C_CLK)
    box(ax, 1, 50, 14, 10, "Reset button\nPB1 (pin D10)", C_EXT)
    box(ax, 21, 50, 15, 10, "rst_and_0\nrstn_i AND\nPLL lock", C_CLK)
    arrow(ax, (15, 71), (21, 71))
    arrow(ax, (28.5, 66), (28.5, 60), "lock_o", dx=4.5, dy=-0.4)
    arrow(ax, (15, 55), (21, 55))
    # cpu and memory
    box(ax, 44, 64, 18, 14, "cpu0\nLattice RISC-V SM\nrv32i, PIC + timer\ndebug (JTAG) on", C_CPU, bold=True)
    arrow(ax, (36, 73), (44, 73), "clk 24 MHz", dy=0.6, fs=6.5)
    ax.plot([36, 40, 40], [55, 55, 67], color=EDGE, lw=1.2)
    arrow(ax, (40, 67), (44, 67), None)
    ax.text(38.5, 56, "rst_n", fontsize=6.5, ha="center", va="bottom")
    box(ax, 44, 46, 18, 10, "system0\n32 KB EBR memory\ninit from firmware .mem", C_MEM)
    arrow(ax, (53, 64), (53, 56), "AHB-L instruction", both=True, dx=-0.5, dy=-0.2, fs=6.5)
    ax.texts[-1].set_ha("left"); ax.texts[-1].set_x(54.5)
    # buses (right column)
    box(ax, 70, 64, 16, 14, "ahbl0\nAHB-Lite interconnect\n2 slaves", C_CPU, bold=True)
    arrow(ax, (62, 71), (70, 71), "AHB-L data", both=True, dy=0.6, fs=6.5)
    ax.plot([70, 66, 66], [67, 67, 51], color=EDGE, lw=1.2)
    arrow(ax, (66, 51), (62, 51), None)
    ax.text(66.6, 58.5, "slave 0\n0x0000_0000", fontsize=6.5, ha="left")
    box(ax, 70, 46, 16, 10, "ahbl2apb0\nAHB-L to APB bridge", C_CPU)
    arrow(ax, (78, 64), (78, 56), "slave 1  0x1000_0000", both=True, dx=-0.5, dy=-0.2, fs=6.5)
    ax.texts[-1].set_ha("left"); ax.texts[-1].set_x(79.2)
    box(ax, 70, 32, 16, 8, "apb0\nAPB interconnect, 3 slaves", C_CPU)
    arrow(ax, (78, 46), (78, 40), "APB", both=True, dx=2.2, dy=-0.2, fs=6.5)
    # peripherals row
    box(ax, 42, 18, 16, 10, "uart0\nUART 115200 8N1\n0x1000_0000", C_PER)
    box(ax, 62, 18, 16, 10, "gpio0\n4 output lines\n0x1000_0400", C_PER)
    box(ax, 82, 18, 16, 10, "oled_4wire\ncustom IP v1.0.0\n0x1000_0800", C_NEW, bold=True)
    ax.plot([78, 78], [32, 30.5], color=EDGE, lw=1.2)
    ax.plot([50, 90], [30.5, 30.5], color=EDGE, lw=1.2)
    for xc in (50, 70, 90):
        arrow(ax, (xc, 30.5), (xc, 28), None)
    # external devices row
    box(ax, 42, 2, 16, 10, "FTDI channel B\nCOM13\nRX B11 / TX A12", C_EXT)
    box(ax, 62, 2, 16, 10, "4 green LEDs\nG14 E14 G15 G13", C_EXT)
    box(ax, 80, 0.5, 19, 14.5, "Digilent Pmod OLED (J14)\nSSD1306, 128 x 32\nCS H12  SDIN H11\nSCLK E16  D/C G11\nRES G12  VBATC F14\nVDDC F15", C_EXT, fs=6.8)
    arrow(ax, (50, 18), (50, 12), "txd / rxd", both=True, dx=3.2, dy=-0.4, fs=6.5)
    arrow(ax, (70, 18), (70, 12), "led_o[3:0]", dx=3.5, dy=-0.4, fs=6.5)
    arrow(ax, (90, 18), (90, 15), "7 signals", dx=4.5, dy=-0.3, fs=6.5)
    # legend
    lx, ly = 1, 40
    for i, (c, t) in enumerate([(C_CLK, "Clock / reset"), (C_CPU, "Processor and buses"),
                                (C_MEM, "Memory"), (C_PER, "Standard peripherals"),
                                (C_NEW, "Custom IP"), (C_EXT, "Board / external")]):
        box(ax, lx, ly - i * 4.8, 3.6, 3, "", c, lw=0.8)
        ax.text(lx + 5, ly - i * 4.8 + 1.5, t, fontsize=7.5, va="center")
    save(fig, "fig1_soc.png")

# ---------------------------------------------------------------- Figure 2: IP internals
def fig_ip():
    fig, ax = canvas(16, 66, "Figure 2: oled_4wire IP internal structure (single clock domain)")
    box(ax, 1, 28, 14, 30, "APB slave\nPSEL PENABLE\nPWRITE PADDR[7:0]\nPWDATA[31:0]\nPRDATA[31:0]\nPREADY = 1\nPSLVERR = 0", C_CPU, fs=8)
    box(ax, 22, 40, 19, 18, "Register block\n0x00 ID (RO)\n0x04 STATUS\n0x08 CONTROL\n0x0C DATA (WO)", C_PER, fs=8, bold=True)
    box(ax, 49, 45, 16, 13, "oled4w_fifo\n16 x 9 bit\n(D/C# + byte)", C_MEM, fs=8.5, bold=True)
    box(ax, 72, 36, 17, 22, "oled4w_spi\ntick divider\nshift register\nstate machine\nIDLE DATA CLK END DONE", C_NEW, fs=8, bold=True)
    box(ax, 22, 14, 19, 17, "CONTROL fields\nCLKDIV[7:0]\nRES_N\nVBATC_N\nVDDC_N", C_PER, fs=8)
    arrow(ax, (15, 43), (22, 49), "APB access", both=True, dy=1.0)
    arrow(ax, (41, 53), (49, 53), "write word", dy=0.8)
    arrow(ax, (49, 47), (41, 47), "FULL / EMPTY", dy=0.8)
    arrow(ax, (65, 53), (72, 53), "tx_data / valid", dy=0.8, fs=6.5)
    arrow(ax, (72, 47), (65, 47), "tx_pop", dy=0.8, fs=6.5)
    arrow(ax, (31.5, 40), (31.5, 31), "write", dx=3, dy=-1.0)
    ax.plot([41, 80.5, 80.5], [27, 27, 36], color=EDGE, lw=1.2)
    arrow(ax, (80.5, 33), (80.5, 36), None)
    ax.text(60, 27.8, "CLKDIV[7:0]", fontsize=7, ha="center")
    # outputs
    box(ax, 93, 46, 6, 12, "SCLK\nSDIN\nDC\nCS", C_EXT, fs=7)
    arrow(ax, (89, 52), (93, 52), None)
    box(ax, 93, 14, 6, 14, "RES_N\nVBATC_N\nVDDC_N", C_EXT, fs=6.5)
    arrow(ax, (41, 19), (93, 19), "software controlled pins", dy=0.8, fs=7)    # STATUS annotation
    ax.text(1, 10, "STATUS: [0] BUSY  [1] EMPTY  [2] FULL  [3] IDLE  [4] OVERFLOW (write 1 to clear)\n"
                   "SCLK = PCLK / (2 x (CLKDIV + 1)); reset value CLKDIV = 1 gives 6 MHz at 24 MHz",
            fontsize=7.5, va="center")
    save(fig, "fig2_ip.png")


# ---------------------------------------------------------------- Figure 3: address map
def fig_map():
    fig, ax = canvas(14, 76, "Figure 3: SoC address map and oled_4wire registers")
    rows = [
        ("0xFFFF_0000", "PIC and timer (CPU internal)", C_CPU),
        ("0x1000_0800", "oled_4wire  (range 0x400)", C_NEW),
        ("0x1000_0400", "gpio0  (range 0x400)", C_PER),
        ("0x1000_0000", "uart0  (range 0x400)", C_PER),
        ("0x0000_0000", "system0 memory, 32 KB (0x8000)", C_MEM),
    ]
    y = 60
    for addr, name, col in rows:
        box(ax, 8, y, 36, 8, name, col, fs=9)
        ax.text(6, y + 4, addr, ha="right", va="center", fontsize=8.5, family="monospace")
        y -= 11
    # register zoom
    regs = [("0x0C", "DATA", "WO: [8] D/C#, [7:0] byte -> FIFO"),
            ("0x08", "CONTROL", "RW: [7:0] CLKDIV, [8] RES_N, [9] VBATC_N, [10] VDDC_N"),
            ("0x04", "STATUS", "RO/W1C: BUSY EMPTY FULL IDLE OVERFLOW"),
            ("0x00", "ID", "RO: 0x4F4C4401")]
    y = 56
    ax.text(70, 66, "oled_4wire registers (base 0x1000_0800)", ha="center", fontsize=9.5, fontweight="bold")
    for off, nm, desc in regs:
        box(ax, 52, y, 46, 8, "", C_NEW, lw=1.0)
        ax.text(54, y + 4, off, fontsize=8.5, va="center", family="monospace")
        ax.text(60.5, y + 5.6, nm, fontsize=9, va="center", fontweight="bold")
        ax.text(60.5, y + 2.2, desc, fontsize=7.2, va="center")
        y -= 9.5
    arrow(ax, (44, 53), (51.6, 53), None, ls="--")
    ax.set_ylim(12, 76)
    fig.set_size_inches(14, 14 * 64 / 100.0)
    save(fig, "fig3_map.png")


# ---------------------------------------------------------------- Figure 4: power-up sequence
def fig_seq():
    fig, ax = canvas(16, 48, "Figure 4: Pmod OLED start-up sequence (oled_start_ssd1306)")
    steps = [
        ("1  Reset state\nVDD off, VBAT off\nRES low", C_EXT),
        ("2  VDDC_N = 0\nlogic supply on\nwait 5 ms", C_CLK),
        ("3  RES_N = 1\nrelease reset\nwait 5 ms", C_CLK),
        ("4  Init list\n(oled_init, 25 cmds)\ndisplay still off", C_PER),
        ("5  Flush\nwait until FIFO\nempty and idle", C_PER),
        ("6  VBATC_N = 0\ndisplay supply on\nwait 100 ms", C_CLK),
        ("7  Display on\nA4, AF\nthen clear + logo", C_NEW),
    ]
    n = len(steps)
    w, gap = 11.2, 2.6
    x = 1
    for i, (t, c) in enumerate(steps):
        box(ax, x, 22, w, 17, t, c, fs=8.6)
        if i < n - 1:
            arrow(ax, (x + w, 30.5), (x + w + gap, 30.5), None)
        x += w + gap
    ax.text(50, 14, "VDDC and VBATC are active-low gates of P-channel switches on the Pmod OLED: "
                    "a high or undriven pin leaves the supply OFF.",
            ha="center", fontsize=8.5)
    ax.text(50, 9, "Power-on order per the Digilent reference manual: VDD first, then VBAT. "
                   "100 ms before display on per the SSD1306 start-up procedure.",
            ha="center", fontsize=8.5)
    save(fig, "fig4_seq.png")


# ---------------------------------------------------------------- Figure 5: development flow
def fig_flow():
    fig, ax = canvas(16, 60, "Figure 5: development, verification and programming flow")
    top = [("oled_4wire RTL\nVHDL-93", C_NEW), ("Questa simulation\ntestbench, 59 words,\n0 errors", C_PER),
           ("Package .ipk\noled_4wire 1.0.0\ninstall in Propel", C_CPU), ("Propel SoC\nregenerate + SGE\n(BSP drivers)", C_CPU)]
    bot = [("Firmware\nriscv gcc rv32i\n-O0, 8,092 bytes", C_MEM), (".mem image\nregenerate system0\ninit values", C_MEM),
           ("Radiant 2026.1.1\nSynplify, map, PAR,\nbitstream", C_CLK), ("Programming\nSRAM test, then\ninternal flash", C_EXT)]
    w, gap = 19.5, 5.0
    x = 3
    for i, (t, c) in enumerate(top):
        box(ax, x, 38, w, 14, t, c, fs=8)
        if i < 3:
            arrow(ax, (x + w, 45), (x + w + gap, 45), None)
        x += w + gap
    x = 3
    for i, (t, c) in enumerate(bot):
        box(ax, x, 12, w, 14, t, c, fs=8)
        if i < 3:
            arrow(ax, (x + w, 19), (x + w + gap, 19), None)
        x += w + gap
    ax.plot([3 + 3 * (w + gap) + w / 2] * 2, [38, 32], color=EDGE, lw=1.2)
    ax.plot([3 + 3 * (w + gap) + w / 2, 3 + w / 2], [32, 32], color=EDGE, lw=1.2)
    arrow(ax, (3 + w / 2, 32), (3 + w / 2, 26), None)
    ax.text(50, 6, "Checks: simulation (IP), Radiant timing and DRC (SoC), programmer JTAG verify, "
                   "board observation (LEDs).", ha="center", fontsize=8.5)
    save(fig, "fig5_flow.png")


# ---------------------------------------------------------------- Figure 6: SPI timing
def fig_timing():
    fig, ax = plt.subplots(figsize=(12, 4.6), dpi=200)
    n = 8
    ticks = 2 * n + 4          # setup + 16 + end + done
    def step(ys, base):
        xs, vs = [], []
        for t, v in enumerate(ys):
            xs += [t, t + 1]
            vs += [base + v * 0.7] * 2
        ax.plot(xs, vs, color="#1f3864", lw=1.6)
    # CS (low during byte): ticks 0..ticks-2
    cs = [1] + [0] * (ticks - 2) + [1]
    step(cs, 6.0)
    # SCLK: low, then pairs data-low / clk-high for 8 bits, then low
    sclk = [0, 0]
    for _ in range(n):
        sclk += [0, 1]
    sclk += [0, 0]
    sclk = sclk[: ticks + 1]
    step(sclk, 4.0)
    # data bits MSB first for 0xA5 = 10100101
    bits = [1, 0, 1, 0, 0, 1, 0, 1]
    sd = [0, 0]
    for b in bits:
        sd += [b, b]
    sd += [0, 0]
    sd = sd[: ticks + 1]
    step(sd, 2.0)
    # D/C#
    dc = [1] * (ticks + 1)
    step(dc, 0.0)
    for base, name in [(6.0, "CS#"), (4.0, "SCLK"), (2.0, "SDIN"), (0.0, "D/C#")]:
        ax.text(-0.6, base + 0.35, name, ha="right", va="center", fontsize=10, fontweight="bold")
    for i, b in enumerate(bits):
        ax.text(2 + 2 * i + 1, 2.9, f"D{7 - i}", ha="center", va="bottom", fontsize=7.5, color="#555555")
    ax.annotate("data set up\n(SCLK low)", xy=(2.5, 4.0), xytext=(4.5, 7.4), fontsize=8,
                arrowprops=dict(arrowstyle="-|>", color="#555555"), ha="center")
    ax.annotate("display samples on\nrising edge", xy=(5, 4.7), xytext=(9.5, 7.4), fontsize=8,
                arrowprops=dict(arrowstyle="-|>", color="#555555"), ha="center")
    ax.annotate("CS# held low one tick\nafter last bit", xy=(ticks - 1.5, 6.0), xytext=(ticks - 3.0, 7.6), fontsize=8,
                arrowprops=dict(arrowstyle="-|>", color="#555555"), ha="center")
    ax.set_xlim(-3, ticks + 1)
    ax.set_ylim(-1, 8.6)
    ax.set_xticks(range(0, ticks + 1, 2))
    ax.set_xticklabels([str(t) for t in range(0, ticks + 1, 2)], fontsize=8)
    ax.set_xlabel("ticks (one tick = CLKDIV + 1 PCLK cycles; one SCLK period = 2 ticks)", fontsize=9)
    ax.set_yticks([])
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    save(fig, "fig6_timing.png")


if __name__ == "__main__":
    fig_soc()
    fig_ip()
    fig_map()
    fig_seq()
    fig_flow()
    fig_timing()
    print("figures written to", OUT)
