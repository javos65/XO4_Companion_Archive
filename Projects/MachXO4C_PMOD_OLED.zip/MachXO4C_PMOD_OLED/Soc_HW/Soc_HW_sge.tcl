# PGE SGE script for Soc_HW
# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}
::ip_catalog::ip_catalog_location -add {C:\lscc\propel\2026.1.1\builder\rtf\ip}

sbp_design open -name {Soc_HW} -path {C:/lscc/workspace/MachXO4C_PMOD_OLED/Soc_HW/Soc_HW/Soc_HW.sbx}
sbp_design save
sbp_design generate
sbp_design save
set _sbxAbs [file normalize {C:/lscc/workspace/MachXO4C_PMOD_OLED/Soc_HW/Soc_HW/Soc_HW.sbx}]
set _sgeAbs [file normalize {C:/lscc/workspace/MachXO4C_PMOD_OLED/Soc_HW}]
sbp_design pge sge -i $_sbxAbs -o $_sgeAbs -nc
puts "pge sge returned without error: Soc_HW"
exit