component uart_model1 is
    port(
        clk: in std_logic;
        rstn: in std_logic;
        uart_rxd: in std_logic;
        uart_txd: out std_logic
    );
end component;

__: uart_model1 port map(
    clk=>,
    rstn=>,
    uart_rxd=>,
    uart_txd=>
);
