# Propel design script: Soc_HW
# Session: 53f8a02e-9319-4029-b6e7-a0d420086a41
# Mode: open

sbp_design open -name {Soc_HW} -path {C:/lscc/workspace/MachXO4C_PMOD_OLED/Soc_HW/Soc_HW/Soc_HW.sbx}

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}

sbp_config_ip -vlnv {latticesemi.com:ip:system0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_FILE_IN:C:/lscc/workspace/MachXO4C_PMOD_OLED/XO4_SW/Debug/XO4_SW.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:8192,ARBITER_EN:False,BYTE_ENABLE_S0:True,BYTE_ENABLE_S1:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,EDIT_ADDRESS_S0:False,EDIT_ADDRESS_S1:False,INIT_CHK:hex,INIT_MEM:True,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:2,REGMODE_S0:True,REGMODE_S1:True,RESET_MODE_S0:sync,RESET_MODE_S1:sync}
sbp_replace -vlnv {latticesemi.com:ip:system0:2.6.0} -name {system0_inst} -component {Soc_HW/system0_inst}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: Soc_HW"