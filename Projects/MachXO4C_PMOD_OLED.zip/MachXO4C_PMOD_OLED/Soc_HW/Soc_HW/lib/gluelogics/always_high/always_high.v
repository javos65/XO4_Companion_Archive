
module always_high (
    output wire out) ;
    assign out = 1'b1 ; 
endmodule



