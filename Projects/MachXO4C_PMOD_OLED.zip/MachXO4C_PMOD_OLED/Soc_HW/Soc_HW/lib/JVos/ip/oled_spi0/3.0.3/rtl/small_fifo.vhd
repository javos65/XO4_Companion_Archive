-------------------------------------------------------------------------------
-- Revision 3.0.3  JayFox 2025/2026
--
-- Description: Small synchronous register FIFO (single clock domain).
--              Generic g_WIDTH : word size
--              Generic g_DEPTH : number of words (any value >= 2)
--
--              - One clock, rising edge only. Flags are derived from a fill
--                counter, so they are valid in the same cycle as the pointers.
--              - FIFO starts empty after reset (no phantom entry).
--              - Read data is "show-ahead": o_rd_data always presents the
--                oldest word; i_rd_en pops it.
--              - Writing while full / reading while empty is ignored and sets a
--                sticky error flag, cleared by the next legal write / read.
--              - Every register is driven from exactly ONE process
--                (fixes the multiple-driver error BN314 on r_RD_INDEX).
--              - The data array has no reset and no initial value, so it maps
--                onto distributed RAM / registers without extra logic.
-------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;

entity module_fifo_regs_no_flags is
  generic (
    g_WIDTH : integer := 9;     -- word size
    g_DEPTH : integer := 8      -- number of words
    );
  port (
    i_nrst_sync : in std_logic; -- active low reset
    i_clk       : in std_logic;

    -- FIFO Write Interface
    i_wr_en   : in  std_logic;
    i_wr_data : in  std_logic_vector(g_WIDTH-1 downto 0);

    -- FIFO Read Interface
    i_rd_en   : in  std_logic;
    o_rd_data : out std_logic_vector(g_WIDTH-1 downto 0);

    -- FIFO Flags
    o_full    : out std_logic;
    o_empty   : out std_logic;
    o_rerror  : out std_logic;
    o_werror  : out std_logic
    );
end module_fifo_regs_no_flags;

architecture rtl of module_fifo_regs_no_flags is

  type t_FIFO_DATA is array (0 to g_DEPTH-1) of std_logic_vector(g_WIDTH-1 downto 0);
  signal r_FIFO_DATA : t_FIFO_DATA;

  signal r_WR_INDEX : integer range 0 to g_DEPTH-1;   -- next location to write
  signal r_RD_INDEX : integer range 0 to g_DEPTH-1;   -- next location to read
  signal r_COUNT    : integer range 0 to g_DEPTH;     -- words stored
  signal r_WERROR   : std_logic;
  signal r_RERROR   : std_logic;

  signal w_FULL   : std_logic;
  signal w_EMPTY  : std_logic;
  signal w_WR     : std_logic;   -- legal write this cycle
  signal w_RD     : std_logic;   -- legal read this cycle

begin

  -- flags straight from the fill counter
  w_FULL  <= '1' when r_COUNT = g_DEPTH else '0';
  w_EMPTY <= '1' when r_COUNT = 0       else '0';

  w_WR <= i_wr_en and (not w_FULL);
  w_RD <= i_rd_en and (not w_EMPTY);

  o_full   <= w_FULL;
  o_empty  <= w_EMPTY;
  o_werror <= r_WERROR;
  o_rerror <= r_RERROR;

  -- direct (show-ahead) read data: oldest word is always visible
  o_rd_data <= r_FIFO_DATA(r_RD_INDEX);

  -- data storage: write only, no reset
  p_MEM : process (i_clk) is
  begin
    if rising_edge(i_clk) then
      if w_WR = '1' then
        r_FIFO_DATA(r_WR_INDEX) <= i_wr_data;
      end if;
    end if;
  end process p_MEM;

  -- pointers, counter and error flags : the one and only driver of each
  p_CTRL : process (i_clk, i_nrst_sync) is
  begin
    if (i_nrst_sync = '0') then
      r_WR_INDEX <= 0;
      r_RD_INDEX <= 0;
      r_COUNT    <= 0;
      r_WERROR   <= '0';
      r_RERROR   <= '0';
    elsif rising_edge(i_clk) then

      -- write pointer / write error
      if w_WR = '1' then
        if r_WR_INDEX = g_DEPTH-1 then
          r_WR_INDEX <= 0;
        else
          r_WR_INDEX <= r_WR_INDEX + 1;
        end if;
        r_WERROR <= '0';
      elsif (i_wr_en = '1') then          -- write while full
        r_WERROR <= '1';
      end if;

      -- read pointer / read error
      if w_RD = '1' then
        if r_RD_INDEX = g_DEPTH-1 then
          r_RD_INDEX <= 0;
        else
          r_RD_INDEX <= r_RD_INDEX + 1;
        end if;
        r_RERROR <= '0';
      elsif (i_rd_en = '1') then          -- read while empty
        r_RERROR <= '1';
      end if;

      -- fill counter
      if (w_WR = '1') and (w_RD = '0') then
        r_COUNT <= r_COUNT + 1;
      elsif (w_WR = '0') and (w_RD = '1') then
        r_COUNT <= r_COUNT - 1;
      end if;

    end if;
  end process p_CTRL;

end rtl;
