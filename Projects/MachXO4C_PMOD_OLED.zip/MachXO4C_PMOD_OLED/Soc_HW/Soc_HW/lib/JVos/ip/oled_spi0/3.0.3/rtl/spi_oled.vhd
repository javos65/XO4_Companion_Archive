-- --------------------------------------------------------------------
-- Revision 3.0.3  JayFox 2025/2026
--
-- 4-wire SPI transmitter for OLED (SSD1306 / SSD1351 style), mode 0:
--   * SCLK idles low, data changes while SCLK is low, sampled on rising edge
--   * MSB first, 8 data bits, D/C# sent as a separate pin (data_in(8))
--   * CS is low for the whole byte, with half a clock of margin at both ends
--
-- Clocking: the shifter runs on dclk_i (separate SPI clock, one SPI bit
-- takes two dclk_i cycles, so SCLK = dclk_i / 2).
-- Interface to the (other clock domain) APB side is a toggle handshake:
--     req_tgl_i  : APB side flips this to request a byte.  data_in is stable
--                  from that moment until ack_tgl_o has caught up.
--     ack_tgl_o  : flipped here when the byte has been sent completely.
-- All crossing signals are double-flop synchronised.
-- --------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity spi_oled is
   port (
        dclk_i    : in  std_logic;                       -- SPI clock domain clock
        rst_n_i   : in  std_logic;                       -- reset, active low
        req_tgl_i : in  std_logic;                       -- request toggle  (from APB clock domain)
        data_in   : in  std_logic_vector(8 downto 0);    -- [8]:d/nc [7:0] byte to send
        ack_tgl_o : out std_logic;                       -- acknowledge toggle (to APB clock domain)
        -- spi ports
        spi_clk   : out std_logic;
        spi_dnc   : out std_logic;
        spi_ncs   : out std_logic;
        spi_data  : out std_logic;
        spi_rst   : out std_logic
   );
end spi_oled;

architecture rtl_spi_oled of spi_oled is

   type spi_state is (IDLE_ST, SETUP_ST, CLK_ST, END_ST, DONE_ST);
   signal spi_st : spi_state;

   signal rst_sync   : std_logic_vector(1 downto 0);   -- reset, released synchronously
   signal rst_n_s    : std_logic;
   signal req_sync   : std_logic_vector(1 downto 0);   -- req_tgl_i synchroniser
   signal last_req   : std_logic;                      -- last request we have taken
   signal ack_tgl    : std_logic;
   signal shifter    : std_logic_vector(7 downto 0);
   signal bit_cnt    : integer range 0 to 7;

begin

   -- OLED hardware reset follows the system reset
   spi_rst   <= rst_n_i;
   ack_tgl_o <= ack_tgl;

   --------------
   -- reset synchroniser : asserted asynchronously, released synchronously
   --------------
   RST_SYNC_PROC: process(rst_n_i, dclk_i)
   begin
      if (rst_n_i = '0') then
         rst_sync <= "00";
      elsif rising_edge(dclk_i) then
         rst_sync <= rst_sync(0) & '1';
      end if;
   end process RST_SYNC_PROC;
   rst_n_s <= rst_sync(1);

   --------------
   -- SPI process
   --------------
   SPI_PROC: process(rst_n_s, dclk_i)
   begin
      if (rst_n_s = '0') then
         spi_ncs  <= '1';
         spi_dnc  <= '0';
         spi_data <= '0';
         spi_clk  <= '0';
         spi_st   <= IDLE_ST;
         req_sync <= "00";
         last_req <= '0';
         ack_tgl  <= '0';
         shifter  <= (others => '0');
         bit_cnt  <= 7;

      elsif rising_edge(dclk_i) then
         req_sync <= req_sync(0) & req_tgl_i;           -- 2 flop synchroniser

         case spi_st is
            when IDLE_ST =>
               spi_ncs  <= '1';
               spi_clk  <= '0';
               spi_data <= '0';
               if (req_sync(1) /= last_req) then        -- new request
                  last_req <= req_sync(1);
                  shifter  <= data_in(7 downto 0);      -- stable : APB side holds it
                  spi_dnc  <= data_in(8);
                  spi_ncs  <= '0';                      -- select device
                  bit_cnt  <= 7;
                  spi_st   <= SETUP_ST;
               end if;

            when SETUP_ST =>                            -- clock low, put bit on the line
               spi_clk  <= '0';
               spi_data <= shifter(7);
               shifter  <= shifter(6 downto 0) & '0';
               spi_st   <= CLK_ST;

            when CLK_ST =>                              -- clock high : device samples bit
               spi_clk  <= '1';
               if (bit_cnt = 0) then
                  spi_st  <= END_ST;
               else
                  bit_cnt <= bit_cnt - 1;
                  spi_st  <= SETUP_ST;
               end if;

            when END_ST =>                              -- clock low, CS still active (hold)
               spi_clk  <= '0';
               spi_st   <= DONE_ST;

            when DONE_ST =>                             -- release CS, tell the APB side
               spi_ncs  <= '1';
               spi_data <= '0';
               ack_tgl  <= last_req;
               spi_st   <= IDLE_ST;

         end case;
      end if;
   end process SPI_PROC;

end rtl_spi_oled;
