-- --------------------------------------------------------------------
-- Revision History :
-- --------------------------------------------------------------------
-- Revision 1.0    JayFox 2025
-- Revision 3.0.3  JayFox 2026  - zero wait-state, standard APB slave
--                              - safe clock-domain crossing to SPI clock
--                              - all registers reset, no undriven registers
--                              - fifo starts empty (no phantom byte)
--
--  APB to 4WIRE SPI (OLED)
--  APB interface, memory mapped (register map unchanged, driver compatible)
--
--  Address   Offset
--  00xx      0x00   ID REGISTER (read only) = 0xB19B00B9
--  01xx      0x04   STATUS REGISTER (read only)
--                      [31:19] 0
--                      [18]    APB write error : data written while FIFO full
--                              (cleared by next accepted write)
--                      [17]    FIFO write error bit
--                      [16]    FIFO FULL bit
--                      [15:3]  0
--                      [2]     FIFO read error bit
--                      [1]     FIFO EMPTY bit
--                      [0]     SPI READY bit  (1 = shifter idle)
--  10xx      0x08   CONTROL REGISTER - read/write, no function
--  11xx      0x0C   DATA WRITE REGISTER
--                      [31:9]  xx
--                      [8]     DC~  (1 = data, 0 = command)
--                      [7:0]   DATAIN
--                      A write while the FIFO is full is dropped and flagged
--                      in STATUS[18]. Read returns the last value written.
-- --------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity apb_to_spi is
   port (
      -- clk_i and rst_n_i are kept out of standard APB SLAVE I/F
      clk_i   : in  std_logic; -- PCLK
      rst_n_i : in  std_logic; -- PRESETn
      sclk_i  : in  std_logic; -- separate SPI-CLK (SCLK = sclk_i / 2)
      PSEL    : in  std_logic;
      PENABLE : in  std_logic;
      PADDR   : in  std_logic_vector(7 downto 0);
      PWRITE  : in  std_logic;
      PWDATA  : in  std_logic_vector(31 downto 0);
      PRDATA  : out std_logic_vector(31 downto 0);
      PREADY  : out std_logic;
      PSLVERR : out std_logic;
      -- spi ports
      SCLK    : out std_logic;
      DC      : out std_logic;
      CS      : out std_logic;
      SDIN    : out std_logic;
      RST     : out std_logic
   );
end apb_to_spi;

architecture rtl_apb_to_spi of apb_to_spi is

   constant C_ID : std_logic_vector(31 downto 0) := x"B19B00B9";

   signal MEM_ADDR     : std_logic_vector(1 downto 0);
   signal REG1_STATUS  : std_logic_vector(31 downto 0);
   signal REG2_CONTROL : std_logic_vector(31 downto 0);
   signal REG3_DATA0   : std_logic_vector(31 downto 0);

   signal apb_access   : std_logic;      -- APB access phase
   signal wr_data_reg  : std_logic;      -- write to DATA register this cycle
   signal wr_ctrl_reg  : std_logic;      -- write to CONTROL register this cycle
   signal apb_werr     : std_logic;      -- sticky : write while full

   -- FIFO signals
   signal FREAD   : std_logic;
   signal FWRITE  : std_logic;
   signal FRDATA  : std_logic_vector(8 downto 0);
   signal EMPTY   : std_logic;
   signal FULL    : std_logic;
   signal RERROR  : std_logic;
   signal WERROR  : std_logic;

   -- SPI hand-over (PCLK domain side of the toggle handshake)
   signal tx_data  : std_logic_vector(8 downto 0);   -- held stable while busy
   signal req_tgl  : std_logic;
   signal ack_tgl  : std_logic;                      -- from SPI domain (async)
   signal ack_sync : std_logic_vector(1 downto 0);
   signal busy     : std_logic;
   signal READY    : std_logic;

   component spi_oled
      port(
         dclk_i    : in  std_logic;
         rst_n_i   : in  std_logic;
         req_tgl_i : in  std_logic;
         data_in   : in  std_logic_vector(8 downto 0);
         ack_tgl_o : out std_logic;
         spi_clk   : out std_logic;
         spi_dnc   : out std_logic;
         spi_ncs   : out std_logic;
         spi_data  : out std_logic;
         spi_rst   : out std_logic
      );
   end component;

   component module_fifo_regs_no_flags
      generic (
         g_WIDTH : integer := 9;
         g_DEPTH : integer := 8
      );
      port(
         i_nrst_sync : in  std_logic;
         i_clk       : in  std_logic;
         i_wr_en     : in  std_logic;
         i_wr_data   : in  std_logic_vector(8 downto 0);
         i_rd_en     : in  std_logic;
         o_rd_data   : out std_logic_vector(8 downto 0);
         o_full      : out std_logic;
         o_empty     : out std_logic;
         o_rerror    : out std_logic;
         o_werror    : out std_logic
      );
   end component;

begin

   -- bits 1:0 of PADDR are not 32 bit aligned addresses : ignored
   MEM_ADDR <= PADDR(3 downto 2);

   -- zero wait-state slave, never an error response
   PREADY  <= '1';
   PSLVERR <= '0';

   apb_access  <= PSEL and PENABLE;
   wr_data_reg <= apb_access and PWRITE when MEM_ADDR = "11" else '0';
   wr_ctrl_reg <= apb_access and PWRITE when MEM_ADDR = "10" else '0';

   -- accept a byte only when the FIFO is not full
   FWRITE <= wr_data_reg and (not FULL);

   SPI0_BLOCK_INST: spi_oled
      port map(
         dclk_i    => sclk_i,
         rst_n_i   => rst_n_i,
         req_tgl_i => req_tgl,
         data_in   => tx_data,
         ack_tgl_o => ack_tgl,
         spi_clk   => SCLK,       -- I/O pin
         spi_dnc   => DC,         -- I/O pin
         spi_ncs   => CS,         -- I/O pin
         spi_data  => SDIN,       -- I/O pin
         spi_rst   => RST         -- I/O pin
      );

   FIFO_BLOCK_INST: module_fifo_regs_no_flags
      generic map (
         g_WIDTH => 9,
         g_DEPTH => 8
      )
      port map(
         i_nrst_sync => rst_n_i,
         i_clk       => clk_i,
         i_wr_en     => FWRITE,
         i_wr_data   => PWDATA(8 downto 0),
         i_rd_en     => FREAD,
         o_rd_data   => FRDATA,
         o_full      => FULL,
         o_empty     => EMPTY,
         o_rerror    => RERROR,
         o_werror    => WERROR
      );

   --------------
   -- Status register (all bits live)
   --------------
   READY <= not busy;

   REG1_STATUS(31 downto 19) <= (others => '0');
   REG1_STATUS(18)           <= apb_werr;
   REG1_STATUS(17)           <= WERROR;
   REG1_STATUS(16)           <= FULL;
   REG1_STATUS(15 downto 3)  <= (others => '0');
   REG1_STATUS(2)            <= RERROR;
   REG1_STATUS(1)            <= EMPTY;
   REG1_STATUS(0)            <= READY;

   --------------
   -- APB read mux : combinational, valid for the whole access
   --------------
   PRDATA <= C_ID         when MEM_ADDR = "00" else
             REG1_STATUS  when MEM_ADDR = "01" else
             REG2_CONTROL when MEM_ADDR = "10" else
             REG3_DATA0;

   --------------
   -- APB write side registers
   --------------
   APB_REG_PROC: process(rst_n_i, clk_i)
   begin
      if (rst_n_i = '0') then
         REG2_CONTROL <= (others => '0');
         REG3_DATA0   <= (others => '0');
         apb_werr     <= '0';
      elsif rising_edge(clk_i) then
         if (wr_ctrl_reg = '1') then
            REG2_CONTROL <= PWDATA;
         end if;
         if (wr_data_reg = '1') then
            REG3_DATA0 <= PWDATA;
            apb_werr   <= FULL;          -- error when written while full, else cleared
         end if;
      end if;
   end process APB_REG_PROC;

   --------------
   -- SPI hand-over : pop a byte from the FIFO and pass it to the SPI shifter
   -- using a toggle request / toggle acknowledge handshake.
   --------------
   SPI_CONTROL_PROC: process(rst_n_i, clk_i)
   begin
      if (rst_n_i = '0') then
         FREAD    <= '0';
         tx_data  <= (others => '0');
         req_tgl  <= '0';
         ack_sync <= "00";
         busy     <= '0';
      elsif rising_edge(clk_i) then
         FREAD    <= '0';                              -- default : 1 cycle pop pulse
         ack_sync <= ack_sync(0) & ack_tgl;            -- 2 flop synchroniser

         if (busy = '0') then
            if (EMPTY = '0') then                      -- byte waiting in FIFO
               tx_data <= FRDATA;                      -- show-ahead data, held until ack
               FREAD   <= '1';                         -- pop it
               req_tgl <= not req_tgl;                 -- request SPI transfer
               busy    <= '1';
            end if;
         else
            if (ack_sync(1) = req_tgl) then            -- SPI finished this byte
               busy <= '0';
            end if;
         end if;
      end if;
   end process SPI_CONTROL_PROC;

end rtl_apb_to_spi;
