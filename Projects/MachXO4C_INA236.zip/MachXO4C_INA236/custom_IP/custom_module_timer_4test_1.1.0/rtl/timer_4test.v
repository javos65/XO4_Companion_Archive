// timer_4test 1.1.0: four 8-bit looping counters, each with a MurmurHash3 32-bit finalizer
// (fmix32), as a switchable power load. Two clocks:
//   PCLK  APB register interface (12 MHz in the reference design)
//   FCLK  counter and hash clock, as fast as timing allows (separate PLL output)
//
// Counters (FCLK): each counts up by one per FCLK edge while its enable bit is set and wraps from
// 0xFF to 0x00; a disabled counter holds its value.
//
// Hash unit per counter (FCLK): every time bit 5 of the counter changes, the unit (when idle) takes
// the 8-bit counter value, zero-extended to 32 bits, and computes the MurmurHash3 finalizer
// sequentially in one 32-bit working register, without a look-up table:
//     h ^= h >> 16;  h *= 0x85EBCA6B;  h ^= h >> 13;  h *= 0xC2B2AE35;  h ^= h >> 16
// Each constant multiplication is a pipelined shift-and-add over the 32 bits of the constant, one
// 32-bit addition per clock (33 clocks), so the critical path is one adder and FCLK can be high.
// One hash takes 3 + 33 + 33 = 69 clocks; a counter changes bit 5 every 32 clocks, so a running counter
// keeps its unit busy all the time (requests that arrive while it is busy are skipped).
//
// Clock-domain crossing: ENABLE goes to FCLK through two flip-flops per bit (quasi-static).
// CLEAR is sent as a toggle per bit and synchronised in FCLK. COUNT and HASHn are read in PCLK
// through two flip-flops per bit; a value that changes during a read can be read inconsistently
// (diagnostic only; the block is a load, the values are not used).
//
// Register map (byte offsets, PADDR[4:2], 32-bit APB, zero wait states):
//   0x00 ID      R   0x54345432 ("T4T2")
//   0x04 ENABLE  RW  bits 3..0 = counter 3..0 runs (1) or holds (0); reset 0 (all off)
//   0x08 COUNT   R   {counter3, counter2, counter1, counter0}, 8 bits each
//   0x0C CLEAR   W   writing 1 to bit n sets counter n to 0 (reads 0)
//   0x10 HASH0   R   last fmix32 result of counter 0
//   0x14 HASH1   R   last fmix32 result of counter 1
//   0x18 HASH2   R   last fmix32 result of counter 2
//   0x1C HASH3   R   last fmix32 result of counter 3

// ---------------------------------------------------------------- sequential fmix32 unit
// Multiply by a constant as shift-and-add, pipelined for a high clock: the constant is a shift
// register (its bit 0 selects the next term), and the selected term is registered one clock before
// it is added, so the only logic between registers is one 32-bit adder. 33 clocks per multiply.
module timer_4test_fmix32 (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start,      // request; taken only when idle
    input  wire [7:0]  din,
    output reg  [31:0] hash
);
    localparam [31:0] C1 = 32'h85EB_CA6B;
    localparam [31:0] C2 = 32'hC2B2_AE35;
    localparam [2:0]  S_IDLE = 3'd0, S_X16A = 3'd1, S_MUL1 = 3'd2, S_X13 = 3'd3,
                      S_MUL2 = 3'd4, S_X16B = 3'd5;

    reg [2:0]  st;
    reg [31:0] h;                  // working value
    reg [31:0] m;                  // multiplicand, shifted left by one per clock
    reg [31:0] csh;                // constant, shifted right by one per clock
    reg [31:0] term;               // selected term, added in the next clock
    reg [31:0] acc;                // partial product
    reg [5:0]  idx;                // 0..32

    wire [31:0] sum = acc + term;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st   <= S_IDLE;
            h    <= 32'd0;
            m    <= 32'd0;
            csh  <= 32'd0;
            term <= 32'd0;
            acc  <= 32'd0;
            idx  <= 6'd0;
            hash <= 32'd0;
        end else begin
            case (st)
                S_IDLE: if (start) begin h <= {24'd0, din}; st <= S_X16A; end
                S_X16A: begin
                    m <= h ^ (h >> 16); csh <= C1; acc <= 32'd0; term <= 32'd0; idx <= 6'd0;
                    st <= S_MUL1;
                end
                S_MUL1, S_MUL2: begin
                    acc  <= sum;                       // adds the term selected last clock
                    term <= csh[0] ? m : 32'd0;        // term for the next clock
                    m    <= m << 1;
                    csh  <= csh >> 1;
                    idx  <= idx + 6'd1;
                    if (idx == 6'd32) begin            // term 31 was added in this clock
                        h  <= sum;
                        st <= (st == S_MUL1) ? S_X13 : S_X16B;
                    end
                end
                S_X13: begin
                    m <= h ^ (h >> 13); csh <= C2; acc <= 32'd0; term <= 32'd0; idx <= 6'd0;
                    st <= S_MUL2;
                end
                S_X16B: begin
                    hash <= h ^ (h >> 16); st <= S_IDLE;
                end
                default: st <= S_IDLE;
            endcase
        end
    end
endmodule
// ---------------------------------------------------------------- APB block
module timer_4test (
    input  wire        PCLK,
    input  wire        PRESETN,
    input  wire        FCLK,       // counter / hash clock
    input  wire [4:0]  PADDR,
    input  wire        PSEL,
    input  wire        PENABLE,
    input  wire        PWRITE,
    input  wire [31:0] PWDATA,
    output reg  [31:0] PRDATA,
    output wire        PREADY,
    output wire        PSLVERR
);
    localparam [31:0] ID_VALUE = 32'h5434_5432;
    localparam [2:0]  A_ID = 3'd0, A_ENABLE = 3'd1, A_COUNT = 3'd2, A_CLEAR = 3'd3,
                      A_HASH0 = 3'd4, A_HASH1 = 3'd5, A_HASH2 = 3'd6, A_HASH3 = 3'd7;

    wire       wr    = PSEL & PENABLE & PWRITE;
    wire [2:0] waddr = PADDR[4:2];

    assign PREADY  = 1'b1;
    assign PSLVERR = 1'b0;

    // ------------------------------------------------ PCLK domain registers
    reg  [3:0]  enable;
    reg  [3:0]  clr_tgl;           // toggles once per CLEAR request bit
    always @(posedge PCLK or negedge PRESETN) begin
        if (!PRESETN) begin
            enable  <= 4'd0;
            clr_tgl <= 4'd0;
        end else if (wr) begin
            if (waddr == A_ENABLE) enable  <= PWDATA[3:0];
            if (waddr == A_CLEAR)  clr_tgl <= clr_tgl ^ PWDATA[3:0];
        end
    end

    // ------------------------------------------------ FCLK reset: asynchronous assert, synchronous release
    reg [1:0] frst_sync;
    always @(posedge FCLK or negedge PRESETN)
        if (!PRESETN) frst_sync <= 2'b00;
        else          frst_sync <= {frst_sync[0], 1'b1};
    wire frst_n = frst_sync[1];

    // ------------------------------------------------ PCLK -> FCLK
    (* syn_preserve = 1 *) reg [3:0] en_s1, en_s2;
    (* syn_preserve = 1 *) reg [3:0] ct_s1, ct_s2;
    reg [3:0] ct_s3;
    always @(posedge FCLK or negedge frst_n) begin
        if (!frst_n) begin
            en_s1 <= 4'd0; en_s2 <= 4'd0;
            ct_s1 <= 4'd0; ct_s2 <= 4'd0; ct_s3 <= 4'd0;
        end else begin
            en_s1 <= enable;  en_s2 <= en_s1;
            ct_s1 <= clr_tgl; ct_s2 <= ct_s1; ct_s3 <= ct_s2;
        end
    end
    wire [3:0] f_en  = en_s2;
    wire [3:0] f_clr = ct_s2 ^ ct_s3;

    // ------------------------------------------------ FCLK domain: counters and hash units
    reg  [7:0]  cnt  [0:3];
    reg  [3:0]  b5_d;
    wire [31:0] hash [0:3];

    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : g_ch
            always @(posedge FCLK or negedge frst_n) begin
                if (!frst_n) begin
                    cnt[i]  <= 8'd0;
                    b5_d[i] <= 1'b0;
                end else begin
                    b5_d[i] <= cnt[i][5];
                    if (f_clr[i])      cnt[i] <= 8'd0;
                    else if (f_en[i])  cnt[i] <= cnt[i] + 8'd1;
                end
            end

            timer_4test_fmix32 u_fmix (
                .clk   (FCLK),
                .rst_n (frst_n),
                .start (cnt[i][5] ^ b5_d[i]),
                .din   (cnt[i]),
                .hash  (hash[i])
            );
        end
    endgenerate

    // ------------------------------------------------ FCLK -> PCLK (read-back, may be inconsistent)
    wire [159:0] f_view = {hash[3], hash[2], hash[1], hash[0], cnt[3], cnt[2], cnt[1], cnt[0]};
    (* syn_preserve = 1 *) reg [159:0] rb_s1, rb_s2;
    always @(posedge PCLK or negedge PRESETN) begin
        if (!PRESETN) begin
            rb_s1 <= 160'd0; rb_s2 <= 160'd0;
        end else begin
            rb_s1 <= f_view; rb_s2 <= rb_s1;
        end
    end

    always @(*) begin
        case (PADDR[4:2])
            A_ID:     PRDATA = ID_VALUE;
            A_ENABLE: PRDATA = {28'd0, enable};
            A_COUNT:  PRDATA = rb_s2[31:0];
            A_HASH0:  PRDATA = rb_s2[63:32];
            A_HASH1:  PRDATA = rb_s2[95:64];
            A_HASH2:  PRDATA = rb_s2[127:96];
            A_HASH3:  PRDATA = rb_s2[159:128];
            default:  PRDATA = 32'd0;
        endcase
    end
endmodule
