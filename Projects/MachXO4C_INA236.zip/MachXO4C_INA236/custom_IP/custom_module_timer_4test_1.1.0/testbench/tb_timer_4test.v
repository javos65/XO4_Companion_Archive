// Self-checking testbench for timer_4test 1.1.0: APB (PCLK) at 12 MHz, counters/hash (FCLK) at 132 MHz.
`timescale 1ns/1ps
module tb_timer_4test;
    reg         PCLK = 1'b0, FCLK = 1'b0, PRESETN = 1'b0;
    reg  [4:0]  PADDR = 5'd0;
    reg         PSEL = 1'b0, PENABLE = 1'b0, PWRITE = 1'b0;
    reg  [31:0] PWDATA = 32'd0;
    wire [31:0] PRDATA;
    wire        PREADY, PSLVERR;
    integer     errors = 0, i, k;
    reg  [31:0] rd, a, b;

    timer_4test dut (.PCLK(PCLK), .PRESETN(PRESETN), .FCLK(FCLK), .PADDR(PADDR), .PSEL(PSEL),
                     .PENABLE(PENABLE), .PWRITE(PWRITE), .PWDATA(PWDATA), .PRDATA(PRDATA),
                     .PREADY(PREADY), .PSLVERR(PSLVERR));

    always #41.667 PCLK = ~PCLK;    // 12 MHz
    always #3.788  FCLK = ~FCLK;    // 132 MHz

    function [31:0] fmix32(input [31:0] x);
        reg [31:0] h;
        begin
            h = x;
            h = h ^ (h >> 16);
            h = h * 32'h85EBCA6B;
            h = h ^ (h >> 13);
            h = h * 32'hC2B2AE35;
            h = h ^ (h >> 16);
            fmix32 = h;
        end
    endfunction

    // a hash unit only ever sees counter values 0, 32, 64, ..., 224 (taken when bit 5 changed;
    // 0 comes from the wrap 255 -> 0, and fmix32(0) = 0 is a valid result)
    function is_valid_hash(input [31:0] v);
        integer j;
        begin
            is_valid_hash = 1'b0;
            for (j = 0; j < 256; j = j + 32) if (fmix32(j) == v) is_valid_hash = 1'b1;
        end
    endfunction

    task apb_write(input [4:0] addr, input [31:0] data);
        begin
            @(posedge PCLK); PADDR <= addr; PWDATA <= data; PWRITE <= 1'b1; PSEL <= 1'b1;
            @(posedge PCLK); PENABLE <= 1'b1;
            @(posedge PCLK); PSEL <= 1'b0; PENABLE <= 1'b0; PWRITE <= 1'b0;
        end
    endtask

    task apb_read(input [4:0] addr, output [31:0] data);
        begin
            @(posedge PCLK); PADDR <= addr; PWRITE <= 1'b0; PSEL <= 1'b1;
            @(posedge PCLK); PENABLE <= 1'b1;
            #1 data = PRDATA;
            @(posedge PCLK); PSEL <= 1'b0; PENABLE <= 1'b0;
        end
    endtask

    task check(input [255:0] what, input ok);
        begin
            if (!ok) begin errors = errors + 1; $display("FAIL: %0s", what); end
            else $display("ok:   %0s", what);
        end
    endtask

    initial begin
        repeat (3) @(posedge PCLK);
        PRESETN = 1'b1;
        repeat (2) @(posedge PCLK);
        apb_read(5'h00, rd);  check("ID reads 0x54345432", rd == 32'h5434_5432);
        apb_read(5'h10, rd);  check("HASH0 resets to 0", rd == 32'd0);
        check("reference fmix32(1) = 0x514E28B7", fmix32(32'd1) == 32'h514E28B7);

        apb_write(5'h04, 32'h1);                         // counter 0 only
        repeat (12) @(posedge PCLK);                     // ~130 FCLK: first hash (input 32) done
        apb_read(5'h10, rd);
        $display("      HASH0 = 0x%08h, fmix32(32) = 0x%08h", rd, fmix32(32));
        check("first HASH0 = fmix32(32)", rd == fmix32(32));
        apb_read(5'h14, rd);  check("HASH1 idle while counter 1 is off", rd == 32'd0);

        apb_write(5'h04, 32'hF);                         // all on
        repeat (60) @(posedge PCLK);
        k = 0;
        for (i = 0; i < 4; i = i + 1) begin
            apb_write(5'h04, 32'h0);                     // stop, so the read-back is stable
            repeat (30) @(posedge PCLK);
            apb_read(5'h10 + 4*i, rd);
            $display("      read 0x%02h: HASH%0d = 0x%08h  (rb_s2 top 0x%08h, f_view top 0x%08h)", 5'h10 + 4*i, i, rd, dut.rb_s2[159:128], dut.f_view[159:128]);
            if (is_valid_hash(rd)) k = k + 1;
            else $display("      HASH%0d = 0x%08h not a valid fmix32 result", i, rd);
            apb_write(5'h04, 32'hF);
        end
        check("all four HASHn hold valid fmix32 results", k == 4);

        apb_write(5'h04, 32'h0);
        repeat (30) @(posedge PCLK);
        apb_read(5'h08, a);  repeat (50) @(posedge PCLK); apb_read(5'h08, b);
        check("counters hold when disabled", a == b);
        apb_write(5'h0C, 32'hF);
        repeat (10) @(posedge PCLK);
        apb_read(5'h08, a);  check("CLEAR sets all counters to 0", a == 32'd0);
        apb_read(5'h04, rd); check("ENABLE reads back 0", rd == 32'd0);
        check("PREADY high, PSLVERR low", PREADY === 1'b1 && PSLVERR === 1'b0);

        if (errors == 0) $display("SIMULATION PASSED");
        else             $display("SIMULATION FAILED: %0d error(s)", errors);
        $finish;
    end
endmodule
