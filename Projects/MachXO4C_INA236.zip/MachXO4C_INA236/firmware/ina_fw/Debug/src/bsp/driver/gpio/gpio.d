src/bsp/driver/gpio/gpio.o: ../src/bsp/driver/gpio/gpio.c \
 ../src/bsp/driver/gpio/gpio.h ../src/bsp/driver/gpio/gpio_regs.h \
 ../src/bsp/driver/reg_access.h
../src/bsp/driver/gpio/gpio.h:
../src/bsp/driver/gpio/gpio_regs.h:
../src/bsp/driver/reg_access.h:
