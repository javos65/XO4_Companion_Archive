src/bsp/driver/INA236_efb/INA236_efb.o: \
 ../src/bsp/driver/INA236_efb/INA236_efb.c \
 ../src/bsp/driver/INA236_efb/INA236_efb.h \
 ../src/bsp/driver/INA236_efb/INA236_efb_regs.h
../src/bsp/driver/INA236_efb/INA236_efb.h:
../src/bsp/driver/INA236_efb/INA236_efb_regs.h:
