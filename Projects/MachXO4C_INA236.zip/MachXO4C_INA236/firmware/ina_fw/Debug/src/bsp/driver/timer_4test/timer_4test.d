src/bsp/driver/timer_4test/timer_4test.o: \
 ../src/bsp/driver/timer_4test/timer_4test.c \
 ../src/bsp/driver/timer_4test/timer_4test.h \
 ../src/bsp/driver/timer_4test/timer_4test_regs.h
../src/bsp/driver/timer_4test/timer_4test.h:
../src/bsp/driver/timer_4test/timer_4test_regs.h:
