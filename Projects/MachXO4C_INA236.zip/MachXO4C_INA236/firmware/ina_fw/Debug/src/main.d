src/main.o: ../src/main.c ../src/bsp/driver/INA236_efb/INA236_efb.h \
 ../src/bsp/driver/INA236_efb/INA236_efb_regs.h \
 ../src/bsp/driver/uart/uart.h ../src/bsp/driver/gpio/gpio.h \
 ../src/bsp/driver/riscv_sm/timer.h \
 ../src/bsp/driver/timer_4test/timer_4test.h \
 ../src/bsp/driver/timer_4test/timer_4test_regs.h
../src/bsp/driver/INA236_efb/INA236_efb.h:
../src/bsp/driver/INA236_efb/INA236_efb_regs.h:
../src/bsp/driver/uart/uart.h:
../src/bsp/driver/gpio/gpio.h:
../src/bsp/driver/riscv_sm/timer.h:
../src/bsp/driver/timer_4test/timer_4test.h:
../src/bsp/driver/timer_4test/timer_4test_regs.h:
