################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ELF_SRCS :=
OBJ_SRCS :=
ASM_SRCS :=
C_SRCS :=
S_UPPER_SRCS :=
O_SRCS :=
SECONDARY_MEMORY :=
OBJS :=
SECONDARY_SIZE :=
S_UPPER_DEPS :=
C_DEPS :=

# Every subdirectory with source files must be described here
SUBDIRS := \
src \
src/bsp/driver/INA236_efb \
src/bsp/driver/gpio \
src/bsp/driver/riscv_sm \
src/bsp/driver/timer_4test \
src/bsp/driver/uart 

