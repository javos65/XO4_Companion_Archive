/* INA236 power monitor, firmware 1.0.
 *
 * Polls four INA236A monitors through the INA236_efb driver (EFB primary I2C) every 200 ms and prints
 * one compact sample line over the UART (115200 baud 8N1); SW1 or the p command prints the full table. RISC-V SM runtime (riscv_sm BSP crt0), polling only,
 * no interrupts, no printf (integer formatting is local to keep the image small).
 *
 * Addresses: UART 0x8000, GPIO 0x8400, INA236_efb 0x8800, PIC/timer 0xFFFF0000.
 * LED lines are on GPIO bits 0..3 (active low): all four blink together every 500 ms (no status LEDs).
 * SW1 on GPIO bit 4 (active low).
 */
#include <stddef.h>
#include <stdint.h>
/* EFB primary I2C (registers 0x100..0x124) on the fixed pins A9/C9, through INA236_efb at 0x8800. */
#include "INA236_efb.h"
#include "bsp/driver/uart/uart.h"
#include "bsp/driver/gpio/gpio.h"
#include "bsp/driver/riscv_sm/timer.h"
#include "timer_4test.h"

/* ---- board constants ---- */
#define UART_BASE        0x00008000u
#define GPIO_BASE        0x00008400u
#define INA_BASE         0x00008800u    /* INA236_efb -> lscc_efb */
#define TIMER_BASE       0xFFFF0000u
#define LOAD_BASE        0x00008C00u    /* timer_4test 1.1: 4 counters + fmix32 units on the fast clock */
#define LOAD_STEP_TICKS  (5u * CPU_HZ)  /* 5 s per load step */
#define CPU_HZ           24000000u      /* CPU clock; machine timer assumed to tick at this rate */
#define APB_HZ           12000000u      /* APB / EFB WISHBONE clock */
#define UART_BAUD        115200u        /* divisor 104 at 12 MHz: 115385 baud, +0.16 % */
#define I2C_HZ           100000u
#define RSHUNT_UOHM      10000u         /* 10 milliohm (Figure 8-1) */
#define CURRENT_LSB_UA   100u           /* 100 uA, SHUNT_CAL = 5120; power LSB 3.2 mW, range +/-3.27 A */
#define TOL_PERCENT      5u             /* voltage tolerance around the nominal value */
#define POLL_TICKS       (CPU_HZ / 5u)  /* 200 ms measurement period (5 samples per second) */
/* INA236 CONFIG: standard setting 0x4127 with AVG = 4 (bits 11..9 = 001): 1.1 ms bus and shunt
 * conversion, 4 averages, continuous -> a new averaged result about every 8.8 ms */
#define INA_CONFIG       0x4327u

/* GPIO lines */
#define LED_BLINK_TICKS  (CPU_HZ / 2u)  /* all four LEDs toggle together every 500 ms */
#define SW1_LINE         4u
#define GPIO_LINES       5u
#define GPIO_OUT_MASK    0x0Fu          /* bits 0..3 outputs (LEDs), bit 4 input (SW1) */

#define NUM_CH           4

struct ch_cfg {
    const char *name;                   /* label printed in the table */
    uint8_t     addr;                   /* INA236A address */
    uint16_t    nominal_mv;             /* expected bus voltage */
};

static const struct ch_cfg cfg[NUM_CH] = {
    { "U19 VCORE ", INA236_ADDR_A0_GND, 3300u },    /* VCC_Core, J19 2-3 */
    { "U20 VCIO2 ", INA236_ADDR_A0_VS,  3300u },    /* Bank 2, J20 2-3 */
    { "U21 BANK01", INA236_ADDR_A0_SDA, 3300u },    /* VCC_BANK_3V3 */
    { "U22 VADJ  ", INA236_ADDR_A0_SCL, 1800u },    /* Banks 4 and 5 */
};

static struct uart_instance       uart;
static struct gpio_instance       gpio;
static struct timer_instance      tmr;
static struct ina236_efb_instance ina;
static struct timer_4test_instance load;
static uint8_t                    load_ok;
static uint8_t                    load_step;     /* 0 = all off, 1..4 = counters 0..n-1 on */
static struct ina236_channel      ch[NUM_CH];
static uint8_t                    present[NUM_CH];
static uint8_t                    autoprint = 1;
static uint8_t                    fault_latched;

/* ------------------------------------------------------------------ console */
static void put_ch(char c) { (void)uart_putc(&uart, (unsigned char)c); }
static void put_str(const char *s) { while (*s) put_ch(*s++); }
static void put_crlf(void) { put_ch('\r'); put_ch('\n'); }

/* unsigned number, right aligned in `width` characters, padded with `pad` */
static void put_num(uint32_t v, int width, char pad)
{
    char buf[11];
    int n = 0;
    do { buf[n++] = (char)('0' + (v % 10u)); v /= 10u; } while (v != 0u && n < 10);
    for (int i = n; i < width; i++) put_ch(pad);
    while (n > 0) put_ch(buf[--n]);
}

static void put_hex2(uint8_t v)
{
    put_ch("0123456789ABCDEF"[(v >> 4) & 0xFu]);
    put_ch("0123456789ABCDEF"[v & 0xFu]);
}

/* ------------------------------------------------------------------ GPIO helpers */
/* Note on the Lattice GPIO driver 1.8.1: gpio_output_write() masks the value with the line's bit
 * (1 << line) without shifting it, so the value must already be in bit position `line`. Passing
 * 0/1 only worked for line 0 (LED1); LED2..LED4 were stuck at 0, i.e. permanently on. Likewise
 * gpio_input_get() returns the whole input register, not one bit. */
static void led(uint32_t line, int on)
{
    (void)gpio_output_write(&gpio, line, (on ? 0u : 1u) << line);   /* active low */
}

static int sw1_pressed(void)
{
    uint32_t v = 0xFFFFFFFFu;
    if (gpio_input_get(&gpio, SW1_LINE, &v) != 0)
        return 0;
    return ((v >> SW1_LINE) & 1u) == 0u;                          /* active low */
}

/* ------------------------------------------------------------------ time base */
static uint64_t now_ticks(void)
{
    unsigned long long v = 0;
    (void)timer_get_mtime(&tmr, &v);
    return (uint64_t)v;
}

/* busy wait on the machine timer, used by the EFB driver for the read real-time wait */
static void udelay(uint32_t us)
{
    uint64_t end = now_ticks() + (uint64_t)us * (CPU_HZ / 1000000u);
    while ((int64_t)(now_ticks() - end) < 0) { }
}

/* ------------------------------------------------------------------ measurement */
static void init_channel(int i)
{
    int rc;
    ina236_channel_default(&ch[i], cfg[i].addr, RSHUNT_UOHM, CURRENT_LSB_UA);
    ch[i].config = INA_CONFIG;
    rc = ina236_probe(&ina, cfg[i].addr);
    if (rc == INA236_OK)
        rc = ina236_configure(&ina, &ch[i]);
    present[i] = (rc == INA236_OK);
    put_str(cfg[i].name);
    put_str(present[i] ? " INA OK" : " INA MISSING");
    if (!present[i]) {
        put_str(" (");
        put_str(ina236_strerror(rc));
        put_str(" SR=0x");
        put_hex2(ina.last_sr);
        put_ch(')');
        fault_latched = 1;
    }
    put_crlf();
}

/* Probe every 7-bit address 0x08..0x77 with an address-only write and list those that
 * acknowledge. Used to find the real INA236 addresses when the expected ones do not answer. */
static int scan_bus(void)
{
    int found = 0;
    put_str("SCAN:");
    for (uint8_t a = 0x08u; a <= 0x77u; a++) {
        if (ina236_i2c_write(&ina, a, NULL, 0u) == INA236_OK) {
            put_str(" 0x");
            put_hex2(a);
            if (ina236_probe(&ina, a) == INA236_OK)
                put_str("(INA236)");              /* manufacturer and device ID match */
            found++;
        }
    }
    put_str(found ? "" : " none");
    put_str(" SR=0x");
    put_hex2(ina.last_sr);
    put_crlf();
    return found;
}

/* EFB primary I2C registers as read back: CR, BR0, BR1, SR (expected CR=8C BR0=1E BR1=00 SR=00) */
static void dump_efb(void)
{
    static const uint32_t off[4] = { INA236_EFB_I2C_CR, INA236_EFB_I2C_BR0, INA236_EFB_I2C_BR1, INA236_EFB_I2C_SR };
    static const char *const nm[4] = { "EFB CR=", " BR0=", " BR1=", " SR=" };
    for (int i = 0; i < 4; i++) { put_str(nm[i]); put_hex2(ina236_efb_reg(&ina, off[i])); }
    put_crlf();
}

static void init_all(void)
{
    (void)scan_bus();                      /* report every address that answers, at every start */
    for (int i = 0; i < NUM_CH; i++)
        init_channel(i);
}

/* one table line; returns 1 when the channel is in fault */
static int report_channel(int i)
{
    struct ina236_sample s;
    const char *flag = "OK";
    int rc = ina236_read_sample(&ina, &ch[i], &s);
    int fault = 0;

    if (rc != INA236_OK && rc != INA236_ERR_CAL) {            /* retry once, then try recovery */
        rc = ina236_read_sample(&ina, &ch[i], &s);
        if (rc != INA236_OK && rc != INA236_ERR_CAL)
            (void)ina236_i2c_recover(&ina);
    }
    put_str(cfg[i].name);
    if (rc != INA236_OK && rc != INA236_ERR_CAL) {
        put_str("  ---- mV  ------ mA  ---- mW ");
        put_str(rc == INA236_ERR_NACK ? "NACK" : "I2C");
        put_crlf();
        return 1;
    }
    {
        uint32_t nom = cfg[i].nominal_mv;
        uint32_t dev = (s.bus_mv > nom) ? (s.bus_mv - nom) : (nom - s.bus_mv);
        if (rc == INA236_ERR_CAL)                 { flag = "CAL";  fault = 1; }
        else if (dev * 100u > nom * TOL_PERCENT)  { flag = (s.bus_mv > nom) ? "HIGH" : "LOW"; fault = 1; }
    }
    put_str("  ");
    put_num(s.bus_mv, 4, ' ');
    put_str(" mV  ");
    {   /* current with 0.1 mA resolution: sign, 3 digits, point, 1 digit */
        int32_t  ua  = s.current_ua;
        uint32_t mag = (uint32_t)(ua < 0 ? -ua : ua) / 100u;      /* in 0.1 mA */
        put_ch(ua < 0 ? '-' : ' ');
        put_num(mag / 10u, 3, '0');
        put_ch('.');
        put_num(mag % 10u, 1, '0');
    }
    put_str(" mA  ");
    put_num(s.power_mw, 4, '0');
    put_str(" mW ");
    put_str(flag);
    put_crlf();
    return fault;
}

static void report_all(void)
{
    int fault = 0;
    put_str("CH         BUS        CURRENT   POWER    STATE\r\n");
    for (int i = 0; i < NUM_CH; i++) {
        if (!present[i]) {                                    /* try to bring a missing device up */
            init_channel(i);
            if (!present[i]) { fault = 1; continue; }
        }
        fault |= report_channel(i);
    }
    if (fault) fault_latched = 1;
}

/* Compact sample line, one per measurement period (for logging and the live plot):
 *   M <time_ms> <mV>,<mA.d>,<mW> <mV>,<mA.d>,<mW> <mV>,<mA.d>,<mW> <mV>,<mA.d>,<mW> L<n>
 * rails in the order U19 U20 U21 U22; a rail that does not answer is "-,-,-"; L<n> is the number of
 * timer_4test counters that are on. About 70 characters, 6 ms at 115200 baud. */
static void put_ma_dec(int32_t ua)
{
    uint32_t mag = (uint32_t)(ua < 0 ? -ua : ua) / 100u;       /* in 0.1 mA */
    if (ua < 0) put_ch('-');
    put_num(mag / 10u, 1, '0');
    put_ch('.');
    put_num(mag % 10u, 1, '0');
}

static void sample_all(void)
{
    struct ina236_sample s;
    int fault = 0;
    uint32_t ms = (uint32_t)(now_ticks() / (CPU_HZ / 1000u));
    put_str("M ");
    put_num(ms, 1, '0');
    for (int i = 0; i < NUM_CH; i++) {
        int rc = present[i] ? ina236_read_sample(&ina, &ch[i], &s) : INA236_ERR_NACK;
        put_ch(' ');
        if (rc != INA236_OK && rc != INA236_ERR_CAL) {
            put_str("-,-,-");
            fault = 1;
            if (present[i]) (void)ina236_i2c_recover(&ina);
            continue;
        }
        {
            uint32_t nom = cfg[i].nominal_mv;
            uint32_t dev = (s.bus_mv > nom) ? (s.bus_mv - nom) : (nom - s.bus_mv);
            if (rc == INA236_ERR_CAL || dev * 100u > nom * TOL_PERCENT) fault = 1;
        }
        put_num(s.bus_mv, 1, '0');
        put_ch(',');
        put_ma_dec(s.current_ua);
        put_ch(',');
        put_num(s.power_mw, 1, '0');
    }
    put_str(" L");
    put_num(load_step, 1, '0');
    put_crlf();
    if (fault) fault_latched = 1;
}

/* ------------------------------------------------------------------ power load */
/* Steps 0..4: 0 counters on, then 1, 2, 3, 4 counters on; then back to 0. */
static void load_apply(void)
{
    uint8_t mask = (uint8_t)((1u << load_step) - 1u);   /* 0x0, 0x1, 0x3, 0x7, 0xF */
    if (!load_ok)
        return;
    (void)timer_4test_set_mask(&load, mask);
    put_str("LOAD: ");
    put_num(load_step, 1, '0');
    put_str(" counter(s) on, mask 0x");
    put_hex2(mask);
    put_crlf();
}

/* ------------------------------------------------------------------ main */
int main(void)
{
    uint64_t next, next_load, next_led;
    unsigned char c;
    uint8_t sw1_prev = 0, hb = 0;

    (void)gpio_init(&gpio, GPIO_BASE, GPIO_LINES, GPIO_OUT_MASK);
    for (uint32_t i = 0; i < 4u; i++) led(i, 0);

    (void)uart_init(&uart, UART_BASE, APB_HZ, UART_BAUD, 1u, 8u);
    uart.blockingRx = 0;                                      /* polled, non-blocking receive */
    (void)timer_init(&tmr, TIMER_BASE, CPU_HZ);

    (void)ina236_efb_init(&ina, INA_BASE);
    ina.delay_us = udelay;
    (void)ina236_i2c_init(&ina, APB_HZ, I2C_HZ);

    put_str("INA236 MONITOR 1.9 (EFB I2C, fmix32 load, 100 uA LSB, AVG 4, 200 ms, 115200, LEDs 500 ms)\r\n");
    dump_efb();
    init_all();
    load_ok = (timer_4test_init(&load, LOAD_BASE) == 0u);
    put_str(load_ok ? "LOAD: timer_4test found at 0x8C00\r\n" : "LOAD: timer_4test NOT found\r\n");
    load_step = 0;
    load_apply();
    next = now_ticks() + POLL_TICKS;
    next_load = now_ticks() + LOAD_STEP_TICKS;
    next_led  = now_ticks() + LED_BLINK_TICKS;

    for (;;) {
        /* 200 ms slot: one compact sample line */
        if ((int64_t)(now_ticks() - next) >= 0) {
            next += POLL_TICKS;
            if (autoprint) sample_all();
        }
        /* LEDs: all four blink together, 500 ms on, 500 ms off (a known, regular load on bank 1) */
        if ((int64_t)(now_ticks() - next_led) >= 0) {
            next_led += LED_BLINK_TICKS;
            hb ^= 1u;
            for (uint32_t i = 0; i < 4u; i++) led(i, hb);
        }
        /* power load: next step every 5 s (1, 2, 3, 4 counters on, then all off, repeat) */
        if ((int64_t)(now_ticks() - next_load) >= 0) {
            next_load += LOAD_STEP_TICKS;
            load_step = (uint8_t)((load_step + 1u) % 5u);
            load_apply();
        }
        /* SW1: print now and clear the fault latch on the press edge */
        {
            uint8_t p = (uint8_t)sw1_pressed();
            if (p && !sw1_prev) {
                fault_latched = 0;
                report_all();
            }
            sw1_prev = p;
        }
        /* serial commands: r re-initialise, p print once, a toggle autoprint */
        if (uart_getc(&uart, &c) == 0) {
            if (c == 'r') { fault_latched = 0; (void)ina236_i2c_reset(&ina); init_all(); }
            else if (c == 'p') { report_all(); }
            else if (c == 'a') { autoprint ^= 1u; }
            else if (c == 's') { (void)scan_bus(); }
            else if (c == 'd') { dump_efb(); }
        }
    }
    return 0;
}
