## Radiant Files
ina_soc/lib/latticesemi.com/module/ahbl2apb0/1.2.0/ahbl2apb0.ipx
ina_soc/lib/latticesemi.com/ip/cpu0/1.9.0/cpu0.ipx
ina_soc/lib/latticesemi.com/ip/sysmem0/2.6.0/sysmem0.ipx
ina_soc/lib/latticesemi.com/ip/gpio0/1.8.1/gpio0.ipx
ina_soc/lib/latticesemi.com/module/ahbl0/1.5.0/ahbl0.ipx
ina_soc/ina_soc.v
ina_soc/lib/custom/module/ina0/1.0.0/ina0.ipx
ina_soc/lib/latticesemi.com/module/rst12/1.1.0/rst12.ipx
ina_soc/lib/latticesemi.com/module/efb0/1.3.0/efb0.ipx
ina_soc/lib/latticesemi.com/module/rst24/1.1.0/rst24.ipx
ina_soc/lib/latticesemi.com/ip/uart0/1.6.0/uart0.ipx
ina_soc/lib/latticesemi.com/module/apb0/1.4.0/apb0.ipx
ina_soc/lib/latticesemi.com/module/pll0/3.0.1/pll0.ipx
