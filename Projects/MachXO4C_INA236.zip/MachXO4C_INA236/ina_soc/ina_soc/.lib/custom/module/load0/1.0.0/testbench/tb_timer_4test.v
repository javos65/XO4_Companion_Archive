// Self-checking testbench for timer_4test 1.0.0 (APB at 12 MHz).
`timescale 1ns/1ps
module tb_timer_4test;
    reg         PCLK = 1'b0, PRESETN = 1'b0;
    reg  [4:0]  PADDR = 5'd0;
    reg         PSEL = 1'b0, PENABLE = 1'b0, PWRITE = 1'b0;
    reg  [31:0] PWDATA = 32'd0;
    wire [31:0] PRDATA;
    wire        PREADY, PSLVERR;
    integer     errors = 0;
    reg  [31:0] rd, a, b;

    timer_4test dut (.PCLK(PCLK), .PRESETN(PRESETN), .PADDR(PADDR), .PSEL(PSEL), .PENABLE(PENABLE),
                     .PWRITE(PWRITE), .PWDATA(PWDATA), .PRDATA(PRDATA), .PREADY(PREADY), .PSLVERR(PSLVERR));

    always #41.667 PCLK = ~PCLK;    // 12 MHz

    task apb_write(input [4:0] addr, input [31:0] data);
        begin
            @(posedge PCLK); PADDR <= addr; PWDATA <= data; PWRITE <= 1'b1; PSEL <= 1'b1;
            @(posedge PCLK); PENABLE <= 1'b1;
            @(posedge PCLK); PSEL <= 1'b0; PENABLE <= 1'b0; PWRITE <= 1'b0;
        end
    endtask

    task apb_read(input [4:0] addr, output [31:0] data);
        begin
            @(posedge PCLK); PADDR <= addr; PWRITE <= 1'b0; PSEL <= 1'b1;
            @(posedge PCLK); PENABLE <= 1'b1;
            #1 data = PRDATA;
            @(posedge PCLK); PSEL <= 1'b0; PENABLE <= 1'b0;
        end
    endtask

    task check(input [255:0] what, input ok);
        begin
            if (!ok) begin errors = errors + 1; $display("FAIL: %0s", what); end
            else $display("ok:   %0s", what);
        end
    endtask

    initial begin
        repeat (3) @(posedge PCLK);
        PRESETN = 1'b1;
        apb_read(5'h00, rd);  check("ID reads 0x54345431", rd == 32'h5434_5431);
        apb_read(5'h04, rd);  check("ENABLE resets to 0", rd == 32'd0);
        apb_read(5'h08, a);   repeat (20) @(posedge PCLK); apb_read(5'h08, b);
        check("all counters hold when disabled", a == b && a == 32'd0);

        apb_write(5'h04, 32'h1);                         // counter 0 only
        apb_read(5'h08, a);   repeat (50) @(posedge PCLK); apb_read(5'h08, b);
        check("counter 0 runs", b[7:0] != a[7:0]);
        check("counters 1..3 hold", b[31:8] == 32'd0);

        apb_write(5'h04, 32'hF);                         // all on
        repeat (300) @(posedge PCLK);                    // more than 256 clocks: wraps
        apb_read(5'h08, a);   repeat (10) @(posedge PCLK); apb_read(5'h08, b);
        check("counter 3 runs", b[31:24] != a[31:24]);
        check("counter 3 advances by the clock count", (b[31:24] - a[31:24]) == 8'd13);
        apb_read(5'h04, rd);  check("ENABLE reads back 0xF", rd == 32'hF);

        apb_write(5'h04, 32'h0);
        apb_write(5'h0C, 32'h5);                         // clear counters 0 and 2
        apb_read(5'h08, a);
        check("CLEAR sets counters 0 and 2 to 0", a[7:0] == 8'd0 && a[23:16] == 8'd0);
        check("CLEAR leaves counters 1 and 3", a[15:8] != 8'd0 && a[31:24] != 8'd0);
        check("PREADY high, PSLVERR low", PREADY === 1'b1 && PSLVERR === 1'b0);

        if (errors == 0) $display("SIMULATION PASSED");
        else             $display("SIMULATION FAILED: %0d error(s)", errors);
        $finish;
    end
endmodule
