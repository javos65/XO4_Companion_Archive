/* timer_4test 1.0.0: register map (byte offsets from the block base, 32-bit APB). */
#ifndef TIMER_4TEST_REGS_H
#define TIMER_4TEST_REGS_H

#define TIMER_4TEST_REG_ID      0x00u   /* RO  0x54345431 ("T4T1") */
#define TIMER_4TEST_REG_ENABLE  0x04u   /* RW  bits 3..0: counter 3..0 runs; reset 0 */
#define TIMER_4TEST_REG_COUNT   0x08u   /* RO  {cnt3, cnt2, cnt1, cnt0}, 8 bits each */
#define TIMER_4TEST_REG_CLEAR   0x0Cu   /* WO  1 in bit n sets counter n to 0 */

#define TIMER_4TEST_ID_VALUE    0x54345431u
#define TIMER_4TEST_NUM         4u
#define TIMER_4TEST_ALL         0x0Fu

#endif /* TIMER_4TEST_REGS_H */
