component load1 is
    port(
        PCLK: in std_logic;
        PRESETN: in std_logic;
        FCLK: in std_logic;
        PADDR: in std_logic_vector(4 downto 0);
        PSEL: in std_logic;
        PENABLE: in std_logic;
        PWRITE: in std_logic;
        PWDATA: in std_logic_vector(31 downto 0);
        PRDATA: out std_logic_vector(31 downto 0);
        PREADY: out std_logic;
        PSLVERR: out std_logic
    );
end component;

__: load1 port map(
    PCLK=>,
    PRESETN=>,
    FCLK=>,
    PADDR=>,
    PSEL=>,
    PENABLE=>,
    PWRITE=>,
    PWDATA=>,
    PRDATA=>,
    PREADY=>,
    PSLVERR=>
);
