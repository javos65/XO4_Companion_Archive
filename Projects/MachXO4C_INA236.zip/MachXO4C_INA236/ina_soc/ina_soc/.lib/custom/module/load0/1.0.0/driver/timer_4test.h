/* timer_4test 1.0.0: BSP driver for four switchable 8-bit looping counters (power test load).
 *
 * Each counter counts on every edge of the block clock (the 12 MHz APB clock) while it is enabled
 * and wraps from 0xFF to 0x00. A disabled counter holds its value. All functions return 0 on
 * success and 1 for a null pointer or a bad argument (the Propel driver convention).
 */
#ifndef TIMER_4TEST_H
#define TIMER_4TEST_H

#include <stdint.h>
#include "timer_4test_regs.h"

struct timer_4test_instance {
    uint32_t base_address;      /* APB base address of the block */
    uint8_t  enable;            /* last value written to ENABLE */
};

/* Binds the instance to the base address, checks the ID register and switches all counters off.
 * Returns 0, 1 for a null pointer, 2 when the ID does not read 0x54345431. */
uint8_t timer_4test_init(struct timer_4test_instance *inst, uint32_t base_addr);

/* Writes the whole enable mask (bits 3..0). */
uint8_t timer_4test_set_mask(struct timer_4test_instance *inst, uint8_t mask);
/* Switches one counter (0..3) on (on != 0) or off, leaving the others as they are. */
uint8_t timer_4test_set(struct timer_4test_instance *inst, uint8_t index, uint8_t on);
/* Reads the enable mask back from the hardware. */
uint8_t timer_4test_get_mask(struct timer_4test_instance *inst, uint8_t *mask);
/* Reads the four counter values; count[n] is counter n. */
uint8_t timer_4test_read(struct timer_4test_instance *inst, uint8_t count[TIMER_4TEST_NUM]);
/* Sets the counters selected by mask to 0. */
uint8_t timer_4test_clear(struct timer_4test_instance *inst, uint8_t mask);

#endif /* TIMER_4TEST_H */
