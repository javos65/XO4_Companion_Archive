/* INA236_efb 1.0.0: BSP driver, see INA236_efb.h.
 *
 * EFB I2C controller sequence (FPGA-IPUG-02287, Figure 7.9, with CKSDIS = 0 as the register
 * description requires for controller operation, so the real-time delay limits of the CKSDIS = 1
 * example do not apply):
 *   write:  TXDR <= addr+W, CMDR <= STA|WR, wait TRRDY; per byte TXDR <= data, CMDR <= WR, wait
 *           TRRDY; end CMDR <= STO.
 *   read:   TXDR <= addr+R, CMDR <= STA|WR (repeated start when a write came first), wait SRW;
 *           per byte CMDR <= RD, wait TRRDY, read RXDR; last byte CMDR <= RD|ACK|STO.
 * After every byte the driver waits for TIP to clear and checks RARC (no acknowledge) and ARBL.
 * Not yet proven on hardware: the TRRDY/TIP handling after the address byte is to be confirmed
 * on the MachXO4 Companion Board; see the release notes.
 */
#include <stddef.h>
#include "INA236_efb.h"

/* ---------------------------------------------------------------- EFB register access */
static inline uint8_t efb_rd(const struct ina236_efb_instance *inst, uint32_t off)
{
    return (uint8_t)(*(volatile uint32_t *)(inst->base_address + off) & 0xFFu);
}

static inline void efb_wr(const struct ina236_efb_instance *inst, uint32_t off, uint32_t v)
{
    *(volatile uint32_t *)(inst->base_address + off) = v & 0xFFu;
}

/* Waits until (SR & mask) == want; records SR in last_sr on timeout */
static int wait_sr(struct ina236_efb_instance *inst, uint8_t mask, uint8_t want)
{
    uint8_t sr = 0;
    for (uint32_t n = 0; n < inst->poll_limit; n++) {
        sr = efb_rd(inst, INA236_EFB_I2C_SR);
        if ((sr & mask) == want)
            return INA236_OK;
    }
    inst->last_sr = sr;
    return INA236_ERR_TIMEOUT;
}

/* Best-effort STOP and flag clear after an error; does not change the original error code */
static void abort_transfer(struct ina236_efb_instance *inst)
{
    uint8_t keep = inst->last_sr;
    efb_wr(inst, INA236_EFB_I2C_CMDR, INA236_EFB_CMDR_STO);
    if (wait_sr(inst, INA236_EFB_SR_BUSY, 0) != INA236_OK) {
        /* STOP did not release the bus: reset the core (a write to CR resets it) */
        efb_wr(inst, INA236_EFB_I2C_CR, 0u);
        efb_wr(inst, INA236_EFB_I2C_CR, INA236_EFB_CR_I2CEN);
    }
    efb_wr(inst, INA236_EFB_I2C_IRQ, 0x0Fu);
    inst->last_sr = keep;                 /* keep the status that caused the abort */
}

/* After a byte has been started: wait for the byte to be in flight (TIP set), then for it to
 * finish (TIP clear), and only then read the acknowledge bit. Reading RARC before the byte has
 * gone out returns a stale value (seen as a false NACK on hardware, 2026-11-18). */
static int byte_done(struct ina236_efb_instance *inst)
{
    uint8_t sr = 0;
    uint32_t n;
    int rc;
    for (n = 0; n < inst->poll_limit; n++) {       /* phase 1: byte started; may be missed if fast */
        sr = efb_rd(inst, INA236_EFB_I2C_SR);
        if (sr & (INA236_EFB_SR_TIP | INA236_EFB_SR_ARBL))
            break;
    }
    rc = wait_sr(inst, INA236_EFB_SR_TIP, 0);      /* phase 2: byte finished */
    if (rc != INA236_OK)
        return rc;
    sr = efb_rd(inst, INA236_EFB_I2C_SR);
    inst->last_sr = sr;
    if (sr & INA236_EFB_SR_ARBL)
        return INA236_ERR_ARBL;
    if (sr & INA236_EFB_SR_RARC)
        return INA236_ERR_NACK;
    return INA236_OK;
}

/* Address phase of a read: wait for SRW (controller receiving) or a NACK indication */
static int read_addr_done(struct ina236_efb_instance *inst)
{
    uint8_t sr = 0;
    for (uint32_t n = 0; n < inst->poll_limit; n++) {
        sr = efb_rd(inst, INA236_EFB_I2C_SR);
        if (sr & INA236_EFB_SR_ARBL) { inst->last_sr = sr; return INA236_ERR_ARBL; }
        if (sr & INA236_EFB_SR_SRW)
            return (sr & INA236_EFB_SR_RARC) ? INA236_ERR_NACK : INA236_OK;
        if (sr & INA236_EFB_SR_TROE) { inst->last_sr = sr; return INA236_ERR_NACK; }
    }
    inst->last_sr = sr;
    return INA236_ERR_TIMEOUT;
}

/* ---------------------------------------------------------------- set-up */
unsigned char ina236_efb_init(struct ina236_efb_instance *inst, uint32_t base_addr)
{
    if (inst == NULL)
        return 1;
    inst->base_address = base_addr;
    inst->poll_limit   = INA236_POLL_LIMIT_DEFAULT;
    inst->wb_clk_hz    = 0;
    inst->i2c_hz       = 0;
    inst->last_sr      = 0;
    inst->last_addr    = 0;
    return 0;
}

int ina236_i2c_init(struct ina236_efb_instance *inst, uint32_t wb_clk_hz, uint32_t i2c_hz)
{
    if (inst == NULL || i2c_hz == 0u || wb_clk_hz == 0u)
        return INA236_ERR_ARG;
    uint32_t div  = 4u * i2c_hz;
    uint32_t pres = (wb_clk_hz + div / 2u) / div;       /* rounded */
    if (pres < 1u || pres > 1023u)
        return INA236_ERR_ARG;
    efb_wr(inst, INA236_EFB_I2C_BR0, pres & 0xFFu);
    efb_wr(inst, INA236_EFB_I2C_BR1, (pres >> 8) & 0x03u);   /* a write to BR1 resets the core */
    efb_wr(inst, INA236_EFB_I2C_CR, INA236_EFB_CR_I2CEN);
    inst->wb_clk_hz = wb_clk_hz;
    inst->i2c_hz    = wb_clk_hz / (4u * pres);
    return INA236_OK;
}

int ina236_i2c_reset(struct ina236_efb_instance *inst)
{
    if (inst == NULL)
        return INA236_ERR_ARG;
    efb_wr(inst, INA236_EFB_I2C_CR, 0u);                  /* a write to CR resets the core */
    efb_wr(inst, INA236_EFB_I2C_CR, INA236_EFB_CR_I2CEN);
    efb_wr(inst, INA236_EFB_I2C_IRQ, 0x0Fu);
    return INA236_OK;
}

int ina236_i2c_recover(struct ina236_efb_instance *inst)
{
    if (inst == NULL)
        return INA236_ERR_ARG;
    abort_transfer(inst);
    (void)ina236_i2c_reset(inst);
    return (efb_rd(inst, INA236_EFB_I2C_SR) & INA236_EFB_SR_BUSY) ? INA236_ERR_ARBL : INA236_OK;
}

/* ---------------------------------------------------------------- raw transfers */
static int do_write(struct ina236_efb_instance *inst, uint8_t addr,
                    const uint8_t *data, uint32_t len, int stop)
{
    int rc;
    efb_wr(inst, INA236_EFB_I2C_TXDR, ((uint32_t)addr << 1) | 0u);
    efb_wr(inst, INA236_EFB_I2C_CMDR, INA236_EFB_CMDR_STA | INA236_EFB_CMDR_WR);
    rc = byte_done(inst);
    for (uint32_t i = 0; rc == INA236_OK && i < len; i++) {
        efb_wr(inst, INA236_EFB_I2C_TXDR, data[i]);
        efb_wr(inst, INA236_EFB_I2C_CMDR, INA236_EFB_CMDR_WR);
        rc = byte_done(inst);
    }
    if (rc != INA236_OK) {
        abort_transfer(inst);
        return rc;
    }
    if (stop) {
        efb_wr(inst, INA236_EFB_I2C_CMDR, INA236_EFB_CMDR_STO);
        if (wait_sr(inst, INA236_EFB_SR_BUSY, 0) != INA236_OK)
            return INA236_ERR_TIMEOUT;
    }
    return INA236_OK;
}

static int do_read(struct ina236_efb_instance *inst, uint8_t addr, uint8_t *data, uint32_t len)
{
    int rc;
    efb_wr(inst, INA236_EFB_I2C_TXDR, ((uint32_t)addr << 1) | 1u);
    efb_wr(inst, INA236_EFB_I2C_CMDR, INA236_EFB_CMDR_STA | INA236_EFB_CMDR_WR);
    rc = read_addr_done(inst);
    for (uint32_t i = 0; rc == INA236_OK && i < len; i++) {
        if (i + 1u < len)
            efb_wr(inst, INA236_EFB_I2C_CMDR, INA236_EFB_CMDR_RD);
        else
            efb_wr(inst, INA236_EFB_I2C_CMDR,
                   INA236_EFB_CMDR_RD | INA236_EFB_CMDR_ACK | INA236_EFB_CMDR_STO);
        rc = wait_sr(inst, INA236_EFB_SR_TRRDY, INA236_EFB_SR_TRRDY);
        if (rc == INA236_OK)
            data[i] = efb_rd(inst, INA236_EFB_I2C_RXDR);
    }
    if (rc != INA236_OK) {
        abort_transfer(inst);
        return rc;
    }
    if (wait_sr(inst, INA236_EFB_SR_BUSY, 0) != INA236_OK)
        return INA236_ERR_TIMEOUT;
    return INA236_OK;
}

static int begin(struct ina236_efb_instance *inst, uint8_t addr)
{
    if (inst == NULL || addr > 0x7Fu)
        return INA236_ERR_ARG;
    inst->last_addr = addr;
    if (wait_sr(inst, INA236_EFB_SR_BUSY, 0) != INA236_OK)
        return INA236_ERR_ARBL;                          /* bus busy before the transfer */
    return INA236_OK;
}

int ina236_i2c_write(struct ina236_efb_instance *inst, uint8_t addr, const uint8_t *data, uint32_t len)
{
    int rc = begin(inst, addr);
    if (rc != INA236_OK)
        return rc;
    if (data == NULL && len != 0u)
        return INA236_ERR_ARG;
    return do_write(inst, addr, data, len, 1);
}

int ina236_i2c_write_read(struct ina236_efb_instance *inst, uint8_t addr,
                          const uint8_t *wdata, uint32_t wlen, uint8_t *rdata, uint32_t rlen)
{
    int rc = begin(inst, addr);
    if (rc != INA236_OK)
        return rc;
    if (rdata == NULL || rlen == 0u || (wdata == NULL && wlen != 0u))
        return INA236_ERR_ARG;
    rc = do_write(inst, addr, wdata, wlen, 0);           /* no STOP: repeated START follows */
    if (rc != INA236_OK)
        return rc;
    return do_read(inst, addr, rdata, rlen);
}

/* ---------------------------------------------------------------- INA236A registers */
int ina236_read_reg(struct ina236_efb_instance *inst, uint8_t addr, uint8_t reg, uint16_t *value)
{
    uint8_t buf[2];
    if (value == NULL)
        return INA236_ERR_ARG;
    int rc = ina236_i2c_write_read(inst, addr, &reg, 1u, buf, 2u);
    if (rc == INA236_OK)
        *value = (uint16_t)(((uint16_t)buf[0] << 8) | buf[1]);
    return rc;
}

int ina236_write_reg(struct ina236_efb_instance *inst, uint8_t addr, uint8_t reg, uint16_t value)
{
    uint8_t buf[3];
    buf[0] = reg;
    buf[1] = (uint8_t)(value >> 8);
    buf[2] = (uint8_t)value;
    return ina236_i2c_write(inst, addr, buf, 3u);
}

int ina236_probe(struct ina236_efb_instance *inst, uint8_t addr)
{
    uint16_t mfr = 0, dev = 0;
    int rc = ina236_read_reg(inst, addr, INA236_REG_MFR_ID, &mfr);
    if (rc == INA236_OK)
        rc = ina236_read_reg(inst, addr, INA236_REG_DEVICE_ID, &dev);
    if (rc != INA236_OK)
        return rc;
    if (mfr != INA236_MFR_ID_VALUE || (dev & INA236_DEVICE_ID_MASK) != INA236_DEVICE_ID_VALUE)
        return INA236_ERR_ID;
    return INA236_OK;
}

/* ---------------------------------------------------------------- calibration */
uint16_t ina236_calc_shunt_cal(uint32_t rshunt_uohm, uint32_t current_lsb_ua, uint8_t adcrange)
{
    /* 0.00512 / (lsb_A x r_ohm) = 5.12e9 / (lsb_uA x r_uohm). 5.12e9 does not fit 32 bits, so
     * compute 2 x (2.56e9 / d) with the remainder rounded in. */
    if (rshunt_uohm == 0u || current_lsb_ua == 0u || current_lsb_ua > 0x7FFFFFFFu / rshunt_uohm)
        return 0;
    uint32_t d   = current_lsb_ua * rshunt_uohm;
    uint32_t q   = 2560000000u / d;
    uint32_t rem = 2560000000u % d;
    uint32_t cal = 2u * q + ((2u * rem >= d) ? 1u : 0u);
    if (adcrange)
        cal = (cal + 2u) / 4u;                           /* Equation 1 note: divide by 4 */
    return (cal >= 1u && cal <= 32767u) ? (uint16_t)cal : 0;
}

void ina236_channel_default(struct ina236_channel *ch, uint8_t addr, uint32_t rshunt_uohm,
                            uint32_t current_lsb_ua)
{
    if (ch == NULL)
        return;
    ch->addr           = addr;
    ch->config         = INA236_CONFIG_DEFAULT;
    ch->adcrange       = 0;
    ch->current_lsb_ua = current_lsb_ua;
    ch->shunt_cal      = ina236_calc_shunt_cal(rshunt_uohm, current_lsb_ua, 0);
}

int ina236_configure(struct ina236_efb_instance *inst, const struct ina236_channel *ch)
{
    uint16_t rb = 0;
    if (ch == NULL || ch->shunt_cal == 0u)
        return INA236_ERR_ARG;
    int rc = ina236_write_reg(inst, ch->addr, INA236_REG_CONFIG, ch->config);
    if (rc == INA236_OK)
        rc = ina236_write_reg(inst, ch->addr, INA236_REG_SHUNT_CAL, ch->shunt_cal);
    if (rc == INA236_OK)
        rc = ina236_read_reg(inst, ch->addr, INA236_REG_SHUNT_CAL, &rb);
    if (rc != INA236_OK)
        return rc;
    return (rb == ch->shunt_cal) ? INA236_OK : INA236_ERR_CAL;
}

/* ---------------------------------------------------------------- measurement */
int ina236_read_sample(struct ina236_efb_instance *inst, const struct ina236_channel *ch,
                       struct ina236_sample *s)
{
    uint16_t v;
    int rc;
    if (ch == NULL || s == NULL)
        return INA236_ERR_ARG;

    rc = ina236_read_reg(inst, ch->addr, INA236_REG_SHUNT, &v);
    if (rc != INA236_OK) return rc;
    s->raw_shunt = (int16_t)v;
    rc = ina236_read_reg(inst, ch->addr, INA236_REG_BUS, &v);
    if (rc != INA236_OK) return rc;
    s->raw_bus = v;
    rc = ina236_read_reg(inst, ch->addr, INA236_REG_CURRENT, &v);
    if (rc != INA236_OK) return rc;
    s->raw_current = (int16_t)v;
    rc = ina236_read_reg(inst, ch->addr, INA236_REG_POWER, &v);
    if (rc != INA236_OK) return rc;
    s->raw_power = v;

    uint32_t nv = ch->adcrange ? INA236_SHUNT_NV_PER_LSB_R1 : INA236_SHUNT_NV_PER_LSB_R0;
    s->shunt_uv   = ((int32_t)s->raw_shunt * (int32_t)nv) / 1000;
    s->bus_mv     = ((uint32_t)(s->raw_bus & 0x7FFFu) * INA236_BUS_UV_PER_LSB) / 1000u;
    s->current_ma = ((int32_t)s->raw_current * (int32_t)ch->current_lsb_ua) / 1000;
    s->power_mw   = (((uint32_t)s->raw_power * ch->current_lsb_ua) / 1000u) * INA236_POWER_LSB_FACTOR;

    /* Calibration fault: Equation 2, Current = SHUNT x SHUNT_CAL / 2048 (8192 for ADCRANGE 1) */
    int32_t expected = ((int32_t)s->raw_shunt * (int32_t)ch->shunt_cal) / (ch->adcrange ? 8192 : 2048);
    if (s->raw_current == 0 && (expected >= 2 || expected <= -2))
        return INA236_ERR_CAL;
    return INA236_OK;
}

const char *ina236_strerror(int code)
{
    switch (code) {
    case INA236_OK:          return "ok";
    case INA236_ERR_TIMEOUT: return "timeout";
    case INA236_ERR_NACK:    return "no acknowledge";
    case INA236_ERR_ARBL:    return "arbitration lost or bus busy";
    case INA236_ERR_ARG:     return "invalid argument";
    case INA236_ERR_ID:      return "wrong device id";
    case INA236_ERR_CAL:     return "calibration fault";
    default:                 return "unknown error";
    }
}
