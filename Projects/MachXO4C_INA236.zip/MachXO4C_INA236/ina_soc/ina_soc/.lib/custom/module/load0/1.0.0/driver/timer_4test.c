/* timer_4test 1.0.0: BSP driver, see timer_4test.h. */
#include <stddef.h>
#include "timer_4test.h"

static inline uint32_t rd(const struct timer_4test_instance *inst, uint32_t off)
{
    return *(volatile uint32_t *)(inst->base_address + off);
}

static inline void wr(const struct timer_4test_instance *inst, uint32_t off, uint32_t v)
{
    *(volatile uint32_t *)(inst->base_address + off) = v;
}

uint8_t timer_4test_init(struct timer_4test_instance *inst, uint32_t base_addr)
{
    if (inst == NULL)
        return 1;
    inst->base_address = base_addr;
    inst->enable = 0;
    if (rd(inst, TIMER_4TEST_REG_ID) != TIMER_4TEST_ID_VALUE)
        return 2;
    wr(inst, TIMER_4TEST_REG_ENABLE, 0u);
    wr(inst, TIMER_4TEST_REG_CLEAR, TIMER_4TEST_ALL);
    return 0;
}

uint8_t timer_4test_set_mask(struct timer_4test_instance *inst, uint8_t mask)
{
    if (inst == NULL || mask > TIMER_4TEST_ALL)
        return 1;
    inst->enable = mask;
    wr(inst, TIMER_4TEST_REG_ENABLE, mask);
    return 0;
}

uint8_t timer_4test_set(struct timer_4test_instance *inst, uint8_t index, uint8_t on)
{
    if (inst == NULL || index >= TIMER_4TEST_NUM)
        return 1;
    uint8_t mask = on ? (uint8_t)(inst->enable | (1u << index))
                      : (uint8_t)(inst->enable & ~(1u << index));
    return timer_4test_set_mask(inst, mask);
}

uint8_t timer_4test_get_mask(struct timer_4test_instance *inst, uint8_t *mask)
{
    if (inst == NULL || mask == NULL)
        return 1;
    *mask = (uint8_t)(rd(inst, TIMER_4TEST_REG_ENABLE) & TIMER_4TEST_ALL);
    return 0;
}

uint8_t timer_4test_read(struct timer_4test_instance *inst, uint8_t count[TIMER_4TEST_NUM])
{
    if (inst == NULL || count == NULL)
        return 1;
    uint32_t v = rd(inst, TIMER_4TEST_REG_COUNT);
    for (uint32_t i = 0; i < TIMER_4TEST_NUM; i++)
        count[i] = (uint8_t)(v >> (8u * i));
    return 0;
}

uint8_t timer_4test_clear(struct timer_4test_instance *inst, uint8_t mask)
{
    if (inst == NULL || mask > TIMER_4TEST_ALL)
        return 1;
    wr(inst, TIMER_4TEST_REG_CLEAR, mask);
    return 0;
}
