component efb0 is
    port(
        clk_i: in std_logic;
        rstn_i: in std_logic;
        apb_psel_i: in std_logic;
        apb_paddr_i: in std_logic_vector(9 downto 0);
        apb_pwdata_i: in std_logic_vector(31 downto 0);
        apb_pwrite_i: in std_logic;
        apb_penable_i: in std_logic;
        apb_pready_o: out std_logic;
        apb_prdata_o: out std_logic_vector(31 downto 0);
        apb_pslverr_o: out std_logic;
        i2c1_irqo: out std_logic;
        int_o: out std_logic;
        i2c1_scl: inout std_logic;
        i2c1_sda: inout std_logic
    );
end component;

__: efb0 port map(
    clk_i=>,
    rstn_i=>,
    apb_psel_i=>,
    apb_paddr_i=>,
    apb_pwdata_i=>,
    apb_pwrite_i=>,
    apb_penable_i=>,
    apb_pready_o=>,
    apb_prdata_o=>,
    apb_pslverr_o=>,
    i2c1_irqo=>,
    int_o=>,
    i2c1_scl=>,
    i2c1_sda=>
);
