    pll0 __(.clki_i( ),
        .clkop_o( ),
        .clkos_o( ),
        .clkos2_o( ),
        .lock_o( ));
