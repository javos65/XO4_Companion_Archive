localparam APB_ENABLE = 1;
localparam REMOVE_TRISTATE = 0;
localparam FAMILY = "LFMXO4";
localparam FIFO_DEPTH = 16;
localparam FIFO_IMPL = "LUT";
localparam TX_FIFO_AE_FLAG = 2;
localparam RX_FIFO_AF_FLAG = 14;
localparam SYS_CLOCK_FREQ = 12;
localparam PRESCALER = 57;
`define xo4f00
`define LFMXO4
`define LFMXO4_110HC
