# MachXO4 INA236 Power Monitor: Project Prompt (Propel and Radiant 2026.1)

Version 2.0 (2026-11-18). Rebuilt from the design as it runs on the board: EFB primary I2C to four INA236A monitors, a switchable logic load (timer_4test) on its own fast clock, fast sampling over UART and a live plot on the PC. Values marked CONFIRMED were given or checked by the user, against the documents in doc/, or on the hardware. Items marked [VERIFY] are open checks; they are collected in section 13.

Path convention: `C:\Users\<name>\PropelIPLocal` is the local Propel IP repository of the user who builds the design (replace `<name>` with the Windows user name).

## 1. Purpose

- Build a Propel RISC-V SoC on the MachXO4 Companion Board (LFMXO4-110HC-6BBG256I, speed grade 6) that reads four INA236A current and voltage monitors through the hardened primary I2C of the MachXO4 EFB and streams the values over the FTDI UART.
- Add a switchable on-chip logic load (timer_4test) so that the measured core current can be stepped in a known pattern.
- Show the four rails live on the PC (bus voltage, current, power) with a Python script.
- The board is new and has no online data. The documents in doc/ are the only authority.
- Working directory: `C:\lscc\workspace\MachXO4C_INA236` (constraints/, custom_IP/, doc/, firmware/, ina_soc/, program/, scripts/, benchmark/).

## 2. Source documents (read before designing)

- Schematics and outline: doc/LFMXO4-110-COMPANION REVA_SCHEMATICS.pdf, doc/LFMXO4-110-COMPANION REVA_OUTLINE.pdf, doc/XO4_HATBOARD.pdf, doc/front.jpg, doc/back.jpg.
- Pin mapping: doc/XO4_Companion_Mapping.xlsx (authoritative for pin names and locations).
- Monitor: doc/ina236.pdf (Figure 8-1 application circuit, Table 7-1 addresses, section 7.6 registers, Table 8-1 scaling, Equations 1 to 4).
- EFB: doc/FPGA-IPUG-02287-1-1-MachXO4-EFB-Module-IP-User-Guide.pdf (Tables 5.1 to 5.11 registers, Figure 7.9 I2C controller flow) and doc/FPGA-TN-02403-1-0-MachXO4-Hardened-Control-Functions-User-Guide.pdf (section 4.3.6 I2C design tips).
- Not in scope: doc/25LP064A.pdf (SPI flash U7), doc/DS_fxls8971cf.pdf (accelerometer U5), doc/dushasstnotes.xlsx.

## 3. General rules

- Tools: Lattice Propel 2026.1.1 (SoC, IP catalog, RISC-V GCC), Lattice Radiant 2026.1.1 with LSE, Questa 2026.1.1 for RTL simulation, Python 3 (pyserial, matplotlib) for the PC tools. Use the Lattice Prompt MCP tools for IP configuration, builds, timing checks and programming. Read lattice://operational_advisory and lattice://workflow first; call validate_topology and validate_timing before reporting a build complete.
- Prefer proven Propel library IP over new RTL. Write custom RTL only where no library IP fits (here: the INA236_efb pass-through and the timer_4test load).
- HDL: Verilog-2001. All I/O LVCMOS33. Pins in section 4.2 must not be changed.
- Record every decision, deviation and open item in design_plan.html.
- Save every verified state as a benchmark folder (bitstream, reports, firmware sources and images, SoC files, constraints, programming chain file, tools, custom IP) with a README and SHA-256 checksums.
- Always ask for approval before programming the board.
- Simulation rule: simulate when RTL changes (custom IP). A firmware-only change needs no simulation: compile, load the memory image, build, check timing.
- Never edit generated files (ina_soc/ina_soc/lib/...). Change the IP source or the Propel configuration and regenerate.
- Never start or stop the user's serial terminal (Tabby). If the FTDI port is busy, ask the user to close it.
- Formal wording, no emojis, no personal data (no user names or personal paths in documents; use `<name>`).

## 4. Hardware facts

### 4.1 INA236A monitors (shared I2C bus, the FPGA is the only controller)

| Ref | I2C address | A0 strap | Monitors | Rail | Nominal |
| --- | --- | --- | --- | --- | --- |
| U19 | 0x40 | GND | FPGA core | VCC_Core | 3.3 V |
| U20 | 0x41 | 3.3 V (VS) | FPGA Bank 2 | VCIO2 | 3.3 V |
| U21 | 0x42 | SDA | FPGA Banks 0 and 1 | VCC_BANK_3V3 | 3.3 V |
| U22 | 0x43 | SCL | FPGA Banks 4 and 5 | Vadj | 1.8 V |

- CONFIRMED (hardware scan): all four answer at 0x40 to 0x43 and identify as INA236 (MANUFACTURER ID 0x5449, DEVICE ID 0xA08x).
- Jumpers J19 (U19) and J20 (U20) select the rail: pins 2-3 = 3.3 V (as delivered), pins 1-2 = 1.2 V. The nominal voltage per channel is a firmware constant.
- CONFIRMED (ina236.pdf Figure 8-1): Rshunt 10 milliohm in the power line of each channel; input filter 10 ohm and 0.1 uF.
- CONFIRMED: the ALERT pins are not wired.

### 4.2 Pins

| Signal | Pin | Bank | Function |
| --- | --- | --- | --- |
| clk12_i (F_12MHz) | T9 | 2 | 12 MHz board clock |
| i2c1_scl | A9 | 0 | EFB primary I2C clock (fixed pin, dual-function sysCONFIG pin) |
| i2c1_sda | C9 | 0 | EFB primary I2C data (fixed pin, dual-function sysCONFIG pin) |
| rxd_i (F_UART_TX) | B11 | 0 | UART from the PC (FPGA RX) |
| txd_o (F_UART_RX) | A12 | 0 | UART to the PC (FPGA TX) |
| sw2_n_i (PB1 / SW2) | D10 | 0 | Active low, resets the design |
| gpio_io[4] (PB2 / SW1) | D11 | 0 | Active low, prints the full table |
| gpio_io[0..3] (LED1..LED4) | G14, E14, G15, G13 | 1 | Active low |

- All other pins stay unused. The DIP switches have no function.
- Banks 0 and 1 are supplied by VCC_BANK_3V3 and measured by U21; LED and I2C/UART activity shows up on U21, not on U19.

### 4.3 I2C bus

- CONFIRMED: A9 and C9 are the fixed pins of the EFB primary I2C. The net names FTDI_SCL and FTDI_SDA are historical; jumpers J2 and J3 are set for UART.
- CONFIRMED: SCL and SDA each have an external 4.7 kohm pull-up to 3.3 V; no internal pull-ups (PULLMODE NONE). Bus speed 100 kHz.

### 4.4 Host connection

- The FTDI UART is a COM port on the PC (COM13 on the reference PC), 115200 baud 8N1.
- CONFIRMED: host tools must open the port with DTR and RTS released and without flow control. With DTR/RTS asserted (the pyserial default) every INA236 read failed while the tool held the port.
- Jumper preconditions (listed in every benchmark README): J2 and J3 in UART position; J19 and J20 at 2-3 (3.3 V).

## 5. SoC system

### 5.1 Objective

A Propel RISC-V SoC that samples U19 to U22 every 200 ms through the EFB I2C controller, converts the registers to engineering units, prints one compact line per sample over UART, blinks the LEDs, and steps the timer_4test load every 5 seconds. Start from the Propel RISC-V SM (riscv_sm) template.

### 5.2 Components and address map

| Block | IP and version | Address | Settings |
| --- | --- | --- | --- |
| PLL | pll 3.0.1 | | 12 MHz in (T9), VCO 480 MHz: CLKOP 24 MHz (divider 20), CLKOS 12 MHz (divider 40), CLKOS2 120 MHz (divider 4), lock output used for reset |
| CPU | riscv_sm 1.9.0 | timer/PIC 0xFFFF0000 | RV32I, no debug, machine timer at 24 MHz |
| System memory | system_memory 2.6.0 | 0x0000, 16 KB | initialised with the firmware image |
| Bus | ahb_lite_interconnect 1.5.0, ahb_lite_to_apb_bridge 1.2.0, apb_interconnect 1.4.0 (4 subordinates) | | AHB-Lite at 24 MHz; APB at 12 MHz |
| UART | uart 1.6.0 | 0x8000 | 115200 baud 8N1 on 12 MHz (divider 104, +0.16 %) |
| GPIO | gpio 1.8.1 | 0x8400 | 5 lines: 0..3 LEDs (out), 4 SW1 (in) |
| INA236_efb | custom:module:INA236_efb:1.0.0 | 0x8800 | APB pass-through to lscc_efb (section 6) |
| EFB | lscc_efb 1.3.0 | behind INA236_efb | APB 32-bit data, 10-bit address, WISHBONE clock 12 MHz; primary I2C enabled, 100 kHz (divider 30), 7-bit addressing, I2C1_SLAVE_ADDR_IN = 11100; all other EFB functions off |
| timer_4test | custom:module:timer_4test:1.1.0 | 0x8C00 | PCLK 12 MHz, FCLK 120 MHz (CLKOS2) (section 7) |

- Reset: SW2 (active low) AND PLL lock, synchronised by two lscc_reset 1.1.0 instances (24 MHz and 12 MHz domains). timer_4test synchronises the reset into FCLK itself.
- The EFB is reached only through INA236_efb; its APB port does not connect to the interconnect directly.
- Interrupts are not used (polling); the unconnected interrupt interfaces are intentional.

### 5.3 Clock domains

| Clock | Source | Frequency | Users |
| --- | --- | --- | --- |
| clk12_i | pin T9 | 12 MHz | PLL reference |
| pll0_inst_clkop_o_net | CLKOP | 24 MHz | CPU, system memory, AHB-Lite, bridge (AHB side) |
| pll0_inst_clkos_o_net | CLKOS | 12 MHz | bridge (APB side), APB interconnect, UART, GPIO, EFB, timer_4test PCLK |
| pll0_inst_clkos2_o_net | CLKOS2 | 120 MHz | timer_4test FCLK (counters and fmix32 units) |

- CLKOS2 is asynchronous to the other clocks by design (set_clock_groups, section 9).

## 6. EFB primary I2C (custom IP INA236_efb 1.0.0)

### 6.1 Package

- vendor custom, library module, name INA236_efb, version 1.0.0, family LFMXO4.
- Location: `C:\Users\<name>\PropelIPLocal\custom_module_INA236_efb_1.0.0`; source copy in custom_IP/.
- rtl/INA236_efb.v: combinational APB pass-through, no clock. APB_S0 (10-bit paddr, 32-bit data) wired 1:1 to APB_M0 (to lscc_efb APB_S0).
- driver/: INA236_efb_regs.h, INA236_efb.h, INA236_efb.c, INA236_efb.xml (EFB I2C controller and INA236A layer); doc/introduction.html; doc/EULA.txt.

### 6.2 Registers

- Window 1 KB; one 8-bit EFB register per 32-bit word; CPU byte offset = EFB index x 4. CONFIRMED: primary I2C at EFB index 0x40 to 0x49 = CPU offset 0x100 to 0x124 (CR, CMDR, BR0, BR1, TXDR, SR, GCDR, RXDR, IRQ, IRQEN).
- SR: 7 TIP, 6 BUSY, 5 RARC (1 = no ACK), 4 SRW, 3 ARBL, 2 TRRDY, 1 TROE, 0 HGC. SR bits other than BUSY are valid only while BUSY = 1 (Table 5.7). RARC reads 1 at idle (SR = 0x20).
- f(I2C) = wb_clk / (prescale x 4): 12 MHz, 100 kHz gives prescale 30 (BR0 0x1E, BR1 0x00).

### 6.3 Four conditions for a working EFB primary I2C (all CONFIRMED on hardware)

1. sysCONFIG `I2C_PORT=ENABLE` (PDC: `ldc_set_sysconfig {I2C_PORT=ENABLE}`). Radiant's default is DISABLE, and then A9/C9 never reach the EFB I2C core. The value EFB_USER is invalid; ENABLE is the valid value. Check the MAP report shows I2C_PORT ENABLE.
2. CR = 0x8C (I2CEN, SDA_DEL_SEL = 11, SDA delay off). The SDA delay needs the internal oscillator, which this design does not instantiate (FPGA-TN-02403 section 4.3.6). Every CR write (reset, recovery) keeps SDA_DEL_SEL = 11.
3. The EFB's own target addresses must not collide with bus devices. I2C1_SLAVE_ADDR_IN = 11100 places them at 0x70 (configuration) and 0x71 (user); the default 10000 would give 0x40 and 0x41, the addresses of U19 and U20.
4. End of byte from TIP: after each command, wait until TIP has been seen high and then low again (with BUSY = 1), then read RARC. TIP rises half an SCL period after START, so "TIP low" directly after the command is not "byte done".

### 6.4 Command sequence (FPGA-IPUG-02287 Figure 7.9, clock stretching on: CKSDIS = 0)

- Write: TXDR = addr+W, CMDR = 0x90 (STA+WR), byte done; per byte TXDR = data, CMDR = 0x10 (WR), byte done; CMDR = 0x40 (STO), wait BUSY = 0.
- Read: TXDR = addr+R, CMDR = 0x90, byte done (address ACK); CMDR = 0x20 (RD); per byte except the last wait TRRDY, read RXDR; last byte CMDR = 0x68 (RD+NACK+STO) (for a one-byte read after a 3 tSCL wait), wait TRRDY, read RXDR; wait BUSY = 0.
- On an error: CMDR = 0x40, wait BUSY = 0; if BUSY stays set, reset the core through CR (keeping CR[3:2] = 11).
- Bus scan: address-only write for 0x08 to 0x77.
- Limit: the EFB cannot generate extra SCL pulses, so a target that holds SDA low cannot be freed by the driver.

## 7. Power load (custom IP timer_4test 1.1.0)

### 7.1 Function

- Four 8-bit looping counters. Each runs on FCLK while its ENABLE bit is set and wraps from 0xFF to 0x00; a disabled counter holds its value.
- One MurmurHash3 32-bit finalizer (fmix32) unit per counter. Each time bit 5 of a running counter changes, the idle unit takes the 8-bit counter value, zero-extended to 32 bits, and computes `h ^= h>>16; h *= 0x85EBCA6B; h ^= h>>13; h *= 0xC2B2AE35; h ^= h>>16`.
- Sequential, no look-up table: one 32-bit working register; each multiplication by a constant is a pipelined shift-and-add (the constant is a shift register, the selected term is registered one clock ahead), one 32-bit addition per clock, 33 clocks per multiplication, 69 clocks per hash. A running counter keeps its unit busy all the time.
- The hash results are readable but not used by the firmware.

### 7.2 Registers (byte offsets, 32-bit APB, zero wait states)

| Offset | Register | Access | Function |
| --- | --- | --- | --- |
| 0x00 | ID | RO | 0x54345432 ("T4T2") |
| 0x04 | ENABLE | RW | bits 3..0: counter 3..0 runs; reset 0 |
| 0x08 | COUNT | RO | four 8-bit counter values |
| 0x0C | CLEAR | WO | 1 in bit n sets counter n to 0 |
| 0x10..0x1C | HASH0..HASH3 | RO | last fmix32 result of counter 0..3 |

### 7.3 Ports and clock crossing

- Ports: PCLK, PRESETN, FCLK, APB_S0 (5-bit PADDR).
- ENABLE crosses to FCLK through two flip-flops per bit; CLEAR as a toggle; COUNT and HASHn come back through two flip-flops (a value that changes during a read can be read inconsistently; diagnostic only).
- Package: `C:\Users\<name>\PropelIPLocal\custom_module_timer_4test_1.1.0` (version 1.0.0, PCLK only and no hash units, is kept beside it). Driver: timer_4test_init, _set_mask, _set, _get_mask, _read, _clear, _read_hash.
- Simulation: Questa testbench tb_timer_4test.v (12 MHz PCLK, 132 MHz FCLK) checks the ID, the hashes against a reference fmix32 (including fmix32(0) = 0 after the 255 to 0 wrap), hold when disabled, and CLEAR.

## 8. Firmware (C, rv32i, polling; version 1.9)

### 8.1 INA236A setting

- CONFIG = 0x4327: standard setting 0x4127 with AVG = 4 (bits 11..9 = 001), VBUSCT and VSHCT 1.1 ms, continuous shunt and bus; a new averaged result about every 8.8 ms.
- CURRENT_LSB = 100 uA, SHUNT_CAL = 0.00512 / (100e-6 x 0.010) = 5120. Current resolution 0.1 mA, power LSB 32 x 100 uA = 3.2 mW, range +/-3.27 A.
- Power is computed inside the INA236 from its current and bus voltage results (POWER register); it is not measured separately.
- Driver conversion: bus mV = BUS x 1.6; current_ua = CURRENT x CURRENT_LSB; power_uw = POWER x 32 x CURRENT_LSB (multiply before dividing; exact for LSB up to 1000 uA).
- Start-up: bus scan (`SCAN: 0x40(INA236) ...`), then ID check and configuration per channel (`INA OK` / `INA MISSING (...)`).

### 8.2 UART output (115200 baud 8N1, CR LF)

- Banner `INA236 MONITOR 1.9 (...)`, register line `EFB CR=8C BR0=1E BR1=00 SR=..`, scan line, channel status, `LOAD: timer_4test found at 0x8C00`.
- Every 200 ms one compact sample line (about 70 characters, 6 ms at 115200 baud):
  `M <time_ms> <mV>,<mA.d>,<mW> <mV>,<mA.d>,<mW> <mV>,<mA.d>,<mW> <mV>,<mA.d>,<mW> L<n>` (rails U19 U20 U21 U22; `-,-,-` = no answer; L<n> = number of timer_4test counters on).
- On each load step: `LOAD: <n> counter(s) on, mask 0x..`.
- Commands: `p` full table, `a` toggle the sample lines, `r` re-initialise, `s` bus scan, `d` EFB register line. SW1 prints the full table.

### 8.3 Load sequence and LEDs

- timer_4test: every 5 seconds one more counter on (masks 0x0, 0x1, 0x3, 0x7, 0xF), then all off; period 25 s.
- LEDs: all four blink together, 500 ms on and 500 ms off (a known, regular load on bank 1). No status LEDs.
- Lattice GPIO driver 1.8.1 quirk (CONFIRMED): gpio_output_write() masks the value with (1 << line) without shifting it, so the value must be passed as (bit << line); gpio_input_get() returns the whole input register, so SW1 is bit 4 of it.

### 8.4 Build notes

- The Debug makefiles are hand-maintained (-march=rv32i; driver folders INA236_efb, timer_4test). Rerunning firmware_gen_build overwrites them.
- Size: about 12 KB code of the 16 KB system memory including stack (the 64-bit millisecond timestamp needs the 64-bit division routine).

## 9. Build flow and constraints

- Propel: change the SoC with a script session (config, add, connect, address), generate, then embed the firmware: compile, bin2mem (plain ASCII, no BOM), add_firmware_to_proj on sysmem0_inst, regenerate, check_memory_init_applied.
- Radiant: LSE, loop limit 20000. The project (ina_soc.rdf) lists the .ipx of every generated instance (ina0, efb0, load1 among others); update it when an instance is added or replaced.
- PDC (constraints/ina_soc.pdc): pins of section 4.2, LVCMOS33, PULLMODE NONE on I2C and inputs, `ldc_set_sysconfig {I2C_PORT=ENABLE}`, and
  `set_clock_groups -asynchronous -group [get_clocks pll0_inst_clkos2_o_net] -group [get_clocks {pll0_inst_clkos_o_net pll0_inst_clkop_o_net}]`.
  The clock-group constraint belongs in the PDC: the PLL output clocks exist only after synthesis, and an SDC reference to them stops synthesis.
- SDC (constraints/ina_soc.sdc): `create_clock` 83.333 ns on clk12_i, 10000 ns on i2c1_scl (the SCL pad feeds the EFB), false paths on the slow asynchronous I/O.
- Strategy: 6 PAR placement seeds (PROP_PAR_PlcIterParDes 6, stop at the first seed that meets timing). With one seed the 120 MHz domain varied between 117.5 and 123 MHz.
- Gates: 0 failing endpoints in all three corners; constraint coverage reviewed (gpio_io unconstrained: waiver).
- Reference result: CPU 24 MHz (Fmax about 25 MHz, small margin), APB 12 MHz, FCLK 120 MHz (Fmax 139.9 MHz with seeds); LUT4 41 %, registers 27 %, block RAM 42 %, PLL 1 of 2, EFB 1 of 1.

## 10. Programming

- JEDEC into the internal flash (Erase, Program, Verify) over JTAG, cable USB2, port FTUSB-0, TCK delay 3 (7.5 MHz), chain file program/program_ina236.xcf (I/O state HighZ).
- The batch programmer reports "failed" because it misses its completion line; the result is the line "Operation: successful" in the programmer log (`%APPDATA%\LatticeSemi\DiamondNG\programmer.log`).
- "Failed to Open FTDI USB port": a serial terminal holds the FTDI chip; ask the user to close it.
- Ask for approval before programming.

## 11. PC tools (scripts/)

- scripts/ina236_plot.py: three stacked, scrolling diagrams (bus voltage, current, power) for the four rails; legend above the plots; status line with the latest values and the load step; optional CSV log.
  `python scripts/ina236_plot.py --port COM13 --csv scripts/rails.csv`
- Reads the compact `M` lines (115200 baud default) and the older table format (`--baud 19200`).
- scripts/ina236_plot.bat (starts it on COM13), scripts/requirements.txt (pyserial, matplotlib).

## 12. Acceptance tests and results

| Test | Result (2026-11-18) |
| --- | --- |
| Bus scan finds 0x40 to 0x43, ID check passes | CONFIRMED |
| Rails within 5 % of nominal | CONFIRMED: about 3316, 3331, 3331, 1801 mV |
| Samples every 200 ms at 115200 baud, live plot on COM13 | CONFIRMED |
| Load steps visible on U19 every 5 s | to be quantified from the CSV log [VERIFY] |
| All four LEDs blink together (500 ms) | CONFIRMED |
| 30 minute soak without hang | [VERIFY] |

- Benchmarks: benchmark/v1.1_i2c241_20261118 (soft I2C controller 2.4.1, reference that worked first), benchmark/v1.4_efb_20261118 (EFB primary I2C). The current state (timer_4test 1.1.0, firmware 1.9) is not yet a benchmark.

## 13. Open checks

- Quantify the current per timer_4test step on U19 and the LED step on U21 from a CSV log.
- 30 minute soak test.
- CPU domain margin: Fmax about 25 MHz at 24 MHz; any CPU-side logic growth needs a timing check.
- System memory headroom: about 1 KB left of 16 KB.
- The AHB-to-APB bridge passes 16 address bits; keep all APB peripherals below 0x10000 (addresses above alias).
- The installed .ipk of INA236_efb still holds the 1.0.0 driver; the updated driver files are beside it in the package folder.
- design_plan.html does not yet record the changes since the EFB benchmark.
