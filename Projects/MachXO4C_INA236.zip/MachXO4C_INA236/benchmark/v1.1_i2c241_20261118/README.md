# INA236 Monitor: benchmark v1.1 (I2C controller 2.4.1)

Saved 2026-11-18 as the reference version that works on hardware.

## Hardware
- **Board:** MachXO4 Companion Board, LFMXO4-110HC-6BBG256I (speed grade 6).
- **I2C:** Lattice I2C controller 2.4.1 (`I2C_inst0_inst`) at 0x10000000. SCL on A9, SDA on C9, LVCMOS33 with the board's 4.7 kohm pull-ups, 12 MHz clock, prescaler 57 (about 100 kHz). The EFB is not used.
- **SoC:** RISC-V SM, 16 KB system memory, UART at 0x8000 (19200 8N1), GPIO at 0x8400. The CPU and AHB run at 24 MHz, the APB at 12 MHz.

## Verified on hardware (2026-11-18, 11:48)
- **Bus scan:** `SCAN: 0x40(INA236) 0x41(INA236) 0x42(INA236) 0x43(INA236)`
- **Measurements:**

| Channel | Bus voltage | Current | Power | State |
|---|---|---|---|---|
| U19 VCORE | 3304 mV | 66 mA | 224 mW | OK |
| U20 VCIO2 | 3316 mV | 1 mA | 0 mW | OK |
| U21 BANK01 | 3316 mV | 3 mA | 0 mW | OK |
| U22 VADJ | 1808 mV | 0 mA | 0 mW | OK |

## Build results
- **Timing:** valid, 0 failing endpoints in all three corners. Constraint coverage is 99.87%; the uncovered ports are the `gpio_io` lines (waiver).
- **Resources:** LUT4 36%, registers 20%, block RAM 42%, PLL 1 of 2, EFB 0.
- **Firmware:** rv32i, code 8144 bytes, memory image of 2037 words embedded and confirmed applied.
- **Programming:** Erase, Program and Verify of the configuration flash over FTUSB-0, TCK 7.5 MHz: "Operation: successful".

## Contents
- **bitstream/:** the .jed and .bit files, plus the timing (.twr), map (.mrp) and pad (.pad) reports.
- **firmware/:** sources, the hand-patched Debug makefiles (rv32i, i2c_master and ina236 drivers), and the .elf, .bin and .mem images.
- **soc/:** the Propel design (`ina_soc.sbx`), the generated top level (`ina_soc.v`), the Radiant project (`ina_soc.rdf`) and the strategy file (`ina_soc1.sty`).
- **constraints/:** `ina_soc.pdc` and `ina_soc.sdc`.
- **program/:** the programmer chain file `program_ina236.xcf`. It points at the working copy `ina_soc/impl_1`, not at this folder.

## Checksums (SHA-256)
| File | Bytes | SHA-256 |
|---|---|---|
| ina_soc_impl_1.jed | 2097141 | `CA049C8D6A50DCD707564C166F13D547770DEBBB0E4C389A4A6EA7DC2559B65C` |
| ina_soc_impl_1.bit | 105240 | `5DEDAF1E8F3F07B223931F62E3711E65D97CACA555DFDD5942C9CA9432FF9BE7` |
| ina_fw.mem | 18333 | `AF6B7D56443150DD5265628709410261629855D81B17DC7741A3EC25315ECE9B` |
| ina_fw.elf | 152928 | `E9D827400C3599DD83CB8274FD90D831399EA2D6D643BFBCA77DBB18FD54DF5E` |
| ina_fw.bin | 8148 | `176A74949BB4945165FE750C191216777FCA087D04E936F792326809958020A2` |

## Known limits
- **Small loads read as 0 mW:** the power register counts in steps of 32 mW.
- **No time limit in the driver:** the wait loops of the Lattice I2C driver have no timeout, so a stuck bus with no error flag would hang the firmware.
- **Address alias:** the I2C controller is reached at 0x10000000 through an alias, because the AHB-to-APB bridge passes only 16 address bits.
- **Build files are hand-edited:** rerunning `firmware_gen_build` would overwrite the patched makefiles.
