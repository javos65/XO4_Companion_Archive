# Timing constraints for ina_soc
# 12 MHz input clock on the top-level port; the 24 MHz and 12 MHz PLL outputs are derived by the
# timer from the PLL (do not create clocks on the PLL outputs).
create_clock -name clk12_i -period 83.333 [get_ports clk12_i]

# I2C (soft I2C controller 2.4.1, 12 MHz clock): SCL and SDA are plain open-drain I/O, sampled
# and driven in the 12 MHz domain at 100 kHz, so they have no timing relationship to constrain.
# Slow, asynchronous board I/O (I2C, UART transmit, LED lines). Recorded waiver in design_plan.html.
set_false_path -to   [get_ports {txd_o i2c1_scl i2c1_sda {gpio_io[0]} {gpio_io[1]} {gpio_io[2]} {gpio_io[3]} {gpio_io[4]}}]
set_false_path -from [get_ports {i2c1_scl i2c1_sda {gpio_io[0]} {gpio_io[1]} {gpio_io[2]} {gpio_io[3]}}]

# Asynchronous user inputs (SW2 reset button, SW1 button, UART receive): no timing relationship
# to the system clocks. Recorded waiver in design_plan.html.
set_false_path -from [get_ports {sw2_n_i rxd_i {gpio_io[4]}}]
