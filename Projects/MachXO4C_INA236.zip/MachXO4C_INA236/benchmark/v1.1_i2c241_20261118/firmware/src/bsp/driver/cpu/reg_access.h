/*   ==================================================================
     Register Access Helpers
     ------------------------------------------------------------------
     Copyright (c) 2019-2025 by Lattice Semiconductor Corporation
     ALL RIGHTS RESERVED

     Provides reg_32b / reg_8b read/write/modify helpers used by
     the Propel peripheral drivers (GPIO, I2C, Ethernet, etc.).
     ================================================================== */

#ifndef REG_ACCESS_H
#define REG_ACCESS_H

#include <stdint.h>

/* ------------------------------------------------------------------ */
/*  32-bit register helpers                                           */
/* ------------------------------------------------------------------ */

static inline uint8_t reg_32b_write(uint32_t reg_addr, uint32_t value)
{
	*(volatile uint32_t *)(uintptr_t)reg_addr = value;
	return 0;
}

static inline uint8_t reg_32b_read(uint32_t reg_addr, uint32_t *reg_32b_value)
{
	*reg_32b_value = *(volatile uint32_t *)(uintptr_t)reg_addr;
	return 0;
}

static inline uint8_t reg_32b_modify(uint32_t reg_addr, uint32_t bits_mask,
				     uint32_t value)
{
	volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)reg_addr;
	*p = (*p & ~bits_mask) | (value & bits_mask);
	return 0;
}

/* ------------------------------------------------------------------ */
/*  16-bit register helpers                                           */
/* ------------------------------------------------------------------ */

static inline uint8_t reg_16b_write(uint32_t reg_addr, uint16_t value)
{
	*(volatile uint16_t *)(uintptr_t)reg_addr = value;
	return 0;
}

static inline uint8_t reg_16b_read(uint32_t reg_addr, uint16_t *value)
{
	*value = *(volatile uint16_t *)(uintptr_t)reg_addr;
	return 0;
}

/* ------------------------------------------------------------------ */
/*  8-bit register helpers                                            */
/* ------------------------------------------------------------------ */

/*
 * NOTE: The I2C driver calls read8(addr, &val) and write8(addr, val)
 * as functions with these signatures.  cpu.h may define single-arg
 * read8/write8 macros; we guard against redefinition here.
 */
#ifdef read8
#undef read8
#endif
#ifdef write8
#undef write8
#endif

static inline void write8(uint32_t reg_addr, uint8_t value)
{
	*(volatile uint8_t *)(uintptr_t)reg_addr = value;
}

static inline void read8(uint32_t reg_addr, uint8_t *value)
{
	*value = *(volatile uint8_t *)(uintptr_t)reg_addr;
}

static inline void reg_8b_modify(uint32_t reg_addr, uint8_t bits_mask,
				 uint8_t value)
{
	volatile uint8_t *p = (volatile uint8_t *)(uintptr_t)reg_addr;
	*p = (*p & ~bits_mask) | (value & bits_mask);
}

#endif /* REG_ACCESS_H */
