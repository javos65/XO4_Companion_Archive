#ifndef CPU_H_
#define CPU_H_

#include <stdint.h>
#include "config/sys_config.h"


#define MTIME_CLOCK_FREQ 32000uL /* 32KHz clock for mtime (adjust per platform if needed) */


/* ---------------------------------
 * MMIO access helpers (32-bit only)
 * ---------------------------------
 */
#define MMIO32(addr) (*(volatile uint32_t *) (uintptr_t) (addr))
#define REG32(base, off) MMIO32((base) + (uint32_t) (off))

/* ---------- basic MMIO helpers (portable) ---------- */
#ifndef read8
#define read8(addr) \
	(*((volatile uint8_t *) (uintptr_t) (addr)))
#define read16(addr) \
	(*((volatile uint16_t *) (uintptr_t) (addr)))
#define read32(addr) \
	(*((volatile uint32_t *) (uintptr_t) (addr)))

#define write8(addr, v) \
	(*((volatile uint8_t *) (uintptr_t) (addr)) = (uint8_t) (v))
#define write16(addr, v) \
	(*((volatile uint16_t *) (uintptr_t) (addr)) = (uint16_t) (v))
#define write32(addr, v) \
	(*((volatile uint32_t *) (uintptr_t) (addr)) = (uint32_t) (v))
#endif

/* ---------
 * PLIC
 * ---------
 */
/* PLIC block offsets (from PLIC_BASE_ADDR) */
#define PLIC_PRIO_BASE 0x000000u    /* Interrupt priority array (ID >= 1) */
#define PLIC_PENDING_BASE 0x001000u /* Pending bits array */
#define PLIC_ENABLE_BASE 0x002000u  /* Enables array (per-context) */

/* Context-specific registers (4KB stride blocks starting at 0x200000) */
#define PLIC_CTX0_BASE 0x200000u /* context 0: hart0 M-mode */
#define PLIC_CTX1_BASE 0x201000u /* context 1: hart0 S-mode */

#define PLIC_THRESHOLD(ctx_base) ((uint32_t) ((ctx_base) + 0x0000u))
#define PLIC_CLAIM(ctx_base) ((uint32_t) ((ctx_base) + 0x0004u))
#define PLIC_COMPLETE(ctx_base) ((uint32_t) ((ctx_base) + 0x0004u))

/* Convenience macros for M-mode and S-mode context regs */
#define PLIC_THRESHOLD_M PLIC_THRESHOLD(PLIC_CTX0_BASE)
#define PLIC_CLAIM_M PLIC_CLAIM(PLIC_CTX0_BASE)
#define PLIC_COMPLETE_M PLIC_COMPLETE(PLIC_CTX0_BASE)

#define PLIC_THRESHOLD_S PLIC_THRESHOLD(PLIC_CTX1_BASE)
#define PLIC_CLAIM_S PLIC_CLAIM(PLIC_CTX1_BASE)
#define PLIC_COMPLETE_S PLIC_COMPLETE(PLIC_CTX1_BASE)

/* Compute address helpers */
static inline void
plic_set_priority(uint32_t source_id, uint32_t prio) {
	/* priority register i at PRIO_BASE + 4*i */
	REG32(PLIC_BASE_ADDR, PLIC_PRIO_BASE + (source_id << 2)) = prio;
}

static inline void
plic_enable(uint32_t ctx_index, uint32_t source_id) {
	/* enables array for context k starts at ENABLE_BASE + 0x100 * k */
	const uint32_t off = PLIC_ENABLE_BASE + (ctx_index * 0x100u) + ((source_id >> 5) << 2);
	const uint32_t bit = 1u << (source_id & 31u);
	REG32(PLIC_BASE_ADDR, off) |= bit;
}

static inline void
plic_disable(uint32_t ctx_index, uint32_t source_id) {
	const uint32_t off = PLIC_ENABLE_BASE + (ctx_index * 0x100u) + ((source_id >> 5) << 2);
	const uint32_t bit = 1u << (source_id & 31u);
	REG32(PLIC_BASE_ADDR, off) &= ~bit;
}

static inline void
plic_set_threshold_m(uint32_t th) {
	REG32(PLIC_BASE_ADDR, PLIC_THRESHOLD_M) = th;
}

static inline uint32_t
plic_claim_m(void) {
	return REG32(PLIC_BASE_ADDR, PLIC_CLAIM_M);
}

static inline void
plic_complete_m(uint32_t id) {
	REG32(PLIC_BASE_ADDR, PLIC_COMPLETE_M) = id;
}

/* ---------
 * CLINT
 * ---------
 */
/* Offsets from CLINT_BASE_ADDR */
#define CLINT_MSIP 0x000000u /* MSIP (hart0) */
#define CLINT_MTIMECMP_L 0x0004000u
#define CLINT_MTIMECMP_H 0x0004004u
#define CLINT_MTIME_L 0x000BFF8u
#define CLINT_MTIME_H 0x000BFFCu

// Accessors
static inline void
clint_msip_set(uint32_t val) {
	REG32(CLINT_BASE_ADDR, CLINT_MSIP) = val;
}
static inline void
clint_mtimecmp_write(uint64_t val) {
	/* Write high last as usual RISC-V CLINT sequence */
	REG32(CLINT_BASE_ADDR, CLINT_MTIMECMP_L) = (uint32_t) val;
	REG32(CLINT_BASE_ADDR, CLINT_MTIMECMP_H) = (uint32_t) (val >> 32);
}
static inline uint64_t
clint_mtime_read(void) {
	uint32_t hi, lo;
	do {
		hi = REG32(CLINT_BASE_ADDR, CLINT_MTIME_H);
		lo = REG32(CLINT_BASE_ADDR, CLINT_MTIME_L);
	} while (hi != REG32(CLINT_BASE_ADDR, CLINT_MTIME_H));
	return ((uint64_t) hi << 32) | lo;
}

static inline void
clint_mtime_init(void) {
	write32(CLINT_BASE_ADDR | CLINT_MTIME_H, 0);
	write32(CLINT_BASE_ADDR | CLINT_MTIME_L, 1);
}

static inline uint64_t
get_miliseconds(void) {
	return clint_mtime_read() / (MTIME_CLOCK_FREQ / 1000uL);
}

/* Busy-wait delay in milliseconds based on CLINT mtime.
 * Note: Assumes MTIME_CLOCK_FREQ is an integer multiple of 1000.
 */
static inline void
delay_ms(uint32_t ms) {
	uint64_t start = clint_mtime_read();
	uint64_t wait_ticks = ((uint64_t) ms * (MTIME_CLOCK_FREQ / 1000uL));

	while ((clint_mtime_read() - start) < wait_ticks)
		; /* spin until elapsed */
}

/* ---------
 * Watchdog Timer (WDT) - inside CLINT space
 * ---------
 */
#define WDT_WDCSR 0x000D000u /* Watchdog Control/Status Register */

/* WDCSR bit fields */
#define WDT_WDCSR_WDEN_Pos 0u
#define WDT_WDCSR_WDEN_Msk (1u << WDT_WDCSR_WDEN_Pos)
#define WDT_WDCSR_S1WTO_Pos 2u
#define WDT_WDCSR_S1WTO_Msk (1u << WDT_WDCSR_S1WTO_Pos)
#define WDT_WDCSR_S2WTO_Pos 3u
#define WDT_WDCSR_S2WTO_Msk (1u << WDT_WDCSR_S2WTO_Pos)
#define WDT_WDCSR_WTOCNT_Pos 4u
#define WDT_WDCSR_WTOCNT_Msk (0x3FFu << WDT_WDCSR_WTOCNT_Pos)

static inline void
wdt_enable(uint32_t timeout10bit) {
	uint32_t v = WDT_WDCSR_WDEN_Msk | ((timeout10bit << WDT_WDCSR_WTOCNT_Pos) & WDT_WDCSR_WTOCNT_Msk);
	REG32(CLINT_BASE_ADDR, WDT_WDCSR) = v;
}

static inline void
wdt_disable(void) {
	REG32(CLINT_BASE_ADDR, WDT_WDCSR) &= ~WDT_WDCSR_WDEN_Msk;
}


#endif /* CPU_H_ */
