/* INA236A layer on top of the Lattice I2C controller 2.4.1 driver (i2c_master.c, polling mode).
 * Bus: I2C_inst0 at 0x10000000, pins A9 (SCL) / C9 (SDA), 100 kHz (prescaler 57 at 12 MHz).
 */
#include <stddef.h>
#include "ina236.h"

unsigned char ina236_bus_init(struct ina236_bus *inst, uint32_t base_addr)
{
    if (inst == NULL)
        return 1;
    inst->last_addr = 0;
    inst->last_sr   = 0;
    inst->i2c_hz    = 0;
    return i2c_master_init(&inst->i2cm, base_addr);
}

int ina236_i2c_init(struct ina236_bus *inst, uint32_t clk_hz, uint32_t i2c_hz)
{
    if (inst == NULL || i2c_hz == 0u || clk_hz < 7u * i2c_hz)
        return INA236_ERR_ARG;
    /* I2C controller 2.4.1: f_SCL = clk / (2 x PRESCALER + 5); 12 MHz, 100 kHz -> 57 (IP GUI value) */
    uint32_t pre = (clk_hz / i2c_hz - 5u) / 2u;
    if (pre > 0x3FFu)
        return INA236_ERR_ARG;
    if (i2c_master_config(&inst->i2cm, I2CM_ADDR_7BIT_MODE, 0u, (uint16_t)pre) != 0u)
        return INA236_ERR_ARG;
    inst->i2c_hz = clk_hz / (2u * pre + 5u);
    return INA236_OK;
}

int ina236_i2c_reset(struct ina236_bus *inst)
{
    if (inst == NULL)
        return INA236_ERR_ARG;
    inst->i2cm.state = I2CM_STATE_IDLE;
    return INA236_OK;
}

int ina236_i2c_recover(struct ina236_bus *inst)
{
    return ina236_i2c_reset(inst);
}

int ina236_i2c_write(struct ina236_bus *inst, uint8_t addr, const uint8_t *data, uint32_t len)
{
    if (inst == NULL || addr > 0x7Fu || data == NULL || len == 0u || len > 255u)
        return INA236_ERR_ARG;
    inst->last_addr = addr;
    return i2c_master_write(&inst->i2cm, addr, (uint8_t)len, (uint8_t *)data) ? INA236_ERR_NACK : INA236_OK;
}

int ina236_i2c_write_read(struct ina236_bus *inst, uint8_t addr,
                          const uint8_t *wdata, uint32_t wlen, uint8_t *rdata, uint32_t rlen)
{
    if (inst == NULL || addr > 0x7Fu || wdata == NULL || wlen == 0u || rdata == NULL || rlen == 0u
        || wlen > 255u || rlen > 255u)
        return INA236_ERR_ARG;
    inst->last_addr = addr;
    return i2c_master_repeated_start(&inst->i2cm, addr, (uint8_t)wlen, (uint8_t *)wdata,
                                     (uint8_t)rlen, rdata) ? INA236_ERR_NACK : INA236_OK;
}

int ina236_i2c_ping(struct ina236_bus *inst, uint8_t addr)
{
    uint8_t b;
    if (inst == NULL || addr > 0x7Fu)
        return INA236_ERR_ARG;
    inst->last_addr = addr;
    return i2c_master_read(&inst->i2cm, addr, 1u, &b) ? INA236_ERR_NACK : INA236_OK;
}
/* ---------------------------------------------------------------- INA236A registers */
int ina236_read_reg(struct ina236_bus *inst, uint8_t addr, uint8_t reg, uint16_t *value)
{
    uint8_t buf[2];
    if (value == NULL)
        return INA236_ERR_ARG;
    int rc = ina236_i2c_write_read(inst, addr, &reg, 1u, buf, 2u);
    if (rc == INA236_OK)
        *value = (uint16_t)(((uint16_t)buf[0] << 8) | buf[1]);
    return rc;
}

int ina236_write_reg(struct ina236_bus *inst, uint8_t addr, uint8_t reg, uint16_t value)
{
    uint8_t buf[3];
    buf[0] = reg;
    buf[1] = (uint8_t)(value >> 8);
    buf[2] = (uint8_t)value;
    return ina236_i2c_write(inst, addr, buf, 3u);
}

int ina236_probe(struct ina236_bus *inst, uint8_t addr)
{
    uint16_t mfr = 0, dev = 0;
    int rc = ina236_read_reg(inst, addr, INA236_REG_MFR_ID, &mfr);
    if (rc == INA236_OK)
        rc = ina236_read_reg(inst, addr, INA236_REG_DEVICE_ID, &dev);
    if (rc != INA236_OK)
        return rc;
    if (mfr != INA236_MFR_ID_VALUE || (dev & INA236_DEVICE_ID_MASK) != INA236_DEVICE_ID_VALUE)
        return INA236_ERR_ID;
    return INA236_OK;
}

/* ---------------------------------------------------------------- calibration */
uint16_t ina236_calc_shunt_cal(uint32_t rshunt_uohm, uint32_t current_lsb_ua, uint8_t adcrange)
{
    /* 0.00512 / (lsb_A x r_ohm) = 5.12e9 / (lsb_uA x r_uohm). 5.12e9 does not fit 32 bits, so
     * compute 2 x (2.56e9 / d) with the remainder rounded in. */
    if (rshunt_uohm == 0u || current_lsb_ua == 0u || current_lsb_ua > 0x7FFFFFFFu / rshunt_uohm)
        return 0;
    uint32_t d   = current_lsb_ua * rshunt_uohm;
    uint32_t q   = 2560000000u / d;
    uint32_t rem = 2560000000u % d;
    uint32_t cal = 2u * q + ((2u * rem >= d) ? 1u : 0u);
    if (adcrange)
        cal = (cal + 2u) / 4u;                           /* Equation 1 note: divide by 4 */
    return (cal >= 1u && cal <= 32767u) ? (uint16_t)cal : 0;
}

void ina236_channel_default(struct ina236_channel *ch, uint8_t addr, uint32_t rshunt_uohm,
                            uint32_t current_lsb_ua)
{
    if (ch == NULL)
        return;
    ch->addr           = addr;
    ch->config         = INA236_CONFIG_DEFAULT;
    ch->adcrange       = 0;
    ch->current_lsb_ua = current_lsb_ua;
    ch->shunt_cal      = ina236_calc_shunt_cal(rshunt_uohm, current_lsb_ua, 0);
}

int ina236_configure(struct ina236_bus *inst, const struct ina236_channel *ch)
{
    uint16_t rb = 0;
    if (ch == NULL || ch->shunt_cal == 0u)
        return INA236_ERR_ARG;
    int rc = ina236_write_reg(inst, ch->addr, INA236_REG_CONFIG, ch->config);
    if (rc == INA236_OK)
        rc = ina236_write_reg(inst, ch->addr, INA236_REG_SHUNT_CAL, ch->shunt_cal);
    if (rc == INA236_OK)
        rc = ina236_read_reg(inst, ch->addr, INA236_REG_SHUNT_CAL, &rb);
    if (rc != INA236_OK)
        return rc;
    return (rb == ch->shunt_cal) ? INA236_OK : INA236_ERR_CAL;
}

/* ---------------------------------------------------------------- measurement */
int ina236_read_sample(struct ina236_bus *inst, const struct ina236_channel *ch,
                       struct ina236_sample *s)
{
    uint16_t v;
    int rc;
    if (ch == NULL || s == NULL)
        return INA236_ERR_ARG;

    rc = ina236_read_reg(inst, ch->addr, INA236_REG_SHUNT, &v);
    if (rc != INA236_OK) return rc;
    s->raw_shunt = (int16_t)v;
    rc = ina236_read_reg(inst, ch->addr, INA236_REG_BUS, &v);
    if (rc != INA236_OK) return rc;
    s->raw_bus = v;
    rc = ina236_read_reg(inst, ch->addr, INA236_REG_CURRENT, &v);
    if (rc != INA236_OK) return rc;
    s->raw_current = (int16_t)v;
    rc = ina236_read_reg(inst, ch->addr, INA236_REG_POWER, &v);
    if (rc != INA236_OK) return rc;
    s->raw_power = v;

    uint32_t nv = ch->adcrange ? INA236_SHUNT_NV_PER_LSB_R1 : INA236_SHUNT_NV_PER_LSB_R0;
    s->shunt_uv   = ((int32_t)s->raw_shunt * (int32_t)nv) / 1000;
    s->bus_mv     = ((uint32_t)(s->raw_bus & 0x7FFFu) * INA236_BUS_UV_PER_LSB) / 1000u;
    s->current_ma = ((int32_t)s->raw_current * (int32_t)ch->current_lsb_ua) / 1000;
    s->power_mw   = (((uint32_t)s->raw_power * ch->current_lsb_ua) / 1000u) * INA236_POWER_LSB_FACTOR;

    /* Calibration fault: Equation 2, Current = SHUNT x SHUNT_CAL / 2048 (8192 for ADCRANGE 1) */
    int32_t expected = ((int32_t)s->raw_shunt * (int32_t)ch->shunt_cal) / (ch->adcrange ? 8192 : 2048);
    if (s->raw_current == 0 && (expected >= 2 || expected <= -2))
        return INA236_ERR_CAL;
    return INA236_OK;
}

const char *ina236_strerror(int code)
{
    switch (code) {
    case INA236_OK:          return "ok";
    case INA236_ERR_TIMEOUT: return "timeout";
    case INA236_ERR_NACK:    return "no acknowledge";
    case INA236_ERR_ARBL:    return "arbitration lost or bus busy";
    case INA236_ERR_ARG:     return "invalid argument";
    case INA236_ERR_ID:      return "wrong device id";
    case INA236_ERR_CAL:     return "calibration fault";
    default:                 return "unknown error";
    }
}
