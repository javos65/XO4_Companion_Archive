/* INA236 register definitions (TI SBOSA81D, Tables 7-2 to 7-13). */
#ifndef INA236_REGS_H
#define INA236_REGS_H

/* ---- INA236 registers (pointer byte values) ---- */
#define INA236_REG_CONFIG      0x00u   /* reset 0x4127 */
#define INA236_REG_SHUNT       0x01u   /* 2.5 uV/LSB (ADCRANGE 0), two's complement */
#define INA236_REG_BUS         0x02u   /* 1.6 mV/LSB, bit 15 reads 0 */
#define INA236_REG_POWER       0x03u   /* 32 x CURRENT_LSB per LSB, unsigned */
#define INA236_REG_CURRENT     0x04u   /* CURRENT_LSB per LSB, two's complement */
#define INA236_REG_SHUNT_CAL   0x05u
#define INA236_REG_MASK_ENABLE 0x06u
#define INA236_REG_ALERT_LIMIT 0x07u
#define INA236_REG_MFR_ID      0x3Eu   /* reads 0x5449 ("TI") */
#define INA236_REG_DEVICE_ID   0x3Fu   /* reads 0xA080 in bits 15..4; bits 3..0 read 0 */

#define INA236_MFR_ID_VALUE    0x5449u
#define INA236_DEVICE_ID_VALUE 0xA080u
#define INA236_DEVICE_ID_MASK  0xFFF0u

/* CONFIG fields */
#define INA236_CFG_RST         (1u << 15)
#define INA236_CFG_ADCRANGE    (1u << 12)   /* 0 = +/-81.92 mV, 1 = +/-20.48 mV */
/* Standard setting: reset default 0x4127 = ADCRANGE 0, AVG 1, VBUSCT 1100 us,
 * VSHCT 1100 us, MODE 111b (continuous shunt and bus voltage) */
#define INA236_CONFIG_DEFAULT  0x4127u

/* MASK/ENABLE bits used */
#define INA236_ME_CVRF         (1u << 3)    /* conversion ready flag */


#endif /* INA236_REGS_H */

