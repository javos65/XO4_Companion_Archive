#ifndef REG_ACCESS_H
#define REG_ACCESS_H

#include <stdint.h>

static inline uint8_t reg_8b_read(uint32_t reg_addr, uint8_t *reg_8b_value) {
    uint8_t volatile *reg_value = (void *)(uintptr_t)reg_addr;
    *reg_8b_value = *reg_value; return 0;
}
static inline uint8_t reg_8b_write(uint32_t reg_addr, uint8_t value) {
    uint8_t volatile *reg_value = (void *)(uintptr_t)reg_addr;
    *reg_value = value; return 0;
}
static inline uint8_t reg_32b_write(uint32_t reg_addr, uint32_t value) {
    *(volatile uint32_t *)(uintptr_t)reg_addr = value; return 0;
}
static inline uint8_t reg_32b_read(uint32_t reg_addr, uint32_t *v) {
    *v = *(volatile uint32_t *)(uintptr_t)reg_addr; return 0;
}
static inline uint8_t reg_32b_modify(uint32_t reg_addr, uint32_t mask, uint32_t value) {
    volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)reg_addr;
    *p = (*p & ~mask) | (value & mask); return 0;
}
static inline uint8_t reg_16b_write(uint32_t reg_addr, uint16_t value) {
    *(volatile uint16_t *)(uintptr_t)reg_addr = value; return 0;
}
static inline uint8_t reg_16b_read(uint32_t reg_addr, uint16_t *v) {
    *v = *(volatile uint16_t *)(uintptr_t)reg_addr; return 0;
}

#ifdef read8
#undef read8
#endif
#ifdef write8
#undef write8
#endif
static inline void write8(uint32_t reg_addr, uint8_t value) {
    *(volatile uint8_t *)(uintptr_t)reg_addr = value;
}
static inline void read8(uint32_t reg_addr, uint8_t *value) {
    *value = *(volatile uint8_t *)(uintptr_t)reg_addr;
}
static inline void reg_8b_modify(uint32_t reg_addr, uint8_t mask, uint8_t value) {
    volatile uint8_t *p = (volatile uint8_t *)(uintptr_t)reg_addr;
    *p = (*p & ~mask) | (value & mask);
}

#endif /* REG_ACCESS_H */
