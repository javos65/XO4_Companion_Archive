/*   ==================================================================
     Copyright (c) 2019-2025 by Lattice Semiconductor Corporation
     ALL RIGHTS RESERVED

     File: feature_flags.h

     ================================================================== */

#ifndef FEATURE_FLAGS_H_
#define FEATURE_FLAGS_H_


#define FEATURE_UART_DEBUG

#define FEATURE_MAIN_BOOTLOADER_TEMPLATE
//#define FEATURE_MICRODRV_SMOKE_TEST
//#define FEATURE_GSRDBOOT_TEMPLATE
//#define FEATURE_GSRDAPP_TEMPLATE

/* ---- GSRDAPP-only sub-features (RTOS, PHY, lwIP) ------------------ */
#ifdef FEATURE_GSRDAPP_TEMPLATE
#define FEATURE_FREE_RTOS_ENABLE
#define FEATURE_ETHERNET_PHY_ENABLE

#ifdef FEATURE_FREE_RTOS_ENABLE
#define FEATURE_LWIP_ENABLE
#define FEATURE_TSE_MAC_1GBPS_ENABLE 1
//#define FEATURE_TSE_MAC_100MBPS_ENABLE 1
//#define FEATURE_TSE_MAC_10MBPS_ENABLE 1
#endif /* FEATURE_FREE_RTOS_ENABLE */
#endif /* FEATURE_GSRDAPP_TEMPLATE */

/* ---- Per-peripheral enables --------------------------------------- *
 * GSRDAPP pulls in the full set of peripherals so memory_map.h exposes
 * every *_BASE_ADDR0 macro referenced by the BSP/debug headers (e.g.
 * UART_DEBUG_BASE_ADDR0 in uart_debug.h).  GSRDBOOT needs UART + storage.
 * The micro-driver smoke test only exercises the driver framework via
 * the UART probe banner, so it just needs UART. */
#if defined(FEATURE_GSRDAPP_TEMPLATE)
#define FEATURE_UART_ENABLE             1
#define FEATURE_GPIO_ENABLE             1
#define FEATURE_I2C_ENABLE              1
#define FEATURE_TSE_MAC_ENABLE          1
#define FEATURE_SGDMA_ENABLE            1
#define FEATURE_LPDDR4_ENABLE           1
#define FEATURE_OSPI_ENABLE             1
#elif defined(FEATURE_MAIN_BOOTLOADER_TEMPLATE)
#define FEATURE_UART_ENABLE             1
#define FEATURE_GPIO_ENABLE             1
#define FEATURE_I2C_ENABLE              1
#define FEATURE_TSE_MAC_ENABLE          1
#define FEATURE_SGDMA_ENABLE            1
#define FEATURE_LPDDR4_ENABLE           1
#define FEATURE_OSPI_ENABLE             1

#ifndef FEATURE_MICRODRV_SMOKE_TEST
#define FEATURE_MICRODRV_SMOKE_TEST
#endif /* FEATURE_MICRODRV_SMOKE_TEST */

#ifndef FEATURE_GSRDBOOT_TEMPLATE
#define FEATURE_GSRDBOOT_TEMPLATE
#endif /* FEATURE_GSRDBOOT_TEMPLATE */

//#define FEATURE_OSPI_PROGRAMMING_ENABLE 1
#endif

/* ---- On-target SoC self-test -------------------------------------- *
 * Orthogonal to the build mode, so it lives here rather than in the top
 * selector block. Compiles src/selftest/, which walks the generated
 * soc_devices[] table and reports per-device PROBE/TEST results over the
 * debug UART. Read-only: it never writes to a peripheral.
 *
 * Deliberately NOT FEATURE_MICRODRV_SMOKE_TEST, which is already taken:
 * that flag is a top-block selector and it is what the reference design's
 * own drv_test/ compiles under. Sharing it would build two overlapping
 * suites and two banners at once. */
//#define FEATURE_SOC_SELFTEST

#if defined(FEATURE_SOC_SELFTEST) && defined(FEATURE_MICRODRV_SMOKE_TEST)
#warning "FEATURE_SOC_SELFTEST and FEATURE_MICRODRV_SMOKE_TEST are both on; \
both will print a device report."
#endif



/* ===================================================================
 * Test enables (disabled in BOOT/APP modes)
 * =================================================================== */

#ifdef FEATURE_GPIO_ENABLE
#define GPIO_INSTANCE_COUNT 1
#endif
#ifdef FEATURE_SGDMA_ENABLE
#define SGDMA_INSTANCE_COUNT 1
#endif
#ifdef FEATURE_TSE_MAC_ENABLE
#define TSE_MAC_INSTANCE_COUNT 1
#endif
#ifdef FEATURE_LPDDR4_ENABLE
#define LPDDR4_INSTANCE_COUNT 1
#endif
#ifdef FEATURE_I2C_ENABLE
#define I2C_INSTANCE_COUNT 1
#endif
#ifdef FEATURE_OSPI_ENABLE
#define OSPI_INSTANCE_COUNT 1
#endif


#endif /* FEATURE_FLAGS_H_ */
