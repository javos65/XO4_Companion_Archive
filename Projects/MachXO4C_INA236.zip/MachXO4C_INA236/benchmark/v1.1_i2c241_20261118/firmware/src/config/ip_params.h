#ifndef IP_PARAMS_H_
#define IP_PARAMS_H_

#include "feature_flags.h"

/* Extracted from SGE bsp/sys_platform.h. Every #define is #ifndef-guarded:
   soc_config.h re-emits the per-instance symbols with a 'u' suffix and is
   the authoritative source for the driver framework, so whichever header
   is included first wins and neither warns. */

#ifndef SYS_PLATFORM_H
#ifndef SYS_PLATFORM_H
#define SYS_PLATFORM_H
#endif /* SYS_PLATFORM_H */
#ifndef DEVICE_FAMILY
#define DEVICE_FAMILY "LFMXO4"
#endif /* DEVICE_FAMILY */
#ifndef LFMXO4_110HC
#define LFMXO4_110HC
#endif /* LFMXO4_110HC */
#ifndef CPU0_INST_NAME
#define CPU0_INST_NAME "cpu0_inst"
#endif /* CPU0_INST_NAME */
#ifndef CPU0_INST_BASE_ADDR
#define CPU0_INST_BASE_ADDR 0xffff0000
#endif /* CPU0_INST_BASE_ADDR */
#ifndef INA0_INST_NAME
#define INA0_INST_NAME "ina0_inst"
#endif /* INA0_INST_NAME */
#ifndef INA0_INST_BASE_ADDR
#define INA0_INST_BASE_ADDR 0x8800
#endif /* INA0_INST_BASE_ADDR */
#ifndef GPIO0_INST_NAME
#define GPIO0_INST_NAME "gpio0_inst"
#endif /* GPIO0_INST_NAME */
#ifndef GPIO_INST_NAME
#define GPIO_INST_NAME GPIO0_INST_NAME
#endif /* GPIO_INST_NAME */
#ifndef GPIO0_INST_BASE_ADDR
#define GPIO0_INST_BASE_ADDR 0x8400
#endif /* GPIO0_INST_BASE_ADDR */
#ifndef GPIO_INST_BASE_ADDR
#define GPIO_INST_BASE_ADDR GPIO0_INST_BASE_ADDR
#endif /* GPIO_INST_BASE_ADDR */
#ifndef SYSMEM0_INST_NAME
#define SYSMEM0_INST_NAME "sysmem0_inst"
#endif /* SYSMEM0_INST_NAME */
#ifndef SYSMEM0_INST_BASE_ADDR
#define SYSMEM0_INST_BASE_ADDR 0x0
#endif /* SYSMEM0_INST_BASE_ADDR */
#ifndef UART0_INST_NAME
#define UART0_INST_NAME "uart0_inst"
#endif /* UART0_INST_NAME */
#ifndef UART0_INST_BASE_ADDR
#define UART0_INST_BASE_ADDR 0x8000
#endif /* UART0_INST_BASE_ADDR */
#ifndef UART_INST_BASE_ADDR
#define UART_INST_BASE_ADDR UART0_INST_BASE_ADDR
#endif /* UART_INST_BASE_ADDR */
#ifndef RISCV_SM_INST_0
#define RISCV_SM_INST_0 CPU0_INST
#endif /* RISCV_SM_INST_0 */
#ifndef INA236_EFB_INST_0
#define INA236_EFB_INST_0 INA0_INST
#endif /* INA236_EFB_INST_0 */
#ifndef GPIO_INST_0
#define GPIO_INST_0 GPIO0_INST
#endif /* GPIO_INST_0 */
#ifndef SYSTEM_MEMORY_INST_0
#define SYSTEM_MEMORY_INST_0 SYSMEM0_INST
#endif /* SYSTEM_MEMORY_INST_0 */
#ifndef UART_INST_0
#define UART_INST_0 UART0_INST
#endif /* UART_INST_0 */
#ifndef REG_TEST_ENABLE
#define REG_TEST_ENABLE 0
#endif /* REG_TEST_ENABLE */
#ifndef CPU0_INST_DEBUG_ENABLE
#define CPU0_INST_DEBUG_ENABLE False
#endif /* CPU0_INST_DEBUG_ENABLE */
#ifndef CPU0_INST_DEVICE
#define CPU0_INST_DEVICE MachXO4
#endif /* CPU0_INST_DEVICE */
#ifndef CPU0_INST_E_EXT
#define CPU0_INST_E_EXT False
#endif /* CPU0_INST_E_EXT */
#ifndef CPU0_INST_E_STANDALONE
#define CPU0_INST_E_STANDALONE False
#endif /* CPU0_INST_E_STANDALONE */
#ifndef CPU0_INST_HB_RANGE
#define CPU0_INST_HB_RANGE 1
#endif /* CPU0_INST_HB_RANGE */
#ifndef CPU0_INST_HW_WATCHPOINT
#define CPU0_INST_HW_WATCHPOINT 0
#endif /* CPU0_INST_HW_WATCHPOINT */
#ifndef CPU0_INST_IRQ_NUM
#define CPU0_INST_IRQ_NUM 1
#endif /* CPU0_INST_IRQ_NUM */
#ifndef CPU0_INST_JTAG_CHANNEL
#define CPU0_INST_JTAG_CHANNEL 14
#endif /* CPU0_INST_JTAG_CHANNEL */
#ifndef CPU0_INST_PICTIMER_START_ADDR
#define CPU0_INST_PICTIMER_START_ADDR 0xFFFF0000
#endif /* CPU0_INST_PICTIMER_START_ADDR */
#ifndef CPU0_INST_PIC_ENABLE
#define CPU0_INST_PIC_ENABLE True
#endif /* CPU0_INST_PIC_ENABLE */
#ifndef CPU0_INST_RADIANT_MEM_SEARCH_PATH
#define CPU0_INST_RADIANT_MEM_SEARCH_PATH ./testbench
#endif /* CPU0_INST_RADIANT_MEM_SEARCH_PATH */
#ifndef CPU0_INST_RESET_VECTOR
#define CPU0_INST_RESET_VECTOR 0x00000000
#endif /* CPU0_INST_RESET_VECTOR */
#ifndef CPU0_INST_RESET_VECTOR_INPUT
#define CPU0_INST_RESET_VECTOR_INPUT 00000000
#endif /* CPU0_INST_RESET_VECTOR_INPUT */
#ifndef CPU0_INST_SIMULATION
#define CPU0_INST_SIMULATION False
#endif /* CPU0_INST_SIMULATION */
#ifndef CPU0_INST_SOFT_JTAG
#define CPU0_INST_SOFT_JTAG False
#endif /* CPU0_INST_SOFT_JTAG */
#ifndef CPU0_INST_TIMER_ENABLE
#define CPU0_INST_TIMER_ENABLE True
#endif /* CPU0_INST_TIMER_ENABLE */
#ifndef GPIO0_INST_GPIO_DIRS
#define GPIO0_INST_GPIO_DIRS 0x00000001
#endif /* GPIO0_INST_GPIO_DIRS */
#ifndef GPIO_INST_GPIO_DIRS
#define GPIO_INST_GPIO_DIRS GPIO0_INST_GPIO_DIRS
#endif /* GPIO_INST_GPIO_DIRS */
#ifndef GPIO0_INST_LINES_NUM
#define GPIO0_INST_LINES_NUM 5
#endif /* GPIO0_INST_LINES_NUM */
#ifndef GPIO_INST_LINES_NUM
#define GPIO_INST_LINES_NUM GPIO0_INST_LINES_NUM
#endif /* GPIO_INST_LINES_NUM */
#ifndef UART0_INST_BAUD_RATE
#define UART0_INST_BAUD_RATE 19200
#endif /* UART0_INST_BAUD_RATE */
#ifndef UART_INST_BAUD_RATE
#define UART_INST_BAUD_RATE UART0_INST_BAUD_RATE
#endif /* UART_INST_BAUD_RATE */
#ifndef UART0_INST_DATA_WIDTH
#define UART0_INST_DATA_WIDTH 8
#endif /* UART0_INST_DATA_WIDTH */
#ifndef UART0_INST_STOP_BITS
#define UART0_INST_STOP_BITS 1
#endif /* UART0_INST_STOP_BITS */
#ifndef UART0_INST_SYS_CLK
#define UART0_INST_SYS_CLK 12.0
#endif /* UART0_INST_SYS_CLK */
#ifndef UART_INST_SYS_CLK
#define UART_INST_SYS_CLK UART0_INST_SYS_CLK
#endif /* UART_INST_SYS_CLK */
#ifndef UART0_INST_IRQ
#define UART0_INST_IRQ 0
#endif /* UART0_INST_IRQ */
#endif

#endif /* IP_PARAMS_H_ */
