#ifndef SYS_CONFIG_H_
#define SYS_CONFIG_H_

/* Master system configuration header: aggregates feature flags, the memory
   map, and IP parameters. Sources include this first. */
#include "feature_flags.h"
#include "memory_map.h"
#include "ip_params.h"

#endif /* SYS_CONFIG_H_ */
