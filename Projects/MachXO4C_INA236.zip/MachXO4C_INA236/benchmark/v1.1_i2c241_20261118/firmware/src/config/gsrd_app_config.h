#ifndef GSRD_APP_CONFIG_H_
#define GSRD_APP_CONFIG_H_

#include "sys_config.h"

#endif /* GSRD_APP_CONFIG_H_ */
