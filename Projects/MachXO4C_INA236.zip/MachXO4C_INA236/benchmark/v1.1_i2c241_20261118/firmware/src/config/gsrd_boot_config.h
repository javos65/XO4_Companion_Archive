#ifndef GSRD_BOOT_CONFIG_H_
#define GSRD_BOOT_CONFIG_H_

#include "sys_config.h"

#endif /* GSRD_BOOT_CONFIG_H_ */
