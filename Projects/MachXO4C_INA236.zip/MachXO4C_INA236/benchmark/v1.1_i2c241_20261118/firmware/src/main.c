/* INA236 power monitor, firmware 1.0.
 *
 * Polls four INA236A monitors through the Lattice I2C controller 2.4.1 once per second and prints a text
 * table over the UART (19200 baud 8N1). RISC-V SM runtime (riscv_sm BSP crt0), polling only,
 * no interrupts, no printf (integer formatting is local to keep the image small).
 *
 * Addresses: UART 0x8000, GPIO 0x8400, I2C controller 0x10000000, PIC/timer 0xFFFF0000.
 * LED lines are on GPIO bits 0..3 (active low), SW1 on GPIO bit 4 (active low).
 */
#include <stddef.h>
#include <stdint.h>
/* Lattice I2C controller 2.4.1 (I2C_inst0, 0x10000000) on A9 (SCL) / C9 (SDA); the EFB is not used. */
#include "ina236.h"
#include "bsp/driver/uart/uart.h"
#include "bsp/driver/gpio/gpio.h"
#include "bsp/driver/riscv_sm/timer.h"

/* ---- board constants ---- */
#define UART_BASE        0x00008000u
#define GPIO_BASE        0x00008400u
#define INA_BASE         0x10000000u    /* I2C_inst0 (i2c_controller 2.4.1) */
#define TIMER_BASE       0xFFFF0000u
#define CPU_HZ           24000000u      /* CPU clock; machine timer assumed to tick at this rate */
#define APB_HZ           12000000u      /* APB clock of the I2C controller */
#define UART_BAUD        19200u
#define I2C_HZ           100000u
#define RSHUNT_UOHM      10000u         /* 10 milliohm (Figure 8-1) */
#define CURRENT_LSB_UA   1000u          /* 1 mA, SHUNT_CAL = 512 */
#define TOL_PERCENT      5u             /* voltage tolerance around the nominal value */
#define POLL_TICKS       CPU_HZ         /* 1 s measurement period */

/* GPIO lines */
#define LED_HEARTBEAT    0u
#define LED_AUTOPRINT    1u
#define LED_I2C          2u
#define LED_FAULT        3u
#define SW1_LINE         4u
#define GPIO_LINES       5u
#define GPIO_OUT_MASK    0x0Fu          /* bits 0..3 outputs (LEDs), bit 4 input (SW1) */

#define NUM_CH           4

struct ch_cfg {
    const char *name;                   /* label printed in the table */
    uint8_t     addr;                   /* INA236A address */
    uint16_t    nominal_mv;             /* expected bus voltage */
};

static const struct ch_cfg cfg[NUM_CH] = {
    { "U19 VCORE ", INA236_ADDR_A0_GND, 3300u },    /* VCC_Core, J19 2-3 */
    { "U20 VCIO2 ", INA236_ADDR_A0_VS,  3300u },    /* Bank 2, J20 2-3 */
    { "U21 BANK01", INA236_ADDR_A0_SDA, 3300u },    /* VCC_BANK_3V3 */
    { "U22 VADJ  ", INA236_ADDR_A0_SCL, 1800u },    /* Banks 4 and 5 */
};

static struct uart_instance       uart;
static struct gpio_instance       gpio;
static struct timer_instance      tmr;
static struct ina236_bus          ina;
static struct ina236_channel      ch[NUM_CH];
static uint8_t                    present[NUM_CH];
static uint8_t                    autoprint = 1;
static uint8_t                    fault_latched;

/* ------------------------------------------------------------------ console */
static void put_ch(char c) { (void)uart_putc(&uart, (unsigned char)c); }
static void put_str(const char *s) { while (*s) put_ch(*s++); }
static void put_crlf(void) { put_ch('\r'); put_ch('\n'); }

/* unsigned number, right aligned in `width` characters, padded with `pad` */
static void put_num(uint32_t v, int width, char pad)
{
    char buf[11];
    int n = 0;
    do { buf[n++] = (char)('0' + (v % 10u)); v /= 10u; } while (v != 0u && n < 10);
    for (int i = n; i < width; i++) put_ch(pad);
    while (n > 0) put_ch(buf[--n]);
}

static void put_hex2(uint8_t v)
{
    put_ch("0123456789ABCDEF"[(v >> 4) & 0xFu]);
    put_ch("0123456789ABCDEF"[v & 0xFu]);
}

/* ------------------------------------------------------------------ GPIO helpers */
static void led(uint32_t line, int on)
{
    (void)gpio_output_write(&gpio, line, on ? 0u : 1u);       /* active low */
}

static int sw1_pressed(void)
{
    uint32_t v = 1u;
    if (gpio_input_get(&gpio, SW1_LINE, &v) != 0)
        return 0;
    return v == 0u;                                           /* active low */
}

/* ------------------------------------------------------------------ time base */
static uint64_t now_ticks(void)
{
    unsigned long long v = 0;
    (void)timer_get_mtime(&tmr, &v);
    return (uint64_t)v;
}

/* ------------------------------------------------------------------ measurement */
static void init_channel(int i)
{
    int rc;
    ina236_channel_default(&ch[i], cfg[i].addr, RSHUNT_UOHM, CURRENT_LSB_UA);
    rc = ina236_probe(&ina, cfg[i].addr);
    if (rc == INA236_OK)
        rc = ina236_configure(&ina, &ch[i]);
    present[i] = (rc == INA236_OK);
    put_str(cfg[i].name);
    put_str(present[i] ? " INA OK" : " INA MISSING");
    if (!present[i]) {
        put_str(" (");
        put_str(ina236_strerror(rc));
        put_ch(')');
        fault_latched = 1;
    }
    put_crlf();
}

/* Probe every 7-bit address 0x08..0x77 with a one-byte read and list those that
 * acknowledge. Used to find the real INA236 addresses when the expected ones do not answer. */
static int scan_bus(void)
{
    int found = 0;
    put_str("SCAN:");
    for (uint8_t a = 0x08u; a <= 0x77u; a++) {
        if (ina236_i2c_ping(&ina, a) == INA236_OK) {
            put_str(" 0x");
            put_hex2(a);
            if (ina236_probe(&ina, a) == INA236_OK)
                put_str("(INA236)");              /* manufacturer and device ID match */
            found++;
        }
    }
    put_str(found ? "" : " none");
    put_crlf();
    return found;
}

static void init_all(void)
{
    (void)scan_bus();                      /* report every address that answers, at every start */
    for (int i = 0; i < NUM_CH; i++)
        init_channel(i);
}

/* one table line; returns 1 when the channel is in fault */
static int report_channel(int i)
{
    struct ina236_sample s;
    const char *flag = "OK";
    int rc = ina236_read_sample(&ina, &ch[i], &s);
    int fault = 0;

    if (rc != INA236_OK && rc != INA236_ERR_CAL) {            /* retry once, then try recovery */
        rc = ina236_read_sample(&ina, &ch[i], &s);
        if (rc != INA236_OK && rc != INA236_ERR_CAL)
            (void)ina236_i2c_recover(&ina);
    }
    put_str(cfg[i].name);
    if (rc != INA236_OK && rc != INA236_ERR_CAL) {
        put_str("  ---- mV  ---- mA  ---- mW ");
        put_str(rc == INA236_ERR_NACK ? "NACK" : "I2C");
        put_crlf();
        return 1;
    }
    {
        uint32_t nom = cfg[i].nominal_mv;
        uint32_t dev = (s.bus_mv > nom) ? (s.bus_mv - nom) : (nom - s.bus_mv);
        if (rc == INA236_ERR_CAL)                 { flag = "CAL";  fault = 1; }
        else if (dev * 100u > nom * TOL_PERCENT)  { flag = (s.bus_mv > nom) ? "HIGH" : "LOW"; fault = 1; }
    }
    put_str("  ");
    put_num(s.bus_mv, 4, ' ');
    put_str(" mV  ");
    if (s.current_ma < 0) { put_ch('-'); put_num((uint32_t)(-s.current_ma), 3, '0'); }
    else                  { put_ch(' '); put_num((uint32_t)s.current_ma, 3, '0'); }
    put_str(" mA  ");
    put_num(s.power_mw, 4, '0');
    put_str(" mW ");
    put_str(flag);
    put_crlf();
    return fault;
}

static void report_all(void)
{
    int fault = 0;
    led(LED_I2C, 1);
    put_str("CH         BUS        CURRENT   POWER    STATE\r\n");
    for (int i = 0; i < NUM_CH; i++) {
        if (!present[i]) {                                    /* try to bring a missing device up */
            init_channel(i);
            if (!present[i]) { fault = 1; continue; }
        }
        fault |= report_channel(i);
    }
    led(LED_I2C, 0);
    if (fault) fault_latched = 1;
}

/* ------------------------------------------------------------------ main */
int main(void)
{
    uint64_t next;
    unsigned char c;
    uint8_t sw1_prev = 0, hb = 0;

    (void)gpio_init(&gpio, GPIO_BASE, GPIO_LINES, GPIO_OUT_MASK);
    for (uint32_t i = 0; i < 4u; i++) led(i, 0);
    led(LED_AUTOPRINT, autoprint);

    (void)uart_init(&uart, UART_BASE, APB_HZ, UART_BAUD, 1u, 8u);
    uart.blockingRx = 0;                                      /* polled, non-blocking receive */
    (void)timer_init(&tmr, TIMER_BASE, CPU_HZ);

    (void)ina236_bus_init(&ina, INA_BASE);
    (void)ina236_i2c_init(&ina, APB_HZ, I2C_HZ);

    put_str("INA236 MONITOR 1.1 (I2C controller 2.4.1)\r\n");
    init_all();
    led(LED_FAULT, fault_latched);
    next = now_ticks() + POLL_TICKS;

    for (;;) {
        /* one-second slot: heartbeat and optional table */
        if ((int64_t)(now_ticks() - next) >= 0) {
            next += POLL_TICKS;
            hb ^= 1u;
            led(LED_HEARTBEAT, hb);
            if (autoprint) report_all();
            led(LED_FAULT, fault_latched);
        }
        /* SW1: print now and clear the fault latch on the press edge */
        {
            uint8_t p = (uint8_t)sw1_pressed();
            if (p && !sw1_prev) {
                fault_latched = 0;
                report_all();
                led(LED_FAULT, fault_latched);
            }
            sw1_prev = p;
        }
        /* serial commands: r re-initialise, p print once, a toggle autoprint */
        if (uart_getc(&uart, &c) == 0) {
            if (c == 'r') { fault_latched = 0; (void)ina236_i2c_reset(&ina); init_all(); led(LED_FAULT, fault_latched); }
            else if (c == 'p') { report_all(); led(LED_FAULT, fault_latched); }
            else if (c == 'a') { autoprint ^= 1u; led(LED_AUTOPRINT, autoprint); }
            else if (c == 's') { (void)scan_bus(); }
        }
    }
    return 0;
}
