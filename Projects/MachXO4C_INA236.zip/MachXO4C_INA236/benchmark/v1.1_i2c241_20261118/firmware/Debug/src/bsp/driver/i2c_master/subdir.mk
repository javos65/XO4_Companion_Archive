################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
C_SRCS += \
../src/bsp/driver/i2c_master/i2c_master.c 

OBJS += \
./src/bsp/driver/i2c_master/i2c_master.o 

C_DEPS += \
./src/bsp/driver/i2c_master/i2c_master.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/i2c_master/%.o: ../src/bsp/driver/i2c_master/%.c src/bsp/driver/i2c_master/subdir.mk
	@echo 'Building file: $<'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -I"../src" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/cpu" -I"../src/bsp/driver/i2c_master" -I"../src/bsp/driver/i2c_master" -I"../src/bsp/driver/ina236" -I"../src/bsp/driver/riscv_sm" -I"../src/bsp/driver/uart" -I"../src/config" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_DOUBLE_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo ' '

