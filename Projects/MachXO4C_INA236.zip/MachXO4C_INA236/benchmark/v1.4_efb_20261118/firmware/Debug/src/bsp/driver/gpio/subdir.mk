################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
C_SRCS += \
../src/bsp/driver/gpio/gpio.c 

OBJS += \
./src/bsp/driver/gpio/gpio.o 

C_DEPS += \
./src/bsp/driver/gpio/gpio.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/gpio/%.o: ../src/bsp/driver/gpio/%.c src/bsp/driver/gpio/subdir.mk
	@echo 'Building file: $<'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -I"../src" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/cpu" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/INA236_efb" -I"../src/bsp/driver/riscv_sm" -I"../src/bsp/driver/uart" -I"../src/config" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_DOUBLE_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo ' '

