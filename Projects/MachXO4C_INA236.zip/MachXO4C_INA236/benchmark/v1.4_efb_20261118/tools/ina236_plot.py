#!/usr/bin/env python3
"""INA236 power monitor: live plot of the four rails from the MachXO4 Companion Board.

Reads the text table that the firmware prints once per second over the FTDI UART
(19200 8N1) and shows three stacked, scrolling diagrams: bus voltage (mV), current (mA)
and power (mW), one line per rail (U19 VCORE, U20 VCIO2, U21 BANK01, U22 VADJ).

Lines it understands (anything else is ignored):
    U19 VCORE   3316 mV   052 mA  0160 mW OK
    U20 VCIO2   3331 mV  -001 mA  0000 mW OK
    U21 BANK01  ---- mV  ---- mA  ---- mW NACK      (missing sample, shown as a gap)

Requirements:  pip install pyserial matplotlib
Usage:         python ina236_plot.py --port COM5
               python ina236_plot.py --list          (show the serial ports)
Options:       --baud 19200   --window 120 (seconds shown)   --csv log.csv (also log the samples)

Close any other terminal (for example Tabby) on the same port first: the FTDI port can only be
opened by one program at a time. The firmware must be in auto-print mode (LED2 on; toggle with 'a').
"""
import argparse
import collections
import csv
import queue
import re
import sys
import threading
import time

import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import serial
import serial.tools.list_ports

RAILS = ["U19", "U20", "U21", "U22"]
NAMES = {"U19": "U19 VCORE (3.3 V)", "U20": "U20 VCIO2 (3.3 V)",
         "U21": "U21 BANK01 (3.3 V)", "U22": "U22 VADJ (1.8 V)"}

LINE_RE = re.compile(
    r"^(U\d{2})\s+\S+\s+(\d+)\s*mV\s+([-\s]?\d+)\s*mA\s+(\d+)\s*mW\s+(\S+)")
FAIL_RE = re.compile(r"^(U\d{2})\s+\S+\s+-+\s*mV")


def reader(ser, out, stop):
    """Background thread: reads lines from the port and queues (time, rail, mV, mA, mW, state)."""
    while not stop.is_set():
        try:
            raw = ser.readline()
        except serial.SerialException as exc:
            out.put(("error", str(exc)))
            return
        if not raw:
            continue
        line = raw.decode("ascii", errors="replace").strip()
        t = time.monotonic()
        m = LINE_RE.match(line)
        if m:
            rail, mv, ma, mw, state = m.groups()
            out.put((t, rail, int(mv), int(ma.replace(" ", "")), int(mw), state))
            continue
        f = FAIL_RE.match(line)
        if f:
            out.put((t, f.group(1), None, None, None, "FAIL"))


def main():
    ap = argparse.ArgumentParser(description="Live plot of the INA236 rails")
    ap.add_argument("--port", help="serial port, e.g. COM5 or /dev/ttyUSB1")
    ap.add_argument("--baud", type=int, default=19200)
    ap.add_argument("--window", type=float, default=120.0, help="seconds shown on the time axis")
    ap.add_argument("--csv", help="optional CSV file to log every sample")
    ap.add_argument("--list", action="store_true", help="list serial ports and exit")
    args = ap.parse_args()

    if args.list or not args.port:
        for p in serial.tools.list_ports.comports():
            print(f"{p.device:10s} {p.description}")
        if not args.port:
            print("\nGive the port with --port (the FTDI UART is usually the higher of the two numbers).")
        return 0

    # Open with DTR and RTS released. pyserial asserts both by default when it opens a port;
    # on the Companion Board that disturbed the I2C bus (every rail reported "I2C" while this
    # script had the port, and the same board ran clean under Tabby). So set them before open().
    ser = serial.Serial()
    ser.port, ser.baudrate = args.port, args.baud
    ser.bytesize, ser.parity, ser.stopbits, ser.timeout = 8, "N", 1, 0.5
    ser.rtscts = ser.dsrdtr = ser.xonxoff = False
    ser.dtr = False
    ser.rts = False
    try:
        ser.open()
    except serial.SerialException as exc:
        print(f"Cannot open {args.port}: {exc}\nIs another terminal (Tabby) still connected?")
        return 1

    q = queue.Queue()
    stop = threading.Event()
    threading.Thread(target=reader, args=(ser, q, stop), daemon=True).start()

    maxlen = int(args.window * 2) + 10              # about one sample per second per rail
    data = {r: {k: collections.deque(maxlen=maxlen) for k in ("t", "mv", "ma", "mw")} for r in RAILS}
    t0 = time.monotonic()

    log_file = writer = None
    if args.csv:
        log_file = open(args.csv, "w", newline="")
        writer = csv.writer(log_file)
        writer.writerow(["time_s", "rail", "bus_mV", "current_mA", "power_mW", "state"])

    plt.style.use("seaborn-v0_8-darkgrid" if "seaborn-v0_8-darkgrid" in plt.style.available else "default")
    fig, axes = plt.subplots(3, 1, sharex=True, figsize=(11, 8))
    fig.canvas.manager.set_window_title(f"INA236 power monitor - {args.port}")
    titles = ("Bus voltage (mV)", "Current (mA)", "Power (mW)")
    keys = ("mv", "ma", "mw")
    lines = {}
    for ax, title, key in zip(axes, titles, keys):
        ax.set_ylabel(title)
        for r in RAILS:
            (lines[(r, key)],) = ax.plot([], [], marker=".", markersize=3, linewidth=1.2, label=NAMES[r])
    # one legend for all three diagrams, in a strip above the plot area so it never covers data
    handles = [lines[(r, "mv")] for r in RAILS]
    fig.legend(handles, [NAMES[r] for r in RAILS], loc="upper center", ncol=4, fontsize=9,
               frameon=False, bbox_to_anchor=(0.5, 0.995))
    axes[-1].set_xlabel("time (s)")
    status = fig.text(0.01, 0.005, "waiting for data...", fontsize=8)
    fig.tight_layout(rect=(0, 0.02, 1, 0.95))   # keep the top 5 % free for the legend

    def update(_frame):
        latest = {}
        while True:
            try:
                item = q.get_nowait()
            except queue.Empty:
                break
            if item[0] == "error":
                status.set_text(f"serial error: {item[1]}")
                continue
            t, rail, mv, ma, mw, state = item
            if rail not in data:
                continue
            ts = t - t0
            d = data[rail]
            d["t"].append(ts)
            # None leaves a gap in the line for a missing sample
            d["mv"].append(mv if mv is not None else float("nan"))
            d["ma"].append(ma if ma is not None else float("nan"))
            d["mw"].append(mw if mw is not None else float("nan"))
            latest[rail] = (mv, ma, mw, state)
            if writer:
                writer.writerow([f"{ts:.2f}", rail, mv, ma, mw, state])
        if writer:
            log_file.flush()

        now = time.monotonic() - t0
        for key in keys:
            for r in RAILS:
                lines[(r, key)].set_data(list(data[r]["t"]), list(data[r][key]))
        for ax in axes:
            ax.set_xlim(max(0.0, now - args.window), max(args.window, now))
            ax.relim()
            ax.autoscale_view(scalex=False, scaley=True)
        if latest:
            status.set_text("  |  ".join(
                f"{r}: {v[0]} mV {v[1]} mA {v[2]} mW {v[3]}" if v[0] is not None else f"{r}: {v[3]}"
                for r, v in sorted(latest.items())))
        return list(lines.values()) + [status]

    anim = FuncAnimation(fig, update, interval=500, cache_frame_data=False)  # noqa: F841 (keep reference)
    try:
        plt.show()
    finally:
        stop.set()
        ser.close()
        if log_file:
            log_file.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
