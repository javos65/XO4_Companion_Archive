# INA236 Monitor: benchmark v1.4 (EFB primary I2C)

Saved 2026-11-18 as the reference version of the EFB design that works on hardware. The earlier
benchmark with the soft I2C controller 2.4.1 is in `../v1.1_i2c241_20261118`.

## Hardware
- **Board:** MachXO4 Companion Board, LFMXO4-110HC-6BBG256I (speed grade 6).
- **I2C:** hardened EFB primary I2C (lscc_efb 1.3.0, APB 32-bit, 10-bit address, 100 kHz, prescale 30) behind the INA236_efb pass-through at 0x8800. SCL on A9, SDA on C9, LVCMOS33, the board's 4.7 kohm pull-ups.
- **SoC:** RISC-V SM, 16 KB system memory, UART at 0x8000 (19200 8N1, COM13 on the host PC), GPIO at 0x8400. The CPU and AHB run at 24 MHz, the APB and EFB at 12 MHz.

## The four fixes that made the EFB I2C work
1. **sysCONFIG `I2C_PORT=ENABLE`:** set in `constraints/ina_soc.pdc` with `ldc_set_sysconfig`. Radiant's default is DISABLE, and with it A9/C9 never reach the EFB.
2. **CR = 0x8C (SDA delay off):** the SDA delay needs the internal oscillator, which this design does not instantiate (FPGA-TN-02403, section 4.3.6).
3. **EFB target addresses 0x70/0x71:** set with I2C1_SLAVE_ADDR_IN = 11100. The default 10000 gives 0x40 (configuration) and 0x41 (user), the same as U19 and U20.
4. **End of each byte taken from TIP:** the driver waits until TIP has been set and cleared, with BUSY = 1, before reading RARC. RARC reads 1 at idle (SR = 0x20). The driver uses clock stretching (CKSDIS = 0) and the FPGA-IPUG-02287 Figure 7.9 command order: 0x90, 0x10, 0x40, 0x20, 0x68.

## Verified on hardware (2026-11-18, 12:28 build)
- **Banner:** `INA236 MONITOR 1.4 (EFB primary I2C, TIP byte end)`
- **Register line:** `EFB CR=8C BR0=1E BR1=00 SR=20`
- **Bus scan:** `SCAN: 0x40(INA236) 0x41(INA236) 0x42(INA236) 0x43(INA236)`
- **Measurements:**

| Channel | Bus voltage | Current | Power | State |
|---|---|---|---|---|
| U19 VCORE | 3313 to 3316 mV | 52 mA | 160 mW | OK |
| U20 VCIO2 | 3329 to 3332 mV | 0 to 1 mA | 0 mW | OK |
| U21 BANK01 | 3329 to 3332 mV | 3 to 7 mA | 0 mW | OK |
| U22 VADJ | 1800 to 1808 mV | 0 mA | 0 mW | OK |

- **Live plot:** `tools/ina236_plot.py --port COM13` runs (confirmed by the user).

## Build results
- **Timing:** valid, 0 failing endpoints in all three corners. Constraint coverage is 99.78%; the uncovered ports are the `gpio_io` lines (waiver).
- **Resources:** LUT4 27%, registers 14%, block RAM 42%, PLL 1 of 2, EFB 1 of 1.
- **Firmware:** rv32i, code 8904 bytes, memory image of 2227 words embedded and confirmed applied.
- **Programming:** Erase, Program and Verify of the configuration flash over FTUSB-0: "Operation: successful".

## Contents
- **bitstream/:** the .jed and .bit files, plus the timing (.twr), map (.mrp) and pad (.pad) reports.
- **firmware/:** sources, including the INA236_efb driver 1.4 and `main.c` 1.4, the hand-patched Debug makefiles (rv32i) and the .elf, .bin and .mem images.
- **soc/:** `ina_soc.sbx`, `ina_soc.v`, `ina_soc.rdf`, `ina_soc1.sty` and `efb0.cfg` (EFB settings).
- **constraints/:** `ina_soc.pdc` (with `I2C_PORT=ENABLE`) and `ina_soc.sdc`.
- **program/:** the programmer chain file `program_ina236.xcf`. It points at the working copy `ina_soc/impl_1`, not at this folder.
- **tools/:** `ina236_plot.py`, the live plot of the three stacked diagrams with optional CSV logging.
- **custom_IP/:** the INA236_efb 1.0.0 IP package with the updated driver.

## Checksums (SHA-256)
| File | Bytes | SHA-256 |
|---|---|---|
| ina_soc_impl_1.jed | 2097141 | `1E90E85E2A330EC225F853EFFAC794C41AD755D9ABE7C1948319CEFF726C4EE2` |
| ina_soc_impl_1.bit | 92673 | `8329A6600DBD9B0F549DB13CE96C8C788300911A750EDDD8BC7D7C1F2E2CB825` |
| ina_fw.mem | 20043 | `C852BB8746379C8888224316119474788E76A42E1B71F5B6516C863384640938` |
| ina_fw.elf | 147372 | `829FEAF0EA914B1D060F36DDA836AA656D130F4B35C795CECAED234AF01FEEFC` |
| ina_fw.bin | 8908 | `5DB2DDCD157500AE5BF54CB36FA471E5377ADDA038026EEC169A6F0DB3A4D19E` |
| ina236_plot.py | 7350 | `5352790241328AB982375F7C92C34B0FB81B0DAAE93B9918A36E4340293D43F2` |

## Known limits
- **Small loads read as 0 mW:** the power register counts in steps of 32 mW.
- **No stuck-bus release:** the EFB cannot generate extra clock pulses, so the driver cannot free an SDA line that a device holds low.
- **Serial port settings:** host tools must open COM13 with DTR and RTS released; otherwise the I2C bus fails.
- **Build files are hand-edited:** rerunning `firmware_gen_build` would overwrite the patched makefiles.
- **Package not rebuilt:** the INA236_efb .ipk still contains the 1.0.0 driver. The updated driver files sit next to it.
