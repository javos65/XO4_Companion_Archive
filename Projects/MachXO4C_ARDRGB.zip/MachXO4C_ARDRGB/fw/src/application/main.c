// MachXO4 Companion board + Arduino MKR RGB Shield (84 x APA102-2020, 7 rows x 12 columns)
// + on-board FXLS8971CF accelerometer: a rolling ball with momentum, friction, bounce and a trail.
//
// Based on the Propel SDK "Hello World" template (embeddedsw/helloworld): the same
// bsp_init() structure, terminal (printf over uart0_inst) and PIC init.
// IPs: mkr_rgb0_inst (custom:module:mkr_rgb_spi, APA102 chain), fxls0_inst
// (custom:module:fxls8971_i2c, I2C SCL B13 / SDA A14), gpio1_inst (ACC_SA0 = 0, ACC_WAKEUP = 1).
//
// Behaviour:
//  - startup message on the UART (19200 8N1, FTDI channel B)
//  - the ball is a point mass on the matrix plane, simulated every 5 ms in fixed point:
//      * gravity: when the board is tilted more than 5 degrees from flat, the downhill
//        component of g accelerates the ball (it gains speed while the tilt lasts)
//      * friction: a constant rolling resistance always works against the motion, so the
//        ball slows down and stops when the board is levelled again
//      * edges: the ball bounces back losing 20% of its energy and comes to rest
//        against the edge when the bounce is too weak
//  - trail: every pixel the ball passes keeps glowing in its colour and fades to dark
//  - display: one frame per accelerometer sample, 200 frames per second
//  - the ball changes colour only when it bounces
//  - heartbeat on board LED1 (D21): 1 s period; LED2..LED4 off
//  - UART: basic info at startup; then only one line per edge bounce (position and g-force),
// Everything runs in the main loop, timed by the RISC-V machine timer (no interrupts).
//
// Clocks: 12 MHz board clock (T9) -> PLL: 24 MHz CPU/AHB, 20 MHz APB.

#include "hal.h"
#include "utils.h"
#include <stdio.h>
#include "sys_platform.h"
#include <riscv_errors.h>
#include "platform_init.h"
#include "device_info.h"
#include "terminal.h"
#include "gpio.h"
#include "timer.h"
#include "mkr_rgb_spi.h"
#include "uart.h"
#include "i2c_master.h"
#include "fxls8971.h"

/* ------------------------------------------------------------------ settings */
/* CPU clock (PLL clkop): the machine timer counts at this rate; keep equal to the PLL setting. */
#define CPU_CLK_HZ           24000000u
/* APB clock (PLL clkos): taken from the SGE, it is the clock the UART was configured for */
#define APB_CLK_HZ           ((uint32_t)(UART0_INST_SYS_CLK * 1000000.0))   /* 20 MHz */
#define I2C_SCL_HZ           400000u

#define HEARTBEAT_HALF_MS    500u    /* LED1 toggle period: 1 s full period */
#define RETRY_PERIOD_MS      1000u   /* sensor init retry */
#define MATRIX_BRIGHTNESS    8u      /* APA102 global brightness 0..31 */

/* Tilt threshold: gravity only drives the ball when the board is tilted more than 5 degrees.
 *     sin^2(tilt) = (x^2 + y^2) / (x^2 + y^2 + z^2),  1000 * sin^2(5 deg) = 7.6 -> 8 */
#define TILT_MIN_SIN2_X1000  8u

/* ---- physics, fixed point ----
 * Speeds in Q8 pixel per second (1/256 px/s), accelerations in Q8 pixel per second^2.
 * Positions in Q8 pixel x POS_SCALE, so pos += v * dt_ms is exact at any speed.
 * Time step 5 ms: one step per accelerometer sample (200 Hz). */
#define PHYS_DT_MS           5
#define POS_SCALE            1000
#define Q8                   256
/* gravity: acceleration = ACCEL_PER_MG * horizontal g component in mg.
 * 20 -> 1 g sideways (90 deg) gives 20*1000/256 = 78 px/s^2, 30 deg (500 mg) gives 39 px/s^2 */
#define ACCEL_PER_MG         20
/* rolling resistance, constant deceleration against the motion: 9 px/s^2 */
#define FRICTION_Q8          (9 * Q8)
/* No speed limit: speed comes only from the tilt force and is lost only to friction and bounces.
 * VGUARD_Q8 only protects the 32-bit fixed-point maths (vx^2 + vy^2 must stay < 2^32). It is far
 * above anything reachable on 12 pixels: 1 g sideways over the full width gives ~41 px/s. */
#define VGUARD_Q8            (150 * Q8)
/* bounce: the speed component into the edge is reversed and multiplied by RESTITUTION_NUM/DEN.
 * A bounce loses 20% of the kinetic energy: speed x sqrt(0.8) = 0.894 = 229/256 */
#define RESTITUTION_NUM      229
#define RESTITUTION_DEN      256
/* a bounce slower than this is absorbed: the ball rests against the edge */
#define BOUNCE_MIN_Q8        (1 * Q8)

/* ---- trail ---- */
/* one frame per physics step = per accelerometer sample: 200 frames per second */
#define RENDER_PERIOD_MS     PHYS_DT_MS
/* every frame each trail pixel loses 1/16 of its level: down to 10% in ~36 frames = ~180 ms
 * at 200 fps (half the previous trail length) */
#define TRAIL_DECAY_SHIFT    4
#define HUE_STEP             160u    /* colour change per bounce (1536 = full wheel) */

/* Sensor axes -> matrix axes. Matrix x = column (left to right), y = row (top to bottom).
 * Measured on the board: rows follow +sensor Y, columns follow +sensor X. */
#define BALL_SWAP_XY         0       /* 1: sensor X drives matrix rows, sensor Y drives columns */
#define BALL_SIGN_X          (1)
#define BALL_SIGN_Y          (1)

/* low-pass filter of the samples: new = old + (sample - old) / 2^FILTER_SHIFT.
 * 3 at 200 Hz gives about the same ~40 ms time constant as 2 at 100 Hz. */
#define FILTER_SHIFT         3

/* board LEDs on gpio0_inst (active high) */
#define LED_HEARTBEAT        0u      /* LED1 */
#define LED_COUNT            4u
/* accelerometer side-band on gpio1_inst (reset values already SA0 = 0, WAKEUP = 1) */
#define ACC_GPIO_SA0         0u
#define ACC_GPIO_WAKEUP      1u

#define XMAX_POS             ((int32_t)(MKR_RGB_WIDTH - 1u) * Q8 * POS_SCALE)
#define YMAX_POS             ((int32_t)(MKR_RGB_HEIGHT - 1u) * Q8 * POS_SCALE)

static struct gpio_instance led_gpio_inst;
static struct gpio_instance acc_gpio_inst;
static struct timer_instance mtimer_inst;
static struct mkr_rgb_instance matrix;
static struct i2c_master_instance i2c_inst;
static struct fxls8971_instance accel;

/* trail: colour and level (0..255) of every pixel */
static mkr_rgb_rgb_t trail_col[MKR_RGB_HEIGHT][MKR_RGB_WIDTH];
static uint8_t      trail_lvl[MKR_RGB_HEIGHT][MKR_RGB_WIDTH];

/* ------------------------------------------------------------------ helpers */
static uint32_t millis(void)
{
	unsigned long long t = 0;
	timer_get_mtime(&mtimer_inst, &t);
	return (uint32_t)(t / (CPU_CLK_HZ / 1000u));
}

static int32_t iabs(int32_t v) { return (v < 0) ? -v : v; }

/* integer square root of a 32-bit value */
static uint32_t isqrt(uint32_t v)
{
	uint32_t r = 0, bit = 1u << 30;
	while (bit > v) bit >>= 2;
	while (bit) {
		if (v >= r + bit) { v -= r + bit; r = (r >> 1) + bit; }
		else             { r >>= 1; }
		bit >>= 2;
	}
	return r;
}

/* ------------------------------------------------------------------ non-blocking UART report
 * printf waits for the UART (19200 baud: ~0.5 ms per character). The bounce report is
 * written into this queue instead and sent one character at a time whenever the UART
 * transmitter is free, so the main loop never waits. A line that does not fit is dropped. */
#define TXQ_SIZE             256u    /* power of two */
static char     txq[TXQ_SIZE];
static uint32_t txq_head, txq_tail;  /* free-running indices */

static void txq_line(const char *s, uint32_t len)
{
	uint32_t i;
	if (TXQ_SIZE - (txq_head - txq_tail) < len) {
		return;                       /* queue full: drop this line */
	}
	for (i = 0; i < len; i++) {
		txq[(txq_head + i) & (TXQ_SIZE - 1u)] = s[i];
	}
	txq_head += len;
}

/* sends queued characters while the UART can take them, never waits */
static void txq_pump(void)
{
	volatile struct uart_dev *dev = (volatile struct uart_dev *)UART0_INST_BASE_ADDR;
	while (txq_tail != txq_head && (dev->lsr & UART_LSR_TX_RDY_MASK)) {
		dev->rxtx = (unsigned char)txq[txq_tail & (TXQ_SIZE - 1u)];
		txq_tail++;
	}
}

/* formats a milli-g value as g with 3 decimals, e.g. "-0.012" */
static int fmt_g(char *p, int32_t mg)
{
	uint32_t a = (uint32_t)iabs(mg);
	return sprintf(p, "%s%lu.%03lu", (mg < 0) ? "-" : "", (unsigned long)(a / 1000u), (unsigned long)(a % 1000u));
}

/* ------------------------------------------------------------------ init */
static int bsp_init(void)
{
	int ret;
	uint32_t i;

	ret = terminal_init(IRQ_BAREMETAL_DEFAULT);

#if CPU_INST_0_PIC_ENABLE
	pic_init(CPU_INST_0_PICTIMER_START_ADDR);
#endif
	timer_init(&mtimer_inst, CPU_INST_0_PICTIMER_START_ADDR, CPU_CLK_HZ);

	/* board LEDs: all off */
	led_gpio_inst.instance_name = GPIO0_INST_NAME;
	gpio_init(&led_gpio_inst, GPIO0_INST_BASE_ADDR, GPIO0_INST_LINES_NUM, GPIO0_INST_GPIO_DIRS);
	for (i = 0; i < LED_COUNT; i++) {
		gpio_output_write(&led_gpio_inst, i, 0u);
	}

	/* accelerometer side-band: SA0 = 0 (address 0x18), WAKEUP = 1 (also the hardware reset values) */
	acc_gpio_inst.instance_name = GPIO1_INST_NAME;
	gpio_init(&acc_gpio_inst, GPIO1_INST_BASE_ADDR, GPIO1_INST_LINES_NUM, GPIO1_INST_GPIO_DIRS);
	gpio_output_write(&acc_gpio_inst, ACC_GPIO_SA0, 0u);
	gpio_output_write(&acc_gpio_inst, ACC_GPIO_WAKEUP, 1u);

	/* FXLS8971_I2C block */
	i2c_inst.instance_name = FXLS0_INST_NAME;
	if (I2C_MASTER_OK != i2c_master_init(&i2c_inst, FXLS0_INST_BASE_ADDR)) {
		printf("ERROR: FXLS8971_I2C block not found at 0x%08lx\n", (unsigned long)FXLS0_INST_BASE_ADDR);
		ret = -1;
	}

	/* RGB matrix */
	matrix.instance_name = MKR_RGB0_INST_NAME;
	if (MKR_RGB_OK != mkr_rgb_init(&matrix, MKR_RGB0_INST_BASE_ADDR)) {
		printf("ERROR: MKR_RGB_SPI block not found at 0x%08lx\n", (unsigned long)MKR_RGB0_INST_BASE_ADDR);
		ret = -1;
	}
	return ret;
}

/* probes and configures the sensor: +/-2 g (finest range, ~1 mg/LSB), 200 Hz. Returns 1 when ready. */
static int accel_start(void)
{
	int ret;

	if (I2C_MASTER_OK != i2c_master_probe(&i2c_inst, FXLS8971_ADDR_SA0_LOW)) {
		printf("FXLS8971: no ACK at address 0x%02x, retrying...\n", FXLS8971_ADDR_SA0_LOW);
		return 0;
	}
	ret = fxls8971_init(&accel, &i2c_inst, FXLS8971_ADDR_SA0_LOW, FXLS8971_RANGE_2G, FXLS8971_ODR_200HZ);
	if (FXLS8971_OK != ret) {
		printf("FXLS8971: init failed (code %d), retrying...\n", ret);
		return 0;
	}
	printf("FXLS8971: WHO_AM_I 0x%02x, PROD_REV %u.%u, range +/-2 g, ODR 200 Hz\n",
	       FXLS8971_WHO_AM_I_VALUE, (unsigned)(accel.prod_rev >> 4), (unsigned)(accel.prod_rev & 0x0Fu));
	return 1;
}

/* ------------------------------------------------------------------ physics */
/* vx^2 + vy^2 in unsigned 32-bit (each |v| <= VGUARD_Q8 + one step, so the sum stays < 2^32) */
static uint32_t vsq(int32_t vx, int32_t vy)
{
	uint32_t ax_ = (uint32_t)iabs(vx), ay_ = (uint32_t)iabs(vy);
	return ax_ * ax_ + ay_ * ay_;
}

struct ball {
	int32_t x, y;      /* position, Q8 pixel x POS_SCALE */
	int32_t vx, vy;    /* speed, Q8 pixel/s */
};

/* one axis against its edges: reflect with 20% energy loss, rest against the edge when too slow.
 * Returns 1 when the ball bounced back (not when it was absorbed). */
static int bounce_axis(int32_t *p, int32_t *v, int32_t pmax)
{
	int bounced = 0;

	if (*p < 0 || *p > pmax) {
		*p = (*p < 0) ? -*p : 2 * pmax - *p;
		*v = -*v * RESTITUTION_NUM / RESTITUTION_DEN;
		if (iabs(*v) < BOUNCE_MIN_Q8) {
			*v = 0;                         /* too weak: rests against the edge */
		} else {
			bounced = 1;
		}
	}
	if (*p < 0) *p = 0;
	if (*p > pmax) *p = pmax;
	return bounced;
}

/* rounded a * dt_ms / 1000 for the fixed-point integration */
static int32_t per_step(int32_t a)
{
	int32_t n = a * PHYS_DT_MS;
	return (n >= 0) ? (n + 500) / 1000 : -((-n + 500) / 1000);
}

/* one 5 ms step. ax/ay: driving acceleration in Q8 px/s^2 (0 when the tilt is below 5 deg).
 * Returns 1 when the ball bounced off an edge in this step. */
static int ball_step(struct ball *b, int32_t ax, int32_t ay)
{
	int32_t speed, dv, fric;
	int bounced;

	/* gravity */
	b->vx += per_step(ax);
	b->vy += per_step(ay);

	/* rolling resistance against the direction of motion */
	speed = (int32_t)isqrt(vsq(b->vx, b->vy));   /* unsigned: < 2^32 below the guard */
	fric  = per_step(FRICTION_Q8);
	if (speed <= fric) {
		if (ax == 0 && ay == 0) { b->vx = 0; b->vy = 0; }   /* comes to rest */
	} else {
		dv = speed - fric;
		b->vx = b->vx * dv / speed;
		b->vy = b->vy * dv / speed;
	}

	/* overflow guard only (see VGUARD_Q8), not a speed limit */
	speed = (int32_t)isqrt(vsq(b->vx, b->vy));
	if (speed > VGUARD_Q8) {
		b->vx = b->vx * VGUARD_Q8 / speed;
		b->vy = b->vy * VGUARD_Q8 / speed;
	}

	/* move (exact: position unit is Q8 / POS_SCALE pixel) and bounce */
	b->x += b->vx * PHYS_DT_MS;
	b->y += b->vy * PHYS_DT_MS;
	bounced  = bounce_axis(&b->x, &b->vx, XMAX_POS);
	bounced |= bounce_axis(&b->y, &b->vy, YMAX_POS);
	return bounced;
}

/* ------------------------------------------------------------------ display */
/* fades the trail one frame and draws everything */
static void render(void)
{
	uint32_t x, y;
	uint8_t l;

	for (y = 0; y < MKR_RGB_HEIGHT; y++) {
		for (x = 0; x < MKR_RGB_WIDTH; x++) {
			l = trail_lvl[y][x];
			/* colour x level / 255, done as (c * l + 255) >> 8: exact at 0 and 255, no divide
			 * (the RISC-V SM has no hardware multiply/divide, a shift is much cheaper) */
			mkr_rgb_set_pixel(&matrix, (uint8_t)x, (uint8_t)y,
			                 (uint8_t)((trail_col[y][x].r * l + 255u) >> 8),
			                 (uint8_t)((trail_col[y][x].g * l + 255u) >> 8),
			                 (uint8_t)((trail_col[y][x].b * l + 255u) >> 8));
			trail_lvl[y][x] = (uint8_t)(l - ((l + (1u << TRAIL_DECAY_SHIFT) - 1u) >> TRAIL_DECAY_SHIFT));
		}
	}
	(void)mkr_rgb_show(&matrix);
}

/* ------------------------------------------------------------------ main */
int main(void)
{
	struct fxls8971_data d = {0, 0, 0};
	struct ball b;
	uint32_t now, last_beat, last_phys, last_render, last_retry;
	int32_t fx = 0, fy = 0, fz = 1000;     /* filtered acceleration, mg */
	int32_t hx = 0, hy = 0;                /* horizontal components in matrix axes, mg */
	int32_t ax = 0, ay = 0;                /* driving acceleration, Q8 px/s^2 */
	int32_t px, py;
	uint32_t sin2_x1000 = 0, bounces = 0;
	uint64_t h2, g2;
	char line[96];
	int n;
	uint16_t hue = 0;
	mkr_rgb_rgb_t ball_col = mkr_rgb_hue(0);
	uint8_t beat = 0, accel_ok = 0, first = 1;

	bsp_init();

	printf(DEVICE_INFO);
	printf("MachXO4 Companion + MKR RGB Shield: rolling ball with momentum, %u x %u matrix\n",
	       (unsigned)MKR_RGB_WIDTH, (unsigned)MKR_RGB_HEIGHT);
	(void)i2c_master_set_speed(&i2c_inst, APB_CLK_HZ, I2C_SCL_HZ);

	mkr_rgb_set_brightness(&matrix, MATRIX_BRIGHTNESS);
	b.x = (int32_t)(MKR_RGB_WIDTH / 2u) * Q8 * POS_SCALE;
	b.y = (int32_t)(MKR_RGB_HEIGHT / 2u) * Q8 * POS_SCALE;
	b.vx = 0;
	b.vy = 0;

	now = millis();
	last_beat = last_phys = last_render = now;
	last_retry = now - RETRY_PERIOD_MS;

	while (1) {
		now = millis();

		/* heartbeat: LED1 toggles every 500 ms */
		if ((uint32_t)(now - last_beat) >= HEARTBEAT_HALF_MS) {
			last_beat += HEARTBEAT_HALF_MS;
			beat ^= 1u;
			gpio_output_write(&led_gpio_inst, LED_HEARTBEAT, beat);
		}

		/* sensor bring-up, retried once per second without blocking the loop */
		if (!accel_ok) {
			if ((uint32_t)(now - last_retry) >= RETRY_PERIOD_MS) {
				last_retry = now;
				accel_ok = (uint8_t)accel_start();
				last_phys = millis();
			}
			continue;
		}

		/* new sample: low-pass filter, tilt and driving acceleration */
		if (fxls8971_data_ready(&accel) > 0 && FXLS8971_OK == fxls8971_read_xyz(&accel, &d)) {
			int32_t sx = fxls8971_to_mg(&accel, d.x);
			int32_t sy = fxls8971_to_mg(&accel, d.y);
			int32_t sz = fxls8971_to_mg(&accel, d.z);
			if (first) {
				fx = sx; fy = sy; fz = sz; first = 0;
			} else {
				fx += (sx - fx) / (1 << FILTER_SHIFT);
				fy += (sy - fy) / (1 << FILTER_SHIFT);
				fz += (sz - fz) / (1 << FILTER_SHIFT);
			}
#if BALL_SWAP_XY
			hx = BALL_SIGN_X * fy;
			hy = BALL_SIGN_Y * fx;
#else
			hx = BALL_SIGN_X * fx;
			hy = BALL_SIGN_Y * fy;
#endif
			h2 = (uint64_t)((int64_t)fx * fx + (int64_t)fy * fy);
			g2 = h2 + (uint64_t)((int64_t)fz * fz);
			sin2_x1000 = (g2 > 0u) ? (uint32_t)((h2 * 1000u) / g2) : 0u;

			if (sin2_x1000 >= TILT_MIN_SIN2_X1000) {
				ax = hx * ACCEL_PER_MG;
				ay = hy * ACCEL_PER_MG;
			} else {
				ax = 0;
				ay = 0;
			}
		}

		/* physics at a fixed 5 ms step (catches up if the loop was delayed).
		 * The ball changes colour only when it bounces off an edge. */
		while ((uint32_t)(now - last_phys) >= PHYS_DT_MS) {
			last_phys += PHYS_DT_MS;
			if (ball_step(&b, ax, ay)) {
				bounces++;
				hue = (uint16_t)((hue + HUE_STEP) % 1536u);
				ball_col = mkr_rgb_hue(hue);
				/* bounce report, queued (sent without waiting by txq_pump) */
				n = sprintf(line, "bounce %lu at %ld,%ld  g ", (unsigned long)bounces,
				            (long)((b.x / POS_SCALE + Q8 / 2) / Q8), (long)((b.y / POS_SCALE + Q8 / 2) / Q8));
				n += fmt_g(line + n, fx);  line[n++] = ' ';
				n += fmt_g(line + n, fy);  line[n++] = ' ';
				n += fmt_g(line + n, fz);
				n += sprintf(line + n, "  |g| ");
				n += fmt_g(line + n, (int32_t)isqrt((uint32_t)(fx * fx + fy * fy + fz * fz)));
				line[n++] = '\r';
				line[n++] = '\n';
				txq_line(line, (uint32_t)n);
			}
		}

		/* the pixel the ball is on: full level, in the ball's current colour */
		px = (b.x / POS_SCALE + Q8 / 2) / Q8;
		py = (b.y / POS_SCALE + Q8 / 2) / Q8;
		trail_col[py][px] = ball_col;
		trail_lvl[py][px] = 255u;

		/* 200 frames per second: draw ball and fading trail */
		if ((uint32_t)(now - last_render) >= RENDER_PERIOD_MS) {
			last_render += RENDER_PERIOD_MS;
			if ((uint32_t)(now - last_render) >= RENDER_PERIOD_MS) {
				last_render = now;      /* fell behind: drop frames instead of rendering back to back */
			}
			render();
		}

		/* UART: send queued bounce reports, never waits */
		txq_pump();
	}

	return 0;
}
