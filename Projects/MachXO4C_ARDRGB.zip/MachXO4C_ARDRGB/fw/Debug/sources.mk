################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ELF_SRCS :=
OBJ_SRCS :=
ASM_SRCS :=
C_SRCS :=
S_UPPER_SRCS :=
O_SRCS :=
SECONDARY_MEMORY :=
OBJS :=
SECONDARY_SIZE :=
S_UPPER_DEPS :=
C_DEPS :=

# Every subdirectory with source files must be described here
SUBDIRS := \
src/application \
src/bsp/driver/fxls8971_i2c \
src/bsp/driver/gpio \
src/bsp/driver/mkr_rgb_spi \
src/bsp/driver/riscv_sm \
src/bsp/driver/uart 

