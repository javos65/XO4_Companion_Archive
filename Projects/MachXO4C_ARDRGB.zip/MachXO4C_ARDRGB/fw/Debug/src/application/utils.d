src/application/utils.o: ../src/application/utils.c \
 ../src/application/utils.h ../src/bsp/sys_platform.h \
 ../src/bsp/riscv_errors.h ../src/application/platform_init.h
../src/application/utils.h:
../src/bsp/sys_platform.h:
../src/bsp/riscv_errors.h:
../src/application/platform_init.h:
