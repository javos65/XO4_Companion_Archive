src/application/terminal.o: ../src/application/terminal.c \
 ../src/application/terminal.h ../src/bsp/driver/riscv_sm/hal.h \
 ../src/bsp/driver/riscv_sm/pic.h ../src/bsp/driver/riscv_sm/util.h \
 ../src/bsp/driver/riscv_sm/stack.h \
 ../src/bsp/driver/riscv_sm/reg_access.h ../src/bsp/driver/riscv_sm/iob.h \
 ../src/application/platform_init.h ../src/bsp/sys_platform.h \
 ../src/bsp/riscv_errors.h ../src/bsp/driver/uart/uart.h
../src/application/terminal.h:
../src/bsp/driver/riscv_sm/hal.h:
../src/bsp/driver/riscv_sm/pic.h:
../src/bsp/driver/riscv_sm/util.h:
../src/bsp/driver/riscv_sm/stack.h:
../src/bsp/driver/riscv_sm/reg_access.h:
../src/bsp/driver/riscv_sm/iob.h:
../src/application/platform_init.h:
../src/bsp/sys_platform.h:
../src/bsp/riscv_errors.h:
../src/bsp/driver/uart/uart.h:
