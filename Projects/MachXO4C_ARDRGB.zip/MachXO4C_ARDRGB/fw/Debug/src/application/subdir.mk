################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
C_SRCS += \
../src/application/main.c \
../src/application/terminal.c \
../src/application/utils.c 

OBJS += \
./src/application/main.o \
./src/application/terminal.o \
./src/application/utils.o 

C_DEPS += \
./src/application/main.d \
./src/application/terminal.d \
./src/application/utils.d 


# Each subdirectory must supply rules for building sources it contributes
src/application/%.o: ../src/application/%.c src/application/subdir.mk
	@echo 'Building file: $<'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -I"../src" -I"../src/application" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/fxls8971_i2c" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/mkr_rgb_spi" -I"../src/bsp/driver/riscv_sm" -I"../src/bsp/driver/uart" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_DOUBLE_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo ' '

