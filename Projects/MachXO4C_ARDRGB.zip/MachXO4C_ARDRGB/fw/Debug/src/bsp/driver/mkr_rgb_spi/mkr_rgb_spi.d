src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi.o: \
 ../src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi.c \
 ../src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi.h \
 ../src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi_regs.h \
 ../src/bsp/driver/riscv_sm/reg_access.h
../src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi.h:
../src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi_regs.h:
../src/bsp/driver/riscv_sm/reg_access.h:
