src/bsp/driver/riscv_sm/iob.o: ../src/bsp/driver/riscv_sm/iob.c \
 ../src/bsp/driver/riscv_sm/iob.h
../src/bsp/driver/riscv_sm/iob.h:
