src/bsp/driver/fxls8971_i2c/fxls8971.o: \
 ../src/bsp/driver/fxls8971_i2c/fxls8971.c \
 ../src/bsp/driver/fxls8971_i2c/fxls8971.h \
 ../src/bsp/driver/fxls8971_i2c/i2c_master.h \
 ../src/bsp/driver/fxls8971_i2c/i2c_master_regs.h
../src/bsp/driver/fxls8971_i2c/fxls8971.h:
../src/bsp/driver/fxls8971_i2c/i2c_master.h:
../src/bsp/driver/fxls8971_i2c/i2c_master_regs.h:
