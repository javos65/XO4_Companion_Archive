src/bsp/driver/uart/uart.o: ../src/bsp/driver/uart/uart.c \
 ../src/bsp/driver/uart/uart.h ../src/bsp/driver/riscv_sm/hal.h \
 ../src/bsp/driver/riscv_sm/pic.h ../src/bsp/driver/riscv_sm/util.h \
 ../src/bsp/driver/riscv_sm/stack.h \
 ../src/bsp/driver/riscv_sm/reg_access.h ../src/bsp/driver/riscv_sm/iob.h
../src/bsp/driver/uart/uart.h:
../src/bsp/driver/riscv_sm/hal.h:
../src/bsp/driver/riscv_sm/pic.h:
../src/bsp/driver/riscv_sm/util.h:
../src/bsp/driver/riscv_sm/stack.h:
../src/bsp/driver/riscv_sm/reg_access.h:
../src/bsp/driver/riscv_sm/iob.h:
