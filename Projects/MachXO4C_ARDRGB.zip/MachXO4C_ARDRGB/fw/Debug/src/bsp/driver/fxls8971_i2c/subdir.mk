################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
C_SRCS += \
../src/bsp/driver/fxls8971_i2c/fxls8971.c \
../src/bsp/driver/fxls8971_i2c/i2c_master.c 

OBJS += \
./src/bsp/driver/fxls8971_i2c/fxls8971.o \
./src/bsp/driver/fxls8971_i2c/i2c_master.o 

C_DEPS += \
./src/bsp/driver/fxls8971_i2c/fxls8971.d \
./src/bsp/driver/fxls8971_i2c/i2c_master.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/fxls8971_i2c/%.o: ../src/bsp/driver/fxls8971_i2c/%.c src/bsp/driver/fxls8971_i2c/subdir.mk
	@echo 'Building file: $<'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -I"../src" -I"../src/application" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/fxls8971_i2c" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/mkr_rgb_spi" -I"../src/bsp/driver/riscv_sm" -I"../src/bsp/driver/uart" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_DOUBLE_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo ' '

