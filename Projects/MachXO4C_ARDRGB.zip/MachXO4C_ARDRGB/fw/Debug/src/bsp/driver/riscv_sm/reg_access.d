src/bsp/driver/riscv_sm/reg_access.o: \
 ../src/bsp/driver/riscv_sm/reg_access.c \
 ../src/bsp/driver/riscv_sm/reg_access.h
../src/bsp/driver/riscv_sm/reg_access.h:
