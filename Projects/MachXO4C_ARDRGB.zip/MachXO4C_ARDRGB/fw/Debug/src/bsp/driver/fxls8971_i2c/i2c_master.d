src/bsp/driver/fxls8971_i2c/i2c_master.o: \
 ../src/bsp/driver/fxls8971_i2c/i2c_master.c \
 ../src/bsp/driver/fxls8971_i2c/i2c_master.h \
 ../src/bsp/driver/fxls8971_i2c/i2c_master_regs.h \
 ../src/bsp/driver/riscv_sm/reg_access.h
../src/bsp/driver/fxls8971_i2c/i2c_master.h:
../src/bsp/driver/fxls8971_i2c/i2c_master_regs.h:
../src/bsp/driver/riscv_sm/reg_access.h:
