src/bsp/driver/riscv_sm/timer.o: ../src/bsp/driver/riscv_sm/timer.c \
 ../src/bsp/driver/riscv_sm/timer.h ../src/bsp/driver/riscv_sm/pic.h \
 ../src/bsp/driver/riscv_sm/util.h ../src/bsp/driver/riscv_sm/stack.h \
 ../src/bsp/driver/riscv_sm/reg_access.h
../src/bsp/driver/riscv_sm/timer.h:
../src/bsp/driver/riscv_sm/pic.h:
../src/bsp/driver/riscv_sm/util.h:
../src/bsp/driver/riscv_sm/stack.h:
../src/bsp/driver/riscv_sm/reg_access.h:
