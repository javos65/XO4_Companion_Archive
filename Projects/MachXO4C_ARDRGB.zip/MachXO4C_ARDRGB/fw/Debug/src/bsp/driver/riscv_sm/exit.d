src/bsp/driver/riscv_sm/exit.o: ../src/bsp/driver/riscv_sm/exit.c
