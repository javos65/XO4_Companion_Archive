################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
C_SRCS += \
../src/bsp/driver/riscv_sm/exit.c \
../src/bsp/driver/riscv_sm/interrupt.c \
../src/bsp/driver/riscv_sm/iob.c \
../src/bsp/driver/riscv_sm/pic.c \
../src/bsp/driver/riscv_sm/reg_access.c \
../src/bsp/driver/riscv_sm/timer.c \
../src/bsp/driver/riscv_sm/util.c 

S_UPPER_SRCS += \
../src/bsp/driver/riscv_sm/crt0.S 

OBJS += \
./src/bsp/driver/riscv_sm/exit.o \
./src/bsp/driver/riscv_sm/interrupt.o \
./src/bsp/driver/riscv_sm/iob.o \
./src/bsp/driver/riscv_sm/pic.o \
./src/bsp/driver/riscv_sm/reg_access.o \
./src/bsp/driver/riscv_sm/timer.o \
./src/bsp/driver/riscv_sm/util.o \
./src/bsp/driver/riscv_sm/crt0.o 

C_DEPS += \
./src/bsp/driver/riscv_sm/exit.d \
./src/bsp/driver/riscv_sm/interrupt.d \
./src/bsp/driver/riscv_sm/iob.d \
./src/bsp/driver/riscv_sm/pic.d \
./src/bsp/driver/riscv_sm/reg_access.d \
./src/bsp/driver/riscv_sm/timer.d \
./src/bsp/driver/riscv_sm/util.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/riscv_sm/%.o: ../src/bsp/driver/riscv_sm/%.c src/bsp/driver/riscv_sm/subdir.mk
	@echo 'Building file: $<'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -I"../src" -I"../src/application" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/fxls8971_i2c" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/mkr_rgb_spi" -I"../src/bsp/driver/riscv_sm" -I"../src/bsp/driver/uart" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_DOUBLE_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo ' '

src/bsp/driver/riscv_sm/%.o: ../src/bsp/driver/riscv_sm/%.S src/bsp/driver/riscv_sm/subdir.mk
	@echo 'Assembling file: $<'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -I"../src" -I"../src/application" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/fxls8971_i2c" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/mkr_rgb_spi" -I"../src/bsp/driver/riscv_sm" -I"../src/bsp/driver/uart" -c -o "$@" "$<"
	@echo ' '

