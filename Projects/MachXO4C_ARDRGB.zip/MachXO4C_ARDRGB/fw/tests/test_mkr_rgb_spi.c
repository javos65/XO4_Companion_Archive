/* Host tests of the MKR_RGB_SPI driver (src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi.c).
 *
 * The real driver source is #included; reg_32b_read/reg_32b_write are replaced by a
 * fake register file (an array standing in for the 1 KB APB window), so the test can
 * see exactly which words the driver writes where.
 *
 * What it checks: APA102 word packing (header, brightness, B/G/R byte order), the
 * chain index of every (x, y), the orientation flips, brightness clipping, the ID/LED
 * count checks of init, that show() starts the frame only after READY and that the
 * READY wait is bounded, and the colour wheel of mkr_rgb_hue().
 * What it cannot see: anything on the real APB bus or the LED pins.
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* ---------------------------------------------------------------- fake register file */
#define FAKE_BASE  0x40001000u
static uint32_t fake_regs[256];          /* word index = offset / 4 */
static uint32_t ctrl_writes;             /* writes to CTRL */
static uint32_t pix_writes_before_start; /* PIX writes seen before the last CTRL write */
static uint32_t pix_writes;
static int      never_ready;

#define REG_ACCESS_H  /* keep the real header out */
#include "../src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi_regs.h"
uint8_t reg_32b_write(uint32_t reg_addr, uint32_t value)
{
    uint32_t off = reg_addr - FAKE_BASE;
    if (off == MKR_RGB_SPI_REG_CTRL) {
        ctrl_writes++;
        pix_writes_before_start = pix_writes;
        return 0;
    }
    if (off >= MKR_RGB_SPI_REG_PIX(0) && off < MKR_RGB_SPI_REG_PIX(84)) {
        pix_writes++;
    }
    fake_regs[off / 4u] = value;
    return 0;
}
uint8_t reg_32b_read(uint32_t reg_addr, uint32_t *v)
{
    uint32_t off = reg_addr - FAKE_BASE;
    if (off == MKR_RGB_SPI_REG_CTRL) {
        *v = never_ready ? 0u : 2u;     /* READY = bit1 */
    } else {
        *v = fake_regs[off / 4u];
    }
    return 0;
}

#include "../src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi.c"

/* ---------------------------------------------------------------- mini framework */
static int checks, failed;
#define CHECK(cond, ...) do { checks++; if (!(cond)) { failed++; printf("FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

static void reset_fake(void)
{
    memset(fake_regs, 0, sizeof fake_regs);
    fake_regs[MKR_RGB_SPI_REG_ID / 4u] = MKR_RGB_SPI_ID_VALUE;
    fake_regs[MKR_RGB_SPI_REG_NLEDS / 4u] = 84u;
    ctrl_writes = 0; pix_writes = 0; pix_writes_before_start = 0; never_ready = 0;
}

static uint32_t pix(uint32_t i) { return fake_regs[MKR_RGB_SPI_REG_PIX(i) / 4u]; }

int main(void)
{
    struct mkr_rgb_instance m;
    uint32_t i, x, y;

    /* word packing: 111 | br | B | G | R */
    CHECK(MKR_RGB_APA102_WORD(31, 0x11, 0x22, 0x33) == 0xFF332211u, "packing %08x",
          (unsigned)MKR_RGB_APA102_WORD(31, 0x11, 0x22, 0x33));
    CHECK(MKR_RGB_APA102_WORD(0, 0, 0, 0) == 0xE0000000u, "header only");
    CHECK(MKR_RGB_APA102_WORD(4, 255, 0, 0) == 0xE40000FFu, "red at br 4");

    /* init: ID and LED count */
    reset_fake();
    CHECK(mkr_rgb_init(&m, FAKE_BASE) == MKR_RGB_OK, "init ok");
    CHECK(m.brightness == 8u && m.orientation == 0u, "init defaults");
    reset_fake(); fake_regs[MKR_RGB_SPI_REG_ID / 4u] = 0;
    CHECK(mkr_rgb_init(&m, FAKE_BASE) == MKR_RGB_ERR_ID, "bad ID detected");
    reset_fake(); fake_regs[MKR_RGB_SPI_REG_NLEDS / 4u] = 50;
    CHECK(mkr_rgb_init(&m, FAKE_BASE) == MKR_RGB_ERR_SIZE, "short chain detected");
    CHECK(mkr_rgb_init(NULL, FAKE_BASE) == MKR_RGB_ERR_PARAM, "null instance");

    /* brightness clip */
    reset_fake(); (void)mkr_rgb_init(&m, FAKE_BASE);
    mkr_rgb_set_brightness(&m, 200);
    CHECK(m.brightness == 31u, "brightness clipped to 31");

    /* chain index = y * 12 + x for every pixel, and START comes after all 84 PIX writes */
    reset_fake(); (void)mkr_rgb_init(&m, FAKE_BASE);
    mkr_rgb_set_brightness(&m, 5);
    for (y = 0; y < MKR_RGB_HEIGHT; y++)
        for (x = 0; x < MKR_RGB_WIDTH; x++)
            mkr_rgb_set_pixel(&m, (uint8_t)x, (uint8_t)y, (uint8_t)x, (uint8_t)y, 0x5A);
    CHECK(mkr_rgb_show(&m) == MKR_RGB_OK, "show ok");
    CHECK(ctrl_writes == 1u, "one START write, got %u", (unsigned)ctrl_writes);
    CHECK(pix_writes_before_start == 84u, "84 PIX writes before START, got %u", (unsigned)pix_writes_before_start);
    for (i = 0; i < 84u; i++) {
        uint32_t ex = MKR_RGB_APA102_WORD(5, i % 12u, i / 12u, 0x5A);
        CHECK(pix(i) == ex, "PIX[%u] = %08x, expected %08x", (unsigned)i, (unsigned)pix(i), (unsigned)ex);
    }

    /* the running-LED start: (0,0) is chain 0 (upper left), (11,6) is chain 83 (lower right) */
    reset_fake(); (void)mkr_rgb_init(&m, FAKE_BASE);
    mkr_rgb_set_pixel(&m, 0, 0, 255, 0, 0);
    mkr_rgb_set_pixel(&m, 11, 6, 0, 0, 255);
    (void)mkr_rgb_show(&m);
    CHECK((pix(0) & 0xFFu) == 255u && (pix(83) & 0xFF0000u) == 0xFF0000u, "corners");
    for (i = 1; i < 83u; i++) CHECK((pix(i) & 0xFFFFFFu) == 0u, "PIX[%u] dark", (unsigned)i);

    /* orientation flips */
    mkr_rgb_set_orientation(&m, MKR_RGB_FLIP_X | MKR_RGB_FLIP_Y);
    (void)mkr_rgb_show(&m);
    CHECK((pix(83) & 0xFFu) == 255u && (pix(0) & 0xFF0000u) == 0xFF0000u, "flip X+Y swaps corners");
    mkr_rgb_set_orientation(&m, MKR_RGB_FLIP_X);
    (void)mkr_rgb_show(&m);
    CHECK((pix(11) & 0xFFu) == 255u, "flip X: upper left -> chain 11");

    /* out of range ignored */
    reset_fake(); (void)mkr_rgb_init(&m, FAKE_BASE);
    mkr_rgb_set_pixel(&m, 12, 0, 1, 1, 1);
    mkr_rgb_set_pixel(&m, 0, 7, 1, 1, 1);
    (void)mkr_rgb_show(&m);
    for (i = 0; i < 84u; i++) CHECK((pix(i) & 0xFFFFFFu) == 0u, "no stray pixel %u", (unsigned)i);

    /* bounded wait: never READY -> timeout, no START */
    reset_fake(); (void)mkr_rgb_init(&m, FAKE_BASE);
    never_ready = 1;
    CHECK(mkr_rgb_show(&m) == MKR_RGB_ERR_TIMEOUT, "timeout reported");
    CHECK(ctrl_writes == 0u, "no START without READY");

    /* colour wheel */
    {
        mkr_rgb_rgb_t c;
        c = mkr_rgb_hue(0);    CHECK(c.r == 255 && c.g == 0 && c.b == 0, "hue 0 red");
        c = mkr_rgb_hue(256);  CHECK(c.r == 255 && c.g == 255 && c.b == 0, "hue 256 yellow");
        c = mkr_rgb_hue(512);  CHECK(c.r == 0 && c.g == 255 && c.b == 0, "hue 512 green");
        c = mkr_rgb_hue(1024); CHECK(c.r == 0 && c.g == 0 && c.b == 255, "hue 1024 blue");
        c = mkr_rgb_hue(1536); CHECK(c.r == 255 && c.g == 0 && c.b == 0, "hue wraps");
        for (i = 0; i < 1536u; i++) {
            c = mkr_rgb_hue((uint16_t)i);
            CHECK((c.r == 255) || (c.g == 255) || (c.b == 255), "full value at hue %u", (unsigned)i);
            CHECK((c.r == 0) || (c.g == 0) || (c.b == 0), "full saturation at hue %u", (unsigned)i);
        }
    }

    printf("checks %d failed %d\n", checks, failed);
    return failed ? 1 : 0;
}
