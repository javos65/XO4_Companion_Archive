#include "mktrgb_spi.h"
#include "reg_access.h"
#include <stddef.h>

#define MKTRGB_DEFAULT_BRIGHTNESS 8u

uint8_t mktrgb_init(struct mktrgb_instance *this_rgb, uint32_t base_addr)
{
    uint32_t v = 0;

    if (NULL == this_rgb) {
        return MKTRGB_ERR_PARAM;
    }
    this_rgb->base_address = base_addr;
    this_rgb->brightness   = MKTRGB_DEFAULT_BRIGHTNESS;
    this_rgb->orientation  = 0u;
    mktrgb_clear(this_rgb);

    reg_32b_read(base_addr + MKTRGB_SPI_REG_ID, &v);
    if (MKTRGB_SPI_ID_VALUE != v) {
        return MKTRGB_ERR_ID;
    }
    reg_32b_read(base_addr + MKTRGB_SPI_REG_NLEDS, &v);
    if (v < MKTRGB_NUM_LEDS) {
        return MKTRGB_ERR_SIZE;
    }
    return MKTRGB_OK;
}

uint8_t mktrgb_is_ready(struct mktrgb_instance *this_rgb)
{
    uint32_t v = 0;

    if (NULL == this_rgb) {
        return 0u;
    }
    reg_32b_read(this_rgb->base_address + MKTRGB_SPI_REG_CTRL, &v);
    return (v & MKTRGB_SPI_CTRL_READY) ? 1u : 0u;
}

uint8_t mktrgb_wait_ready(struct mktrgb_instance *this_rgb)
{
    uint32_t n;

    if (NULL == this_rgb) {
        return MKTRGB_ERR_PARAM;
    }
    for (n = 0; n < MKTRGB_TIMEOUT_POLLS; n++) {
        if (mktrgb_is_ready(this_rgb)) {
            return MKTRGB_OK;
        }
    }
    return MKTRGB_ERR_TIMEOUT;
}

void mktrgb_set_brightness(struct mktrgb_instance *this_rgb, uint8_t brightness)
{
    if (NULL != this_rgb) {
        this_rgb->brightness = (brightness > MKTRGB_BRIGHTNESS_MAX) ? MKTRGB_BRIGHTNESS_MAX : brightness;
    }
}

void mktrgb_set_orientation(struct mktrgb_instance *this_rgb, uint8_t flags)
{
    if (NULL != this_rgb) {
        this_rgb->orientation = flags & (MKTRGB_FLIP_X | MKTRGB_FLIP_Y);
    }
}

void mktrgb_fill(struct mktrgb_instance *this_rgb, uint8_t r, uint8_t g, uint8_t b)
{
    uint32_t x, y;

    if (NULL == this_rgb) {
        return;
    }
    for (y = 0; y < MKTRGB_HEIGHT; y++) {
        for (x = 0; x < MKTRGB_WIDTH; x++) {
            this_rgb->fb[y][x].r = r;
            this_rgb->fb[y][x].g = g;
            this_rgb->fb[y][x].b = b;
        }
    }
}

void mktrgb_clear(struct mktrgb_instance *this_rgb)
{
    mktrgb_fill(this_rgb, 0u, 0u, 0u);
}

void mktrgb_set_pixel(struct mktrgb_instance *this_rgb, uint8_t x, uint8_t y,
                      uint8_t r, uint8_t g, uint8_t b)
{
    if ((NULL == this_rgb) || (x >= MKTRGB_WIDTH) || (y >= MKTRGB_HEIGHT)) {
        return;
    }
    this_rgb->fb[y][x].r = r;
    this_rgb->fb[y][x].g = g;
    this_rgb->fb[y][x].b = b;
}

void mktrgb_write_image(struct mktrgb_instance *this_rgb,
                        const mktrgb_rgb_t img[MKTRGB_HEIGHT][MKTRGB_WIDTH])
{
    uint32_t x, y;

    if ((NULL == this_rgb) || (NULL == img)) {
        return;
    }
    for (y = 0; y < MKTRGB_HEIGHT; y++) {
        for (x = 0; x < MKTRGB_WIDTH; x++) {
            this_rgb->fb[y][x] = img[y][x];
        }
    }
}

uint8_t mktrgb_show(struct mktrgb_instance *this_rgb)
{
    uint32_t base, x, y, sx, sy, idx;
    const mktrgb_rgb_t *p;

    if (NULL == this_rgb) {
        return MKTRGB_ERR_PARAM;
    }
    if (MKTRGB_OK != mktrgb_wait_ready(this_rgb)) {
        return MKTRGB_ERR_TIMEOUT;
    }
    base = this_rgb->base_address;
    for (y = 0; y < MKTRGB_HEIGHT; y++) {
        for (x = 0; x < MKTRGB_WIDTH; x++) {
            /* physical position of the LED with chain index y * WIDTH + x */
            sx = (this_rgb->orientation & MKTRGB_FLIP_X) ? (MKTRGB_WIDTH - 1u - x) : x;
            sy = (this_rgb->orientation & MKTRGB_FLIP_Y) ? (MKTRGB_HEIGHT - 1u - y) : y;
            p   = &this_rgb->fb[sy][sx];
            idx = y * MKTRGB_WIDTH + x;
            reg_32b_write(base + MKTRGB_SPI_REG_PIX(idx),
                          MKTRGB_APA102_WORD(this_rgb->brightness, p->r, p->g, p->b));
        }
    }
    reg_32b_write(base + MKTRGB_SPI_REG_CTRL, MKTRGB_SPI_CTRL_START);
    return MKTRGB_OK;
}

mktrgb_rgb_t mktrgb_hue(uint16_t hue)
{
    mktrgb_rgb_t c = {0u, 0u, 0u};
    uint8_t f;

    hue = (uint16_t)(hue % 1536u);
    f   = (uint8_t)(hue & 0xFFu);
    switch (hue >> 8) {
    case 0:  c.r = 255u;              c.g = f;                  c.b = 0u;                 break; /* red -> yellow */
    case 1:  c.r = (uint8_t)(255u - f); c.g = 255u;             c.b = 0u;                 break; /* yellow -> green */
    case 2:  c.r = 0u;                c.g = 255u;               c.b = f;                  break; /* green -> cyan */
    case 3:  c.r = 0u;                c.g = (uint8_t)(255u - f); c.b = 255u;              break; /* cyan -> blue */
    case 4:  c.r = f;                 c.g = 0u;                 c.b = 255u;               break; /* blue -> magenta */
    default: c.r = 255u;              c.g = 0u;                 c.b = (uint8_t)(255u - f); break; /* magenta -> red */
    }
    return c;
}
