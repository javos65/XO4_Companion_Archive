/* Driver of the MKTRGB_SPI block (custom:module:mktrgb_spi:1.0.0) for the
 * Arduino MKR RGB Shield: 84 APA102-2020 LEDs, 7 rows x 12 columns.
 *
 * The driver keeps a frame buffer in RAM (one RGB value per pixel plus one global
 * brightness). Drawing functions only change that buffer; mktrgb_show() copies it
 * to the block's pixel registers and starts the transfer (278 us at 10 MHz CKI).
 *
 * Coordinates: x = column 0..11 (left to right), y = row 0..6 (top to bottom).
 * Chain order on the shield (schematic ASX00010): row by row, each row left to right,
 * so LED index = y * 12 + x. If the board is mounted rotated, set the orientation
 * with mktrgb_set_orientation() instead of changing the application.
 */
#ifndef MKTRGB_SPI_H
#define MKTRGB_SPI_H

#include <stdint.h>
#include "mktrgb_spi_regs.h"

#define MKTRGB_WIDTH             12u
#define MKTRGB_HEIGHT            7u
#define MKTRGB_NUM_LEDS          (MKTRGB_WIDTH * MKTRGB_HEIGHT)   /* 84 */

#define MKTRGB_BRIGHTNESS_MAX    31u

/* orientation flags for mktrgb_set_orientation() */
#define MKTRGB_FLIP_X            (1u << 0)   /* mirror left/right */
#define MKTRGB_FLIP_Y            (1u << 1)   /* mirror top/bottom */

/* return codes */
#define MKTRGB_OK                0
#define MKTRGB_ERR_PARAM         1   /* null pointer or bad argument */
#define MKTRGB_ERR_ID            2   /* ID register does not match: block not found */
#define MKTRGB_ERR_SIZE          3   /* block has fewer LEDs than the matrix */
#define MKTRGB_ERR_TIMEOUT       4   /* READY did not come back */

/* polls of CTRL before a wait for READY is declared timed out */
#define MKTRGB_TIMEOUT_POLLS     100000u

typedef struct {
    uint8_t r;
    uint8_t g;
    uint8_t b;
} mktrgb_rgb_t;

struct mktrgb_instance {
    const char  *instance_name;
    uint32_t     base_address;
    uint8_t      brightness;                         /* 0..31, applied to all pixels */
    uint8_t      orientation;                        /* MKTRGB_FLIP_* */
    mktrgb_rgb_t fb[MKTRGB_HEIGHT][MKTRGB_WIDTH];    /* frame buffer [y][x] */
};

/* Binds the instance to the base address, checks ID and LED count, clears the frame
 * buffer and sets brightness 8. The LEDs are not updated until mktrgb_show().
 * Returns MKTRGB_OK, MKTRGB_ERR_PARAM, MKTRGB_ERR_ID or MKTRGB_ERR_SIZE. */
uint8_t mktrgb_init(struct mktrgb_instance *this_rgb, uint32_t base_addr);

/* 1 when the block is idle (no frame being sent). */
uint8_t mktrgb_is_ready(struct mktrgb_instance *this_rgb);

/* Global brightness 0..31 (values above 31 are clipped). */
void mktrgb_set_brightness(struct mktrgb_instance *this_rgb, uint8_t brightness);

/* Orientation of the matrix: combination of MKTRGB_FLIP_X / MKTRGB_FLIP_Y. */
void mktrgb_set_orientation(struct mktrgb_instance *this_rgb, uint8_t flags);

/* Frame buffer drawing; out-of-range coordinates are ignored. */
void mktrgb_clear(struct mktrgb_instance *this_rgb);
void mktrgb_fill(struct mktrgb_instance *this_rgb, uint8_t r, uint8_t g, uint8_t b);
void mktrgb_set_pixel(struct mktrgb_instance *this_rgb, uint8_t x, uint8_t y,
                      uint8_t r, uint8_t g, uint8_t b);

/* Copies a whole 7 x 12 image (img[y][x]) into the frame buffer. */
void mktrgb_write_image(struct mktrgb_instance *this_rgb,
                        const mktrgb_rgb_t img[MKTRGB_HEIGHT][MKTRGB_WIDTH]);

/* Waits for READY, writes the 84 pixel registers and starts the transfer.
 * Returns without waiting for the transfer to finish.
 * Returns MKTRGB_OK, MKTRGB_ERR_PARAM or MKTRGB_ERR_TIMEOUT. */
uint8_t mktrgb_show(struct mktrgb_instance *this_rgb);

/* Waits until the current transfer is finished. Returns MKTRGB_OK or MKTRGB_ERR_TIMEOUT. */
uint8_t mktrgb_wait_ready(struct mktrgb_instance *this_rgb);

/* Helper: hue 0..1535 (6 x 256 steps around the colour wheel), full saturation and value. */
mktrgb_rgb_t mktrgb_hue(uint16_t hue);

#endif /* MKTRGB_SPI_H */
