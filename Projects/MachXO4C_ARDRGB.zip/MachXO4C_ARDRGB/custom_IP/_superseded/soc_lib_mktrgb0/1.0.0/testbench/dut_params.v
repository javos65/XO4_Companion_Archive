localparam NUM_LEDS = 84;
`define xo4f00
`define LFMXO4
`define LFMXO4_110HC
