# Prompt: MachXO4 Companion + Arduino MKR RGB Shield - rolling ball

Use this prompt to recreate the MachXO4C_ARDRGB project from scratch with Claude Code and the
Lattice Propel / Radiant MCP tools. It contains every decision that was made during the original
session, including the corrections that were found on the hardware.

---

## 1. Hardware

- **FPGA board:** Lattice MachXO4-110-HC Companion board, Rev A, device **LFMXO4-110HC-6BBG256I**
  (speed grade 6, BBG256 package). Banks 0 and 1 are 3.3 V.
- **LED shield:** Arduino **MKR RGB Shield** (ASX00010), 84 x APA102-2020 RGB LEDs, **7 rows x 12 columns**,
  daisy chained, plugged into the Companion board's Arduino MKR header (J22/J23). The board's 5 V jumper
  for the Arduino header is set. The shield has **no level shifter**: the first LED sees 3.3 V CMOS levels.
- **Accelerometer:** on-board NXP **FXLS8971CF** (U5), I2C mode.
- **USB:** FTDI FT2232H. Channel A = JTAG (cable USB2, port FTUSB-0), channel B = UART.
- **Documents** in `doc/`: APA102-2020 datasheet, MKR RGB Shield schematic (ASX00010-schematics.pdf),
  Companion board schematic (LFMXO4-110-COMPANION REVA_*.pdf), MKR_RGB.md, FXLS8971CF datasheet.

### Pin map (verified on hardware)

| Signal | FPGA pin | Bank | Notes |
|---|---|---|---|
| clk12_i | T9 | 2 | 12 MHz from the FTDI crystal (PCLKT2_1) |
| rstn_i | D10 | 0 | Push button PB1, active low, pull-up |
| uart_rxd_i | B11 | 0 | FTDI channel B TX -> FPGA RX |
| uart_txd_o | A12 | 0 | FPGA TX -> FTDI channel B RX |
| led_io[3:0] | G14, E14, G15, G13 | 1 | Board LEDs D21..D24, active high |
| led_sdi_o | **D14** | 1 | MKR **A3** = ARD_D18 -> shield LEDSDI |
| led_cki_o | **D7** | 0 | MKR **A4** = ARD_D19 -> shield LEDCKI |
| acc_scl_io | B13 | 0 | FXLS8971 SCL (4.7k pull-up on board) |
| acc_sda_io | A14 | 0 | FXLS8971 SDA (4.7k pull-up on board) |
| acc_gpio_io[0] | B7 | 0 | ACC_SA0, driven 0 -> I2C address 0x18 |
| acc_gpio_io[1] | B12 | 0 | ACC_WAKEUP (CS_B), driven 1 |

**Important:** the Companion header J23 uses **MKR numbering**: A0 = ARD_D15, A1 = ARD_D16, A2 = ARD_D17,
A3 = ARD_D18, A4 = ARD_D19. The Uno-style mapping "A3 = D17 (E15), A4 = D18 (D14)" is wrong; it was the
cause of a dark matrix in the first hardware test. Check pins against the schematic text
(`pdftotext -layout`) before trusting a pin note.

---

## 2. Custom IP: mkr_rgb_spi (package `mkr_rgb_spi_1.0.0.ipk`)

Create a Lattice custom IP, VLNV **custom:module:mkr_rgb_spi:1.0.0**, folder
`custom_IP/custom_module_mkr_rgb_spi_1.0.0`, and install it into `C:\Users\<user>\PropelIPLocal`.
Name the package with its revision: `<name>_<version>.ipk`.
Use the existing `custom_module_fxls8971_i2c_1.0.0` as the file-format reference
(metadata.xml with `version="2.0" platform="Propel"`, both platforms esi and radiant, one setting,
bus_interface.xml for APB_S0, memory_map.xml, .ippackagerproject, driver/, doc/, rtl/, testbench/).

- **Parameter:** `NUM_LEDS` (default 84, range 1..125).
- **Ports:** PCLK, PRESETN, APB slave APB_S0 (PADDR[9:0], PSEL, PENABLE, PWRITE, PWDATA, PRDATA, PREADY=1, PSLVERR=0),
  LED_SDI, LED_CKI.
- **Register map (1 KB window):**

| Offset | Name | Access | Description |
|---|---|---|---|
| 0x000 | ID | R | 0x52474231 ("RGB1") |
| 0x004 | CTRL | RW | bit0 START (W, 1 sends one frame, ignored while busy, reads 0); bit1 READY (R, 1 = idle) |
| 0x008 | NLEDS | R | NUM_LEDS |
| 0x00C + 4*i | PIX[i] | RW | APA102 LED frame of LED i: [31:29]=111, [28:24] brightness, [23:16] blue, [15:8] green, [7:0] red |

- **Pixel buffer:** one block RAM (pseudo dual port, 128 x 32). The APB read address is captured in
  the setup phase, so PREADY can stay 1. While busy, the RAM read port belongs to the serial engine:
  PIX writes are ignored and PIX reads are undefined.
- **Serial engine:** CKI = PCLK / 2 (PCLK 20 MHz -> **CKI 10 MHz**). SDI changes with the falling edge of CKI,
  the LED samples on the rising edge; CKI idles low. Frame = start frame 32 x 0, NUM_LEDS x 32 bit LED
  frames (PIX[0] first, MSB first), end frame 64 x 1. 84 LEDs = 2784 clocks = 278.4 us.
- **Testbench:** self-checking (Questa from the Radiant install, `vlog -sv`): ID, NLEDS, CTRL after reset,
  write and read back all 84 PIX, two frames with different content, decode SDI on every CKI rising edge,
  check bit count, start/end frame, every LED word, CKI period exactly 100.0 ns, a PIX write during a frame
  is ignored, CKI idles low.
- **BSP driver** (`driver/mkr_rgb_spi.h/.c/_regs.h`, `driver/mkr_rgb_spi.xml` with structName `mkr_rgb_instance`,
  initName `mkr_rgb_init`): frame buffer `fb[7][12]` in RAM plus global brightness and orientation flags.
  All names use the `mkr_rgb_` / `MKR_RGB_` prefix.
  API: `mkr_rgb_init`, `mkr_rgb_is_ready`, `mkr_rgb_wait_ready` (bounded poll), `mkr_rgb_set_brightness`
  (0..31, clipped), `mkr_rgb_set_orientation` (MKR_RGB_FLIP_X / FLIP_Y), `mkr_rgb_clear`, `mkr_rgb_fill`,
  `mkr_rgb_set_pixel`, `mkr_rgb_write_image(img[7][12])`, `mkr_rgb_show` (wait READY, write 84 PIX, START),
  `mkr_rgb_hue(0..1535)`. Types `struct mkr_rgb_instance`, `mkr_rgb_rgb_t`.
  Chain order on the shield: row by row, each row left to right, index = y*12 + x.
- **doc/introduction.html:** ports, parameter, register map, every driver function with return codes,
  and two compiling example snippets (driver use and direct register access).

---

## 3. Propel SoC

Build the SoC like the proven MachXO4C_ACCEL design (RISC-V SM, Propel SDK hello-world structure):

- **CPU:** `riscv_sm` 1.9.0 (cpu0_inst), PIC and timer enabled, debug off, IRQ_NUM 2.
- **Memory:** `system_memory` 2.6.0, AHBL, 2 ports, 8192 x 32 bit (32 KB) EBR, firmware initialised.
- **Buses:** `ahb_lite_interconnect` 1.6.0 (1 master, 2 slaves) -> `ahb_lite_to_apb_bridge` 1.2.0
  (APB_CLK_EN true) -> `apb_interconnect` 1.5.0 (1 master, 5 slaves).
- **PLL:** 12 MHz in -> CLKOP **24 MHz** (CPU/AHB), CLKOS **20 MHz** (APB, all peripherals). VCO 480 MHz.
- **Reset:** glue `rst_and` = rstn_i AND pll lock -> cpu0 rst_n_i; cpu0 system_resetn_o resets everything else.
- **Peripherals and addresses:**

| Instance | IP | Base | Configuration |
|---|---|---|---|
| uart0_inst | uart 1.6.0 | 0x40000000 | SYS_CLOCK_FREQ 20, **115200** baud, 8N1, IRQ 0 |
| mkr_rgb0_inst | mkr_rgb_spi 1.0.0 | 0x40001000 | NUM_LEDS 84 |
| gpio0_inst | gpio 1.8.1 | 0x40002000 | 4 outputs, reset 0 (board LEDs), IRQ 1 |
| fxls0_inst | fxls8971_i2c 1.0.0 | 0x40003000 | PRESCALE_RESET 49 |
| gpio1_inst | gpio 1.8.1 | 0x40004000 | 2 outputs, DIRECTION 3, reset value 2 (SA0 = 0, WAKEUP = 1) |

- cpu0 TIMER_IRQ_M0 and gpio1 INTR intentionally unconnected (firmware polls the machine timer).
- When adding peripherals to an opened design, extend the existing clock and reset nets
  (`pll0_inst_clkos_o_net`, `cpu0_inst_system_resetn_o_net`) instead of creating new nets.

### Constraints

- `constraints/xo4_companion_ardrgb.pdc`: the pin map above, all LVCMOS33; LED pins DRIVE=8 SLEWRATE=FAST.
- `constraints/soc_timing.sdc`: `create_clock -period 83.333 [get_ports clk12_i]`; false paths from/to the
  slow board I/O (reset, UART, LEDs, I2C, accelerometer GPIO) and to led_sdi_o / led_cki_o.

---

## 4. Firmware (RISC-V SM, Propel SDK hello-world based)

- Start from `C:\lscc\propel\2026.1.1\embeddedsw\helloworld\application` plus the SGE `bsp/`.
  terminal.c defines `LSCC_STDIO_UART_APB` so printf goes to the APB UART.
- **Compiler setting:** the RISC-V SM has **no multiply extension**. After `firmware_gen_build`, set
  `-march=rv32i` in all `Debug/*.mk` / makefile and "Multiply extension (RVM)" = false in `.cproject`
  (the generator emits rv32im, which stops the build in riscv_errors.h).
- Two-pass build: Propel generate -> SGE -> firmware -> `bin2mem` -> `add_firmware_to_proj` on system0_inst
  -> `check_memory_init_applied` -> Radiant build. Image must stay below 29,952 bytes (32 KB minus stack 0xA00
  and heap 0x100).

### Application behaviour (main.c)

- **Startup UART output only:** DEVICE_INFO block, the line
  `MachXO4 Companion + MKR RGB Shield: rolling ball with momentum, 12 x 7 matrix`,
  and the FXLS8971 WHO_AM_I / PROD_REV / range / ODR line.
- **Heartbeat:** board LED1 toggles every 500 ms (1 s period) in the main loop; LED2..LED4 off.
- **Accelerometer:** FXLS8971 at I2C address 0x18, 400 kHz SCL, +/-2 g, **ODR 200 Hz**; low-pass filter
  new = old + (sample - old) / 8. Sensor init retried once per second without blocking.
- **Rolling ball physics** (fixed point, no floats; speeds in 1/256 px/s, positions in 1/256 px x 1000),
  one step every **5 ms**:
  - Tilt gate: sin^2(tilt) = (x^2+y^2)/(x^2+y^2+z^2); the force only acts above **5 degrees** (sin^2 x 1000 >= 8).
  - Force: the full measured horizontal acceleration (X/Y in mg, including movement and bumps):
    a = 20 x mg (Q8 px/s^2), so 1 g sideways = 78 px/s^2.
  - Axis mapping: matrix x = +sensor X, matrix y = +sensor Y (no swap).
  - Rolling resistance: constant **9 px/s^2** against the direction of motion; the ball stops when it is slower
    than one step of friction and no force acts.
  - No speed limit (only an overflow guard at 150 px/s that cannot be reached on 12 pixels).
  - Edges: the ball bounces back and loses **20 % of its energy** (speed x 229/256); bounces slower than 1 px/s
    are absorbed and the ball rests against the edge.
- **Display:** **200 frames per second**, one frame per physics step. Brightness 8/31. The ball's pixel is set to
  full level in the current ball colour; every pixel fades by 1/16 per frame (to 10 % in about 180 ms), which
  gives the trail. Colour = hue wheel, changes by 160/1536 **only on a bounce**. Rendering uses
  (c x l + 255) >> 8 instead of a division.
- **UART during run:** only one line per edge bounce, e.g.
  `bounce 12 at 11,3  g 0.412 -0.087 0.903  |g| 0.997`, written into a 256-byte queue and sent one character
  at a time when the UART is free (never blocks the loop). No periodic status stream.

---

## 5. Build, check and program

- Propel: save / generate / save / DRC must pass; validate_topology must pass.
- Radiant: timing must be met at all corners with 100 % constraint coverage (`validate_timing`).
- Programming over FTDI channel A (USB2, FTUSB-0, TCK delay 3 = 7.5 MHz) with `pgrcmd.exe -infile <xcf>`:
  - SRAM: `constraints/program_sram.xcf`, Fast Configuration of `impl_1/soc_impl_1.bit`.
  - Flash: `constraints/program_flash.xcf`, Erase,Program,Verify of `impl_1/soc_impl_1.jed`
    (update `<JedecChecksum>` from the `C....*` line of the .jed).
- Terminal: FTDI channel B COM port, **115200 8N1**.

## 6. Expected results

- mkr_rgb_spi simulation: TEST PASSED, 2784 bits per frame, CKI 10.00 MHz.
- Timing met (setup at 100 C and -40 C, hold at -40 C); worst setup slack about 1.4 ns.
- Resources (LFMXO4-110HC): about 3,620 LUT4 (39 %), 1,680 registers (17 %), 38 of 48 EBR, 1 of 2 PLL.
- Firmware about 27.4 KB.
