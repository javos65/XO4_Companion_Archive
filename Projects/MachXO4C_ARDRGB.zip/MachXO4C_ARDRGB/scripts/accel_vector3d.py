#!/usr/bin/env python3
"""
Live 3D acceleration vector from the MachXO4 Companion board (FXLS8971CF over RISC-V SM).

The firmware prints a banner, waits 3 s and then prints 10 lines per second on the
UART (19200 8N1), x,y,z in g with a trailing comma, for example:

    0.012,-0.003,1.001,

Only lines in this format are used; the banner and any other text are ignored.

This script reads those lines from a serial port, parses x/y/z (in g) and draws:
  - the acceleration vector as a 3D arrow from the origin,
  - its shadows on the XY, XZ and YZ planes,
  - a fading trail of the last positions of the arrow tip,
  - a text panel with X, Y, Z, |a|, roll, pitch and the line rate.

Usage:
    python scripts/accel_vector3d.py --port COM13   (FTDI USB-UART, channel B)
    python scripts/accel_vector3d.py --demo         (no board: simulated tilting sensor)
    python scripts/accel_vector3d.py --list         (show the serial ports)

Needs: numpy, matplotlib, pyserial  (pip install numpy matplotlib pyserial)
"""

import argparse
import math
import queue
import re
import sys
import threading
import time
from collections import deque

DEFAULT_BAUD = 19200

# "0.012,-0.003,1.001,": three values in g, a comma after each one
_CSV_RE = re.compile(
    r"^\s*(?P<x>[+-]?\d+\.\d+)\s*,\s*(?P<y>[+-]?\d+\.\d+)\s*,\s*(?P<z>[+-]?\d+\.\d+)\s*,\s*$"
)


def parse_line(line):
    """Parses one "x,y,z," line. Returns a dict with x, y, z in g, or None for any other
    line (banner, sensor info, partial lines)."""
    c = _CSV_RE.match(line)
    if not c:
        return None
    return {"x": float(c.group("x")), "y": float(c.group("y")), "z": float(c.group("z"))}


def tilt_angles(x, y, z):
    """Roll and pitch in degrees from a static acceleration vector (gravity)."""
    roll = math.degrees(math.atan2(y, z))
    pitch = math.degrees(math.atan2(-x, math.sqrt(y * y + z * z)))
    return roll, pitch


# ---------------------------------------------------------------------------- sources
class SerialSource(threading.Thread):
    """Reads lines from the serial port in the background and queues parsed samples."""

    def __init__(self, port, baud, out_q, echo=False):
        super().__init__(daemon=True)
        import serial  # pyserial, imported here so --demo and the parser need no pyserial
        self.ser = serial.Serial(port, baud, timeout=0.5)
        self.q = out_q
        self.echo = echo
        self.stop_evt = threading.Event()

    def run(self):
        buf = b""
        while not self.stop_evt.is_set():
            try:
                chunk = self.ser.read(256)
            except Exception as exc:  # port unplugged
                print(f"serial error: {exc}", file=sys.stderr)
                break
            if not chunk:
                continue
            buf += chunk
            while b"\n" in buf:
                raw, buf = buf.split(b"\n", 1)
                line = raw.decode("ascii", errors="replace").strip()
                if self.echo and line:
                    print(line)
                s = parse_line(line)
                if s is not None:
                    s["t_rx"] = time.monotonic()   # arrival time, for the line-rate display
                    self.q.put(s)

    def stop(self):
        self.stop_evt.set()
        try:
            self.ser.close()
        except Exception:
            pass


class DemoSource(threading.Thread):
    """Simulated board: gravity vector of a slowly tilting sensor plus noise, 10 lines/s."""

    def __init__(self, out_q, echo=False):
        super().__init__(daemon=True)
        self.q = out_q
        self.echo = echo
        self.stop_evt = threading.Event()

    def run(self):
        import random
        t0 = time.time()
        n = 0
        while not self.stop_evt.is_set():
            t = time.time() - t0
            roll = math.radians(40.0 * math.sin(0.5 * t))
            pitch = math.radians(30.0 * math.sin(0.31 * t + 1.0))
            x = -math.sin(pitch) + random.gauss(0, 0.004)
            y = math.cos(pitch) * math.sin(roll) + random.gauss(0, 0.004)
            z = math.cos(pitch) * math.cos(roll) + random.gauss(0, 0.004)
            n += 10
            line = f"{x:.3f},{y:.3f},{z:.3f},"   # same format as the firmware
            if self.echo:
                print(line)
            s = parse_line(line)
            s["t_rx"] = time.monotonic()
            self.q.put(s)
            time.sleep(0.1)

    def stop(self):
        self.stop_evt.set()


# ---------------------------------------------------------------------------- viewer
class Vector3DView:
    def __init__(self, src_q, g_range=1.5, trail=60, title="FXLS8971CF acceleration"):
        import matplotlib.pyplot as plt
        self.plt = plt
        self.q = src_q
        self.g = g_range
        self.trail = deque(maxlen=trail)
        self.last = None
        self.rate_t = deque(maxlen=20)

        self.fig = plt.figure(figsize=(9, 7))
        self.fig.canvas.manager.set_window_title(title) if self.fig.canvas.manager else None
        self.ax = self.fig.add_subplot(111, projection="3d")
        self.text = self.fig.text(0.02, 0.97, "waiting for data...", va="top", family="monospace", fontsize=10)
        self.fig.suptitle(title, x=0.62, y=0.97, fontsize=12)
        self.dyn = []
        self._draw_static()

    def _draw_static(self):
        ax, g = self.ax, self.g
        ax.set_xlim(-g, g)
        ax.set_ylim(-g, g)
        ax.set_zlim(-g, g)
        ax.set_xlabel("X (g)")
        ax.set_ylabel("Y (g)")
        ax.set_zlabel("Z (g)")
        try:
            ax.set_box_aspect((1, 1, 1))
        except AttributeError:
            pass
        for v, c in (((g, 0, 0), "tab:red"), ((0, g, 0), "tab:green"), ((0, 0, g), "tab:blue")):
            ax.plot([-v[0], v[0]], [-v[1], v[1]], [-v[2], v[2]], color=c, lw=0.8, alpha=0.5)
        # 1 g reference circle in the XY plane
        import numpy as np
        a = np.linspace(0, 2 * np.pi, 120)
        ax.plot(np.cos(a), np.sin(a), np.zeros_like(a), color="0.6", lw=0.6, ls=":")

    def _clear_dynamic(self):
        for artist in self.dyn:
            try:
                artist.remove()
            except Exception:
                pass
        self.dyn = []

    def update(self, _frame):
        got = None
        while True:
            try:
                got = self.q.get_nowait()
                self.rate_t.append(got["t_rx"])   # arrival time, not redraw time
            except queue.Empty:
                break
        if got is None:
            return []
        self.last = got
        x, y, z = got["x"], got["y"], got["z"]
        self.trail.append((x, y, z))

        self._clear_dynamic()
        ax, g = self.ax, self.g
        mag = math.sqrt(x * x + y * y + z * z)

        # main vector
        self.dyn.append(ax.quiver(0, 0, 0, x, y, z, color="black", lw=2.5,
                                  arrow_length_ratio=0.12, normalize=False))
        # projections on the three planes (shadows)
        self.dyn.append(ax.quiver(0, 0, -g, x, y, 0, color="tab:purple", lw=1.2, alpha=0.5, arrow_length_ratio=0.1))
        self.dyn.append(ax.quiver(0, g, 0, x, 0, z, color="tab:orange", lw=1.2, alpha=0.5, arrow_length_ratio=0.1))
        self.dyn.append(ax.quiver(-g, 0, 0, 0, y, z, color="tab:cyan", lw=1.2, alpha=0.5, arrow_length_ratio=0.1))
        # component dashes from the tip
        self.dyn += ax.plot([x, x], [y, y], [0, z], color="0.4", lw=0.8, ls="--")
        self.dyn += ax.plot([0, x], [0, y], [0, 0], color="0.4", lw=0.8, ls="--")
        # trail of the tip
        if len(self.trail) > 1:
            tx, ty, tz = zip(*self.trail)
            self.dyn += ax.plot(tx, ty, tz, color="tab:red", lw=1.0, alpha=0.6)

        roll, pitch = tilt_angles(x, y, z)
        rate = 0.0
        if len(self.rate_t) > 1 and self.rate_t[-1] > self.rate_t[0]:
            rate = (len(self.rate_t) - 1) / (self.rate_t[-1] - self.rate_t[0])
        lines = [
            f"X     {x:+7.3f} g",
            f"Y     {y:+7.3f} g",
            f"Z     {z:+7.3f} g",
            f"|a|   {mag:7.3f} g",
            f"roll  {roll:+7.1f} deg",
            f"pitch {pitch:+7.1f} deg",
            f"rate  {rate:4.1f} lines/s",
        ]
        self.text.set_text("\n".join(lines))
        return self.dyn

    def run(self, interval_ms=100):
        from matplotlib.animation import FuncAnimation
        self.anim = FuncAnimation(self.fig, self.update, interval=interval_ms, cache_frame_data=False)
        self.plt.show()


# ---------------------------------------------------------------------------- main
def main(argv=None):
    p = argparse.ArgumentParser(description="Live 3D acceleration vector from the MachXO4 Companion FXLS8971 demo")
    p.add_argument("--port", help="serial port, e.g. COM13")
    p.add_argument("--baud", type=int, default=DEFAULT_BAUD, help=f"baud rate (default {DEFAULT_BAUD})")
    p.add_argument("--demo", action="store_true", help="simulated data, no board needed")
    p.add_argument("--list", action="store_true", help="list serial ports and exit")
    p.add_argument("--range", type=float, default=1.5, help="axis range in g (default 1.5)")
    p.add_argument("--trail", type=int, default=60, help="number of trail points (default 60)")
    p.add_argument("--echo", action="store_true", help="also print the received lines")
    args = p.parse_args(argv)

    if args.list:
        from serial.tools import list_ports
        for port in list_ports.comports():
            print(f"{port.device:12s} {port.description}")
        return 0
    if not args.demo and not args.port:
        p.error("give --port (see --list) or --demo")

    q = queue.Queue()
    src = DemoSource(q, args.echo) if args.demo else SerialSource(args.port, args.baud, q, args.echo)
    src.start()
    try:
        Vector3DView(q, g_range=args.range, trail=args.trail).run()
    finally:
        src.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
