# One external clock: 12 MHz on clk12_i (T9). The PLL in the SoC derives the
# 24 MHz CPU/AHB clock (clkop) and the 20 MHz APB clock (clkos); Radiant derives
# those PLL output clocks from this input clock.
create_clock -name {clk12} -period 83.333 [get_ports clk12_i]

# Slow asynchronous board signals: push-button reset, UART RX (synchronised in the UART),
# LEDs. No I/O timing requirement.
set_false_path -from [get_ports {rstn_i uart_rxd_i led_io[*] acc_scl_io acc_sda_io acc_gpio_io[*]}]
set_false_path -to   [get_ports {uart_txd_o led_io[*] acc_scl_io acc_sda_io acc_gpio_io[*]}]

# APA102 outputs: SDI and CKI both come straight from flip-flops clocked by the 20 MHz APB clock
# and change on the same edge; the LED samples SDI on the CKI rising edge one PCLK period (50 ns)
# after SDI changes. Only the relative skew of the two pins matters, which is far below 50 ns,
# so no output delay is constrained.
set_false_path -to [get_ports {led_sdi_o led_cki_o}]
