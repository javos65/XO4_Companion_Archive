run_tcl -fg soc_impl_1_synplify.tcl
