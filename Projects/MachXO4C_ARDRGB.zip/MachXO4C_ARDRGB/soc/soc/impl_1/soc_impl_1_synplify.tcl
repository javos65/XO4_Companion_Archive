#-- Lattice Semiconductor Corporation Ltd.
#-- Synplify OEM project file

#device options
set_option -technology MachXO4
set_option -part LFMXO4_110HC
set_option -package BBG256I
set_option -speed_grade -6
#compilation/mapping options
set_option -symbolic_fsm_compiler true
set_option -resource_sharing true

#use verilog standard option
set_option -vlog_std v2001

#map options
set_option -frequency 200
set_option -maxfan 1000
set_option -auto_constrain_io 0
set_option -retiming false; set_option -pipe true
set_option -force_gsr false
set_option -compiler_compatible 0


set_option -default_enum_encoding default

#timing analysis options



#automatic place and route (vendor) options
set_option -write_apr_constraint 1

#synplifyPro options

set_option -syn_reduce_controlset_size 0
set_option -stop_shift_reset_merging 0
set_option -fix_gated_and_generated_clocks 0
set_option -update_models_cp 0
set_option -resolve_multiple_driver 0


set_option -rw_check_on_ram 0



#-- set any command lines input by customer

set_option -dup false
set_option -disable_io_insertion false
add_file -constraint {C:/lscc/radiant/2026.1.1/scripts/tcl/flow/radiant_synplify_vars.tcl}
add_file -constraint {soc_impl_1_cpe.ldc}
add_file -verilog {C:/lscc/radiant/2026.1.1/ip/pmi/pmi_lfmxo4.v}
add_file -vhdl -lib pmi {C:/lscc/radiant/2026.1.1/ip/pmi/pmi_lfmxo4.vhd}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/soc.v}
add_file -verilog -vlog_std sysv {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/pll0/3.0.1/rtl/pll0.sv}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/apb0/1.5.0/rtl/apb0.v}
add_file -verilog -vlog_std sysv {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/ahbl2apb0/1.2.0/rtl/ahbl2apb0.sv}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/cpu0/1.9.0/rtl/cpu0.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/gpio0/1.8.1/rtl/gpio0.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/ahbl0/1.6.0/rtl/ahbl0.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/uart0/1.6.0/rtl/uart0.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/system0/2.6.0/rtl/system0.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/custom/module/fxls0/1.0.0/rtl/fxls0.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/gpio1/1.8.1/rtl/gpio1.v}
add_file -verilog -vlog_std v2001 {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/custom/module/mkr_rgb0/1.0.0/rtl/mkr_rgb0.v}
#-- top module name
set_option -top_module soc
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/custom/module/fxls0/1.0.0}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/custom/module/mkr_rgb0/1.0.0}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/cpu0/1.9.0}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/gpio0/1.8.1}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/gpio1/1.8.1}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/system0/2.6.0}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/uart0/1.6.0}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/ahbl0/1.6.0}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/ahbl2apb0/1.2.0}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/apb0/1.5.0}
set_option -include_path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/pll0/3.0.1}

#-- set result format/file last
project -result_format "vm"
project -result_file "./soc_impl_1.vm"

#-- error message log file
project -log_file {soc_impl_1.srf}

project -run -clean
