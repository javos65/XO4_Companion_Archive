## Radiant Files
soc/lib/latticesemi.com/module/apb0/1.5.0/apb0.ipx
soc/lib/latticesemi.com/ip/gpio1/1.8.1/gpio1.ipx
soc/soc.v
soc/lib/latticesemi.com/ip/system0/2.6.0/system0.ipx
soc/lib/latticesemi.com/module/pll0/3.0.1/pll0.ipx
soc/lib/custom/module/fxls0/1.0.0/fxls0.ipx
soc/lib/latticesemi.com/ip/uart0/1.6.0/uart0.ipx
soc/lib/latticesemi.com/ip/cpu0/1.9.0/cpu0.ipx
soc/lib/latticesemi.com/module/ahbl2apb0/1.2.0/ahbl2apb0.ipx
soc/lib/custom/module/mkr_rgb0/1.0.0/mkr_rgb0.ipx
soc/lib/latticesemi.com/module/ahbl0/1.6.0/ahbl0.ipx
soc/lib/latticesemi.com/ip/gpio0/1.8.1/gpio0.ipx
