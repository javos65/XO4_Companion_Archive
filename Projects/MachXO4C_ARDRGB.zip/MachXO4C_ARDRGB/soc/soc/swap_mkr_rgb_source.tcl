# Replace the renamed IP in the Radiant project: mktrgb0 (old name) -> mkr_rgb0
prj_open {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc.rdf}
prj_remove_source {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/custom/module/mktrgb0/1.0.0/mktrgb0.ipx}
prj_add_source {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/custom/module/mkr_rgb0/1.0.0/mkr_rgb0.ipx}
prj_save
prj_close
