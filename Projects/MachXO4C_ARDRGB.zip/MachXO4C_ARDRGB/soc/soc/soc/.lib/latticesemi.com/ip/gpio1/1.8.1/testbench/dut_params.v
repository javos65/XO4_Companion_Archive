localparam FAMILY = "LFMXO4";
localparam IO_LINES_COUNT = 2;
localparam EXTERNAL_BUF = 0;
localparam OUT_RESET_VAL = "32'h00000002";
localparam DIRECTION_DEF_VAL = "32'h00000003";
localparam IF_USER_INTF = "APB";
`define xo4f00
`define LFMXO4
`define LFMXO4_110HC
