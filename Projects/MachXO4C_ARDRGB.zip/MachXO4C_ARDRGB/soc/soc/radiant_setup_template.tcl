set current_path "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc"

cd $current_path

set radiant_project "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc.rdf"

set DEVICE "LFMXO4-110HC-6BBG256I"

set PERFORMANCE "6"

set DESIGN "soc"

array set VFILE_LIST ""
set VFILE_LIST(1) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/apb0/1.5.0/apb0.ipx"
set VFILE_LIST(2) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/gpio1/1.8.1/gpio1.ipx"
set VFILE_LIST(3) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/soc.v"
set VFILE_LIST(4) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/system0/2.6.0/system0.ipx"
set VFILE_LIST(5) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/pll0/3.0.1/pll0.ipx"
set VFILE_LIST(6) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/custom/module/fxls0/1.0.0/fxls0.ipx"
set VFILE_LIST(7) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/uart0/1.6.0/uart0.ipx"
set VFILE_LIST(8) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/cpu0/1.9.0/cpu0.ipx"
set VFILE_LIST(9) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/ahbl2apb0/1.2.0/ahbl2apb0.ipx"
set VFILE_LIST(10) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/custom/module/mkr_rgb0/1.0.0/mkr_rgb0.ipx"
set VFILE_LIST(11) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/module/ahbl0/1.6.0/ahbl0.ipx"
set VFILE_LIST(12) "C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/gpio0/1.8.1/gpio0.ipx"

proc check_project_device_and_performance {expected_performance expected_device} {
    set prj_device_result [prj_device]
    set prj_device_list [split $prj_device_result " "]
    if { [llength $prj_device_list] != 6 } {
        puts "Error: prj_device_list must have exactly 6 elements, got [llength $prj_device_list]."
        exit 1
    }
    set prj_perf [lindex $prj_device_list 3]
    set prj_part [lindex $prj_device_list 5]
    if { ($prj_perf ne $expected_performance) || ($prj_part ne $expected_device) } {
        puts "Device or performance mismatch: Project($prj_part, $prj_perf) vs Expected($expected_device, $expected_performance)"
        exit 1
    }
}

set index [array names VFILE_LIST]
if { [file exists $radiant_project] == 1} {
    prj_open $radiant_project
    check_project_device_and_performance $PERFORMANCE $DEVICE
} else {
    prj_create -name "soc" -impl "impl_1" -dev $DEVICE -performance $PERFORMANCE -synthesis "synplify"
    prj_save
}


foreach i $index {
    if { [catch {prj_add_source $VFILE_LIST($i)} fid] } {
        puts "file already exists in project."
    }
}

prj_save

