prj_open {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc.rdf}
prj_add_source {C:/lscc/workspace/MachXO4C_ARDRGB/constraints/soc_timing.sdc}
prj_add_source {C:/lscc/workspace/MachXO4C_ARDRGB/constraints/xo4_companion_ardrgb.pdc}
prj_save
prj_close
