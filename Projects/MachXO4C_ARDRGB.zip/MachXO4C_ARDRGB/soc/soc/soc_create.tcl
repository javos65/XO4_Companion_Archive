# Propel design script: soc
# Session: fbb8774b-ddc8-4bcc-a865-2aada741e048
# Mode: open

sbp_design open -name {soc} -path {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/soc.sbx}

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}

sbp_config_ip -vlnv {latticesemi.com:ip:system0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4C_ARDRGB\fw\Debug\fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:8192,ARBITER_EN:False,BYTE_ENABLE_S0:True,BYTE_ENABLE_S1:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,EDIT_ADDRESS_S0:False,EDIT_ADDRESS_S1:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:2,REGMODE_S0:True,REGMODE_S1:True,RESET_MODE_S0:sync,RESET_MODE_S1:sync}
sbp_replace -vlnv {latticesemi.com:ip:system0:2.6.0} -name {system0_inst} -component {soc/system0_inst}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: soc"