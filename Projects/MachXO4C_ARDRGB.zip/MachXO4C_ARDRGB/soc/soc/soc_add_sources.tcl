prj_open {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc.rdf}
prj_add_source {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/custom/module/fxls0/1.0.0/fxls0.ipx}
prj_add_source {C:/lscc/workspace/MachXO4C_ARDRGB/soc/soc/soc/lib/latticesemi.com/ip/gpio1/1.8.1/gpio1.ipx}
puts "SOURCES_AFTER: [prj_list_source]"
prj_save
prj_close
