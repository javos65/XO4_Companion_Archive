# Add the FXLS8971CF accelerometer to the MachXO4C_ARDRGB SoC (edit of soc.sbx).
# Basis: MachXO4C_ACCEL (same board, same custom IP custom:module:fxls8971_i2c:1.0.0).
#  - fxls0_inst : soft I2C controller, SCL B13 / SDA A14, APB 0x40003000
#                 PRESCALE_RESET 49 -> f_SCL = 20 MHz / (4 * 50) = 100 kHz at reset (firmware sets 400 kHz)
#  - gpio1_inst : 2 outputs, [0] ACC_SA0 (B7) reset 0 -> I2C address 0x18, [1] ACC_WAKEUP (B12) reset 1
#                 APB 0x40004000. Reset values make the sensor address fixed before any firmware runs.

sbp_config_ip -vlnv {custom:module:fxls0:1.0.0} -meta_vlnv {custom:module:fxls8971_i2c:1.0.0} -cfg_value {PRESCALE_RESET:49}
sbp_config_ip -vlnv {latticesemi.com:ip:gpio1:1.8.1} -meta_vlnv {latticesemi.com:ip:gpio:1.8.1} -cfg_value {IO_LINES_COUNT:2,IF_USER_INTF:APB,EXTERNAL_BUF:false,DIRECTION_DEF_VAL_INPUT:3,OUT_RESET_VAL_INPUT:2}

sbp_add_component -vlnv {custom:module:fxls0:1.0.0} -name {fxls0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:gpio1:1.8.1} -name {gpio1_inst}

sbp_connect_interface_net {soc/apb0_inst/APB_M03} {soc/fxls0_inst/APB_S0}
sbp_connect_interface_net {soc/apb0_inst/APB_M04} {soc/gpio1_inst/APB_S0}

sbp_add_port -direction inout acc_scl_io
sbp_add_port -direction inout acc_sda_io
sbp_add_port -from 1 -to 0 -direction inout acc_gpio_io

# PCLK and reset are added to the existing nets pll0_inst_clkos_o_net and
# cpu0_inst_system_resetn_o_net with sbp_connect_net -name (queued separately).
sbp_connect_net {soc/fxls0_inst/I2C_SCL} {soc/acc_scl_io}
sbp_connect_net {soc/fxls0_inst/I2C_SDA} {soc/acc_sda_io}
sbp_connect_net {soc/gpio1_inst/gpio_io} {soc/acc_gpio_io}

sbp_assign_addr_seg -offset 'h40003000 {soc/apb0_inst/APB_M03} {soc/fxls0_inst/APB_S0}
sbp_assign_addr_seg -offset 'h40004000 {soc/apb0_inst/APB_M04} {soc/gpio1_inst/APB_S0}
