# Propel design script: soc
# Session: eb2e0902-a972-400c-bb59-b0116c5e7b4e
# Mode: new

file delete -force {soc}
sbp_create_project -name {soc} -path {.} -device {LFMXO4-110HC-6BBG256I} -speed {6} -language {verilog} -board {NA}
# Blank template ships clk_i/rstn_i -- remove them, as Lattice's own create_soc_demo.tcl does.
catch { sbp_delete "soc/clk_i" -type port }
catch { sbp_delete "soc/rstn_i" -type port }

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}

::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}
sbp_config_ip -vlnv {latticesemi.com:module:pll0:3.0.1} -meta_vlnv {latticesemi.com:module:pll:3.0.1} -cfg_value {gui_config_mode:FREQUENCY,gui_freq_refclk:12,gui_clkop_freq:24,gui_clkop_tol:0,gui_clkos_en:true,gui_clkos_freq:20,gui_clkos_tol:0,gui_en_lock_port:true}
sbp_config_ip -vlnv {latticesemi.com:ip:cpu0:1.9.0} -meta_vlnv {latticesemi.com:ip:riscv_sm:1.9.0} -cfg_value {DEBUG_ENABLE:false,PIC_ENABLE:true,TIMER_ENABLE:true,IRQ_NUM:2}
sbp_config_ip -vlnv {latticesemi.com:ip:system0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INTERFACE:AHBL,PORT_COUNT:2,ADDR_DEPTH:8192,DATA_WIDTH:32,MEMORY_TYPE:EBR,REGMODE_S0:true,REGMODE_S1:true}
sbp_config_ip -vlnv {latticesemi.com:module:ahbl0:1.6.0} -meta_vlnv {latticesemi.com:module:ahb_lite_interconnect:1.6.0} -cfg_value {TOTAL_MASTER_CNT:1,TOTAL_SLAVE_CNT:2}
sbp_config_ip -vlnv {latticesemi.com:module:ahbl2apb0:1.2.0} -meta_vlnv {latticesemi.com:module:ahb_lite_to_apb_bridge:1.2.0} -cfg_value {APB_CLK_EN:true}
sbp_config_ip -vlnv {latticesemi.com:module:apb0:1.5.0} -meta_vlnv {latticesemi.com:module:apb_interconnect:1.5.0} -cfg_value {TOTAL_MASTER_CNT:1,TOTAL_SLAVE_CNT:3}
sbp_config_ip -vlnv {latticesemi.com:ip:uart0:1.6.0} -meta_vlnv {latticesemi.com:ip:uart:1.6.0} -cfg_value {SYS_CLOCK_FREQ:20,BAUD_RATE_TYPE:Standard,STANDARD_BAUD_RATE:19200,LCR_DATA_BITS:8,LCR_STOP_BITS:1}
sbp_config_ip -vlnv {latticesemi.com:ip:gpio0:1.8.1} -meta_vlnv {latticesemi.com:ip:gpio:1.8.1} -cfg_value {IO_LINES_COUNT:4,IF_USER_INTF:APB,EXTERNAL_BUF:false,DIRECTION_DEF_VAL_INPUT:F,OUT_RESET_VAL_INPUT:0}
sbp_config_ip -vlnv {custom:module:mkr_rgb0:1.0.0} -meta_vlnv {custom:module:mkr_rgb_spi:1.0.0} -cfg_value {NUM_LEDS:84}
sbp_add_component -vlnv {latticesemi.com:module:pll0:3.0.1} -name {pll0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:cpu0:1.9.0} -name {cpu0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:system0:2.6.0} -name {system0_inst}
sbp_add_component -vlnv {latticesemi.com:module:ahbl0:1.6.0} -name {ahbl0_inst}
sbp_add_component -vlnv {latticesemi.com:module:ahbl2apb0:1.2.0} -name {ahbl2apb0_inst}
sbp_add_component -vlnv {latticesemi.com:module:apb0:1.5.0} -name {apb0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:uart0:1.6.0} -name {uart0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:gpio0:1.8.1} -name {gpio0_inst}
sbp_add_component -vlnv {custom:module:mkr_rgb0:1.0.0} -name {mkr_rgb0_inst}
sbp_add_gluelogic -name rst_and_0 -logicinfo [sbp_create_glue_logic equation rst_and {} { {"expr":"A & B","module_name":"rst_and"}}]
sbp_connect_interface_net {soc/cpu0_inst/AHBL_M1_DATA} {soc/ahbl0_inst/AHBL_S00}
sbp_connect_interface_net {soc/cpu0_inst/AHBL_M0_INSTR} {soc/system0_inst/AHBL_S0}
sbp_connect_interface_net {soc/ahbl0_inst/AHBL_M00} {soc/system0_inst/AHBL_S1}
sbp_connect_interface_net {soc/ahbl0_inst/AHBL_M01} {soc/ahbl2apb0_inst/AHBL_S0}
sbp_connect_interface_net {soc/ahbl2apb0_inst/APB_M0} {soc/apb0_inst/APB_S00}
sbp_connect_interface_net {soc/apb0_inst/APB_M00} {soc/uart0_inst/APB_S0}
sbp_connect_interface_net {soc/apb0_inst/APB_M01} {soc/mkr_rgb0_inst/APB_S0}
sbp_connect_interface_net {soc/apb0_inst/APB_M02} {soc/gpio0_inst/APB_S0}
sbp_connect_interface_net {soc/uart0_inst/INT_M0} {soc/cpu0_inst/IRQ_S0}
sbp_connect_interface_net {soc/gpio0_inst/INTR} {soc/cpu0_inst/IRQ_S1}
sbp_add_port -direction in clk12_i
sbp_add_port -direction in rstn_i
sbp_add_port -direction in uart_rxd_i
sbp_add_port -direction out uart_txd_o
sbp_add_port -from 3 -to 0 -direction inout led_io
sbp_add_port -direction out led_sdi_o
sbp_add_port -direction out led_cki_o
sbp_connect_net {soc/clk12_i} {soc/pll0_inst/clki_i}
sbp_connect_net {soc/pll0_inst/clkop_o} {soc/cpu0_inst/clk_i} {soc/system0_inst/ahbl_hclk_i} {soc/ahbl0_inst/ahbl_hclk_i} {soc/ahbl2apb0_inst/clk_i}
sbp_connect_net {soc/pll0_inst/clkos_o} {soc/ahbl2apb0_inst/pclk_i} {soc/apb0_inst/apb_pclk_i} {soc/uart0_inst/clk_i} {soc/gpio0_inst/clk_i} {soc/mkr_rgb0_inst/PCLK}
sbp_connect_net {soc/rstn_i} {soc/rst_and_0/A}
sbp_connect_net {soc/pll0_inst/lock_o} {soc/rst_and_0/B}
sbp_connect_net {soc/rst_and_0/O} {soc/cpu0_inst/rst_n_i}
sbp_connect_net {soc/cpu0_inst/system_resetn_o} {soc/system0_inst/ahbl_hresetn_i} {soc/ahbl0_inst/ahbl_hresetn_i} {soc/ahbl2apb0_inst/rst_n_i} {soc/ahbl2apb0_inst/presetn_i} {soc/apb0_inst/apb_presetn_i} {soc/uart0_inst/rst_n_i} {soc/gpio0_inst/resetn_i} {soc/mkr_rgb0_inst/PRESETN}
sbp_connect_net {soc/uart_rxd_i} {soc/uart0_inst/rxd_i}
sbp_connect_net {soc/uart0_inst/txd_o} {soc/uart_txd_o}
sbp_connect_net {soc/gpio0_inst/gpio_io} {soc/led_io}
sbp_connect_net {soc/mkr_rgb0_inst/LED_SDI} {soc/led_sdi_o}
sbp_connect_net {soc/mkr_rgb0_inst/LED_CKI} {soc/led_cki_o}
sbp_assign_addr_seg -offset 'h00000000 {soc/cpu0_inst/AHBL_M0_INSTR} {soc/system0_inst/AHBL_S0}
sbp_assign_addr_seg -offset 'h00000000 {soc/ahbl0_inst/AHBL_M00} {soc/system0_inst/AHBL_S1}
sbp_assign_addr_seg -offset 'h40000000 {soc/apb0_inst/APB_M00} {soc/uart0_inst/APB_S0}
sbp_assign_addr_seg -offset 'h40001000 {soc/apb0_inst/APB_M01} {soc/mkr_rgb0_inst/APB_S0}
sbp_assign_addr_seg -offset 'h40002000 {soc/apb0_inst/APB_M02} {soc/gpio0_inst/APB_S0}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: soc"