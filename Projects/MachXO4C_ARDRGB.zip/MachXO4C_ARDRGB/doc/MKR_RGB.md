

MKR RGB


source : https://docs.arduino.cc/hardware/mkr-rgb-shield/

XO4C Board : Arduino support
5V JMPR : Needed 
3V JMPR: not needed


Arduino MKR pins
LEDSDI  A3
LEDCKI  A4

MKR RGB Board :

J1 : External Supply GND
JP1 : Cascade pins
JP2 : Power Selection (normaly closed)

LEDS :
84x  RGB APA102 2020, 2x2mm SMD LED, ranged 7x12

JP2 
On the Arduino MKR RGB Shield, JPR2 (or JP2) is a power selection solder jumper that connects or isolates the LED matrix's 5V power rail from the underlying Arduino MKR board's 5V pin.
According to the official Arduino MKR RGB Shield Documentation, its behavior depends on how you power your setup:

- Default state (Closed/Bridged). A small trace connects the two pads on the back of the board so the 84 LEDs draw power directly from the MKR board's 5V rail.
- Modified state (Cut/Open). Cutting the trace between the pads isolates the LED matrix from the MKR board's 5V rail so you can safely feed high-current external 5V power into JP1 without back-powering or overloading the MKR board's voltage regulator or USB port.

When to Modify JPR2
- Keep it closed if you are running simple animations at low-to-medium brightness powered solely through the MKR board's USB connection.
- Cut the trace if you connect an external 5V power supply to JP1 to run the matrix at high brightness. (Remember to keep a common ground connection between the external supply and the MKR board).

JP1 
2-pin cascade output header connected to the SDO (Serial Data Out) and CKO (Clock Out) pins of the 84th (final) APA102 LED in the matrix.
How Cascading Works via JP1

- Purpose: Allows you to daisy-chain additional APA102 LED strips or a second MKR RGB Shield to extend your display beyond the built-in 84 LEDs.
- Wiring to Another MKR RGB Shield: Connect CKO and SDO on the first shield's JP1 header to pins A4 (Clock In) and A3 (Data In) on the next shield's headers.
- Wiring to an External APA102 Strip: Connect SDO to the strip's Data In (DI/DIN), CKO to Clock In (CI/CLK), and share a common GND.
- Power & Software Notes: All cascaded shields or strips must share a common ground with the MKR board and its power supply. Because the official Arduino_MKRRGB library is hardcoded for a single 12 × 7 matrix, you will need to use a third-party library (such as FastLED or Adafruit DotStar) to address the extra LEDs beyond pixel 84

J1
What J1 Does on the Schematic
- Function. J1 acts as a ground isolation or configuration bridge between separate ground nets on the PCB (such as tying the external power ground plane and the MKR logic ground plane together).
- Why It Exists. When powering the 84 APA102 LEDs from a separate high-current 5V supply, keeping a single-point ground tie prevents ground loops while ensuring the MKR board's data signals (A3/A4) and the LEDs share the exact same GND reference.
- Physical Behavior. Leaving J1 closed keeps the shield's ground plane directly tied to the MKR header ground pins, whereas opening it isolates those ground planes for custom wiring or star-ground setups.

SDI/CKI
On the Arduino MKR RGB Shield, SDI (often written as DSI or DI for Serial Data Input) and CKI (CI for Clock Input) form a 2-wire synchronous serial interface similar to SPI.
They shift color and brightness data from one APA102 LED to the next in a daisy chain.

Hardware Connection on the Shield

- Pin Mapping. According to the Arduino MKR RGB Shield Datasheet, the MKR board sends data out on pin A3 (SDI) and the clock signal out on pin A4 (CKI).
- Voltage Level Shifting. Because MKR boards operate at 3.3V logic while the APA102 LEDs run at 5V, the shield passes A3 and A4 through an onboard logic level shifter before reaching the first LED.
- Daisy-Chaining. Only the first LED connects to the microcontroller. Once LED 1 reads its data, it passes the remaining bits out of its SDO (Data Out) and CKO (Clock Out) pins directly into LED 2's SDI and CKI pins, repeating all the way to LED 84 (and out to JP1).

How the Data & Clock Signals Work

Unlike single-wire LEDs (like WS2812B/NeoPixels) that require strict microsecond timing, CKI tells the LEDs exactly when to read SDI:
- Clock Synchronization (CKI). Every time the voltage on CKI rises from LOW to HIGH (a rising edge), the LED reads the current logic state (1 or 0) sitting on the SDI line. Because the clock controls the speed, you can drive the matrix at almost any speed—from slow bit-banging up to several megahertz.
- Data Stream Structure (SDI). According to the SparkFun APA102 Hookup Guide, a full update frame consists of three parts sent over SDI:
	1. Start Frame (32 bits). Thirty-two 0 bits (0x00000000) tell all 84 LEDs to reset their internal counters and prepare for new data.
	2. LED Frames (32 bits per LED). Each LED consumes the first 32-bit packet it sees after the start frame. This packet contains 111 (3 header bits), 5 bits for global brightness (0–31), 8 bits for Blue, 8 bits for Green, and 8 bits for Red. Every subsequent 32-bit packet is forwarded down the chain to the next LED.
	3. End Frame. Additional clock pulses (at least N/2 bits, or 42+ bits for 84 LEDs) push the final data bits all the way through the shift registers to the last LED in the chain.


    Arduino MKR pins to FPGA
(corrected 2026-11-19 from the Companion schematic, sheet 5, header J23 in MKR numbering:
 pin 1 AREF, 2 ARD_D15 = A0, 3 ARD_D16 = A1, 4 ARD_D17 = A2, 5 ARD_D18 = A3, 6 ARD_D19 = A4, ...)
LEDSDI  A3 -> ARD_D18 D14   (bank 1)
LEDCKI  A4 -> ARD_D19 D7    (bank 0)
Previous entry (A3 -> ARD_D17 E15, A4 -> ARD_D18 D14) used Uno numbering and is wrong:
E15 is MKR A2, D14 is MKR A3.
