## Radiant Files
XO4_FLS_MC/XO4_FLS_MC.v
XO4_FLS_MC/lib/latticesemi.com/module/apb0/1.5.0/apb0.ipx
XO4_FLS_MC/lib/latticesemi.com/ip/cpu0/2.9.0/cpu0.ipx
XO4_FLS_MC/lib/latticesemi.com/ip/gpio0/1.8.1/gpio0.ipx
XO4_FLS_MC/lib/latticesemi.com/module/ahbl2apb0/1.2.0/ahbl2apb0.ipx
XO4_FLS_MC/lib/latticesemi.com/module/ahbl0/1.6.0/ahbl0.ipx
XO4_FLS_MC/lib/latticesemi.com/module/efb0/1.3.0/efb0.ipx
XO4_FLS_MC/lib/latticesemi.com/ip/sysmem0/2.6.0/sysmem0.ipx
XO4_FLS_MC/lib/latticesemi.com/ip/uart0/1.6.0/uart0.ipx
