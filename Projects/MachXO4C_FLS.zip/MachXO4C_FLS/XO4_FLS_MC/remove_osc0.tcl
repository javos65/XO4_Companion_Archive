prj_open "C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC.rdf"
prj_remove_source "C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC/lib/latticesemi.com/module/osc0/1.1.0/osc0.ipx"
prj_save
prj_close
