run_tcl -fg XO4_FLS_MC_impl_1_synplify.tcl
