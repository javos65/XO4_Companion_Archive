component IS25LP064A_efb0 is
    port(
        apb_paddr_i: in std_logic_vector(9 downto 0);
        apb_psel_i: in std_logic;
        apb_penable_i: in std_logic;
        apb_pwrite_i: in std_logic;
        apb_pwdata_i: in std_logic_vector(31 downto 0);
        apb_prdata_o: out std_logic_vector(31 downto 0);
        apb_pready_o: out std_logic;
        apb_pslverr_o: out std_logic;
        efb_paddr_o: out std_logic_vector(9 downto 0);
        efb_psel_o: out std_logic;
        efb_penable_o: out std_logic;
        efb_pwrite_o: out std_logic;
        efb_pwdata_o: out std_logic_vector(31 downto 0);
        efb_prdata_i: in std_logic_vector(31 downto 0);
        efb_pready_i: in std_logic;
        efb_pslverr_i: in std_logic
    );
end component;

__: IS25LP064A_efb0 port map(
    apb_paddr_i=>,
    apb_psel_i=>,
    apb_penable_i=>,
    apb_pwrite_i=>,
    apb_pwdata_i=>,
    apb_prdata_o=>,
    apb_pready_o=>,
    apb_pslverr_o=>,
    efb_paddr_o=>,
    efb_psel_o=>,
    efb_penable_o=>,
    efb_pwrite_o=>,
    efb_pwdata_o=>,
    efb_prdata_i=>,
    efb_pready_i=>,
    efb_pslverr_i=>
);
