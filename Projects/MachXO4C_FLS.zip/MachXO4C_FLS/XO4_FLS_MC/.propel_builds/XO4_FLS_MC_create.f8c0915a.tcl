# Propel design script: XO4_FLS_MC
# Session: e4beeac8-ccce-47ea-98dd-16d40660364a
# Mode: open

sbp_design open -name {XO4_FLS_MC} -path {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC/XO4_FLS_MC.sbx}
puts "DEVICE BEFORE: [sbp_design get_device]"
sbp_design set_device -device {LFMXO4-110HC} -speed {6} -package {BBG256} -operating {Industrial}
puts "DEVICE AFTER: [sbp_design get_device]"

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}


# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: XO4_FLS_MC"
