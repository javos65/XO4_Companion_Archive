# Propel design script: XO4_FLS_MC
# Session: ff2ab869-e8f6-45d7-bfd5-a094efbe3f5c
# Mode: open

sbp_design open -name {XO4_FLS_MC} -path {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC/XO4_FLS_MC.sbx}

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}
::ip_catalog::ip_catalog_location -add {C:\lscc\propel\2026.1.1\builder\rtf\ip}

sbp_config_ip -vlnv {custom:module:IS25LP064A_efb0:1.0.0} -meta_vlnv {custom:module:IS25LP064A_efb:1.0.0} -cfg_value {}
sbp_disconnect_interface_net {XO4_FLS_MC/apb0_inst/APB_M01} {XO4_FLS_MC/efb0_inst/APB_S0}
sbp_add_component -vlnv {custom:module:IS25LP064A_efb0:1.0.0} -name {IS25LP064A_efb0_inst}
sbp_connect_interface_net {XO4_FLS_MC/apb0_inst/APB_M01} {XO4_FLS_MC/IS25LP064A_efb0_inst/APB_S0}
sbp_connect_interface_net {XO4_FLS_MC/IS25LP064A_efb0_inst/APB_M0} {XO4_FLS_MC/efb0_inst/APB_S0}
sbp_assign_addr_seg -offset 'hA400 {XO4_FLS_MC/apb0_inst/APB_M01} {XO4_FLS_MC/IS25LP064A_efb0_inst/APB_S0}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: XO4_FLS_MC"
