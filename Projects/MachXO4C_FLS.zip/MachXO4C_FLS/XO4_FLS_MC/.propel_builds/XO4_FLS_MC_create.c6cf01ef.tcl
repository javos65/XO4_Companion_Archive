# Propel design script: XO4_FLS_MC
# Session: d6fbe33e-4d5f-4317-9cb9-0dcdeac320ae
# Mode: open

sbp_design open -name {XO4_FLS_MC} -path {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC/XO4_FLS_MC.sbx}

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}
::ip_catalog::ip_catalog_location -add {C:\lscc\propel\2026.1.1\builder\rtf\ip}


# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: XO4_FLS_MC"