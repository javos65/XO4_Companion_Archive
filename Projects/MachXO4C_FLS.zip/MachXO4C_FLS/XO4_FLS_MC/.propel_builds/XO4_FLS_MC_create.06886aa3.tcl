# Propel design script: XO4_FLS_MC
# Session: ed1cabd6-d40d-44fd-86c4-9e59e98ab214
# Mode: open

sbp_design open -name {XO4_FLS_MC} -path {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC/XO4_FLS_MC.sbx}

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}

sbp_disconnect_net {XO4_FLS_MC/osc0_inst/clk_out_o} {XO4_FLS_MC/cpu0_inst/clk_i} {XO4_FLS_MC/sysmem0_inst/ahbl_hclk_i} {XO4_FLS_MC/ahbl0_inst/ahbl_hclk_i} {XO4_FLS_MC/ahbl2apb0_inst/clk_i} {XO4_FLS_MC/apb0_inst/apb_pclk_i} {XO4_FLS_MC/uart0_inst/clk_i} {XO4_FLS_MC/efb0_inst/clk_i} {XO4_FLS_MC/gpio0_inst/clk_i}
sbp_delete {XO4_FLS_MC/osc0_inst} -type component
sbp_add_port -direction in clk_12m_i
sbp_connect_net {XO4_FLS_MC/clk_12m_i} {XO4_FLS_MC/cpu0_inst/clk_i} {XO4_FLS_MC/sysmem0_inst/ahbl_hclk_i} {XO4_FLS_MC/ahbl0_inst/ahbl_hclk_i} {XO4_FLS_MC/ahbl2apb0_inst/clk_i} {XO4_FLS_MC/apb0_inst/apb_pclk_i} {XO4_FLS_MC/uart0_inst/clk_i} {XO4_FLS_MC/efb0_inst/clk_i} {XO4_FLS_MC/gpio0_inst/clk_i}
sbp_config_ip -vlnv {latticesemi.com:ip:uart0:1.6.0} -meta_vlnv {latticesemi.com:ip:uart:1.6.0} -cfg_value {SYS_CLOCK_FREQ:12,BAUD_RATE_TYPE:Standard,STANDARD_BAUD_RATE:19200,FIFO:False,LCR_DATA_BITS:8,LCR_PARITY_ENABLE_IN:False,LCR_STOP_BITS:1,RXRDY_ENA:False,TXRDY_ENA:False}
sbp_replace -vlnv {latticesemi.com:ip:uart0:1.6.0} -name {uart0_inst} -component {XO4_FLS_MC/uart0_inst}
sbp_config_ip -vlnv {latticesemi.com:module:efb0:1.3.0} -meta_vlnv {latticesemi.com:module:lscc_efb:1.3.0} -cfg_value {EFB_WB_CLK_FREQ_TB:12,SPI_DESIRED_CLK:3,APB_ADDR_WIDTH:10,APB_DATA_WIDTH:32,CFG0_INIT_ALL_ZEROS_IN:True,CFG0_INIT_PAGES_IN:1,CFG1_INIT_ALL_ZEROS_IN:True,CFG1_INIT_PAGES_IN:1,EFB_I2C1_IN:False,EFB_I2C2_IN:False,EFB_INTERFACE_IN:APB,EFB_PLL_IN:False,EFB_SPI_IN:True,EFB_TAMPER_PORT_LOCK_IN:False,EFB_TAMPER_SRC_JTAG_IN:False,EFB_TAMPER_SRC_SI2C_IN:False,EFB_TAMPER_SRC_SSPI_IN:False,EFB_TAMPER_SRC_WB_IN:False,EFB_TAMPER_TYPE_LOCKED_FLASH_SRAM_IN:False,EFB_TAMPER_TYPE_MANUFACTURE_MODE_IN:False,EFB_TAMPER_TYPE_PASSWORD_IN:False,EFB_TC_IN:False,EFB_UFM_IN:False,EFB_WB_IN:True,I2C1_ADDRESSING_IN:7BIT,I2C1_BUS_PERF:100kHz,I2C1_GEN_CALL_IN:False,I2C1_SLAVE_ADDR_IN:10000,I2C2_ADDRESSING_IN:7BIT,I2C2_BUS_PERF:100kHz,I2C2_GEN_CALL_IN:False,I2C2_SLAVE_ADDR_IN:10000,SPI_CLK_INV_IN:False,SPI_CS_NUM:1,SPI_INTR_EN:False,SPI_INTR_RXOVR_IN:False,SPI_INTR_RXRDY_IN:False,SPI_INTR_TXOVR_IN:False,SPI_INTR_TXRDY_IN:False,SPI_LSB_FIRST_IN:False,SPI_MODE:BOTH,SPI_PHASE_ADJ_IN:False,SPI_SLAVE_HANDSHAKE_IN:False,SPI_WAKEUP_IN:False,TC_STL_OV_INT_IN:False,UFM0_INIT_ALL_ZEROS_IN:True,UFM0_INIT_PAGES_IN:1,UFM1_INIT_ALL_ZEROS_IN:True,UFM1_INIT_PAGES_IN:1,UFM2_INIT_ALL_ZEROS_IN:True,UFM2_INIT_PAGES_IN:1,UFM3_INIT_ALL_ZEROS_IN:True,UFM3_INIT_PAGES_IN:1,UFM_INIT_ALL_ZEROS_IN:True,UFM_INIT_PAGES_IN:1}
sbp_replace -vlnv {latticesemi.com:module:efb0:1.3.0} -name {efb0_inst} -component {XO4_FLS_MC/efb0_inst}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: XO4_FLS_MC"