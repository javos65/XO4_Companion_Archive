# Propel design script: XO4_FLS
# Session: 2229b528-87e1-4bb9-8e2f-7c6c724240bc
# Mode: new

file delete -force {XO4_FLS}
sbp_create_project -name {XO4_FLS} -path {.} -device {LFMXO4-110HC-5BBG484C} -speed {5} -language {verilog} -board {NA}
# Blank template ships clk_i/rstn_i -- remove them, as Lattice's own create_soc_demo.tcl does.
catch { sbp_delete "XO4_FLS/clk_i" -type port }
catch { sbp_delete "XO4_FLS/rstn_i" -type port }

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}

sbp_config_ip -vlnv {latticesemi.com:module:osc0:1.1.0} -meta_vlnv {latticesemi.com:module:osc:1.1.0} -cfg_value {NOM_FREQ:19.00}
sbp_config_ip -vlnv {latticesemi.com:ip:cpu0:1.9.0} -meta_vlnv {latticesemi.com:ip:riscv_sm:1.9.0} -cfg_value {PIC_ENABLE:true,TIMER_ENABLE:true,IRQ_NUM:2,DEBUG_ENABLE:false}
sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INTERFACE:AHBL,ADDR_DEPTH:8192,DATA_WIDTH:32,MEMORY_TYPE:EBR,PORT_COUNT:2}
sbp_config_ip -vlnv {latticesemi.com:module:ahbl0:1.6.0} -meta_vlnv {latticesemi.com:module:ahb_lite_interconnect:1.6.0} -cfg_value {TOTAL_MASTER_CNT:1,TOTAL_SLAVE_CNT:2}
sbp_config_ip -vlnv {latticesemi.com:module:ahbl2apb0:1.2.0} -meta_vlnv {latticesemi.com:module:ahb_lite_to_apb_bridge:1.2.0} -cfg_value {}
sbp_config_ip -vlnv {latticesemi.com:module:apb0:1.5.0} -meta_vlnv {latticesemi.com:module:apb_interconnect:1.5.0} -cfg_value {TOTAL_MASTER_CNT:1,TOTAL_SLAVE_CNT:2}
sbp_config_ip -vlnv {latticesemi.com:ip:uart0:1.6.0} -meta_vlnv {latticesemi.com:ip:uart:1.6.0} -cfg_value {SYS_CLOCK_FREQ:19,BAUD_RATE_TYPE:Standard,STANDARD_BAUD_RATE:115200,LCR_DATA_BITS:8,LCR_STOP_BITS:1,LCR_PARITY_ENABLE_IN:false,FIFO:false}
sbp_config_ip -vlnv {latticesemi.com:module:efb0:1.3.0} -meta_vlnv {latticesemi.com:module:lscc_efb:1.3.0} -cfg_value {EFB_WB_IN:true,EFB_INTERFACE_IN:APB,APB_DATA_WIDTH:32,APB_ADDR_WIDTH:10,EFB_WB_CLK_FREQ_TB:19,EFB_I2C1_IN:false,EFB_I2C2_IN:false,EFB_SPI_IN:true,SPI_MODE:BOTH,SPI_CS_NUM:1,SPI_DESIRED_CLK:4.75,EFB_TC_IN:false,EFB_UFM_IN:false}
sbp_add_component -vlnv {latticesemi.com:module:osc0:1.1.0} -name {osc0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:cpu0:1.9.0} -name {cpu0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst}
sbp_add_component -vlnv {latticesemi.com:module:ahbl0:1.6.0} -name {ahbl0_inst}
sbp_add_component -vlnv {latticesemi.com:module:ahbl2apb0:1.2.0} -name {ahbl2apb0_inst}
sbp_add_component -vlnv {latticesemi.com:module:apb0:1.5.0} -name {apb0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:uart0:1.6.0} -name {uart0_inst}
sbp_add_component -vlnv {latticesemi.com:module:efb0:1.3.0} -name {efb0_inst}
sbp_connect_interface_net {XO4_FLS/cpu0_inst/AHBL_M0_INSTR} {XO4_FLS/sysmem0_inst/AHBL_S0}
sbp_connect_interface_net {XO4_FLS/cpu0_inst/AHBL_M1_DATA} {XO4_FLS/ahbl0_inst/AHBL_S00}
sbp_connect_interface_net {XO4_FLS/ahbl0_inst/AHBL_M00} {XO4_FLS/sysmem0_inst/AHBL_S1}
sbp_connect_interface_net {XO4_FLS/ahbl0_inst/AHBL_M01} {XO4_FLS/ahbl2apb0_inst/AHBL_S0}
sbp_connect_interface_net {XO4_FLS/ahbl2apb0_inst/APB_M0} {XO4_FLS/apb0_inst/APB_S00}
sbp_connect_interface_net {XO4_FLS/apb0_inst/APB_M00} {XO4_FLS/uart0_inst/APB_S0}
sbp_connect_interface_net {XO4_FLS/apb0_inst/APB_M01} {XO4_FLS/efb0_inst/APB_S0}
sbp_connect_interface_net {XO4_FLS/uart0_inst/INT_M0} {XO4_FLS/cpu0_inst/IRQ_S0}
sbp_connect_interface_net {XO4_FLS/efb0_inst/INTR} {XO4_FLS/cpu0_inst/IRQ_S1}
sbp_add_port -direction in rstn_i
sbp_add_port -direction in uart_rxd_i
sbp_add_port -direction out uart_txd_o
sbp_add_port -direction inout spi_clk_io
sbp_add_port -direction inout spi_mosi_io
sbp_add_port -direction inout spi_miso_io
sbp_add_port -from 0 -to 0 -direction out spi_csn_o
sbp_connect_net {XO4_FLS/osc0_inst/clk_out_o} {XO4_FLS/cpu0_inst/clk_i} {XO4_FLS/sysmem0_inst/ahbl_hclk_i} {XO4_FLS/ahbl0_inst/ahbl_hclk_i} {XO4_FLS/ahbl2apb0_inst/clk_i} {XO4_FLS/apb0_inst/apb_pclk_i} {XO4_FLS/uart0_inst/clk_i} {XO4_FLS/efb0_inst/clk_i}
sbp_connect_net {XO4_FLS/rstn_i} {XO4_FLS/cpu0_inst/rst_n_i}
sbp_connect_net {XO4_FLS/cpu0_inst/system_resetn_o} {XO4_FLS/sysmem0_inst/ahbl_hresetn_i} {XO4_FLS/ahbl0_inst/ahbl_hresetn_i} {XO4_FLS/ahbl2apb0_inst/rst_n_i} {XO4_FLS/apb0_inst/apb_presetn_i} {XO4_FLS/uart0_inst/rst_n_i} {XO4_FLS/efb0_inst/rstn_i}
sbp_connect_constant -constant 1'B0 {XO4_FLS/osc0_inst/stdby_i}
sbp_connect_net {XO4_FLS/uart_rxd_i} {XO4_FLS/uart0_inst/rxd_i}
sbp_connect_net {XO4_FLS/uart0_inst/txd_o} {XO4_FLS/uart_txd_o}
sbp_connect_net {XO4_FLS/efb0_inst/spi_clk} {XO4_FLS/spi_clk_io}
sbp_connect_net {XO4_FLS/efb0_inst/spi_mosi} {XO4_FLS/spi_mosi_io}
sbp_connect_net {XO4_FLS/efb0_inst/spi_miso} {XO4_FLS/spi_miso_io}
sbp_connect_net {XO4_FLS/efb0_inst/spi_csn} {XO4_FLS/spi_csn_o}
sbp_assign_addr_seg -offset 'h00000000 {XO4_FLS/cpu0_inst/AHBL_M0_INSTR} {XO4_FLS/sysmem0_inst/AHBL_S0}
sbp_assign_addr_seg -offset 'h00000000 {XO4_FLS/ahbl0_inst/AHBL_M00} {XO4_FLS/sysmem0_inst/AHBL_S1}
sbp_assign_addr_seg -offset 'h0000A000 {XO4_FLS/apb0_inst/APB_M00} {XO4_FLS/uart0_inst/APB_S0}
sbp_assign_addr_seg -offset 'h0000A400 {XO4_FLS/apb0_inst/APB_M01} {XO4_FLS/efb0_inst/APB_S0}
sbp_connect_constant -constant 1'B1 {XO4_FLS/efb0_inst/spi_scsn}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: XO4_FLS"