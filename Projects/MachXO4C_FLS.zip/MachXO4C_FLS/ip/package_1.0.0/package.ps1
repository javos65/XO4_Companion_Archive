# Packages IS25LP064A_efb 1.0.0 with the IP Packager engine on the command line (ippkg.exe).
# Output: custom_module_IS25LP064A_efb_1.0.0.ipk in this folder, plus ippkg_out.txt / ippkg_err.txt.
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$blk  = (Resolve-Path (Join-Path $here '..\custom_module_IS25LP064A_efb_1.0.0')).Path
$env:FOUNDRY = 'C:\lscc\propel\2026.1.1\builder\rtf\ispfpga'
$pkg  = "$env:FOUNDRY\bin\nt64\ippkg.exe"
$meta = @("$blk\metadata.xml", "$blk\bus_interface.xml", "$blk\memory_map.xml")
$rtl  = @("$blk\rtl\IS25LP064A_efb.v")
$drv  = @('IS25LP064A_efb_regs.h','IS25LP064A_efb.c','IS25LP064A_efb.h','IS25LP064A_efb.xml') | % { "$blk\driver\$_" }
$out  = "$here\custom_module_IS25LP064A_efb_1.0.0.ipk"
if (Test-Path $out) { Remove-Item $out }
$enc = New-Object Text.UTF8Encoding($false)
[IO.File]::WriteAllLines("$here\metadata_list.txt", [string[]]$meta, $enc)
[IO.File]::WriteAllLines("$here\rtl_list.txt",      [string[]]$rtl,  $enc)
[IO.File]::WriteAllLines("$here\driver_list.txt",   [string[]]$drv,  $enc)
& $pkg -metadata_files "$here\metadata_list.txt" -rtl_files "$here\rtl_list.txt" -driver_files "$here\driver_list.txt" `
    -help_file "$blk\doc\introduction.html" -o $out `
    1> "$here\ippkg_out.txt" 2> "$here\ippkg_err.txt"
"exit=$LASTEXITCODE"
Get-Content "$here\ippkg_out.txt","$here\ippkg_err.txt"
if (Test-Path $out) {
    Add-Type -A System.IO.Compression.FileSystem
    $z = [IO.Compression.ZipFile]::OpenRead($out); $z.Entries | % FullName; $z.Dispose()
}
