// MachXO4 EFB SPI serial flash demo (LFMXO4-110-EVN), RISC-V MC.
// UART transmit as in MachXO4_TTS2: uart_init(), non-blocking driver calls and a
// transmit queue serviced by tx_service(), one character per pass. printf() writes
// into the queue through iob_init().

#include "hal.h"
#include "utils.h"
#include <stdio.h>
#include "sys_platform.h"
#include <riscv_errors.h>
#include "platform_init.h"
#include "iob.h"
#include "uart.h"
#include "gpio.h"
#include "app/efb_spi.h"
#include "app/flash_demo.h"
#include "app/w25q.h"

#define UART_BASE   UART0_INST_BASE_ADDR
#define CPU_HZ      12000000u

/* Polling-loop iterations per heartbeat half period (about 0.5 s at 12 MHz) */
#define HEARTBEAT_LOOPS  63000u

static struct uart_instance uart0;
static struct gpio_instance led_gpio_inst;
static uint32_t led_state;
static uint32_t heartbeat;

/* ---- transmit queue: as in MachXO4_TTS2 ---------------------------------------------------------------- */
#define TXQ_SIZE 4096u                /* power of two, larger than one hex dump of the demo */
static uint8_t  txq[TXQ_SIZE];
static uint32_t tx_wr, tx_rd;

static void tx_service(void)
{
	if (tx_rd != tx_wr) {
		if (uart_putc(&uart0, txq[tx_rd & (TXQ_SIZE - 1u)]) == 0) {
			tx_rd++;
		}
	}
}

/* gpio0 lines (all outputs, reset value 3'b110); flash CS# is the EFB spi_csn */
#define GPIO_LINE_LED        0u   /* heartbeat LED D6, ball J1 */
#define GPIO_LINE_FLASH_WP   1u   /* flash WP#, V9 */
#define GPIO_LINE_FLASH_HOLD 2u   /* flash HOLD#, W8 */

/* gpio_output_write() masks the value with the line bit, so pass it shifted */
static void gpio_line_set(uint32_t line, uint32_t level)
{
	gpio_output_write(&led_gpio_inst, line, level ? (1u << line) : 0u);
}

static void heartbeat_toggle(void)
{
	led_state ^= 1u;
	gpio_line_set(GPIO_LINE_LED, led_state);
}

/* One pass of the main loop: send at most one character, run the heartbeat LED */
static void loop_pass(void)
{
	tx_service();
	if (++heartbeat >= HEARTBEAT_LOOPS) {
		heartbeat = 0;
		heartbeat_toggle();
	}
}

static void tx_put(uint8_t c)
{
	while ((tx_wr - tx_rd) >= TXQ_SIZE) {
		loop_pass();                  /* queue full: let the main loop send */
	}
	txq[tx_wr & (TXQ_SIZE - 1u)] = c;
	tx_wr++;
}

/* printf() output: into the transmit queue, LF sent as CR LF */
static int queue_putc(char c, FILE *file)
{
	(void) file;
	if (c == '\n')
		tx_put('\r');
	tx_put((uint8_t)c);
	return (unsigned char)c;
}

static int queue_getc(FILE *file)
{
	unsigned char c;
	(void) file;
	while (uart_getc(&uart0, &c) != 0) {
		loop_pass();
	}
	return c;
}

static int queue_flush(FILE *file)
{
	(void) file;
	while (tx_rd != tx_wr) {
		loop_pass();
	}
	return 0;
}

static void bsp_init(void)
{
	uart_init(&uart0, UART_BASE, CPU_HZ, UART0_INST_BAUD_RATE, 1u, 8u);
	uart0.blockingTx = 0;             /* never wait inside a call */
	uart0.blockingRx = 0;
	iob_init(queue_putc, queue_getc, queue_flush);

	led_gpio_inst.instance_name = LED_GPIO_INST_NAME;
	gpio_init(&led_gpio_inst, LED_GPIO_INST_BASE_ADDR, LED_GPIO_INST_LINES_NUM, LED_GPIO_INST_GPIO_DIRS);

	/* Flash WP# and HOLD# high (inactive) */
	gpio_line_set(GPIO_LINE_FLASH_WP, 1u);
	gpio_line_set(GPIO_LINE_FLASH_HOLD, 1u);
}

/* Send what is queued, then wait for any key on the UART, blinking the heartbeat LED D6 */
static void wait_key(void)
{
	unsigned char c;

	for (;;) {
		loop_pass();
		if (tx_rd == tx_wr && uart_getc(&uart0, &c) == 0)
			return;
	}
}

int main(void)
{
	uint32_t run = 0;

	bsp_init();
	heartbeat_toggle();

	printf("MachXO4 running \n");
	printf("\nMachXO4 EFB SPI serial flash demo (LFMXO4-110-EVN)\n");
	printf("RISC-V MC + EFB SPI controller -> W25Q64JVSSIQ, UART %u 8N1\n",
	       (unsigned)UART0_INST_BAUD_RATE);

	efb_spi_init(EFB0_INST_BASE_ADDR);
	printf("EFB SPI registers after init:\n");
	efb_spi_report();

	/* Bring-up step 1: read the JEDEC ID (raw bytes shown) to prove the
	   EFB SPI to W25Q64JV interface before the block test runs. */
	while (true) {
		static const uint8_t tx[4] = { 0x9Fu, 0x00u, 0x00u, 0x00u };
		uint8_t rx[4] = { 0, 0, 0, 0 };
		int rc[4] = { -2, -2, -2, -2 };
		uint8_t sr[4] = { 0, 0, 0, 0 };
		int rc_sel, rc_desel;
		uint32_t id;

		printf("\n=== ID read %u : command 9F, then 3 dummy bytes ===\n", (unsigned)run++);
		printf("  SPISR before          : %02X\n", (unsigned)efb_spi_status());

		/* TN1246 Figure 17-16: CR2 <= C0, wait TRDY; per byte TXDR <= tx,
		   wait RRDY, rx <= RXDR; CR2 <= 80, wait not TIP */
		rc_sel = efb_spi_select();
		printf("  select (CR2=C0)       : %s, SPISR %02X\n",
		       rc_sel == EFB_SPI_OK ? "ok" : "TIMEOUT", (unsigned)efb_spi_status());
		for (uint32_t i = 0; i < 4u; i++) {
			rc[i] = efb_spi_xfer(tx[i], &rx[i]);
			sr[i] = efb_spi_status();
		}
		rc_desel = efb_spi_deselect();

		for (uint32_t i = 0; i < 4u; i++)
			printf("  byte %u : sent %02X  read back %02X  %s  SPISR %02X\n",
			       (unsigned)i, (unsigned)tx[i], (unsigned)rx[i],
			       rc[i] == EFB_SPI_OK ? "ok     " : "TIMEOUT", (unsigned)sr[i]);
		printf("  deselect (CR2=80)     : %s, SPISR %02X\n",
		       rc_desel == EFB_SPI_OK ? "ok" : "TIMEOUT", (unsigned)efb_spi_status());

		id = ((uint32_t)rx[1] << 16) | ((uint32_t)rx[2] << 8) | rx[3];
		printf("[ID   ] JEDEC ID = %02X %02X %02X  -> %s\n",
		       (unsigned)rx[1], (unsigned)rx[2], (unsigned)rx[3],
		       (id == W25Q64JV_JEDEC_ID) ? "W25Q64JV, interface OK" :
		       "unexpected (expected EF 40 17)");
		if (rc_sel != EFB_SPI_OK || rc_desel != EFB_SPI_OK ||
		    rc[0] != EFB_SPI_OK || rc[1] != EFB_SPI_OK || rc[2] != EFB_SPI_OK || rc[3] != EFB_SPI_OK)
			efb_spi_report();

		/* Bring-up step 2: write enable latch. SR1 bit 1 = WEL, bit 0 = BUSY.
		   Expected: SR1 x0, after 06h x2, after 04h x0. */
		if (id == W25Q64JV_JEDEC_ID) {
			uint8_t s0 = 0, s1 = 0, s2 = 0;
			int r0, r1, r2, r3;

			r0 = w25q_read_status(&s0);
			r1 = efb_spi_cmd1(W25Q_CMD_WRITE_ENABLE);
			r2 = w25q_read_status(&s1);
			(void)efb_spi_cmd1(W25Q_CMD_WRITE_DISABLE);
			r3 = w25q_read_status(&s2);
			printf("[WEL  ] TB sequence, WP#/HOLD# high: SR1 %02X -> 06h -> %02X (WEL %s) -> 04h -> %02X%s\n",
			       (unsigned)s0, (unsigned)s1,
			       (s1 & W25Q_SR1_WEL) ? "set" : "NOT set", (unsigned)s2,
			       (r0 | r1 | r2 | r3) == 0 ? "" : "  TIMEOUT");

			/* Bring-up step 3: block erase / write / read back / compare */
			flash_demo_run(run - 1u);
		} else {
			printf("Block test skipped: JEDEC ID check failed.\n");
		}

		printf("\nPress any key to run again with a new pattern...\n");
		wait_key();
	}

	return 0;
}
