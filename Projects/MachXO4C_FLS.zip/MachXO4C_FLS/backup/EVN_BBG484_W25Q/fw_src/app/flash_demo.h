#ifndef FLASH_DEMO_H_
#define FLASH_DEMO_H_

#include <stdint.h>

/* Test sector agreed for the demo: last 4 KB sector of the 8 MB W25Q64JV */
#define FLASH_DEMO_SECTOR_ADDR  0x7FF000u
#define FLASH_DEMO_BLOCK_SIZE   256u

void flash_demo_fill_pattern(uint8_t *buf, uint32_t len, uint32_t seed);
/* Returns the mismatch count; *first gets the first mismatching offset, or len */
uint32_t flash_demo_compare(const uint8_t *a, const uint8_t *b, uint32_t len, uint32_t *first);
uint32_t flash_demo_count_not_erased(const uint8_t *buf, uint32_t len);
/* One erase / blank-check / write / read-back pass; returns 0 on PASS */
int flash_demo_run(uint32_t seed);

#endif /* FLASH_DEMO_H_ */
