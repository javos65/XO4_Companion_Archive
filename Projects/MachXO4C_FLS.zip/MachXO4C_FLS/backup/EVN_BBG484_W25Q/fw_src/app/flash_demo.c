#include <stdio.h>
#include <stdint.h>
#include "app/w25q.h"
#include "app/efb_spi.h"
#include "app/flash_demo.h"

static uint8_t wr_buf[FLASH_DEMO_BLOCK_SIZE];
static uint8_t rd_buf[FLASH_DEMO_BLOCK_SIZE];

void flash_demo_fill_pattern(uint8_t *buf, uint32_t len, uint32_t seed)
{
    /* incrementing ramp offset by the run number, so each run writes new data */
    for (uint32_t i = 0; i < len; i++)
        buf[i] = (uint8_t)(i + seed * 0x35u);
}

uint32_t flash_demo_compare(const uint8_t *a, const uint8_t *b, uint32_t len, uint32_t *first)
{
    uint32_t bad = 0;
    *first = len;
    for (uint32_t i = 0; i < len; i++) {
        if (a[i] != b[i]) {
            if (bad == 0) *first = i;
            bad++;
        }
    }
    return bad;
}

uint32_t flash_demo_count_not_erased(const uint8_t *buf, uint32_t len)
{
    uint32_t n = 0;
    for (uint32_t i = 0; i < len; i++)
        if (buf[i] != 0xFFu) n++;
    return n;
}

static void hex_dump(const char *title, uint32_t addr, const uint8_t *buf, uint32_t len)
{
    printf("%s\n", title);
    for (uint32_t row = 0; row < len; row += 16) {
        printf("  %06X:", (unsigned)(addr + row));
        for (uint32_t i = 0; i < 16 && row + i < len; i++)
            printf(" %02X", buf[row + i]);
        printf("  |");
        for (uint32_t i = 0; i < 16 && row + i < len; i++) {
            uint8_t c = buf[row + i];
            putchar((c >= 0x20u && c < 0x7Fu) ? c : '.');
        }
        printf("|\n");
    }
}

static const char *w25q_err_str(int rc)
{
    switch (rc) {
    case W25Q_OK:          return "OK";
    case W25Q_ERR_SPI:     return "EFB SPI controller did not respond";
    case W25Q_ERR_TIMEOUT: return "flash stayed BUSY";
    case W25Q_ERR_ARG:     return "bad argument";
    case W25Q_ERR_WEL:     return "write enable latch not set (flash not responding?)";
    default:               return "unknown error";
    }
}

int flash_demo_run(uint32_t seed)
{
    const uint32_t addr = FLASH_DEMO_SECTOR_ADDR;
    uint32_t id, first, bad;
    int rc;

    printf("\n=== Run %u : W25Q64JV block test @ 0x%06X ===\n", (unsigned)seed, (unsigned)addr);

    rc = w25q_read_jedec_id(&id);
    if (rc != W25Q_OK) {
        printf("[ID   ] FAIL : %s\n", w25q_err_str(rc));
        if (rc == W25Q_ERR_SPI)
            efb_spi_report();
        return -1;
    }
    printf("[ID   ] JEDEC ID = %02X %02X %02X", (unsigned)((id >> 16) & 0xFFu),
           (unsigned)((id >> 8) & 0xFFu), (unsigned)(id & 0xFFu));
    if (id != W25Q64JV_JEDEC_ID) {
        printf("  -> expected EF 40 17 (W25Q64JV). Check JP8 (CSSPIN to U6).\n");
        return -1;
    }
    printf("  -> W25Q64JV\n");

    printf("[ERASE] Sector erase 4 KB @ 0x%06X ... ", (unsigned)addr);
    rc = w25q_sector_erase(addr);
    if (rc != W25Q_OK) {
        printf("FAIL : %s\n", w25q_err_str(rc));
        return -1;
    }
    printf("done\n");

    rc = w25q_read(addr, rd_buf, FLASH_DEMO_BLOCK_SIZE);
    if (rc != W25Q_OK) {
        printf("[BLANK] FAIL : %s\n", w25q_err_str(rc));
        return -1;
    }
    bad = flash_demo_count_not_erased(rd_buf, FLASH_DEMO_BLOCK_SIZE);
    printf("[BLANK] %u of %u bytes not 0xFF -> %s\n", (unsigned)bad,
           (unsigned)FLASH_DEMO_BLOCK_SIZE, bad ? "NOT BLANK" : "blank");

    flash_demo_fill_pattern(wr_buf, FLASH_DEMO_BLOCK_SIZE, seed);
    hex_dump("[WRITE] Page program, data written:", addr, wr_buf, FLASH_DEMO_BLOCK_SIZE);
    rc = w25q_page_program(addr, wr_buf, FLASH_DEMO_BLOCK_SIZE);
    if (rc != W25Q_OK) {
        printf("[WRITE] FAIL : %s\n", w25q_err_str(rc));
        return -1;
    }

    for (uint32_t i = 0; i < FLASH_DEMO_BLOCK_SIZE; i++)
        rd_buf[i] = 0;
    rc = w25q_read(addr, rd_buf, FLASH_DEMO_BLOCK_SIZE);
    if (rc != W25Q_OK) {
        printf("[READ ] FAIL : %s\n", w25q_err_str(rc));
        return -1;
    }
    hex_dump("[READ ] Read back, data read:", addr, rd_buf, FLASH_DEMO_BLOCK_SIZE);

    bad = flash_demo_compare(wr_buf, rd_buf, FLASH_DEMO_BLOCK_SIZE, &first);
    if (bad) {
        printf("[CHECK] FAIL : %u mismatches, first at offset 0x%02X (wrote %02X, read %02X)\n",
               (unsigned)bad, (unsigned)first, wr_buf[first], rd_buf[first]);
        return -1;
    }
    printf("[CHECK] PASS : %u bytes written and read back identical\n", (unsigned)FLASH_DEMO_BLOCK_SIZE);
    return 0;
}
