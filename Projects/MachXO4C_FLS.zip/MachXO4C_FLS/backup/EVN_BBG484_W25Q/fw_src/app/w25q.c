#include <stdint.h>
#include <stddef.h>
#include "app/efb_spi.h"
#include "app/w25q.h"

/* Send command + 24-bit address with CS held low; caller deselects */
static int w25q_cmd_addr(uint8_t cmd, uint32_t addr)
{
    if (efb_spi_select() != EFB_SPI_OK) return W25Q_ERR_SPI;
    if (efb_spi_xfer(cmd, NULL) != EFB_SPI_OK) return W25Q_ERR_SPI;
    if (efb_spi_xfer((uint8_t)(addr >> 16), NULL) != EFB_SPI_OK) return W25Q_ERR_SPI;
    if (efb_spi_xfer((uint8_t)(addr >> 8), NULL) != EFB_SPI_OK) return W25Q_ERR_SPI;
    if (efb_spi_xfer((uint8_t)addr, NULL) != EFB_SPI_OK) return W25Q_ERR_SPI;
    return W25Q_OK;
}

static int w25q_end(int rc)
{
    if (efb_spi_deselect() != EFB_SPI_OK && rc == W25Q_OK)
        rc = W25Q_ERR_SPI;
    return rc;
}

int w25q_read_jedec_id(uint32_t *id)
{
    uint8_t b[3];
    int rc = W25Q_OK;
    if (!id) return W25Q_ERR_ARG;
    if (efb_spi_select() != EFB_SPI_OK || efb_spi_xfer(W25Q_CMD_JEDEC_ID, NULL) != EFB_SPI_OK)
        rc = W25Q_ERR_SPI;
    for (int i = 0; i < 3 && rc == W25Q_OK; i++)
        if (efb_spi_xfer(0x00, &b[i]) != EFB_SPI_OK) rc = W25Q_ERR_SPI;
    rc = w25q_end(rc);
    if (rc == W25Q_OK)
        *id = ((uint32_t)b[0] << 16) | ((uint32_t)b[1] << 8) | b[2];
    return rc;
}

int w25q_read_status(uint8_t *sr1)
{
    int rc = W25Q_OK;
    if (!sr1) return W25Q_ERR_ARG;
    if (efb_spi_select() != EFB_SPI_OK
        || efb_spi_xfer(W25Q_CMD_READ_SR1, NULL) != EFB_SPI_OK
        || efb_spi_xfer(0x00, sr1) != EFB_SPI_OK)
        rc = W25Q_ERR_SPI;
    return w25q_end(rc);
}

static int w25q_wait_ready(void)
{
    uint8_t sr1;
    for (uint32_t n = 0; n < W25Q_BUSY_POLL_LIMIT; n++) {
        if (w25q_read_status(&sr1) != W25Q_OK) return W25Q_ERR_SPI;
        if (!(sr1 & W25Q_SR1_BUSY)) return W25Q_OK;
    }
    return W25Q_ERR_TIMEOUT;
}

static int w25q_write_enable(void)
{
    uint8_t sr1;
    int rc = W25Q_OK;
    if (efb_spi_select() != EFB_SPI_OK || efb_spi_xfer(W25Q_CMD_WRITE_ENABLE, NULL) != EFB_SPI_OK)
        rc = W25Q_ERR_SPI;
    rc = w25q_end(rc);
    if (rc != W25Q_OK) return rc;
    if (w25q_read_status(&sr1) != W25Q_OK) return W25Q_ERR_SPI;
    return (sr1 & W25Q_SR1_WEL) ? W25Q_OK : W25Q_ERR_WEL;
}

int w25q_sector_erase(uint32_t addr)
{
    int rc;
    if (addr >= W25Q64_SIZE || (addr % W25Q_SECTOR_SIZE) != 0) return W25Q_ERR_ARG;
    if ((rc = w25q_wait_ready()) != W25Q_OK) return rc;
    if ((rc = w25q_write_enable()) != W25Q_OK) return rc;
    rc = w25q_end(w25q_cmd_addr(W25Q_CMD_SECTOR_ERASE, addr));
    if (rc != W25Q_OK) return rc;
    return w25q_wait_ready();
}

int w25q_page_program(uint32_t addr, const uint8_t *buf, uint32_t len)
{
    int rc;
    if (!buf || len == 0 || addr >= W25Q64_SIZE) return W25Q_ERR_ARG;
    /* a program must not cross a page boundary or it wraps inside the page */
    if ((addr % W25Q_PAGE_SIZE) + len > W25Q_PAGE_SIZE) return W25Q_ERR_ARG;
    if ((rc = w25q_wait_ready()) != W25Q_OK) return rc;
    if ((rc = w25q_write_enable()) != W25Q_OK) return rc;
    rc = w25q_cmd_addr(W25Q_CMD_PAGE_PROGRAM, addr);
    for (uint32_t i = 0; i < len && rc == W25Q_OK; i++)
        if (efb_spi_xfer(buf[i], NULL) != EFB_SPI_OK) rc = W25Q_ERR_SPI;
    rc = w25q_end(rc);
    if (rc != W25Q_OK) return rc;
    return w25q_wait_ready();
}

int w25q_read(uint32_t addr, uint8_t *buf, uint32_t len)
{
    int rc;
    if (!buf || addr >= W25Q64_SIZE || len > W25Q64_SIZE - addr) return W25Q_ERR_ARG;
    if ((rc = w25q_wait_ready()) != W25Q_OK) return rc;
    rc = w25q_cmd_addr(W25Q_CMD_READ_DATA, addr);
    for (uint32_t i = 0; i < len && rc == W25Q_OK; i++)
        if (efb_spi_xfer(0x00, &buf[i]) != EFB_SPI_OK) rc = W25Q_ERR_SPI;
    return w25q_end(rc);
}
