#ifndef EFB_SPI_H_
#define EFB_SPI_H_

/* MachXO4 EFB hard SPI controller, APB interface with APB_DATA_WIDTH = 32.
   Each 8-bit EFB register sits on its own 32-bit word: CPU offset =
   EFB register index * 4 (lscc_efb 1.3.0 memory_map.xml). */

#include <stdint.h>

#define EFB_SPICR0   0x150u
#define EFB_SPICR1   0x154u
#define EFB_SPICR2   0x158u
#define EFB_SPIBR    0x15Cu
#define EFB_SPICSR   0x160u
#define EFB_SPITXDR  0x164u
#define EFB_SPISR    0x168u
#define EFB_SPIRXDR  0x16Cu
#define EFB_SPIIRQ   0x170u
#define EFB_SPIIRQEN 0x174u

/* SPICR1 */
#define EFB_SPICR1_SPE   (1u << 7)
/* SPICR2 */
#define EFB_SPICR2_MSTR  (1u << 7)
#define EFB_SPICR2_MCSH  (1u << 6)
#define EFB_SPICR2_CPOL  (1u << 2)
#define EFB_SPICR2_CPHA  (1u << 1)
#define EFB_SPICR2_LSBF  (1u << 0)
/* SPISR */
#define EFB_SPISR_TIP    (1u << 7)
#define EFB_SPISR_TRDY   (1u << 4)
#define EFB_SPISR_RRDY   (1u << 3)
#define EFB_SPISR_ROE    (1u << 1)
#define EFB_SPISR_MDF    (1u << 0)

/* SPIBR: SCK = 12 MHz / (DIVIDER + 1) = 1.5 MHz. SPICR2[MCSH] may only be used
   when the WISHBONE clock is divided by more than 4 (FPGA-IPUG-02287 Table 5.15). */
#define EFB_SPIBR_DIVIDER 7u

/* SPICSR value selecting chip-select 0 (active low); 0xFF deselects all */
#define EFB_SPICSR_CS0   0xFEu
#define EFB_SPICSR_NONE  0xFFu

#define EFB_SPI_OK       0
#define EFB_SPI_TIMEOUT  (-1)

/* Status-poll bound per byte: one byte at SCK = 1.5 MHz is about 5 us,
   so this guards against a hung controller, not a slow one. */
#define EFB_SPI_POLL_LIMIT 100000u

/* SPISR reads after deselect to hold CS high (about 10 us at 12 MHz,
   15 SCK periods at 1.5 MHz) */
#define EFB_SPI_CS_HIGH_LOOPS 30u

void efb_spi_init(uint32_t base);
/* Hold CS0 low for a multi-byte transaction (SPICR2.MCSH) */
int efb_spi_select(void);
/* Full-duplex one-byte exchange; rx may be NULL */
int efb_spi_xfer(uint8_t tx, uint8_t *rx);
/* Release CS0 and wait for the controller to go idle */
int efb_spi_deselect(void);
/* Single-byte command with chip select (e.g. 06h, 04h) */
int efb_spi_cmd1(uint8_t cmd);
/* Current SPISR value */
uint8_t efb_spi_status(void);
/* Print the wait that timed out and the SPI register contents */
void efb_spi_report(void);

#endif /* EFB_SPI_H_ */
