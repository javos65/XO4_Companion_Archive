#include <stdint.h>
#include <stdio.h>
#include "app/efb_spi.h"

static uint32_t efb_base;

static inline uint32_t efb_rd(uint32_t off)
{
    return *(volatile uint32_t *)(efb_base + off) & 0xFFu;
}

static inline void efb_wr(uint32_t off, uint32_t v)
{
    *(volatile uint32_t *)(efb_base + off) = v & 0xFFu;
}

/* Diagnostics: the wait that timed out first, and SPISR at that moment */
static const char *fail_step;
static uint32_t fail_sr;

static int efb_wait_step(uint32_t mask, uint32_t want, const char *step)
{
    uint32_t sr = 0;
    for (uint32_t n = 0; n < EFB_SPI_POLL_LIMIT; n++) {
        sr = efb_rd(EFB_SPISR);
        if ((sr & mask) == want)
            return EFB_SPI_OK;
    }
    if (fail_step == 0) {
        fail_step = step;
        fail_sr = sr;
    }
    return EFB_SPI_TIMEOUT;
}

#define efb_wait(mask, want) efb_wait_step((mask), (want), #mask)

/* Single-byte command with chip select (e.g. 06h, 04h) */
int efb_spi_cmd1(uint8_t cmd)
{
    int rc = EFB_SPI_OK;
    uint8_t rx;

    if (efb_spi_select() != EFB_SPI_OK || efb_spi_xfer(cmd, &rx) != EFB_SPI_OK)
        rc = EFB_SPI_TIMEOUT;
    if (efb_spi_deselect() != EFB_SPI_OK)
        rc = EFB_SPI_TIMEOUT;
    return rc;
}

uint8_t efb_spi_status(void)
{
    return (uint8_t)efb_rd(EFB_SPISR);
}

void efb_spi_report(void)
{
    printf("  EFB SPI timeout waiting for %s, SPISR was %02X\n",
           fail_step ? fail_step : "(none)", (unsigned)fail_sr);
    printf("  SPICR0 %02X  SPICR1 %02X  SPICR2 %02X  SPIBR %02X  SPICSR %02X  SPISR %02X  SPIIRQEN %02X\n",
           (unsigned)efb_rd(EFB_SPICR0), (unsigned)efb_rd(EFB_SPICR1), (unsigned)efb_rd(EFB_SPICR2),
           (unsigned)efb_rd(EFB_SPIBR), (unsigned)efb_rd(EFB_SPICSR), (unsigned)efb_rd(EFB_SPISR),
           (unsigned)efb_rd(EFB_SPIIRQEN));
    printf("  (expected after init: SPICR1 80, SPICR2 80, SPIBR 07, SPICSR FE, SPISR 10)\n");
    fail_step = 0;
}

void efb_spi_init(uint32_t base)
{
    efb_base = base;
    /* Every write to SPICR0/1/2, SPIBR or SPICSR resets the SPI core
       (FPGA-IPUG-02287 Tables 5.13 to 5.17), so all of them are written here
       once, and a transaction only toggles SPICR2[MCSH] (Figure 7.13). */
    efb_wr(EFB_SPICR2, EFB_SPICR2_MSTR);      /* controller, mode 0, MSB first */
    efb_wr(EFB_SPIBR, EFB_SPIBR_DIVIDER);     /* MCSH needs a divider above 4 */
    efb_wr(EFB_SPICSR, EFB_SPICSR_CS0);       /* CS0 (CSSPIN) is the flash */
    efb_wr(EFB_SPICR1, EFB_SPICR1_SPE);
    (void)efb_rd(EFB_SPIRXDR);                /* drop any stale receive byte */
}

/* Transaction start exactly as the lscc_efb IP testbench (tb_tasks_spi.v,
   task spi_1write): CR2 <= C0, wait TRDY, then SPICSR <= chip select. The
   SPICR2 write resets the SPI core, so SPICSR is written after it on every
   transaction rather than once at init. */
int efb_spi_select(void)
{
    efb_wr(EFB_SPICR2, EFB_SPICR2_MSTR | EFB_SPICR2_MCSH);
    if (efb_wait(EFB_SPISR_TRDY, EFB_SPISR_TRDY) != EFB_SPI_OK)
        return EFB_SPI_TIMEOUT;
    efb_wr(EFB_SPICSR, EFB_SPICSR_CS0);
    return EFB_SPI_OK;
}

int efb_spi_xfer(uint8_t tx, uint8_t *rx)
{
    if (efb_wait(EFB_SPISR_TRDY, EFB_SPISR_TRDY) != EFB_SPI_OK)
        return EFB_SPI_TIMEOUT;
    efb_wr(EFB_SPITXDR, tx);
    if (efb_wait(EFB_SPISR_RRDY, EFB_SPISR_RRDY) != EFB_SPI_OK)
        return EFB_SPI_TIMEOUT;
    uint8_t v = (uint8_t)efb_rd(EFB_SPIRXDR);
    if (rx)
        *rx = v;
    return EFB_SPI_OK;
}

int efb_spi_deselect(void)
{
    /* testbench spi_1write: wait TRDY, CR2 <= 80, wait not TIP */
    int rc = efb_wait(EFB_SPISR_TRDY, EFB_SPISR_TRDY);
    efb_wr(EFB_SPICR2, EFB_SPICR2_MSTR);      /* clear MCSH: CS# goes high */
    if (efb_wait(EFB_SPISR_TIP, 0) != EFB_SPI_OK)
        rc = EFB_SPI_TIMEOUT;
    /* CS# high time before the next command (tSHSL >= 50 ns) */
    for (volatile uint32_t n = 0; n < EFB_SPI_CS_HIGH_LOOPS; n++)
        (void)efb_rd(EFB_SPISR);
    return rc;
}
