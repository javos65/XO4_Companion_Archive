#ifndef W25Q_H_
#define W25Q_H_

/* Winbond W25Q64JV serial NOR flash over the EFB SPI controller */

#include <stdint.h>

#define W25Q_CMD_WRITE_ENABLE  0x06u
#define W25Q_CMD_WRITE_DISABLE 0x04u
#define W25Q_CMD_READ_SR1      0x05u
#define W25Q_CMD_READ_DATA     0x03u
#define W25Q_CMD_PAGE_PROGRAM  0x02u
#define W25Q_CMD_SECTOR_ERASE  0x20u
#define W25Q_CMD_JEDEC_ID      0x9Fu

#define W25Q_SR1_BUSY          (1u << 0)
#define W25Q_SR1_WEL           (1u << 1)

#define W25Q_PAGE_SIZE         256u
#define W25Q_SECTOR_SIZE       4096u
#define W25Q64_SIZE            0x800000u

/* JEDEC ID of the W25Q64JV: manufacturer EF, memory type 40, capacity 17 */
#define W25Q64JV_JEDEC_ID      0xEF4017u

#define W25Q_OK                0
#define W25Q_ERR_SPI           (-1)
#define W25Q_ERR_TIMEOUT       (-2)
#define W25Q_ERR_ARG           (-3)
#define W25Q_ERR_WEL           (-4)

/* Status polls while BUSY: each poll is two SPI bytes (~4 us), so this
   bounds a wait at several seconds, above the 4 KB erase maximum. */
#define W25Q_BUSY_POLL_LIMIT   2000000u

int w25q_read_jedec_id(uint32_t *id);
int w25q_read_status(uint8_t *sr1);
int w25q_sector_erase(uint32_t addr);
int w25q_page_program(uint32_t addr, const uint8_t *buf, uint32_t len);
int w25q_read(uint32_t addr, uint8_t *buf, uint32_t len);

#endif /* W25Q_H_ */
