# Propel design script: XO4_FLS_MC
# Session: 386b89bd-871b-4b63-b2ce-1147138ed25b
# Mode: open

sbp_design open -name {XO4_FLS_MC} -path {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC/XO4_FLS_MC.sbx}

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}

sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4_FLS\fw\XO4_FLS_MC_fw\Debug\XO4_FLS_MC_fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:8192,BYTE_ENABLE_S0:True,BYTE_ENABLE_S1:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,EDIT_ADDRESS_S0:False,EDIT_ADDRESS_S1:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:2,REGMODE_S0:False,REGMODE_S1:False,RESET_MODE_S0:sync,RESET_MODE_S1:sync}
sbp_replace -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst} -component {XO4_FLS_MC/sysmem0_inst}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: XO4_FLS_MC"