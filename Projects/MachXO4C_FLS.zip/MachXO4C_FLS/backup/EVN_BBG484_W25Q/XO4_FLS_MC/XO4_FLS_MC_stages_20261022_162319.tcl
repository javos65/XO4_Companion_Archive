prj_open {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC.rdf}
prj_run_synthesis -forceOne
prj_run_map
prj_run_par
prj_run_bitstream
prj_save
prj_close
