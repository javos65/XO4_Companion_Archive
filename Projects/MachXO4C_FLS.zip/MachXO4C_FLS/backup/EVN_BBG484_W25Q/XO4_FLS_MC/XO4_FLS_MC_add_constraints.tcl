prj_open {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC.rdf}
prj_save
prj_close
