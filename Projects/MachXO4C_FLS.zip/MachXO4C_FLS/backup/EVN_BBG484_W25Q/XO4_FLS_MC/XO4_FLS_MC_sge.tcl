# PGE SGE script for XO4_FLS_MC
# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}
::ip_catalog::ip_catalog_location -add {C:\lscc\propel\2026.1.1\builder\rtf\ip}

sbp_design open -name {XO4_FLS_MC} -path {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC/XO4_FLS_MC.sbx}
sbp_design save
sbp_design generate
sbp_design save
set _sbxAbs [file normalize {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC/XO4_FLS_MC/XO4_FLS_MC.sbx}]
set _sgeAbs [file normalize {C:/lscc/workspace/MachXO4_FLS/XO4_FLS_MC}]
sbp_design pge sge -i $_sbxAbs -o $_sgeAbs -nc
puts "pge sge returned without error: XO4_FLS_MC"
exit