    $display("[%012t] ===== Flash Tests via User Interface =====", $time);

    //  Read Device ID
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'hE0);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[31:24]);
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[23:16]);
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[15:8]);
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[7:0]);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    $display("[%012t] --- Read Device ID Code Test Done (functional check only) ---", $time);
    