component efb0 is
    port(
        clk_i: in std_logic;
        rstn_i: in std_logic;
        apb_psel_i: in std_logic;
        apb_paddr_i: in std_logic_vector(9 downto 0);
        apb_pwdata_i: in std_logic_vector(31 downto 0);
        apb_pwrite_i: in std_logic;
        apb_penable_i: in std_logic;
        apb_pready_o: out std_logic;
        apb_prdata_o: out std_logic_vector(31 downto 0);
        apb_pslverr_o: out std_logic;
        int_o: out std_logic;
        spi_clk: inout std_logic;
        spi_miso: inout std_logic;
        spi_mosi: inout std_logic;
        spi_csn: out std_logic_vector(0 to 0);
        spi_scsn: in std_logic
    );
end component;

__: efb0 port map(
    clk_i=>,
    rstn_i=>,
    apb_psel_i=>,
    apb_paddr_i=>,
    apb_pwdata_i=>,
    apb_pwrite_i=>,
    apb_penable_i=>,
    apb_pready_o=>,
    apb_prdata_o=>,
    apb_pslverr_o=>,
    int_o=>,
    spi_clk=>,
    spi_miso=>,
    spi_mosi=>,
    spi_csn=>,
    spi_scsn=>
);
