    $display("[%012t] ===== Flash Tests via User Interface =====", $time);
 
    //  Read Status Register 0
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h3C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read_test(P_UFM_CFGRXDR, 8'h01);
    wb_read(P_UFM_CFGRXDR);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    $display("[%012t] --- Read Status Register 0 Test Done ---", $time);

    //  Read Status Register 1
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h3D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    $display("[%012t] --- Read Status Register 1 Test Done ---", $time);

    //  Read Device ID
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'hE0);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[31:24]);
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[23:16]);
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[15:8]);
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[7:0]);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    $display("[%012t] --- Read Device ID Code Test Done (functional check only) ---", $time);

    //  Read Feature Row
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'hC0);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read_test(P_UFM_CFGRXDR, 8'hAB);
    wb_read_test(P_UFM_CFGRXDR, 8'hCD);
    wb_read_test(P_UFM_CFGRXDR, 8'h12);
    wb_read_test(P_UFM_CFGRXDR, 8'h34);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    $display("[%012t] --- Read USERCODE (SRAM) Test Done ---", $time);

    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);

    //  Read Feature Row
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'hE7);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    $display("[%012t] --- Read Feature Row Test Done ---", $time);

    //  Read Feature Row
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'hC0);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    $display("[%012t] --- Read USERCODE (CFG) Test Done ---", $time);
