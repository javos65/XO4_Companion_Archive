    $display("[%012t] ===== UFM Tests via I2C =====", $time);
    
    // Device ID test
    fork
    i2c1_mstr_write_4data_open_read(P_I2C1_SLV_ADDR, 8'hE0, 8'h00, 8'h00, 8'h00, 0, 4);
    begin
        while(~i2c1_t_srw_r) @(posedge clk_gen_r);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != DEVICE_ID_TB[31:24];
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, DEVICE_ID_TB[7:0], i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != DEVICE_ID_TB[23:16];
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, DEVICE_ID_TB[15:8], i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != DEVICE_ID_TB[15:8];
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, DEVICE_ID_TB[23:16], i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != DEVICE_ID_TB[7:0];
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, DEVICE_ID_TB[31:24], i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
    end
    join
    $display("[%012t] --- Read Device ID Code Test Done (functional check only) ---", $time);
    
    // Write Test only if enough UFM pages
    if (P_UFM_INIT_PAGES > 2 && UFM_INIT_ALL_ZEROS == "ENABLED") begin
    
    // Enable Configuration Interface
    i2c1_mstr_write_3data(P_I2C1_SLV_ADDR, 8'h74, 8'h08, 8'h00, 0);
    #5_000; // Enable wait time
    
    // Set UFM Address (I2C is +2)
    i2c1_mstr_write_open(P_I2C1_SLV_ADDR, 0);
        //Start - Set Address to Start Page
        wbt_write(P_I2C1_TXDR, 8'hB4);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h40);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, {2'd0, P_UFM_WRITE_I2C[13:8]});
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, P_UFM_WRITE_I2C[7:0]);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        // Finish Write Address - I2C Stop
        wbt_write(P_I2C1_CMDR, 8'h44);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_busy_r == 1'b1)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
    
    i2c1_mstr_write_open(P_I2C1_SLV_ADDR, 0);
        //Start - Write Command - 1st Page
        wbt_write(P_I2C1_TXDR, 8'hC9);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        // Write Data
        wbt_write(P_I2C1_TXDR, 8'h20);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h21);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h22);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h23);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h24);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h25);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h26);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h27);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h28);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h29);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h2A);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h2B);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h2C);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h2D);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h2E);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h2F);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        // Finish Write 1st Page - I2C Stop
        wbt_write(P_I2C1_CMDR, 8'h44);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_busy_r == 1'b1)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
    // Wait Busy Flag
    while (i2c_ufm_busy_r) begin
      fork
        i2c1_mstr_write_4data_open_read(P_I2C1_SLV_ADDR, 8'hF0, 8'h00, 8'h00, 8'h00, 0, 1);
        #10_000;
        begin
            while(~i2c1_t_srw_r) @(posedge clk_gen_r);
            #P_I2C1_SCL_DLY;
            while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
            if (i2c_1_shift_reg_w == 8'h00)
                i2c_ufm_busy_r = 0;
            else
                i2c_ufm_busy_r = 1;
            #P_I2C1_SCL_DLY;
        end
      join
    end
    
    fork
    i2c1_mstr_write_4data_open_read(P_I2C1_SLV_ADDR, 8'hF0, 8'h00, 8'h00, 8'h00, 0, 1);
    begin
        while(~i2c1_t_srw_r) @(posedge clk_gen_r);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h00;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h00, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
    end
    join
    
    i2c1_mstr_write_open(P_I2C1_SLV_ADDR, 0);
        //Start - Write Command - 2nd Page
        wbt_write(P_I2C1_TXDR, 8'hC9);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        // Write Data
        wbt_write(P_I2C1_TXDR, 8'h30);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h31);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h32);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h33);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h34);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h35);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h36);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h37);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h38);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h39);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h3A);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h3B);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h3C);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h3D);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h3E);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h3F);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        // Finish Write 2nd Page - I2C Stop
        wbt_write(P_I2C1_CMDR, 8'h44);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_busy_r == 1'b1)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
    // Wait Busy Flag
    while (i2c_ufm_busy_r) begin
      fork
        i2c1_mstr_write_4data_open_read(P_I2C1_SLV_ADDR, 8'hF0, 8'h00, 8'h00, 8'h00, 0, 1);
        #10_000;
        begin
            while(~i2c1_t_srw_r) @(posedge clk_gen_r);
            #P_I2C1_SCL_DLY;
            while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
            if (i2c_1_shift_reg_w == 8'h00)
                i2c_ufm_busy_r = 0;
            else
                i2c_ufm_busy_r = 1;
            #P_I2C1_SCL_DLY;
        end
      join
    end
    
    fork
    i2c1_mstr_write_4data_open_read(P_I2C1_SLV_ADDR, 8'hF0, 8'h00, 8'h00, 8'h00, 0, 1);
    begin
        while(~i2c1_t_srw_r) @(posedge clk_gen_r);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h00;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h00, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
    end
    join
    
    // Disable Configuration Interface
    i2c1_mstr_write_3data(P_I2C1_SLV_ADDR, 8'h26, 8'h00, 8'h00, 0);
    
    // Bypass (NOP)
    i2c1_mstr_write_1data(P_I2C1_SLV_ADDR, 8'hFF, 0);
    
    $display("[%012t] --- UFM Write 2 Pages Done ---", $time);
    
     // Enable Configuration Interface
    i2c1_mstr_write_3data(P_I2C1_SLV_ADDR, 8'h74, 8'h08, 8'h00, 0);
    #5_000; // Enable wait time
    
    // Set UFM Address (I2C is +2)
    i2c1_mstr_write_open(P_I2C1_SLV_ADDR, 0);
        //Start - Set Address to Start Page
        wbt_write(P_I2C1_TXDR, 8'hB4);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h40);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, 8'h00);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, {2'd0, P_UFM_WRITE_I2C[13:8]});
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, P_UFM_WRITE_I2C[7:0]);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        // Finish Write Address - I2C Stop
        wbt_write(P_I2C1_CMDR, 8'h44);
        @(posedge clk_gen_r);
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_busy_r == 1'b1)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
    
    // Read Command
    fork
    i2c1_mstr_write_4data_open_read(P_I2C1_SLV_ADDR, 8'hCA, 8'h10, 8'h00, 8'h03, 0, 48);
    begin
        while(~i2c1_t_srw_r) @(posedge clk_gen_r);
        #P_I2C1_SCL_DLY;
        for (ii = 0; ii < 16; ii = ii + 1) begin   // Dummy page
            while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
            #P_I2C1_SCL_DLY;
        end
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h20;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h20, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h21;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h21, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h22;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h22, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h23;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h23, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h24;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h24, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h25;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h25, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h26;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h26, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h27;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h27, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h28;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h28, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h29;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h29, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h2A;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h2A, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h2B;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h2B, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h2C;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h2C, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h2D;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h2D, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h2E;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h2E, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h2F;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h2F, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h30;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h30, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h31;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h31, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h32;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h32, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h33;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h33, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h34;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h34, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h35;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h35, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h36;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h36, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h37;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h37, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h38;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h38, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h39;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h39, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h3A;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h3A, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h3B;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h3B, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h3C;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h3C, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h3D;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h3D, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h3E;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h3E, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
        while(i2c_1_shift_cnt_w != 8) @(posedge clk_gen_r);
        i2c_t_err_r = i2c_1_shift_reg_w != 8'h3F;
            if (i2c_t_err_r) $display("[%012t]   ### Configuration I2C Read Data Error - Expected: %h, Actual: %h", $time, 8'h3F, i2c_1_shift_reg_w);
        #P_I2C1_SCL_DLY;
    end
    join
    
    // Disable Configuration Interface
    i2c1_mstr_write_3data(P_I2C1_SLV_ADDR, 8'h26, 8'h00, 8'h00, 0);
    
    // Bypass (NOP)
    i2c1_mstr_write_1data(P_I2C1_SLV_ADDR, 8'hFF, 0);
    
    repeat(10) @ (posedge clk_gen_r);
    $display("[%012t] --- UFM Read 2 Pages Test Done ---", $time);
    
    end // UFM_INIT_ALL_ZEROS write 2 pages
    