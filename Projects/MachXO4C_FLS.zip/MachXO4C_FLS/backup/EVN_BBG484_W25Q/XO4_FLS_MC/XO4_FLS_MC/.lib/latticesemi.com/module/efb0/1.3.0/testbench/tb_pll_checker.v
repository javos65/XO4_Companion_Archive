`ifndef __TB_PLL_CHK__
`define __TB_PLL_CHK__

`timescale 1ps / 1ps
module tb_pll_checker #(
    parameter DEBUG = 1
)(
    input  wire pll_clk_i,
    input  wire rstn_i,
    input  wire enable_i,
    output reg  pll_chk_o
);

    reg [63:0] expected_period_ps = 10000; // 10ns = 10000ps
    reg [63:0] allowed_margin_ps  = 100;   // 0.1ns = 100ps

    reg [63:0] last_pll_edge_time = 0;
    reg [63:0] measured_period_ps = 0;

    task set_expected_period (
        input [63:0] period_ps,
        input [63:0] margin_ps
    );
        begin
          expected_period_ps = period_ps;
          allowed_margin_ps  = margin_ps;
        end
    endtask

    // Measure PLL period
    always @(posedge pll_clk_i or negedge rstn_i) begin
        if (!rstn_i) begin
            last_pll_edge_time <= 0;
            measured_period_ps <= 0;
        end
        else begin
            if (last_pll_edge_time != 0)
                measured_period_ps <= $time - last_pll_edge_time;
            last_pll_edge_time <= $time;
        end
    end
    
    always @(posedge pll_clk_i or negedge rstn_i) begin
        if (!rstn_i) begin
            pll_chk_o <= 1;
        end else if (enable_i) begin
            if (last_pll_edge_time != 0) begin
                if ((measured_period_ps >= (expected_period_ps - allowed_margin_ps)) &&
                    (measured_period_ps <= (expected_period_ps + allowed_margin_ps)))
                    pll_chk_o <= 1;
                else
                    pll_chk_o <= 0;
            end
        end
    end

    task pll_check;
        if (~pll_chk_o)
            $display("[%012t]   !!! PLL Period Check Fail !!! Measured: %0d ps, Expected: ~%0d ps", $time, measured_period_ps, expected_period_ps);
        else if (DEBUG)
            $display("[%012t]   ### PLL Period Check Pass ### Measured: %0d ps, Expected: ~%0d ps", $time, measured_period_ps, expected_period_ps);
    endtask

endmodule
`endif
