// =============================================================================
// >>>>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// -----------------------------------------------------------------------------
//   Copyright (c) 2025 by Lattice Semiconductor Corporation
//   ALL RIGHTS RESERVED
// -----------------------------------------------------------------------------
//
//   Permission:
//
//      Lattice SG Pte. Ltd. grants permission to use this code
//      pursuant to the terms of the Lattice Reference Design License Agreement.
//
//
//   Disclaimer:
//
//      This VHDL or Verilog source code is intended as a design reference
//      which illustrates how these types of functions can be implemented.
//      It is the user's responsibility to verify their design for
//      consistency and functionality through the use of formal
//      verification methods.  Lattice provides no warranty
//      regarding the use or functionality of this code.
//
// -----------------------------------------------------------------------------
//
//                  Lattice SG Pte. Ltd.
//                  101 Thomson Road, United Square #07-02
//                  Singapore 307591
//
//
//                  TEL: 1-800-Lattice (USA and Canada)
//                       +65-6631-2000 (Singapore)
//                       +1-503-268-8001 (other locations)
//
//                  web: http://www.latticesemi.com/
//                  email: techsupport@latticesemi.com
//
// -----------------------------------------------------------------------------
//
// =============================================================================
//                         FILE DETAILS
// Project               :
// File                  : tb_i2c_checker.v
// Title                 :
// Description           : 
// =============================================================================
//                        REVISION HISTORY
// Version               : 1.0.0.
// Author(s)             :
// Mod. Date             :
// Changes Made          : Initial release.
// =============================================================================

`ifndef __TB_I2C_CHK__
`define __TB_I2C_CHK__

`timescale 1ns / 1ps

module tb_i2c_checker (
    input               i2c1_scl_i,
    input               i2c1_sda_i,
    
    input               i2c2_scl_i,
    input               i2c2_sda_i,
    
    input               tx_1_flag_i,
    input               tx_2_flag_i,
    
    output reg [31:0]   i2c_1_tx_count_o,
    output reg [7:0]    i2c_1_shift_o,
    output reg [3:0]    i2c_1_shift_cnt_o,
    
    output reg [31:0]   i2c_2_tx_count_o,
    output reg [7:0]    i2c_2_shift_o,
    output reg [3:0]    i2c_2_shift_cnt_o
);

    reg i2c_1_rst;
    reg i2c_2_rst;

always @ (negedge i2c1_scl_i or posedge i2c_1_rst)
    if (i2c_1_rst)
        i2c_1_tx_count_o <= 0;
    else if (tx_1_flag_i)
        i2c_1_tx_count_o <= i2c_1_tx_count_o + 1;
        
always @ (negedge i2c1_sda_i)
    if (i2c1_scl_i)
        i2c_1_rst <= 1'b1;
    else
        i2c_1_rst <= 1'b0;

always @ (posedge i2c1_scl_i or posedge i2c_1_rst)
    if (i2c_1_rst)
        i2c_1_shift_o <= 8'h00;
    else
        i2c_1_shift_o <= {i2c_1_shift_o[6:0], i2c1_sda_i};

always @ (posedge i2c1_scl_i or posedge i2c_1_rst)
    if (i2c_1_rst)
        i2c_1_shift_cnt_o <= 4'd0;
    else if (i2c_1_shift_cnt_o >= 4'd8)
        i2c_1_shift_cnt_o <= 4'd0;
    else
        i2c_1_shift_cnt_o <= i2c_1_shift_cnt_o + 4'd1;
        
always @ (negedge i2c2_scl_i or posedge i2c_2_rst)
    if (i2c_2_rst)
        i2c_2_tx_count_o <= 0;
    else if (tx_2_flag_i)
        i2c_2_tx_count_o <= i2c_2_tx_count_o + 1;
        
always @ (negedge i2c2_sda_i)
    if (i2c2_scl_i)
        i2c_2_rst <= 1'b1;
    else
        i2c_2_rst <= 1'b0;

always @ (posedge i2c2_scl_i or posedge i2c_2_rst)
    if (i2c_2_rst)
        i2c_2_shift_o <= 8'h00;
    else
        i2c_2_shift_o <= {i2c_2_shift_o[6:0], i2c2_sda_i};

always @ (posedge i2c2_scl_i or posedge i2c_2_rst)
    if (i2c_2_rst)
        i2c_2_shift_cnt_o <= 4'd0;
    else if (i2c_2_shift_cnt_o >= 4'd8)
        i2c_2_shift_cnt_o <= 4'd0;
    else
        i2c_2_shift_cnt_o <= i2c_2_shift_cnt_o + 4'd1;

endmodule
`endif // __EFB_I2C_CHK__
