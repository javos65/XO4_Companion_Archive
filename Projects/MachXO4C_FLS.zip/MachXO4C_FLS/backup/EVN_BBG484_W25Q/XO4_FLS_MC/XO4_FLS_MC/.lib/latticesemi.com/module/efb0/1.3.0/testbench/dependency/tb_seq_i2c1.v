    if (EFB_WB_IN) begin
    $display("[%012t] ===== Primary I2C Tests as Controller =====", $time);
    i2c_tgt_1_inst.enable_check_on_rx();
    i2c_tgt_1_inst.set_expected_data(7'h00, 8'hF5);
    i2c1_write_1data(P_I2C1_SLV_MODEL, 8'hF5);
    repeat(10) @ (posedge clk_gen_r);
    
    i2c1_read_1data_test(P_I2C1_SLV_MODEL, 8'hF5);
    repeat(10) @ (posedge clk_gen_r);
    
    i2c_tgt_1_inst.set_expected_data(7'h00, 8'h11);
    i2c_tgt_1_inst.set_expected_data(7'h01, 8'h22);
    i2c_tgt_1_inst.set_expected_data(7'h02, 8'h33);
    i2c_tgt_1_inst.set_expected_data(7'h03, 8'h44);
    i2c1_write_4data(P_I2C1_SLV_MODEL, 8'h11, 8'h22, 8'h33, 8'h44);
    $display("[%012t] --- I2C Controller Write Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    i2c1_read_4data(P_I2C1_SLV_MODEL);
    $display("[%012t] --- I2C Controller Read Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);

    i2c_tgt_1_inst.set_expected_data(7'h00, 8'h5F);
    i2c1_1data_repeated_start(P_I2C1_SLV_MODEL, 8'h5F);
    $display("[%012t] --- Repeated Start Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    t_reset;
    
    i2c_tgt_1_inst.set_expected_data(7'h00, 8'hA6);
    i2c1_write_1data(P_I2C1_SLV_MODEL, 8'hA6);
    repeat(10) @ (posedge clk_gen_r);
    
    i2c1_read_1data_test(P_I2C1_SLV_MODEL, 8'hA6);
    repeat(10) @ (posedge clk_gen_r);
    
    // Change Prescale
    wb_write(P_I2C1_BR0, 8'hE7);
    wb_write(P_I2C1_BR1, 8'h03);
    i2c_tgt_1_inst.set_expected_data(7'h00, 8'hA7);
    i2c1_write_1data(P_I2C1_SLV_MODEL, 8'hA7);
    $display("[%012t] --- Clock Prescale Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    // Return config prescale
    wb_write(P_I2C1_BR0, P_I2C1_BR0_INIT);
    wb_write(P_I2C1_BR1, P_I2C1_BR1_INIT);
    repeat(10) @ (posedge clk_gen_r);
    end // EFB as Controller tests
    
    // EFB as Target Tests
    $display("[%012t] ===== Primary I2C Tests as Target =====", $time);
    if(I2C1_ADDRESSING == "10BIT")
        i2c1_mstr_write_1data(P_I2C1_SLV_ADDR[9:0], 8'hF5, 0);
    else
        i2c1_mstr_write_1data(P_I2C1_SLV_ADDR[6:0], 8'hF5, 0);
    // wb_read_test(P_I2C1_RXDR, 8'hF5);   // Confirm written data at RXDR
    $display("[%012t] --- I2C Target Write Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    if (EFB_WB_IN) begin
    wb_write(P_I2C1_TXDR, 8'hF5);
    if(I2C1_ADDRESSING == "10BIT")
        i2c1_mstr_read_1data(P_I2C1_SLV_ADDR[9:0], 8'hF5);
    else
        i2c1_mstr_read_1data(P_I2C1_SLV_ADDR[6:0], 8'hF5);
    $display("[%012t] --- I2C Target Read Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    i2c1_mstr_write_1data(0, 8'hF3, 1);
    if (I2C1_GEN_CALL == "ENABLED")
        wb_read_test(P_I2C1_GCDR, 8'hF3);   // Confirm written data at GCDR
    else
        wb_read_test(P_I2C1_GCDR, 8'h00);   // Confirm written data at GCDR
    
    $display("[%012t] --- General Call Enable Test Done ---", $time);
    end
    repeat(10) @ (posedge clk_gen_r);