$display("[%012t] ===== Timer/Counter Tests =====", $time);

if (TC_SCLK_SEL == "NCLOCK") tc_clk_sel_r = 1'b1;

#500;
tc_rstn_r = 1'b1;

if (P_TC_TOP_SET*P_TC_CCLK_SEL > P_TC_MAX_SIM) begin
    #1000;
    $display("[%012t] --- Static Configuration test excluded due to long simulation time ---", $time);
end
else if (P_TC_TOP_SET == 0 || P_TC_OCR_SET == 0) begin
    repeat (P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
    tc_chk_en_r = 1'b1;
    repeat (3) begin
        tb_tc_checker.set_exp_tc(0);
        repeat (P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
        tb_tc_checker.set_exp_tc(0);
        repeat (P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
    end
    $display("[%012t]   ### Timer/Counter Timeout - no assertion ###", $time);
    tc_chk_en_r = 1'b0;
    repeat(10) @ (posedge tcclk_gen_r);

    $display("[%012t] --- Static Configuration Check Done ---", $time);
end
else begin

// ============================================================================
// TC_MODE: CTCM (Clear Timer on Compare Match)
// ============================================================================
if (TC_MODE == "CTCM") begin    
        
    // ========================================================================
    // CTCM + STATIC
    // ========================================================================
    if (TC_OC_MODE == "STATIC") begin
        fork
        begin
            repeat (P_TC_TOP_SET*P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (3) begin
                repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);    // Static - no change

                repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON") begin
                tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    if (TC_OV_INT == "ON") begin
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                end
            end
            if (TC_ICR_INT == "ON") begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b1;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b0;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_int(1);
                tb_tc_checker.interr_check(1);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                // Clear interrupt
                tb_tc_checker.interr_check(0);
                wb_write(P_TCIRQ, 8'h04);
                @ (posedge tcclk_gen_r);

                tb_tc_checker.set_exp_int(0);
                tb_tc_checker.interr_check(1);
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.interr_check(0);
            end
        end
        join
    end
    
    // ========================================================================
    // CTCM + TOGGLE
    // ========================================================================
    else if (TC_OC_MODE == "TOGGLE") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(1);

            repeat (3) begin
                repeat (P_TC_TOP_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);

                repeat (P_TC_TOP_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end

        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON") begin
                tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    if (TC_OV_INT == "ON") begin
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                end
            end
            if (TC_ICR_INT == "ON") begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b1;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b0;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_int(1);
                tb_tc_checker.interr_check(1);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                // Clear interrupt
                tb_tc_checker.interr_check(0);
                wb_write(P_TCIRQ, 8'h04);
                @ (posedge tcclk_gen_r);

                tb_tc_checker.set_exp_int(0);
                tb_tc_checker.interr_check(1);
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.interr_check(0);
            end
        end
        join
    end
    
    // ========================================================================
    // CTCM + WAVE_GENERATOR
    // ========================================================================
    else if (TC_OC_MODE == "WAVE_GENERATOR") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(0);

            repeat (3) begin
                repeat (P_TC_TOP_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);

                repeat (P_TC_TOP_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end

        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON") begin
                tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    if (TC_OV_INT == "ON") begin
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                end
            end
            if (TC_ICR_INT == "ON") begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b1;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b0;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_int(1);
                tb_tc_checker.interr_check(1);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                // Clear interrupt
                tb_tc_checker.interr_check(0);
                wb_write(P_TCIRQ, 8'h04);
                @ (posedge tcclk_gen_r);

                tb_tc_checker.set_exp_int(0);
                tb_tc_checker.interr_check(1);
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.interr_check(0);
            end
        end
        join
    end
    
    // ========================================================================
    // CTCM + INV_WAVE_GENERATOR
    // ========================================================================
    else if (TC_OC_MODE == "INV_WAVE_GENERATOR") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (~tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(1);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(1);

            repeat (3) begin
                repeat (P_TC_TOP_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);

                repeat (P_TC_TOP_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end

        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON") begin
                tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    if (TC_OV_INT == "ON") begin
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                end
            end
            if (TC_ICR_INT == "ON") begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b1;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b0;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_int(1);
                tb_tc_checker.interr_check(1);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                // Clear interrupt
                tb_tc_checker.interr_check(0);
                wb_write(P_TCIRQ, 8'h04);
                @ (posedge tcclk_gen_r);

                tb_tc_checker.set_exp_int(0);
                tb_tc_checker.interr_check(1);
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.interr_check(0);
            end
        end
        join
    end
end

// ============================================================================
// TC_MODE: WATCHDOG
// ============================================================================
else if (TC_MODE == "WATCHDOG") begin    
        
    // ========================================================================
    // WATCHDOG + STATIC
    // ========================================================================
    if (TC_OC_MODE == "STATIC") begin
        fork
        begin
            repeat (P_TC_TOP_SET*P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (3) begin
                repeat (P_TC_TOP_SET+P_TC_OCR_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);    // Static - no change

                repeat (P_TC_TOP_SET+P_TC_OCR_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET+P_TC_OCR_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    if (TC_OV_INT == "ON") begin
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                end
            end
            if (TC_ICR_INT == "ON") begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b1;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b0;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_int(1);
                tb_tc_checker.interr_check(1);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                // Clear interrupt
                tb_tc_checker.interr_check(0);
                wb_write(P_TCIRQ, 8'h04);
                @ (posedge tcclk_gen_r);

                tb_tc_checker.set_exp_int(0);
                tb_tc_checker.interr_check(1);
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.interr_check(0);
            end
        end
        join
    end
    
    // ========================================================================
    // WATCHDOG + TOGGLE
    // ========================================================================
    else if (TC_OC_MODE == "TOGGLE") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(1);

            repeat (3) begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                    while (~tc_int && ~tc_timeout_w) begin
                        @ (posedge tcclk_gen_r);
                    end
                    tb_tc_checker.stop_timeout_counter();

                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat (P_TC_TOP_SET-P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                end
            end
            if (TC_ICR_INT == "ON") begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b1;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b0;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_int(1);
                tb_tc_checker.interr_check(1);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                // Clear interrupt
                tb_tc_checker.interr_check(0);
                wb_write(P_TCIRQ, 8'h04);
                @ (posedge tcclk_gen_r);

                tb_tc_checker.set_exp_int(0);
                tb_tc_checker.interr_check(1);
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.interr_check(0);
            end
        end
        join
    end
    
    // ========================================================================
    // WATCHDOG + WAVE_GENERATOR
    // ========================================================================
    else if (TC_OC_MODE == "WAVE_GENERATOR") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (3) begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                    while (~tc_int && ~tc_timeout_w) begin
                        @ (posedge tcclk_gen_r);
                    end
                    tb_tc_checker.stop_timeout_counter();

                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat (P_TC_TOP_SET-P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                end
            end
            if (TC_ICR_INT == "ON") begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b1;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b0;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_int(1);
                tb_tc_checker.interr_check(1);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                // Clear interrupt
                tb_tc_checker.interr_check(0);
                wb_write(P_TCIRQ, 8'h04);
                @ (posedge tcclk_gen_r);

                tb_tc_checker.set_exp_int(0);
                tb_tc_checker.interr_check(1);
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.interr_check(0);
            end
        end
        join
    end
    
    // ========================================================================
    // WATCHDOG + INV_WAVE_GENERATOR
    // ========================================================================
    else if (TC_OC_MODE == "INV_WAVE_GENERATOR") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (~tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(1);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (3) begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);
            end
            
            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                    while (~tc_int && ~tc_timeout_w) begin
                        @ (posedge tcclk_gen_r);
                    end
                    tb_tc_checker.stop_timeout_counter();

                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat (P_TC_TOP_SET-P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                end
            end
            if (TC_ICR_INT == "ON") begin
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b1;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tc_ic_r = 1'b0;
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_int(1);
                tb_tc_checker.interr_check(1);

                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                // Clear interrupt
                tb_tc_checker.interr_check(0);
                wb_write(P_TCIRQ, 8'h04);
                @ (posedge tcclk_gen_r);

                tb_tc_checker.set_exp_int(0);
                tb_tc_checker.interr_check(1);
                repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.interr_check(0);
            end
        end
        join
    end
end

// ============================================================================
// TC_MODE: FASTPWM
// ============================================================================
else if (TC_MODE == "FASTPWM") begin    
        
    // ========================================================================
    // FASTPWM + STATIC
    // ========================================================================
    if (TC_OC_MODE == "STATIC") begin
        fork
        begin
            repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (3) begin
                repeat (P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);    // Static - no change

                repeat (P_TC_TOP_SET-P_TC_OCR_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat (P_TC_TOP_SET-P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                end
            end
        end
        join
    end
    
    // ========================================================================
    // FASTPWM + TOGGLE
    // ========================================================================
    else if (TC_OC_MODE == "TOGGLE") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(0);

            repeat (P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(1);

            repeat (3) begin
                repeat (P_TC_TOP_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);

                repeat (P_TC_TOP_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat (P_TC_TOP_SET-P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                end
            end
        end
        join
    end
    
    // ========================================================================
    // FASTPWM + WAVE_GENERATOR
    // ========================================================================
    else if (TC_OC_MODE == "WAVE_GENERATOR") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (P_TC_OCR_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(1);

            repeat (3) begin
                repeat (P_TC_TOP_SET-P_TC_OCR_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);

                repeat (P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat (P_TC_TOP_SET-P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                end
            end
        end
        join
    end
    
    // ========================================================================
    // FASTPWM + INV_WAVE_GENERATOR
    // ========================================================================
    else if (TC_OC_MODE == "INV_WAVE_GENERATOR") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (~tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(1);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (P_TC_OCR_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(0);

            repeat (3) begin
                repeat (P_TC_TOP_SET-P_TC_OCR_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);

                repeat (P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat (P_TC_TOP_SET-P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h01);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                end
            end
        end
        join
    end
end

// ============================================================================
// TC_MODE: PFCPWM (Phase-Frequency Correct PWM)
// ============================================================================
else if (TC_MODE == "PFCPWM") begin    
        
    // ========================================================================
    // PFCPWM + STATIC
    // ========================================================================
    if (TC_OC_MODE == "STATIC") begin
        fork
        begin
            repeat (P_TC_TOP_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (3) begin
                repeat (P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);    // Static - no change

                repeat (P_TC_TOP_SET-P_TC_OCR_SET) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                tb_tc_checker.start_timeout_counter((P_TC_TOP_SET+P_TC_OCR_SET)*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat(P_TC_TOP_SET*2-1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_TOP_SET*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat ((P_TC_TOP_SET-P_TC_OCR_SET)*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h03);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                end
            end
        end
        join
    end
    
    // ========================================================================
    // PFCPWM + TOGGLE
    // ========================================================================
    else if (TC_OC_MODE == "TOGGLE") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (P_TC_OCR_SET+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(1);

            repeat ((P_TC_TOP_SET-P_TC_OCR_SET)*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(0);

            repeat (3) begin
                repeat (P_TC_OCR_SET*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);

                repeat ((P_TC_TOP_SET-P_TC_OCR_SET)*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                tb_tc_checker.start_timeout_counter((P_TC_TOP_SET+P_TC_OCR_SET)*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET*2-1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_TOP_SET*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat ((P_TC_TOP_SET-P_TC_OCR_SET)*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h03);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                end
            end
        end
        join
    end
    
    // ========================================================================
    // PFCPWM + WAVE_GENERATOR
    // ========================================================================
    else if (TC_OC_MODE == "WAVE_GENERATOR") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(0);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (P_TC_TOP_SET+(P_TC_TOP_SET-P_TC_OCR_SET)+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(1);

            repeat (3) begin
                repeat (P_TC_OCR_SET*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);

                repeat ((P_TC_TOP_SET-P_TC_OCR_SET)*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                tb_tc_checker.start_timeout_counter((P_TC_TOP_SET+P_TC_OCR_SET)*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat (P_TC_TOP_SET*2-1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);

                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_TOP_SET*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat ((P_TC_TOP_SET-P_TC_OCR_SET)*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h03);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                end
            end
        end
        join
    end
    
    // ========================================================================
    // PFCPWM + INV_WAVE_GENERATOR
    // ========================================================================
    else if (TC_OC_MODE == "INV_WAVE_GENERATOR") begin
        fork
        begin
            tb_tc_checker.start_timeout_counter(P_TC_TOP_SET*P_TC_CCLK_SEL*2);
            while (~tc_oc && ~tc_timeout_w) begin
                @ (posedge tcclk_gen_r);
            end
            tb_tc_checker.stop_timeout_counter();
            
            tb_tc_checker.set_exp_tc(1);
            tc_chk_en_r = 1'b1;
            tb_tc_checker.timer_check(1);

            repeat (P_TC_TOP_SET+(P_TC_TOP_SET-P_TC_OCR_SET)+1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
            repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
            tb_tc_checker.set_exp_tc(0);

            repeat (3) begin
                repeat (P_TC_OCR_SET*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(1);

                repeat ((P_TC_TOP_SET-P_TC_OCR_SET)*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                tb_tc_checker.set_exp_tc(0);
            end

            tc_chk_en_r = 1'b0;
            tb_tc_checker.timer_check(0);
        end
        begin
            if (TC_OVERFLOW == "ENABLED" || TC_OV_INT == "ON" || TC_OCR_INT == "ON") begin
                tb_tc_checker.start_timeout_counter((P_TC_TOP_SET+P_TC_OCR_SET)*P_TC_CCLK_SEL*2);
                while (~tc_int && ~tc_timeout_w) begin
                    @ (posedge tcclk_gen_r);
                end
                tb_tc_checker.stop_timeout_counter();
                
                if (TC_OVERFLOW == "ENABLED") begin
                    tb_tc_checker.set_exp_int(1);

                    repeat(P_TC_CCLK_SEL-1) @ (posedge tcclk_gen_r);
                    tb_tc_checker.set_exp_int(0);
                    tb_tc_checker.interr_check(1);

                    repeat (6) begin
                        repeat(P_TC_TOP_SET*2-1) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(0);
                    end
                end
                else if (EFB_TC_PORTMODE == "WB") begin
                    // Clear interrupt
                    tb_tc_checker.interr_check(0);
                    wb_write(P_TCIRQ, 8'h03);
                    @ (posedge tcclk_gen_r);
                    
                    if (TC_OCR_INT == "ON") begin
                        repeat (P_TC_OCR_SET+2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h02);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                    repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                    if (TC_OV_INT == "ON") begin
                        if (TC_OCR_INT == "OFF") repeat (P_TC_TOP_SET*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        repeat ((P_TC_TOP_SET-P_TC_OCR_SET)*2) repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.set_exp_int(1);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);

                        // Clear interrupt
                        tb_tc_checker.interr_check(0);
                        wb_write(P_TCIRQ, 8'h03);
                        @ (posedge tcclk_gen_r);

                        tb_tc_checker.set_exp_int(0);
                        tb_tc_checker.interr_check(1);
                        repeat(P_TC_CCLK_SEL) @ (posedge tcclk_gen_r);
                        tb_tc_checker.interr_check(0);
                        
                    end
                end
            end
        end
        join
    end
end

tc_chk_en_r = 1'b0;
repeat(10) @ (posedge tcclk_gen_r);

$display("[%012t] --- Static Configuration Check Done ---", $time);
end

if (EFB_TC_PORTMODE == "WB") begin
    tc_clk_sel_r = 1'b0;
    repeat(500) @ (posedge tcclk_gen_r);
    
    wb_write(P_TCIRQ, 8'h0F);
    repeat(10) @ (posedge tcclk_gen_r);
    
    // Re-configuration
    wb_write(P_TCCR0, 8'h90);       // Pre-scale 8
    wb_write(P_TCCR1, 8'h34);       // Toggle on Top Match, WDT
    wb_write(P_TCTOPSET0, 8'h88);   // TOP 5000 (0x1388)
    wb_write(P_TCTOPSET1, 8'h13);   // 
    wb_write(P_TCOCRSET0, 8'hA0);   // OCR 4000 (0x0FA0)
    wb_write(P_TCOCRSET1, 8'h0F);   // 
    wb_write(P_TCIRQEN, 8'h04);     // Enable Capture Counter interrupt
    repeat(10) @ (posedge tcclk_gen_r);
    
    tc_rstn_r = 1'b0;
    repeat(10) @ (posedge tcclk_gen_r);
    tc_rstn_r = 1'b1;
    
    repeat(2500) @ (posedge tcclk_gen_r);  // 2500 cycles before capture / 8 -> 312 (0x138) 

    tc_ic_r = 1'b1;
    repeat (8) @ (posedge tcclk_gen_r);
    tc_ic_r = 1'b0;
    repeat (8) @ (posedge tcclk_gen_r);
    
    wb_read_test(P_TCICR0, 8'h36);      // Capture value (0x136 actual)
    wb_read_test(P_TCICR1, 8'h01);      
    tb_tc_checker.interr_check(1);
    tb_tc_checker.set_exp_int(1);

    repeat (8) @ (posedge tcclk_gen_r);
    tb_tc_checker.interr_check(0);

    wb_read_test(P_TCIRQ, 8'h04);       // Read Flag
    wb_write(P_TCIRQ, 8'h04);           // Clear Flag
    tb_tc_checker.interr_check(1);
    tb_tc_checker.set_exp_int(0);

    repeat (8) @ (posedge tcclk_gen_r);
    tb_tc_checker.interr_check(0);

    // Re-configuration
    wb_write(P_TCCR0, 8'hA8);       // Pre-scale 1024
    wb_write(P_TCCR1, 8'h3A);       // Clear on TOP Match, Set on OCR Match, FPWM
    wb_write(P_TCTOPSET0, 8'h0A);   // TOP 10 (0x000A)
    wb_write(P_TCTOPSET1, 8'h00);   // 
    wb_write(P_TCOCRSET0, 8'h02);   // OCR 2 (0x0002)
    wb_write(P_TCOCRSET1, 8'h00);   // 
    wb_write(P_TCIRQEN, 8'h02);     // Enable OCR OVF interrupts

    tc_rstn_r = 1'b0;
    repeat(10) @ (posedge tcclk_gen_r);
    tc_rstn_r = 1'b1;
    
    repeat (3) repeat(1024) @ (posedge tcclk_gen_r);
    tb_tc_checker.interr_check(1);
    tb_tc_checker.set_exp_int(1);
    
    wb_read_test(P_TCIRQ, 8'h02);       // Read Flag
    wb_write(P_TCIRQ, 8'h02);           // Clear Flag
    tb_tc_checker.interr_check(1);
    tb_tc_checker.set_exp_int(0);

    repeat(10) @ (posedge tcclk_gen_r);
    tb_tc_checker.interr_check(0);
    
    wb_write(P_TCIRQEN, 8'h01);         // Enable OCR OVF interrupts
    repeat (2) repeat(1024) @ (posedge tcclk_gen_r);
    tb_tc_checker.interr_check(1);
    tb_tc_checker.set_exp_int(0);

    repeat(10) @ (posedge tcclk_gen_r);
    tb_tc_checker.interr_check(0);

    repeat (10) repeat(1024) @ (posedge tcclk_gen_r);
    tb_tc_checker.interr_check(1);
    tb_tc_checker.set_exp_int(1);
    
    repeat(10) @ (posedge tcclk_gen_r);
    tb_tc_checker.interr_check(0);

    wb_read_test(P_TCIRQ, 8'h03);       // Read Flag
    wb_write(P_TCIRQ, 8'h03);           // Clear Flag
    tb_tc_checker.interr_check(1);
    tb_tc_checker.set_exp_int(0);

    repeat(10) @ (posedge tcclk_gen_r);
    tb_tc_checker.interr_check(0);

    $display("[%012t] --- Dynamic Re-configuration Check Done ---", $time);
    
end
