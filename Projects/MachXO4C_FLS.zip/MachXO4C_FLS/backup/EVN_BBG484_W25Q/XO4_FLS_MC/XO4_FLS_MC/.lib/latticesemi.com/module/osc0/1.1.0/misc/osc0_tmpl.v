    osc0 __(.stdby_i( ),
        .clk_out_o( ),
        .sedstdby_o( ));
