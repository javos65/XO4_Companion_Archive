// =============================================================================
// >>>>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// -----------------------------------------------------------------------------
//   Copyright (c) 2025 by Lattice Semiconductor Corporation
//   ALL RIGHTS RESERVED
// -----------------------------------------------------------------------------
//
//   Permission:
//
//      Lattice SG Pte. Ltd. grants permission to use this code
//      pursuant to the terms of the Lattice Reference Design License Agreement.
//
//
//   Disclaimer:
//
//      This VHDL or Verilog source code is intended as a design reference
//      which illustrates how these types of functions can be implemented.
//      It is the user's responsibility to verify their design for
//      consistency and functionality through the use of formal
//      verification methods.  Lattice provides no warranty
//      regarding the use or functionality of this code.
//
// -----------------------------------------------------------------------------
//
//                  Lattice SG Pte. Ltd.
//                  101 Thomson Road, United Square #07-02
//                  Singapore 307591
//
//
//                  TEL: 1-800-Lattice (USA and Canada)
//                       +65-6631-2000 (Singapore)
//                       +1-503-268-8001 (other locations)
//
//                  web: http://www.latticesemi.com/
//                  email: techsupport@latticesemi.com
//
// -----------------------------------------------------------------------------
//
// =============================================================================
//                         FILE DETAILS
// Project               :
// File                  : tb_wb2apb.v
// Title                 :
// Description           : 
// =============================================================================
//                        REVISION HISTORY
// Version               : 1.0.0.
// Author(s)             :
// Mod. Date             :
// Changes Made          : Initial release.
// =============================================================================

`ifndef __TB_WB2APB__
`define __TB_WB2APB__

`timescale 1ns / 1ps

module tb_wb2apb (
    // WISHBONE interface
    input  wire        wb_clk_i,
    input  wire        wb_rst_i,
    input  wire        wb_cyc_i,
    input  wire        wb_stb_i,
    input  wire        wb_we_i,
    input  wire [7:0]  wb_adr_i,
    input  wire [7:0]  wb_dat_i,
    output reg  [7:0]  wb_dat_o,
    output reg         wb_ack_o,

    // APB interface
    output reg         apb_penable_i,
    output reg         apb_psel_i,
    output reg         apb_pwrite_i,
    output reg  [7:0]  apb_paddr_i,
    output reg  [7:0]  apb_pwdata_i,
    input  wire        apb_pready_o,
    input  wire [7:0]  apb_prdata_o,
    output wire        apb_pslverr_o
);

    // APB slave error is always 0
    assign apb_pslverr_o = 1'b0;

    // State encoding
    localparam IDLE   = 2'b00;
    localparam SETUP  = 2'b01;
    localparam ACCESS = 2'b10;

    reg [1:0] state, next_state;

    // State transition
    always @(posedge wb_clk_i or posedge wb_rst_i) begin
        if (wb_rst_i)
            state <= IDLE;
        else
            state <= next_state;
    end

    // Next state logic
    always @(*) begin
        case (state)
            IDLE:   next_state = (wb_cyc_i && wb_stb_i) ? SETUP : IDLE;
            SETUP:  next_state = ACCESS;
            ACCESS: next_state = (apb_pready_o) ? IDLE : ACCESS;
            default: next_state = IDLE;
        endcase
    end

    // Latch address and data during SETUP
    reg [7:0] latched_addr;
    reg [7:0] latched_data;

    always @(posedge wb_clk_i or posedge wb_rst_i) begin
        if (wb_rst_i) begin
            latched_addr <= 8'b0;
            latched_data <= 8'b0;
        end else if (state == SETUP) begin
            latched_addr <= wb_adr_i;
            latched_data <= wb_dat_i;
        end
    end

    // Simple APB handshake: assert PSEL and PENABLE immediately when WB transaction is detected,
    // hold until PREADY, then assert WB_ACK for one cycle.
    always @(posedge wb_clk_i or posedge wb_rst_i) begin
        if (wb_rst_i) begin
            apb_psel_i    <= 1'b0;
            apb_penable_i <= 1'b0;
            apb_pwrite_i  <= 1'b0;
            apb_paddr_i   <= 8'b0;
            apb_pwdata_i  <= 8'b0;
            wb_ack_o      <= 1'b0;
            wb_dat_o      <= 8'b0;
        end else begin
            if (wb_ack_o) begin
                // Clear handshake after acknowledge
                apb_psel_i    <= 1'b0;
                apb_penable_i <= 1'b0;
                wb_ack_o      <= 1'b0;
            end else if (wb_cyc_i && wb_stb_i && !apb_psel_i) begin
                // Start new transaction
                apb_psel_i    <= 1'b1;
                apb_penable_i <= 1'b1;
                apb_pwrite_i  <= wb_we_i;
                apb_paddr_i   <= wb_adr_i;
                apb_pwdata_i  <= wb_dat_i;
                wb_ack_o      <= 1'b0;
            end else if (apb_psel_i && apb_penable_i && apb_pready_o) begin
                // Transaction complete, assert WB_ACK and clear APB handshake
                wb_ack_o      <= 1'b1;
                wb_dat_o      <= apb_prdata_o;
                apb_psel_i    <= 1'b0;
                apb_penable_i <= 1'b0;
                apb_pwrite_i  <= 1'b0;
            end
        end
    end

endmodule
`endif // __EFB_WB2APB__
