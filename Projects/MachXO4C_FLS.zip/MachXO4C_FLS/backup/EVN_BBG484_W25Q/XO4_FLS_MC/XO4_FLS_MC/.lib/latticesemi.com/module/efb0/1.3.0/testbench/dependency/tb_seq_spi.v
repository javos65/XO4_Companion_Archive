if (SPI_MODE == "BOTH") begin
    $display("[%012t] ===== SPI Tests as Controller =====", $time);
    spi_1write(0, 8'h50);
    if (SPI_CLK_INV == "DISABLED" || SPI_PHASE_ADJ == "DISABLED") begin
        if (SPI_LSB_FIRST == "DISABLED")
            wbt_read_test(P_SPIRXDR, 8'h50);
        else
            wbt_read_test(P_SPIRXDR, 8'h0A);
    end
    
    if (SPI_CS_NUM > 1) begin
    spi_tgt_1_inst.set_expected_data(8'h51);
    spi_cmd_1write(1, 8'h51);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 2) begin
    spi_tgt_2_inst.set_expected_data(8'h52);
    spi_cmd_1write(2, 8'h52);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 3) begin
    spi_tgt_3_inst.set_expected_data(8'h53);
    spi_cmd_1write(3, 8'h53);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 4) begin
    spi_tgt_4_inst.set_expected_data(8'h54);
    spi_cmd_1write(4, 8'h54);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 5) begin
    spi_tgt_5_inst.set_expected_data(8'h55);
    spi_cmd_1write(5, 8'h55);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 6) begin
    spi_tgt_6_inst.set_expected_data(8'h56);
    spi_cmd_1write(6, 8'h56);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 7) begin
    spi_tgt_7_inst.set_expected_data(8'h57);
    spi_cmd_1write(7, 8'h57);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    $display("[%012t] --- SPI Controller Write Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    // spi_cmd_1read(0, 8'h50); - EFB Controller (no Read checking)
    
    if (SPI_CS_NUM > 1) begin
    spi_cmd_1read(1, 8'h51);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 2) begin
    spi_cmd_1read(2, 8'h52);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 3) begin
    spi_cmd_1read(3, 8'h53);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 4) begin
    spi_cmd_1read(4, 8'h54);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 5) begin
    spi_cmd_1read(5, 8'h55);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 6) begin
    spi_cmd_1read(6, 8'h56);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    if (SPI_CS_NUM > 7) begin
    spi_cmd_1read(7, 8'h57);
    repeat(50) @ (posedge clk_gen_r);
    end
    
    $display("[%012t] --- SPI Controller Read Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
end
    
    $display("[%012t] ===== SPI Tests as Target =====", $time);
    spi_tst_1write(0, 8'h5A);
    wb_read_test(P_SPIRXDR, 8'h5A);
    repeat(50) @ (posedge clk_gen_r);
    
    $display("[%012t] --- SPI Target Access Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    wb_write(P_SPICR2, 8'h01);
    repeat(10) @ (posedge clk_gen_r);
    wbt_write(P_SPICR2, 8'h01);
    repeat(10) @ (posedge clk_gen_r);
    
    spi_tst_1write(0, 8'hCC);
    wb_read_test(P_SPIRXDR, 8'h33);
    repeat(50) @ (posedge clk_gen_r);
    
    wb_write(P_SPICR2, 8'h00);
    repeat(10) @ (posedge clk_gen_r);
    
    $display("[%012t] --- SPI Target LSBF Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
