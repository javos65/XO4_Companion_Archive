    $display("[%012t] ===== UFM Tests via User Interface =====", $time);
    
    // --- Read 1 Page
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Set UFM Address to Start Page
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hB4);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h40);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {2'b00, P_UFM_INIT_PAGE[13:8]});
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, P_UFM_INIT_PAGE[7:0]);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    if (UFM_INIT_ALL_ZEROS == "DISABLED") begin
        wb_read_test(P_UFM_CFGRXDR, 8'hFE);
        wb_read_test(P_UFM_CFGRXDR, 8'hDC);
        wb_read_test(P_UFM_CFGRXDR, 8'hBA);
        wb_read_test(P_UFM_CFGRXDR, 8'h98);
        wb_read_test(P_UFM_CFGRXDR, 8'h76);
        wb_read_test(P_UFM_CFGRXDR, 8'h54);
        wb_read_test(P_UFM_CFGRXDR, 8'h32);
        wb_read_test(P_UFM_CFGRXDR, 8'h10);
        wb_read_test(P_UFM_CFGRXDR, 8'h01);
        wb_read_test(P_UFM_CFGRXDR, 8'h23);
        wb_read_test(P_UFM_CFGRXDR, 8'h45);
        wb_read_test(P_UFM_CFGRXDR, 8'h67);
        wb_read_test(P_UFM_CFGRXDR, 8'h89);
        wb_read_test(P_UFM_CFGRXDR, 8'hAB);
        wb_read_test(P_UFM_CFGRXDR, 8'hCD);
        wb_read_test(P_UFM_CFGRXDR, 8'hEF);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (Memory File)---", $time);
    end // not UFM_INIT_ALL_ZEROS
    else begin
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (All 0's)---", $time);
    end
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Write Test only if enough UFM pages
    if (UFM_INIT_PAGES > 2) begin

    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    //--- Erase UFM
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Erase command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCB);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h80, 0);
    // Check UFM Status
    ufm_poll_status();
    
    while (cfg_ufm_busy_r) begin
        #1_000_000; // Erase wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    $display("[%012t] --- UFM Erase Test Done ---", $time);
    
    //--- Write 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset)
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h40);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'd0, P_UFM_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Write command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h02);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h04);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h05);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h06);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h07);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h09);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Write command to Address 0001
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h11);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h12);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h13);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h14);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h15);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h16);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h17);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h18);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h19);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Write 2 Pages Done ---", $time);
    
    // --- Read 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset)
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h40);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM_INIT_PAGE[23:16]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM_INIT_PAGE[15:8]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h01);
    wb_read_test(P_UFM_CFGRXDR, 8'h02);
    wb_read_test(P_UFM_CFGRXDR, 8'h03);
    wb_read_test(P_UFM_CFGRXDR, 8'h04);
    wb_read_test(P_UFM_CFGRXDR, 8'h05);
    wb_read_test(P_UFM_CFGRXDR, 8'h06);
    wb_read_test(P_UFM_CFGRXDR, 8'h07);
    wb_read_test(P_UFM_CFGRXDR, 8'h08);
    wb_read_test(P_UFM_CFGRXDR, 8'h09);
    wb_read_test(P_UFM_CFGRXDR, 8'h0A);
    wb_read_test(P_UFM_CFGRXDR, 8'h0B);
    wb_read_test(P_UFM_CFGRXDR, 8'h0C);
    wb_read_test(P_UFM_CFGRXDR, 8'h0D);
    wb_read_test(P_UFM_CFGRXDR, 8'h0E);
    wb_read_test(P_UFM_CFGRXDR, 8'h0F);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h10);
    wb_read_test(P_UFM_CFGRXDR, 8'h11);
    wb_read_test(P_UFM_CFGRXDR, 8'h12);
    wb_read_test(P_UFM_CFGRXDR, 8'h13);
    wb_read_test(P_UFM_CFGRXDR, 8'h14);
    wb_read_test(P_UFM_CFGRXDR, 8'h15);
    wb_read_test(P_UFM_CFGRXDR, 8'h16);
    wb_read_test(P_UFM_CFGRXDR, 8'h17);
    wb_read_test(P_UFM_CFGRXDR, 8'h18);
    wb_read_test(P_UFM_CFGRXDR, 8'h19);
    wb_read_test(P_UFM_CFGRXDR, 8'h1A);
    wb_read_test(P_UFM_CFGRXDR, 8'h1B);
    wb_read_test(P_UFM_CFGRXDR, 8'h1C);
    wb_read_test(P_UFM_CFGRXDR, 8'h1D);
    wb_read_test(P_UFM_CFGRXDR, 8'h1E);
    wb_read_test(P_UFM_CFGRXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Read 2 Pages Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);

    end
    