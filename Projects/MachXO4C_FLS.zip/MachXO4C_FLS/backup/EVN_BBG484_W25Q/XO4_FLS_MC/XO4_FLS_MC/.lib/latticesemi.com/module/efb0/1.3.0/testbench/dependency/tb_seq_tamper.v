    $display("[%012t] ===== Anti-Tamper Tests =====", $time);
    tamper_detect_in_r = 1'b0;
    #10_000;

    // Enable Configuration Interface (Transparent)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();

    // Program Flash Protect Key
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hF1);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h12);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h34);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h56);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h78);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h9A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hBC);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hDE);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hF0);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h21);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h43);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h65);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h87);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hA9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCB);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hED);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);

    $display("[%012t] --- Program Flash Protect Key Done ---", $time);

    // Read Flash Protect Key
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hF2);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h12);
    wb_read_test(P_UFM_CFGRXDR, 8'h34);
    wb_read_test(P_UFM_CFGRXDR, 8'h56);
    wb_read_test(P_UFM_CFGRXDR, 8'h78);
    wb_read_test(P_UFM_CFGRXDR, 8'h9A);
    wb_read_test(P_UFM_CFGRXDR, 8'hBC);
    wb_read_test(P_UFM_CFGRXDR, 8'hDE);
    wb_read_test(P_UFM_CFGRXDR, 8'h0F);
    wb_read_test(P_UFM_CFGRXDR, 8'hF0);
    wb_read_test(P_UFM_CFGRXDR, 8'h21);
    wb_read_test(P_UFM_CFGRXDR, 8'h43);
    wb_read_test(P_UFM_CFGRXDR, 8'h65);
    wb_read_test(P_UFM_CFGRXDR, 8'h87);
    wb_read_test(P_UFM_CFGRXDR, 8'hA9);
    wb_read_test(P_UFM_CFGRXDR, 8'hCB);
    wb_read_test(P_UFM_CFGRXDR, 8'hED);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);

    $display("[%012t] --- Read Flash Protect Key Test Pass ---", $time);

    tamper_detect_in_r = 1'b1;
    #10_000;
    
    // Read FEABITs
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFB);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);

    // Erase FEABITs
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h04);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00); // Fbits erase = XXXX_X100_XX00_0000_XXXX_XXXX
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h80, 0);
    // Check UFM Status
    ufm_poll_status();
    
    while (cfg_ufm_busy_r) begin
        #1_000_000; // Erase wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();

    // Program FEABITs
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hF8);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);

    $display("[%012t] --- Program FEABITs Done ---", $time);

    // Read FEABITs
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFB);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // wb_read_test(P_UFM_CFGRXDR, 8'h00);
    // wb_read_test(P_UFM_CFGRXDR, 8'h00);
    // wb_read_test(P_UFM_CFGRXDR, 8'h00);
    // wb_read_test(P_UFM_CFGRXDR, 8'h0E);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);

    $display("[%012t] --- Read FEABITs Done ---", $time);

    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);

    #1000;
    gsr_rstn_r  = 0;
    #500;
    pur_rstn_r  = 0;
    #500;
    rst_gen_r   = 1'b1;
    #1000;
    gsr_rstn_r  = 1;
    #500;
    pur_rstn_r  = 1;
    #500;
    rst_gen_r   = 1'b0;
    #200_000;

    $display("[%012t] --- POR Done ---", $time);
    #10_000;

    tamper_detect_in_r = 1'b1;
    #10_000;

    //  Read Device ID
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'hE0);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[31:24]);
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[23:16]);
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[15:8]);
    wb_read_test(P_UFM_CFGRXDR, DEVICE_ID_TB[7:0]);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);

    #10_000;

    tamper_detect_in_r = 1'b0;
    #10_000;

    $display("[%012t] --- Tamper Assert Test Done ---", $time);
