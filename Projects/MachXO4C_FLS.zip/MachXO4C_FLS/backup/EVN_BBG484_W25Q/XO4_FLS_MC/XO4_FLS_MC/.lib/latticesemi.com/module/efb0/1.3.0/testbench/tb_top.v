`ifndef __EFB_TB_TOP__
`define __EFB_TB_TOP__

`timescale 1ns / 1ps

module tb_top ( );

//----------------------------------------------------------------
// Parameters/Defines
//----------------------------------------------------------------
`include "dut_params.v"

localparam SYSCLK_PERIOD    = (1000/EFB_WB_CLK_FREQ_TB);
localparam UFM_WAIT_CYCLE   = (EFB_WB_CLK_FREQ_TB);

localparam P_I2C1_SCL_DLY   = (I2C1_BUS_PERF == "50kHz")?   20_000  :
                              (I2C1_BUS_PERF == "100kHz")?  10_000  :
                              (I2C1_BUS_PERF == "400kHz")?   2_500  : 2_500;
                              
localparam P_I2C2_SCL_DLY   = (I2C2_BUS_PERF == "50kHz")?   20_000  :
                              (I2C2_BUS_PERF == "100kHz")?  10_000  :
                              (I2C2_BUS_PERF == "400kHz")?   2_500  : 2_500;

localparam P_I2C1_SLV_ADDR  = str_to_bin(I2C1_SLAVE_ADDR);
localparam P_I2C2_SLV_ADDR  = str_to_bin(I2C2_SLAVE_ADDR);

localparam P_I2C1_CLK_DIV   = str_to_dec(I2C1_CLK_DIVIDER)-1;
localparam P_I2C2_CLK_DIV   = str_to_dec(I2C2_CLK_DIVIDER)-1;
localparam P_I2C1_BR0_INIT  = P_I2C1_CLK_DIV[7:0];
localparam P_I2C1_BR1_INIT  = P_I2C1_CLK_DIV[9:8];
localparam P_I2C2_BR0_INIT  = P_I2C2_CLK_DIV[7:0];
localparam P_I2C2_BR1_INIT  = P_I2C2_CLK_DIV[9:8];

localparam P_I2C1_SLV_MODEL = 7'h65;
localparam P_I2C2_SLV_MODEL = 7'h6A;

localparam P_SPI_BR_INIT    = str_to_dec(SPI_CLK_DIVIDER)-1;

localparam P_TC_PRESCALE    = (TC_CCLK_SEL == "0"   )? 0 :
                              (TC_CCLK_SEL == "1"   )? 1 :
                              (TC_CCLK_SEL == "8"   )? 2 :
                              (TC_CCLK_SEL == "64"  )? 3 :
                              (TC_CCLK_SEL == "256" )? 4 :
                              (TC_CCLK_SEL == "1024")? 5 : 7;
localparam P_TC_CLKEDGE     = (TC_SCLK_SEL == "NCLOCK"  | TC_SCLK_SEL == "NOSC"  )? 1'b1 : 1'b0;
localparam P_TC_CLKSEL      = (TC_SCLK_SEL == "POSC"    | TC_SCLK_SEL == "NOSC"  )? 1'b1 : 1'b0;
localparam P_TC_OCM         = (TC_OC_MODE == "STATIC")          ? 2'b00 : 
                              (TC_OC_MODE == "TOGGLE")          ? 2'b01 : 
                              (TC_OC_MODE == "WAVE_GENERATOR")  ? 2'b10 : 2'b11 ;
localparam P_TC_MODE        = (TC_MODE == "WATCHDOG")   ? 2'b00 : 
                              (TC_MODE == "CTCM")       ? 2'b01 : 
                              (TC_MODE == "FASTPWM")    ? 2'b10 : 2'b11 ;
localparam P_TC_TOP_SET     = str_to_dec(TC_TOP_SET);
localparam P_TC_OCR_SET     = str_to_dec(TC_OCR_SET);
localparam P_TC_CCLK_SEL    = str_to_dec(TC_CCLK_SEL);
localparam P_TC_OCR_TOGG    = P_TC_TOP_SET/P_TC_OCR_SET;
localparam P_TC_MAX_SIM     = 50_000_000;  // 500ms limit

localparam PLL_FREQ_IN      = 50.0      ;
localparam PLL_FREQ_STR     = "50.0"    ;
localparam PLL_REF_IN       = 20        ;
localparam TC_REF_IN        = 10        ;

localparam PLL0_CLKI_DIV    = 5         ;
localparam PLL0_CLKFB_DIV   = 12        ;
localparam PLL0_CLKA_FREQ   = "120.0"   ;
localparam PLL0_CLKA_DIV    = 5         ;
localparam PLL0_CLKA_CPHA   = 4         ;
localparam PLL0_CLKA_FPHA   = 0         ;
localparam PLL0_CLKB_FREQ   = "100.0"   ;
localparam PLL0_CLKB_DIV    = 6         ;
localparam PLL0_CLKB_CPHA   = 5         ;
localparam PLL0_CLKB_FPHA   = 0         ;

localparam PLL1_CLKI_DIV    = 5         ;
localparam PLL1_CLKFB_DIV   = 8         ;
localparam PLL1_CLKA_FREQ   = "80.0"    ;
localparam PLL1_CLKA_DIV    = 5         ;
localparam PLL1_CLKA_CPHA   = 4         ;
localparam PLL1_CLKA_FPHA   = 0         ;
localparam PLL1_CLKB_FREQ   = "50.0"    ;
localparam PLL1_CLKB_DIV    = 8         ;
localparam PLL1_CLKB_CPHA   = 7         ;
localparam PLL1_CLKB_FPHA   = 0         ;

// New PLL0 configurations
localparam PLL0_TEST_CLKI_DIV    = 1         ;
localparam PLL0_TEST_CLKFB_DIV   = 1         ;
localparam PLL0_TEST_CLKA_FREQ   = "50.0"    ;
localparam PLL0_TEST_CLKA_DIV    = 9         ;
localparam PLL0_TEST_CLKA_CPHA   = 8         ;
localparam PLL0_TEST_CLKA_FPHA   = 0         ;
localparam PLL0_TEST_CLKA_PHA    = "0-deg"   ;
localparam PLL0_TEST_CLKB_FREQ   = "75.0"    ;
localparam PLL0_TEST_CLKB_DIV    = 6         ;
localparam PLL0_TEST_CLKB_CPHA   = 5         ;
localparam PLL0_TEST_CLKB_FPHA   = 0         ;
localparam PLL0_TEST_CLKB_PHA    = "0-deg"   ;

// New PLL1 configurations
localparam PLL1_TEST_CLKI_DIV    = 5         ;
localparam PLL1_TEST_CLKFB_DIV   = 12        ;
localparam PLL1_TEST_CLKA_FREQ   = "120.0"   ;
localparam PLL1_TEST_CLKA_DIV    = 4         ;
localparam PLL1_TEST_CLKA_CPHA   = 3         ;
localparam PLL1_TEST_CLKA_FPHA   = 0         ;
localparam PLL1_TEST_CLKA_PHA    = "0-deg"   ;
localparam PLL1_TEST_CLKB_FREQ   = "60.0"    ;
localparam PLL1_TEST_CLKB_DIV    = 8         ;
localparam PLL1_TEST_CLKB_CPHA   = 7         ;
localparam PLL1_TEST_CLKB_FPHA   = 0         ;
localparam PLL1_TEST_CLKB_PHA    = "0-deg"   ;

localparam P_UFM_INIT_PAGE  = str_to_dec(UFM_INIT_START_PAGE);
localparam P_UFM_INIT_PAGES = str_to_dec(UFM_INIT_PAGES);
localparam P_UFM_WRITE_I2C  = P_UFM_INIT_PAGE + 2;
localparam P_UFM_WRITE_SPI  = P_UFM_INIT_PAGE + 4;

localparam P_CFG0_INIT_PAGE  = str_to_dec(CFG0_INIT_START_PAGE);
localparam P_CFG0_INIT_PAGES = str_to_dec(CFG0_INIT_PAGES);
localparam P_CFG0_WRITE_I2C  = P_CFG0_INIT_PAGE + 2;
localparam P_CFG0_WRITE_SPI  = P_CFG0_INIT_PAGE + 4;

localparam P_CFG1_INIT_PAGE  = str_to_dec(CFG1_INIT_START_PAGE);
localparam P_CFG1_INIT_PAGES = str_to_dec(CFG1_INIT_PAGES);
localparam P_CFG1_WRITE_I2C  = P_CFG1_INIT_PAGE + 2;
localparam P_CFG1_WRITE_SPI  = P_CFG1_INIT_PAGE + 4;

localparam P_UFM0_INIT_PAGE  = str_to_dec(UFM0_INIT_START_PAGE);
localparam P_UFM0_INIT_PAGES = str_to_dec(UFM0_INIT_PAGES);
localparam P_UFM0_WRITE_I2C  = P_UFM0_INIT_PAGE + 2;
localparam P_UFM0_WRITE_SPI  = P_UFM0_INIT_PAGE + 4;

localparam P_UFM1_INIT_PAGE  = str_to_dec(UFM1_INIT_START_PAGE);
localparam P_UFM1_INIT_PAGES = str_to_dec(UFM1_INIT_PAGES);
localparam P_UFM1_WRITE_I2C  = P_UFM1_INIT_PAGE + 2;
localparam P_UFM1_WRITE_SPI  = P_UFM1_INIT_PAGE + 4;

localparam P_UFM2_INIT_PAGE  = str_to_dec(UFM2_INIT_START_PAGE);
localparam P_UFM2_INIT_PAGES = str_to_dec(UFM2_INIT_PAGES);
localparam P_UFM2_WRITE_I2C  = P_UFM2_INIT_PAGE + 2;
localparam P_UFM2_WRITE_SPI  = P_UFM2_INIT_PAGE + 4;

localparam P_UFM3_INIT_PAGE  = str_to_dec(UFM3_INIT_START_PAGE);
localparam P_UFM3_INIT_PAGES = str_to_dec(UFM3_INIT_PAGES);
localparam P_UFM3_WRITE_I2C  = P_UFM3_INIT_PAGE + 2;
localparam P_UFM3_WRITE_SPI  = P_UFM3_INIT_PAGE + 4;

localparam P_UFM_SEL_WRITE_I2C =  (EFB_UFM3 == "ENABLED")? P_UFM3_WRITE_I2C :
                                  (EFB_UFM2 == "ENABLED")? P_UFM2_WRITE_I2C :
                                  (EFB_UFM1 == "ENABLED")? P_UFM1_WRITE_I2C :
                                  (EFB_UFM0 == "ENABLED")? P_UFM0_WRITE_I2C : 
                                  (EFB_CFG1 == "ENABLED")? P_CFG1_WRITE_I2C : 
                                  (EFB_CFG0 == "ENABLED")? P_CFG0_WRITE_I2C : 8'hFF;
localparam P_UFM_SEL_WRITE_SPI =  (EFB_UFM3 == "ENABLED")? P_UFM3_WRITE_SPI :
                                  (EFB_UFM2 == "ENABLED")? P_UFM2_WRITE_SPI :
                                  (EFB_UFM1 == "ENABLED")? P_UFM1_WRITE_SPI :
                                  (EFB_UFM0 == "ENABLED")? P_UFM0_WRITE_SPI : 
                                  (EFB_CFG1 == "ENABLED")? P_CFG1_WRITE_SPI : 
                                  (EFB_CFG0 == "ENABLED")? P_CFG0_WRITE_SPI : 8'hFF;
localparam P_UFM_SEL_INIT_PAGES = (EFB_UFM3 == "ENABLED")? P_UFM3_INIT_PAGES :
                                  (EFB_UFM2 == "ENABLED")? P_UFM2_INIT_PAGES :
                                  (EFB_UFM1 == "ENABLED")? P_UFM1_INIT_PAGES :
                                  (EFB_UFM0 == "ENABLED")? P_UFM0_INIT_PAGES : 
                                  (EFB_CFG1 == "ENABLED")? P_CFG1_INIT_PAGES : 
                                  (EFB_CFG0 == "ENABLED")? P_CFG0_INIT_PAGES : 1;
localparam P_UFM_SEL_ADDR_BIT =   (EFB_UFM3 == "ENABLED")? 4'b10_01 :
                                  (EFB_UFM2 == "ENABLED")? 4'b10_00 :
                                  (EFB_UFM1 == "ENABLED")? 4'b01_01 :
                                  (EFB_UFM0 == "ENABLED")? 4'b00_01 : 
                                  (EFB_CFG1 == "ENABLED")? 4'b01_00 : 
                                  (EFB_CFG0 == "ENABLED")? 4'b00_00 : 4'b11_11;

localparam DEBUG = 0;

//----------------------------------------------------------------
// Register and Wire Declarations
//----------------------------------------------------------------
reg         clk_gen_r   ;
reg         refclk_gen_r;
reg         tcclk_gen_r ;
reg         rst_gen_r   ;
reg         test_err_r  ;
reg         gsr_rstn_r  ;
reg         pur_rstn_r  ;

// Wishbone for EFB instance
reg         wb_cyc_r    ;
reg         wb_stb_r    ;
reg         wb_we_r     ;
reg  [7:0]  wb_adr_r    ;
reg  [7:0]  wb_dat_r    ;

wire        wb_clk_i    ;
wire        wb_rst_i    ;
wire        wb_cyc_i    ;
wire        wb_stb_i    ;
wire        wb_we_i     ;
wire [7:0]  wb_adr_i    ;
wire [7:0]  wb_dat_i    ;
wire [7:0]  wb_dat_o    ;
wire        wb_ack_o    ;

reg [7:0]   wb_test_r   ;
reg         wb_chk_r    ;

// APB signals
wire                        clk_i           ;
wire                        rstn_i          ;
wire                        apb_penable_i   ;
wire                        apb_psel_i      ;
wire                        apb_pwrite_i    ;
wire [APB_ADDR_WIDTH-1:0]   apb_paddr_i     ;
wire [7:0]                  apb_paddr_w     ;
wire [APB_DATA_WIDTH-1:0]   apb_pwdata_i    ;
wire [7:0]                  apb_pwdata_w    ;
wire                        apb_pready_o    ;
wire [APB_DATA_WIDTH:0]     apb_prdata_o    ;
wire [7:0]                  apb_prdata_w    ;
wire                        apb_pslverr_o   ;

// I2C for EFB instance
tri1        i2c1_scl        ;
tri1        i2c1_sda        ;
tri1        i2c2_scl        ;
tri1        i2c2_sda        ;

wire        ufm_sn          ;

wire        rx_1_flag_w     ;
wire        tx_1_flag_w     ;

wire        rx_2_flag_w     ;
wire        tx_2_flag_w     ;

reg         i2c_1_tip_r     ;
reg         i2c_1_busy_r    ;
reg         i2c_1_rarc_r    ;
reg         i2c_1_srw_r     ;
reg         i2c_1_arbl_r    ;
reg         i2c_1_trrdy_r   ;
reg         i2c_1_troe_r    ;
reg         i2c_1_hgc_r     ;

reg         i2c_2_tip_r     ;
reg         i2c_2_busy_r    ;
reg         i2c_2_rarc_r    ;
reg         i2c_2_srw_r     ;
reg         i2c_2_arbl_r    ;
reg         i2c_2_trrdy_r   ;
reg         i2c_2_troe_r    ;
reg         i2c_2_hgc_r     ;

wire [31:0] i2c_1_tx_count_w    ;
wire [7:0]  i2c_1_shift_reg_w   ;
wire [3:0]  i2c_1_shift_cnt_w   ;
reg         i2c_1_chk_r         ;

wire [31:0] i2c_2_tx_count_w    ;
wire        i2c_2_rst           ;
wire [7:0]  i2c_2_shift_reg_w   ;
wire [3:0]  i2c_2_shift_cnt_w   ;
reg         i2c_2_chk_r         ;

// SPI for EFB instance
tri0        spi_clk              ;
tri1        spi_mosi             ;
tri1        spi_miso             ;
wire        spi_scsn             ;
wire [7:0]  spi_csn              ;
wire [7:0]  spi_err_w ;

// Wishbone for EFB controller transactions
reg         wbt_cyc_r    ;
reg         wbt_stb_r    ;
reg         wbt_we_r     ;
reg  [7:0]  wbt_adr_r    ;
reg  [7:0]  wbt_dat_r    ;
reg         wbt_chk_r    ;

wire        wbt_clk_i    ;
wire        wbt_rst_i    ;
wire [7:0]  wbt_dat_o    ;
wire        wbt_ack_o    ;

reg         i2c1_t_tip_r     ;
reg         i2c1_t_busy_r    ;
reg         i2c1_t_rarc_r    ;
reg         i2c1_t_srw_r     ;
reg         i2c1_t_arbl_r    ;
reg         i2c1_t_trrdy_r   ;
reg         i2c1_t_troe_r    ;
reg         i2c1_t_hgc_r     ;

reg         i2c2_t_tip_r     ;
reg         i2c2_t_busy_r    ;
reg         i2c2_t_rarc_r    ;
reg         i2c2_t_srw_r     ;
reg         i2c2_t_arbl_r    ;
reg         i2c2_t_trrdy_r   ;
reg         i2c2_t_troe_r    ;
reg         i2c2_t_hgc_r     ;

// SPI
reg         spi_tip_r        ;
reg         spi_trdy_r       ;
reg         spi_rrdy_r       ;
reg         spi_roe_r        ;
reg         spi_mdf_r        ;
reg         ufm_sn_r         ;
wire        spi_scsn_w       ;

// SPI (EFB Instance)
reg         spi_t_tip_r      ;
reg         spi_t_trdy_r     ;
reg         spi_t_rrdy_r     ;
reg         spi_t_roe_r      ;
reg         spi_t_mdf_r      ;

// UFM access thru Wishbone
reg         cfg_sr_wbcact_r  ;
reg         cfg_sr_txfe_r    ;
reg         cfg_sr_txff_r    ;
reg         cfg_sr_rxfe_r    ;
reg         cfg_sr_rxff_r    ;
reg         cfg_sr_sspiact_r ;
reg         cfg_sr_i2cact_r  ;

reg         cfg_ufm_busy_r   ;
reg         i2c_ufm_busy_r   ;
reg         i2c_t_err_r      ;
reg         spi_ufm_busy_r   ;

// Timer-Counter Static
reg         tc_clk_sel_r    ;
wire        tc_clki         ;
wire        tc_rstn         ;
wire        tc_int          ;
wire        tc_ic           ;
wire        tc_oc           ;
reg         tc_ic_r         ;
reg         tc_rstn_r       ;
wire        tc_chk_tc_w     ;
wire        tc_chk_int_w    ;
wire        tc_timeout_w    ;
reg         tc_chk_en_r     ;

// PLL
wire        pll0_clkop_w    ;
wire        pll0_clkos_w    ;
wire        pll0_lock_w     ;
wire        pll0_ack_i      ;
wire [7:0]  pll0_dati_i     ;
wire        pll0_clk_o      ;
wire        pll0_rst_o      ;
wire [4:0]  pll0_addr_o     ;
wire [7:0]  pll0_dato_o     ;
wire        pll0_we_o       ;
wire        pll0_stb_o      ;
wire        pll1_clkop_w    ;
wire        pll1_clkos_w    ;
wire        pll1_lock_w     ;
wire        pll1_ack_i      ;
wire [7:0]  pll1_dati_i     ;
wire        pll1_clk_o      ;
wire        pll1_rst_o      ;
wire [4:0]  pll1_addr_o     ;
wire [7:0]  pll1_dato_o     ;
wire        pll1_we_o       ;
wire        pll1_stb_o      ;

wire [3:0]  pll_chk_w       ;
reg  [3:0]  pll_chk_en_r    ;

wire        tamper_detect_in    ;
wire        tamper_src_lock     ;
wire        tamper_detect_clk   ;
wire        tamper_detect       ;
wire [1:0]  tamper_type         ;
wire [1:0]  tamper_src          ;
reg         tamper_detect_in_r  ;
reg         tamper_src_lock_r   ;
reg         tamper_detect_clk_r ;

integer     ii, jj;

//----------------------------------------------------------------
// EFB Register Address Map
//----------------------------------------------------------------
localparam P_MC1_DIVFBK_FRAC_L      = 8'h00;
localparam P_MC1_DIVFBK_FRAC_H      = 8'h01;
localparam P_MC1_MC1_LOADREG        = 8'h02;
localparam P_MC1_DELA               = 8'h02;
localparam P_MC1_PLLPDN             = 8'h03;
localparam P_MC1_DELB               = 8'h03;
localparam P_MC1_WBRESET            = 8'h04;
localparam P_MC1_DELC               = 8'h04;
localparam P_MC1_USE_DESI           = 8'h05;
localparam P_MC1_DELD               = 8'h05;
localparam P_MC1_REFIN_RESET        = 8'h06;
localparam P_MC1_DIVA               = 8'h06;
localparam P_MC1_PLLRST_ENA         = 8'h07;
localparam P_MC1_DIVB               = 8'h07;
localparam P_MC1_MRST_ENA           = 8'h08;
localparam P_MC1_DIVC               = 8'h08;
localparam P_MC1_STDBY              = 8'h09;
localparam P_MC1_DIVD               = 8'h09;
localparam P_MC1_ENABLE_SYNC        = 8'h0A;
localparam P_MC1_PHIB               = 8'h0A;
localparam P_MC1_INT_LOCK_STICKY    = 8'h0A;
localparam P_MC1_PHIA               = 8'h0A;
localparam P_MC1_DCRST_ENA          = 8'h0B;
localparam P_MC1_PHID               = 8'h0B;
localparam P_MC1_RESERVED2          = 8'h0B;
localparam P_MC1_PHIC               = 8'h0B;
localparam P_MC1_DDRST_ENA          = 8'h0C;
localparam P_MC1_SEL_OUTB           = 8'h0C;
localparam P_MC1_INTFB              = 8'h0C;
localparam P_MC1_SEL_OUTA           = 8'h0C;
localparam P_MC1_LOCK               = 8'h0D;
localparam P_MC1_SEL_OUTC           = 8'h0D;
localparam P_MC1_SEL_OUTD           = 8'h0D;
localparam P_MC1_SEL_DIVA           = 8'h0E;
localparam P_MC1_SEL_DIVB           = 8'h0E;
localparam P_MC1_SEL_DIVC           = 8'h0E;
localparam P_MC1_SEL_DIVD           = 8'h0E;
localparam P_MC1_CLKOP_TRIM         = 8'h0F;
localparam P_MC1_CLKOS_TRIM         = 8'h0F;
localparam P_MC1_DYN_SOURCE         = 8'h10;
localparam P_MC1_LOCK_SEL           = 8'h10;
localparam P_MC1_ENABLE_CLK         = 8'h10;
localparam P_MC1_TRIMOS3_BYPASS_N   = 8'h11;
localparam P_MC1_TRIMOS2_BYPASS_N   = 8'h11;
localparam P_MC1_TRIMOS_BYPASS_N    = 8'h11;
localparam P_MC1_TRIMOP_BYPASS_N    = 8'h11;
localparam P_MC1_DYN_SEL            = 8'h11;
localparam P_MC1_DIRECTION          = 8'h11;
localparam P_MC1_ROTATE             = 8'h11;
localparam P_MC1_LF_RESGRND         = 8'h12;
localparam P_MC1_SEL_REF1           = 8'h12;
localparam P_MC1_EN_UP              = 8'h12;
localparam P_MC1_SEL_REF2           = 8'h12;
localparam P_MC1_DIVFBK_ORDER       = 8'h13;
localparam P_MC1_CLKMUX_FB          = 8'h13;
localparam P_MC1_SEL_FBK            = 8'h13;
localparam P_MC1_GMC_RESET          = 8'h14;
localparam P_MC1_DIVREF             = 8'h14;
localparam P_MC1_FORCE_VFILTER      = 8'h15;
localparam P_MC1_DIVFBK             = 8'h15;
localparam P_MC1_LF_PRESET          = 8'h16;
localparam P_MC1_LF_RESET           = 8'h16;
localparam P_MC1_TEST_ICP           = 8'h16;
localparam P_MC1_EN_FILTER_OPAMP    = 8'h16;
localparam P_MC1_FLOAT_ICP          = 8'h16;
localparam P_MC1_GPROG              = 8'h16;
localparam P_MC1_KPROG              = 8'h17;
localparam P_MC1_IPROG              = 8'h17;
localparam P_MC1_GMC_PRESET         = 8'h18;
localparam P_MC1_RPROG              = 8'h18;
localparam P_MC1_GMCREF_SEL         = 8'h19;
localparam P_MC1_MFGOUT2_SEL        = 8'h19;
localparam P_MC1_MFGOUT1_SEL        = 8'h19;
localparam P_MC1_GMCSEL             = 8'h1A;
localparam P_MC1_VCO_BYPASS_D0      = 8'h1A;
localparam P_MC1_VCO_BYPASS_C0      = 8'h1A;
localparam P_MC1_VCO_BYPASS_B0      = 8'h1A;
localparam P_MC1_VCO_BYPASS_A0      = 8'h1A;
localparam P_MC1_EN_PHI             = 8'h1B;
localparam P_MC1_DPROG              = 8'h1B;
localparam P_MC1_LOCK_STS           = 8'h1C;

localparam P_MC2_DIVFBK_FRAC_L      = 8'h20;
localparam P_MC2_DIVFBK_FRAC_H      = 8'h21;
localparam P_MC2_MC1_LOADREG        = 8'h22;
localparam P_MC2_DELA               = 8'h22;
localparam P_MC2_PLLPDN             = 8'h23;
localparam P_MC2_DELB               = 8'h23;
localparam P_MC2_WBRESET            = 8'h24;
localparam P_MC2_DELC               = 8'h24;
localparam P_MC2_USE_DESI           = 8'h25;
localparam P_MC2_DELD               = 8'h25;
localparam P_MC2_REFIN_RESET        = 8'h26;
localparam P_MC2_DIVA               = 8'h26;
localparam P_MC2_PLLRST_ENA         = 8'h27;
localparam P_MC2_DIVB               = 8'h27;
localparam P_MC2_MRST_ENA           = 8'h28;
localparam P_MC2_DIVC               = 8'h28;
localparam P_MC2_STDBY              = 8'h29;
localparam P_MC2_DIVD               = 8'h29;
localparam P_MC2_ENABLE_SYNC        = 8'h2A;
localparam P_MC2_PHIB               = 8'h2A;
localparam P_MC2_INT_LOCK_STICKY    = 8'h2A;
localparam P_MC2_PHIA               = 8'h2A;
localparam P_MC2_DCRST_ENA          = 8'h2B;
localparam P_MC2_PHID               = 8'h2B;
localparam P_MC2_RESERVED2          = 8'h2B;
localparam P_MC2_PHIC               = 8'h2B;
localparam P_MC2_DDRST_ENA          = 8'h2C;
localparam P_MC2_SEL_OUTB           = 8'h2C;
localparam P_MC2_INTFB              = 8'h2C;
localparam P_MC2_SEL_OUTA           = 8'h2C;
localparam P_MC2_LOCK               = 8'h2D;
localparam P_MC2_SEL_OUTC           = 8'h2D;
localparam P_MC2_SEL_OUTD           = 8'h2D;
localparam P_MC2_SEL_DIVA           = 8'h2E;
localparam P_MC2_SEL_DIVB           = 8'h2E;
localparam P_MC2_SEL_DIVC           = 8'h2E;
localparam P_MC2_SEL_DIVD           = 8'h2E;
localparam P_MC2_CLKOP_TRIM         = 8'h2F;
localparam P_MC2_CLKOS_TRIM         = 8'h2F;
localparam P_MC2_DYN_SOURCE         = 8'h30;
localparam P_MC2_LOCK_SEL           = 8'h30;
localparam P_MC2_ENABLE_CLK         = 8'h30;
localparam P_MC2_TRIMOS3_BYPASS_N   = 8'h31;
localparam P_MC2_TRIMOS2_BYPASS_N   = 8'h31;
localparam P_MC2_TRIMOS_BYPASS_N    = 8'h31;
localparam P_MC2_TRIMOP_BYPASS_N    = 8'h31;
localparam P_MC2_DYN_SEL            = 8'h31;
localparam P_MC2_DIRECTION          = 8'h31;
localparam P_MC2_ROTATE             = 8'h31;
localparam P_MC2_LF_RESGRND         = 8'h32;
localparam P_MC2_SEL_REF1           = 8'h32;
localparam P_MC2_EN_UP              = 8'h32;
localparam P_MC2_SEL_REF2           = 8'h32;
localparam P_MC2_DIVFBK_ORDER       = 8'h33;
localparam P_MC2_CLKMUX_FB          = 8'h33;
localparam P_MC2_SEL_FBK            = 8'h33;
localparam P_MC2_GMC_RESET          = 8'h34;
localparam P_MC2_DIVREF             = 8'h34;
localparam P_MC2_FORCE_VFILTER      = 8'h35;
localparam P_MC2_DIVFBK             = 8'h35;
localparam P_MC2_LF_PRESET          = 8'h36;
localparam P_MC2_LF_RESET           = 8'h36;
localparam P_MC2_TEST_ICP           = 8'h36;
localparam P_MC2_EN_FILTER_OPAMP    = 8'h36;
localparam P_MC2_FLOAT_ICP          = 8'h36;
localparam P_MC2_GPROG              = 8'h36;
localparam P_MC2_KPROG              = 8'h37;
localparam P_MC2_IPROG              = 8'h37;
localparam P_MC2_GMC_PRESET         = 8'h38;
localparam P_MC2_RPROG              = 8'h38;
localparam P_MC2_GMCREF_SEL         = 8'h39;
localparam P_MC2_MFGOUT2_SEL        = 8'h39;
localparam P_MC2_MFGOUT1_SEL        = 8'h39;
localparam P_MC2_GMCSEL             = 8'h3A;
localparam P_MC2_VCO_BYPASS_D0      = 8'h3A;
localparam P_MC2_VCO_BYPASS_C0      = 8'h3A;
localparam P_MC2_VCO_BYPASS_B0      = 8'h3A;
localparam P_MC2_VCO_BYPASS_A0      = 8'h3A;
localparam P_MC2_EN_PHI             = 8'h3B;
localparam P_MC2_DPROG              = 8'h3B;
localparam P_MC2_LOCK_STS           = 8'h3C;

localparam P_I2C1_CR            = 8'h40;
localparam P_I2C1_CMDR          = 8'h41;
localparam P_I2C1_BR0           = 8'h42;
localparam P_I2C1_BR1           = 8'h43;
localparam P_I2C1_TXDR          = 8'h44;
localparam P_I2C1_SR            = 8'h45;
localparam P_I2C1_GCDR          = 8'h46;
localparam P_I2C1_RXDR          = 8'h47;
localparam P_I2C1_IRQ           = 8'h48;
localparam P_I2C1_IRQEN         = 8'h49;
    
localparam P_I2C2_CR            = 8'h4A;
localparam P_I2C2_CMDR          = 8'h4B;
localparam P_I2C2_BR0           = 8'h4C;
localparam P_I2C2_BR1           = 8'h4D;
localparam P_I2C2_TXDR          = 8'h4E;
localparam P_I2C2_SR            = 8'h4F;
localparam P_I2C2_GCDR          = 8'h50;
localparam P_I2C2_RXDR          = 8'h51;
localparam P_I2C2_IRQ           = 8'h52;
localparam P_I2C2_IRQEN         = 8'h53;
    
localparam P_SPICR0             = 8'h54;
localparam P_SPICR1             = 8'h55;
localparam P_SPICR2             = 8'h56;
localparam P_SPIBR              = 8'h57;
localparam P_SPICSR             = 8'h58;
localparam P_SPITXDR            = 8'h59;
localparam P_SPISR              = 8'h5A;
localparam P_SPIRXDR            = 8'h5B;
localparam P_SPIIRQ             = 8'h5C;
localparam P_SPIIRQEN           = 8'h5D;
    
localparam P_TCCR0              = 8'h5E; 
localparam P_TCCR1              = 8'h5F;
localparam P_TCTOPSET0          = 8'h60;
localparam P_TCTOPSET1          = 8'h61;
localparam P_TCOCRSET0          = 8'h62;
localparam P_TCOCRSET1          = 8'h63;
localparam P_TCCR2              = 8'h64;
localparam P_TCCNT0             = 8'h65;
localparam P_TCCNT1             = 8'h66;
localparam P_TCTOP0             = 8'h67;
localparam P_TCTOP1             = 8'h68;
localparam P_TCOCR0             = 8'h69;
localparam P_TCOCR1             = 8'h6A;
localparam P_TCICR0             = 8'h6B;
localparam P_TCICR1             = 8'h6C;
localparam P_TCSR0              = 8'h6D;
localparam P_TCIRQ              = 8'h6E;
localparam P_TCIRQEN            = 8'h6F;
    
localparam P_UFM_CFGCR          = 8'h70;
localparam P_UFM_CFGTXDR        = 8'h71;
localparam P_UFM_CFGSR          = 8'h72;
localparam P_UFM_CFGRXDR        = 8'h73;
localparam P_UFM_CFGIRQ         = 8'h74;
localparam P_UFM_CFGIRQEN       = 8'h75;

//----------------------------------------------------------------
// Clock generation
//----------------------------------------------------------------
initial begin   // Wishbone Clock (Configurable)
  clk_gen_r = 1'b0;
  forever begin
    clk_gen_r = #(SYSCLK_PERIOD/2) ~clk_gen_r;
  end
end

initial begin   // 50MHz RefClk for PLL
  refclk_gen_r = 1'b0;
  forever begin
    refclk_gen_r = #(PLL_REF_IN/2) ~refclk_gen_r;
  end
end

initial begin   // 100MHz Clock for Timer/Counter
  tcclk_gen_r = 1'b0;
  forever begin
    tcclk_gen_r = #(TC_REF_IN/2) ~tcclk_gen_r;
  end
end

initial begin   // Tamper Detect Clock
  tamper_detect_clk_r = 1'b0;
  forever begin
    tamper_detect_clk_r = #(SYSCLK_PERIOD/2) ~tamper_detect_clk_r;
  end
end

//----------------------------------------------------------------
// Maximum Simulation Time
//----------------------------------------------------------------
`ifndef MAX_SIM_TIME
  `define MAX_SIM_TIME 10000
`endif
initial begin
  #(`MAX_SIM_TIME*1e6); // End simulation after 10s
  $stop;
end

//----------------------------------------------------------------
// Submodules
//----------------------------------------------------------------
`include "dut_inst.v"

assign wb_clk_i = clk_gen_r ;
assign wb_rst_i = rst_gen_r ;
assign wb_cyc_i = wb_cyc_r  ;
assign wb_stb_i = wb_stb_r  ;
assign wb_we_i  = wb_we_r   ;
assign wb_adr_i = wb_adr_r  ;
assign wb_dat_i = wb_dat_r  ;

assign clk_i    = clk_gen_r ;
assign rstn_i   = ~rst_gen_r;
assign ufm_sn   = (~ufm_sn_r)?  spi_scsn_w : 1'b1;

if (EFB_INTERFACE_IN == "APB") begin: _tb_wb2apb_

if (APB_DATA_WIDTH == 32) begin: _tb_apb32_
    assign apb_paddr_i    = {{(APB_ADDR_WIDTH-10){1'b0}}, apb_paddr_w[7:0], 2'b00} ;
    assign apb_pwdata_i   = {{(APB_ADDR_WIDTH-8){1'b0}}, apb_pwdata_w[7:0]} ;
    assign apb_prdata_w   = apb_prdata_o[7:0]  ;
end else begin: _tb_apb8_
    assign apb_paddr_i    = apb_paddr_w   ;
    assign apb_pwdata_i   = apb_pwdata_w  ;
    assign apb_prdata_w   = apb_prdata_o  ;
end 

tb_wb2apb wb_to_apb_inst (
    .wb_clk_i               (wb_clk_i           ),
    .wb_rst_i               (wb_rst_i           ),
    .wb_cyc_i               (wb_cyc_i           ),
    .wb_stb_i               (wb_stb_i           ),
    .wb_we_i                (wb_we_i            ),
    .wb_adr_i               (wb_adr_i           ),
    .wb_dat_i               (wb_dat_i           ),
    .wb_dat_o               (wb_dat_o           ),
    .wb_ack_o               (wb_ack_o           ),
    .apb_penable_i          (apb_penable_i      ),
    .apb_psel_i             (apb_psel_i         ),
    .apb_pwrite_i           (apb_pwrite_i       ),
    .apb_paddr_i            (apb_paddr_w        ),
    .apb_pwdata_i           (apb_pwdata_w       ),
    .apb_pready_o           (apb_pready_o       ),
    .apb_prdata_o           (apb_prdata_w       ),
    .apb_pslverr_o          (apb_pslverr_o      )
);
end // _tb_wb2apb_

GSRB GSR_INST (
    .GSR (gsr_rstn_r)
);

PUR PUR_INST (
    .PUR (pur_rstn_r)
);

i2c_target_model #(
    .I2C_ADR                (P_I2C1_SLV_MODEL   ),
    .MEM_DEPTH              (8                  ),
    .MDL_NAME               ("i2c_tgt_1"        ),
    .DEBUG                  (DEBUG              )
) i2c_tgt_1_inst (  
    .scl                    (i2c1_scl           ),
    .sda                    (i2c1_sda           ),
    .rx_flag                (rx_1_flag_w        ),
    .tx_flag                (tx_1_flag_w        )
);  
    
i2c_target_model #( 
    .I2C_ADR                (P_I2C2_SLV_MODEL   ),
    .MEM_DEPTH              (8                  ),
    .MDL_NAME               ("i2c_tgt_2"        ),
    .DEBUG                  (DEBUG              )
) i2c_tgt_2_inst (  
    .scl                    (i2c2_scl           ),
    .sda                    (i2c2_sda           ),
    .rx_flag                (rx_2_flag_w        ),
    .tx_flag                (tx_2_flag_w        )
);

tb_i2c_checker i2c_checker_inst(
    .i2c1_scl_i             (i2c1_scl           ),
    .i2c1_sda_i             (i2c1_sda           ),
    .tx_1_flag_i            (tx_1_flag_w        ),
    .i2c2_scl_i             (i2c2_scl           ),
    .i2c2_sda_i             (i2c2_sda           ),
    .tx_2_flag_i            (tx_2_flag_w        ),
    .i2c_1_tx_count_o       (i2c_1_tx_count_w   ),
    .i2c_1_shift_o          (i2c_1_shift_reg_w  ),
    .i2c_1_shift_cnt_o      (i2c_1_shift_cnt_w  ),
    .i2c_2_tx_count_o       (i2c_2_tx_count_w   ),
    .i2c_2_shift_o          (i2c_2_shift_reg_w  ),
    .i2c_2_shift_cnt_o      (i2c_2_shift_cnt_w  )
);

spi_target_model #(  
    .MDL_NAME               ("spi_tgt_1"        ),
    .DEBUG                  (DEBUG              )
) spi_tgt_1_inst (
    .spi_clk                (spi_clk            ),
    .spi_scsn               (spi_csn[1]         ),
    .spi_miso               (spi_miso           ),
    .spi_mosi               (spi_mosi           ),
    .spi_err_chk            (spi_err_w[1]       )
);

spi_target_model #(  
    .MDL_NAME               ("spi_tgt_2"        ),
    .DEBUG                  (DEBUG              )
) spi_tgt_2_inst (
    .spi_clk                (spi_clk            ),
    .spi_scsn               (spi_csn[2]         ),
    .spi_miso               (spi_miso           ),
    .spi_mosi               (spi_mosi           ),
    .spi_err_chk            (spi_err_w[2]       )
);

spi_target_model #(  
    .MDL_NAME               ("spi_tgt_3"        ),
    .DEBUG                  (DEBUG              )
) spi_tgt_3_inst (
    .spi_clk                (spi_clk            ),
    .spi_scsn               (spi_csn[3]         ),
    .spi_miso               (spi_miso           ),
    .spi_mosi               (spi_mosi           ),
    .spi_err_chk            (spi_err_w[3]       )
);

spi_target_model #(  
    .MDL_NAME               ("spi_tgt_4"        ),
    .DEBUG                  (DEBUG              )
) spi_tgt_4_inst (
    .spi_clk                (spi_clk            ),
    .spi_scsn               (spi_csn[4]         ),
    .spi_miso               (spi_miso           ),
    .spi_mosi               (spi_mosi           ),
    .spi_err_chk            (spi_err_w[4]       )
);

spi_target_model #(  
    .MDL_NAME               ("spi_tgt_5"        ),
    .DEBUG                  (DEBUG              )
) spi_tgt_5_inst (
    .spi_clk                (spi_clk            ),
    .spi_scsn               (spi_csn[5]         ),
    .spi_miso               (spi_miso           ),
    .spi_mosi               (spi_mosi           ),
    .spi_err_chk            (spi_err_w[5]       )
);

spi_target_model #(  
    .MDL_NAME               ("spi_tgt_6"        ),
    .DEBUG                  (DEBUG              )
) spi_tgt_6_inst (
    .spi_clk                (spi_clk            ),
    .spi_scsn               (spi_csn[6]         ),
    .spi_miso               (spi_miso           ),
    .spi_mosi               (spi_mosi           ),
    .spi_err_chk            (spi_err_w[6]       )
);

spi_target_model #(  
    .MDL_NAME               ("spi_tgt_7"        ),
    .DEBUG                  (DEBUG              )
) spi_tgt_7_inst (
    .spi_clk                (spi_clk            ),
    .spi_scsn               (spi_csn[7]         ),
    .spi_miso               (spi_miso           ),
    .spi_mosi               (spi_mosi           ),
    .spi_err_chk            (spi_err_w[7]       )
);

assign wbt_clk_i    = clk_gen_r ;
assign wbt_rst_i    = rst_gen_r ;
assign spi_err_w[0] = 1'b0;
assign spi_t_csn    = (SPI_MODE == "BOTH")? spi_csn[0] : 1'b1;
assign spi_scsn     = (~ufm_sn_r)? 1'b1 : spi_scsn_w;

if (SUBFAMILY == "LFMXO4D") begin : _efb_ctrl_xo4d

  efb_controller_1 #(
    .EFB_WB_CLK_FREQ        (EFB_WB_CLK_FREQ    ),
    .I2C1_BUS_PERF          (I2C1_BUS_PERF      ),
    .I2C1_CLK_DIVIDER       (I2C1_CLK_DIVIDER   ),
    .I2C1_ADDRESSING        (I2C1_ADDRESSING    ),
    .I2C2_BUS_PERF          (I2C2_BUS_PERF      ),
    .I2C2_CLK_DIVIDER       (I2C2_CLK_DIVIDER   ),
    .I2C2_ADDRESSING        (I2C2_ADDRESSING    ),
    .SPI_CLK_DIVIDER        (SPI_CLK_DIVIDER    ),
    .SPI_LSB_FIRST          (SPI_LSB_FIRST      ),
    .SPI_CLK_INV            (SPI_CLK_INV        ),
    .SPI_PHASE_ADJ          (SPI_PHASE_ADJ      ),
    .SPI_SLAVE_HANDSHAKE    (SPI_SLAVE_HANDSHAKE)
  ) efb_controller_inst (
    .wb_clk_i               (wbt_clk_i          ),
    .wb_rst_i               (wbt_rst_i          ),
    .wb_cyc_i               (wbt_cyc_r          ),
    .wb_stb_i               (wbt_stb_r          ),
    .wb_we_i                (wbt_we_r           ),
    .wb_adr_i               (wbt_adr_r          ),
    .wb_dat_i               (wbt_dat_r          ),
    .wb_dat_o               (wbt_dat_o          ),
    .wb_ack_o               (wbt_ack_o          ),
    .i2c1_irqo              ( ),
    .i2c2_irqo              ( ),
    .i2c1_scl               (i2c1_scl           ),
    .i2c1_sda               (i2c1_sda           ),
    .i2c2_scl               (i2c2_scl           ),
    .i2c2_sda               (i2c2_sda           ),
    .spi_clk                (spi_clk            ),
    .spi_csn                (spi_scsn_w         ),
    .spi_miso               (spi_miso           ),
    .spi_mosi               (spi_mosi           ),
    .spi_scsn               (spi_t_csn          )
  );

end
else begin : _efb_ctrl_xo4

  efb_controller_0 #(
    .EFB_WB_CLK_FREQ        (EFB_WB_CLK_FREQ    ),
    .I2C1_BUS_PERF          (I2C1_BUS_PERF      ),
    .I2C1_CLK_DIVIDER       (I2C1_CLK_DIVIDER   ),
    .I2C1_ADDRESSING        (I2C1_ADDRESSING    ),
    .I2C2_BUS_PERF          (I2C2_BUS_PERF      ),
    .I2C2_CLK_DIVIDER       (I2C2_CLK_DIVIDER   ),
    .I2C2_ADDRESSING        (I2C2_ADDRESSING    ),
    .SPI_CLK_DIVIDER        (SPI_CLK_DIVIDER    ),
    .SPI_LSB_FIRST          (SPI_LSB_FIRST      ),
    .SPI_CLK_INV            (SPI_CLK_INV        ),
    .SPI_PHASE_ADJ          (SPI_PHASE_ADJ      ),
    .SPI_SLAVE_HANDSHAKE    (SPI_SLAVE_HANDSHAKE)
  ) efb_controller_inst (
    .wb_clk_i               (wbt_clk_i          ),
    .wb_rst_i               (wbt_rst_i          ),
    .wb_cyc_i               (wbt_cyc_r          ),
    .wb_stb_i               (wbt_stb_r          ),
    .wb_we_i                (wbt_we_r           ),
    .wb_adr_i               (wbt_adr_r          ),
    .wb_dat_i               (wbt_dat_r          ),
    .wb_dat_o               (wbt_dat_o          ),
    .wb_ack_o               (wbt_ack_o          ),
    .i2c1_irqo              ( ),
    .i2c2_irqo              ( ),
    .i2c1_scl               (i2c1_scl           ),
    .i2c1_sda               (i2c1_sda           ),
    .i2c2_scl               (i2c2_scl           ),
    .i2c2_sda               (i2c2_sda           ),
    .spi_clk                (spi_clk            ),
    .spi_csn                (spi_scsn_w         ),
    .spi_miso               (spi_miso           ),
    .spi_mosi               (spi_mosi           ),
    .spi_scsn               (spi_t_csn          )
  );

end

// Timer-Counter Setup
assign tc_clki = (tc_clk_sel_r)? ~tcclk_gen_r : tcclk_gen_r;
assign tc_rstn = tc_rstn_r;
assign tc_ic   = tc_ic_r;

// PLL setup
tb_pll_0 #(
    .PLL_CLKI_DIV           (PLL0_CLKI_DIV  ),
    .PLL_CLKFB_DIV          (PLL0_CLKFB_DIV ),
    .PLL_FREQ_IN            (PLL_FREQ_IN    ),
    .PLL_FREQ_STR           (PLL_FREQ_STR   ),
    .PLL_CLKA_DIV           (PLL0_CLKA_DIV  ),
    .PLL_CLKA_FREQ          (PLL0_CLKA_FREQ ),
    .PLL_CLKA_CPHA          (PLL0_CLKA_CPHA ),
    .PLL_CLKA_FPHA          (PLL0_CLKA_FPHA ),
    .PLL_CLKB_DIV           (PLL0_CLKB_DIV  ),
    .PLL_CLKB_FREQ          (PLL0_CLKB_FREQ ),
    .PLL_CLKB_CPHA          (PLL0_CLKB_CPHA ),
    .PLL_CLKB_FPHA          (PLL0_CLKB_FPHA )
    ) pll_0_inst (
    .clki_i                 (refclk_gen_r       ),
    .clkop_o                (pll0_clkop_w       ),
    .clkos_o                (pll0_clkos_w       ),
    .lock_o                 (pll0_lock_w        ),
    .pllclk_i               (pll0_clk_o         ),
    .pllrst_i               (pll0_rst_o         ),
    .pllstb_i               (pll0_stb_o         ),
    .pllwe_i                (pll0_we_o          ),
    .plldati_i              (pll0_dato_o        ),
    .plladdr_i              (pll0_addr_o        ),
    .plldato_o              (pll0_dati_i        ),
    .pllack_o               (pll0_ack_i         )
);

tb_pll_0 #(
    .PLL_CLKI_DIV           (PLL1_CLKI_DIV  ),
    .PLL_CLKFB_DIV          (PLL1_CLKFB_DIV ),
    .PLL_FREQ_IN            (PLL_FREQ_IN    ),
    .PLL_FREQ_STR           (PLL_FREQ_STR   ),
    .PLL_CLKA_DIV           (PLL1_CLKA_DIV  ),
    .PLL_CLKA_FREQ          (PLL1_CLKA_FREQ ),
    .PLL_CLKA_CPHA          (PLL1_CLKA_CPHA ),
    .PLL_CLKA_FPHA          (PLL0_CLKA_FPHA ),
    .PLL_CLKB_DIV           (PLL1_CLKB_DIV  ),
    .PLL_CLKB_FREQ          (PLL1_CLKB_FREQ ),
    .PLL_CLKB_CPHA          (PLL1_CLKB_CPHA ),
    .PLL_CLKB_FPHA          (PLL0_CLKB_FPHA )
    ) pll_1_inst (
    .clki_i                 (refclk_gen_r       ),
    .clkop_o                (pll1_clkop_w       ),
    .clkos_o                (pll1_clkos_w       ),
    .lock_o                 (pll1_lock_w        ),
    .pllclk_i               (pll1_clk_o         ),
    .pllrst_i               (pll1_rst_o         ),
    .pllstb_i               (pll1_stb_o         ),
    .pllwe_i                (pll1_we_o          ),
    .plldati_i              (pll1_dato_o        ),
    .plladdr_i              (pll1_addr_o        ),
    .plldato_o              (pll1_dati_i        ),
    .pllack_o               (pll1_ack_i         )
);

tb_pll_checker #(
    .DEBUG                 (DEBUG               )
) pll_0_op_checker (
    .pll_clk_i              (pll0_clkop_w       ),
    .rstn_i                 (~rst_gen_r         ),
    .enable_i               (pll_chk_en_r[0]    ),
    .pll_chk_o              (pll_chk_w[0]       )
);

tb_pll_checker #(
    .DEBUG                 (DEBUG               )
) pll_0_os_checker (
    .pll_clk_i              (pll0_clkos_w       ),
    .rstn_i                 (~rst_gen_r         ),
    .enable_i               (pll_chk_en_r[1]    ),
    .pll_chk_o              (pll_chk_w[1]       )
);

tb_pll_checker #(
    .DEBUG                 (DEBUG               )
) pll_1_op_checker (
    .pll_clk_i              (pll1_clkop_w       ),
    .rstn_i                 (~rst_gen_r         ),
    .enable_i               (pll_chk_en_r[2]    ),
    .pll_chk_o              (pll_chk_w[2]       )
);

tb_pll_checker #(
    .DEBUG                 (DEBUG               )
) pll_1_os_checker (
    .pll_clk_i              (pll1_clkos_w       ),
    .rstn_i                 (~rst_gen_r         ),
    .enable_i               (pll_chk_en_r[3]    ),
    .pll_chk_o              (pll_chk_w[3]       )
);

tb_timer_checker #(
    .DEBUG                 (DEBUG               )
) tb_tc_checker (
    .clk_i                  (tcclk_gen_r        ),
    .rstn_i                 (tc_rstn            ),
    .enable_i               (tc_chk_en_r        ),
    .tc_oc_i                (tc_oc              ),
    .tc_int_i               (tc_int             ),
    .oc_chk_o               (tc_chk_tc_w        ),
    .int_chk_o              (tc_chk_int_w       ),
    .timeout_o              (tc_timeout_w       )
);

// Tamper Detect / Response Setup
assign tamper_detect_clk = tamper_detect_clk_r  ;
assign tamper_detect_in  = tamper_detect_in_r   ;
assign tamper_src_lock   = tamper_src_lock_r    ;

//----------------------------------------------------------------
// Tasks
//----------------------------------------------------------------
task t_init;
  begin
    test_err_r      = 0;
    wb_chk_r        = 1'b1;
    wb_cyc_r        = 1'b0;
    wb_stb_r        = 1'b0;
    wb_we_r         = 1'b0;
    wb_adr_r        = 8'h00;
    wb_dat_r        = 8'h00;

    i2c_1_tip_r     = 0;
    i2c_1_busy_r    = 0;
    i2c_1_rarc_r    = 0;
    i2c_1_srw_r     = 0;
    i2c_1_arbl_r    = 0;
    i2c_1_trrdy_r   = 0;
    i2c_1_troe_r    = 0;
    i2c_1_hgc_r     = 0;
    
    i2c_1_chk_r     = 1;
    
    i2c_2_tip_r     = 0;
    i2c_2_busy_r    = 0;
    i2c_2_rarc_r    = 0;
    i2c_2_srw_r     = 0;
    i2c_2_arbl_r    = 0;
    i2c_2_trrdy_r   = 0;
    i2c_2_troe_r    = 0;
    i2c_2_hgc_r     = 0;
    
    i2c_2_chk_r     = 1;
    
    wbt_cyc_r        = 1'b0;
    wbt_stb_r        = 1'b0;
    wbt_we_r         = 1'b0;
    wbt_adr_r        = 8'h00;
    wbt_dat_r        = 8'h00;
    wbt_chk_r        = 1'b1;
    
    i2c1_t_tip_r     = 0;
    i2c1_t_busy_r    = 0;
    i2c1_t_rarc_r    = 0;
    i2c1_t_srw_r     = 0;
    i2c1_t_arbl_r    = 0;
    i2c1_t_trrdy_r   = 0;
    i2c1_t_troe_r    = 0;
    i2c1_t_hgc_r     = 0;
    
    i2c2_t_tip_r     = 0;
    i2c2_t_busy_r    = 0;
    i2c2_t_rarc_r    = 0;
    i2c2_t_srw_r     = 0;
    i2c2_t_arbl_r    = 0;
    i2c2_t_trrdy_r   = 0;
    i2c2_t_troe_r    = 0;
    i2c2_t_hgc_r     = 0;
    
    cfg_sr_wbcact_r  = 0;
    cfg_sr_txfe_r    = 1;
    cfg_sr_txff_r    = 0;
    cfg_sr_rxfe_r    = 1;
    cfg_sr_rxff_r    = 0;
    cfg_sr_sspiact_r = 0;
    cfg_sr_i2cact_r  = 0;
    
    cfg_ufm_busy_r   = 0;
    i2c_ufm_busy_r   = 1;
    i2c_t_err_r      = 0;
    spi_ufm_busy_r   = 1;
    
    spi_tip_r        = 0;
    spi_trdy_r       = 0;
    spi_rrdy_r       = 0;
    spi_roe_r        = 0;
    spi_mdf_r        = 0;
    ufm_sn_r         = 1;
    
    spi_t_tip_r      = 0;
    spi_t_trdy_r     = 0;
    spi_t_rrdy_r     = 0;
    spi_t_roe_r      = 0;
    spi_t_mdf_r      = 0;
    
    tc_clk_sel_r     = 0;
    tc_ic_r          = 0;
    tc_rstn_r        = 0;
    tc_chk_en_r      = 0;

    tamper_detect_in_r  = 0;
    tamper_src_lock_r   = 0;
    
    pll_chk_en_r     = 0;

    pur_rstn_r       = 1;
    gsr_rstn_r       = 1;
  end
endtask

task t_reset;
  begin
    rst_gen_r = 1'b1;
    #200;
    rst_gen_r = 1'b0;
    #350;
    repeat(5) @ (posedge clk_gen_r);
  end
endtask

task wb_write;
  input [7:0] addr, data;
  begin
    wb_cyc_r <= 1'b1;
    wb_stb_r <= 1'b1;
    wb_we_r  <= 1'b1;
    
    wb_adr_r <= addr;
    wb_dat_r <= data;
    
    @ (posedge clk_gen_r);
    while (~wb_ack_o) @ (posedge clk_gen_r);
    
    wb_cyc_r <= 1'b0;
    wb_stb_r <= 1'b0;
    wb_we_r  <= 1'b0;
    wb_adr_r <= 8'h0;
    wb_dat_r <= 8'h0;
    
  end
endtask

task wb_write_open;
  input [7:0] addr, data;
  begin
    wb_cyc_r <= 1'b1;
    wb_stb_r <= 1'b1;
    wb_we_r  <= 1'b1;
    
    wb_adr_r <= addr;
    wb_dat_r <= data;
    
    @ (posedge clk_gen_r);
    while (~wb_ack_o) @ (posedge clk_gen_r);
  end
endtask

task wb_read;
  input [7:0] addr;
  begin
    @ (posedge clk_gen_r);
    wb_cyc_r <= 1'b1;
    wb_stb_r <= 1'b1;
    wb_we_r  <= 1'b0;
    
    wb_adr_r <= addr;
    wb_dat_r <= 8'h0;
    
    while (~wb_ack_o) @ (posedge clk_gen_r);
    
    wb_cyc_r <= 1'b0;
    wb_stb_r <= 1'b0;
    wb_we_r  <= 1'b0;
    wb_adr_r <= 8'h0;
    
  end
endtask

task wb_read_test;
  input [7:0] addr;
  input [7:0] exp_data;
  begin
    @ (posedge clk_gen_r);
    wb_cyc_r <= 1'b1;
    wb_stb_r <= 1'b1;
    wb_we_r  <= 1'b0;
    
    wb_adr_r <= addr;
    wb_dat_r <= 8'h0;
    
    while (~wb_ack_o) @ (posedge clk_gen_r);
    wb_chk_r = (wb_dat_o == exp_data);
    if (wb_chk_r) begin
        if (DEBUG)
        $display("[%012t]   ### User Interface Expected Read Data (Addr: %h - Expected: %h, Actual: %h", $time, addr, exp_data, wb_dat_o);
    end 
    else
        $display("[%012t]   !!! User Interface Read Data Error (Addr: %h - Expected: %h, Actual: %h", $time, addr, exp_data, wb_dat_o);
    
    wb_cyc_r <= 1'b0;
    wb_stb_r <= 1'b0;
    wb_we_r  <= 1'b0;
    wb_adr_r <= 8'h0;
  end
endtask

task wbt_write;
  input [7:0] addr, data;
  begin
    wbt_cyc_r <= 1'b1;
    wbt_stb_r <= 1'b1;
    wbt_we_r  <= 1'b1;
    
    wbt_adr_r <= addr;
    wbt_dat_r <= data;
    
    @ (posedge clk_gen_r);
    while (~wbt_ack_o) @ (posedge clk_gen_r);
    
    wbt_cyc_r <= 1'b0;
    wbt_stb_r <= 1'b0;
    wbt_we_r  <= 1'b0;
    wbt_adr_r <= 8'h0;
    wbt_dat_r <= 8'h0;
    
    @ (posedge clk_gen_r);
    
  end
endtask

task wbt_read;
  input [7:0] addr;
  begin
    @ (posedge clk_gen_r);
    wbt_cyc_r <= 1'b1;
    wbt_stb_r <= 1'b1;
    wbt_we_r  <= 1'b0;
    
    wbt_adr_r <= addr;
    wbt_dat_r <= 8'h0;
    
    @ (posedge clk_gen_r);
    while (~wbt_ack_o) @ (posedge clk_gen_r);
    
    wbt_cyc_r <= 1'b0;
    wbt_stb_r <= 1'b0;
    wbt_we_r  <= 1'b0;
    wbt_adr_r <= 8'h0;
    
  end
endtask

task wbt_read_test;
  input [7:0] addr;
  input [7:0] exp_data;
  begin
    @ (posedge clk_gen_r);
    wbt_cyc_r <= 1'b1;
    wbt_stb_r <= 1'b1;
    wbt_we_r  <= 1'b0;
    
    wbt_adr_r <= addr;
    wbt_dat_r <= 8'h0;
    
    @ (posedge clk_gen_r);
    while (~wbt_ack_o) @ (posedge clk_gen_r);
    wbt_chk_r = (wbt_dat_o == exp_data);
    if (wbt_chk_r) begin
        if (DEBUG)
        $display("[%012t]   ### User Interface Expected Read Data (Addr: %h) - Expected: %h, Actual: %h", $time, addr, exp_data, wbt_dat_o);
    end
    else
        $display("[%012t]   !!! User Interface Read Data Error (Addr: %h) - Expected: %h, Actual: %h", $time, addr, exp_data, wbt_dat_o);
    @ (posedge clk_gen_r);
    
    wbt_cyc_r <= 1'b0;
    wbt_stb_r <= 1'b0;
    wbt_we_r  <= 1'b0;
    wbt_adr_r <= 8'h0;
    
  end
endtask

task get_ufm_status;
  begin
    wb_read(P_UFM_CFGSR);
    cfg_sr_wbcact_r    <= wb_dat_o[7];
    cfg_sr_txfe_r      <= wb_dat_o[5];
    cfg_sr_txff_r      <= wb_dat_o[4];
    cfg_sr_rxfe_r      <= wb_dat_o[3];
    cfg_sr_rxff_r      <= wb_dat_o[2];
    cfg_sr_sspiact_r   <= wb_dat_o[1];
    cfg_sr_i2cact_r    <= wb_dat_o[0];
  end
endtask

task ufm_poll_status;
  begin
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (4) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h3C);
    repeat (4) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (4) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (4) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (4) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    repeat (4) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (4) @(posedge clk_gen_r);
  end
endtask

task ufm_poll_busy_flag;
  input [7:0] exp_data;
  input bypass;
  begin
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (4) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'hF0);
    repeat (4) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (4) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (4) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (4) @(posedge clk_gen_r);
    
    if(bypass) begin
        wb_read(P_UFM_CFGRXDR);
        cfg_ufm_busy_r    <= wb_dat_o[7];
        repeat (4) @(posedge clk_gen_r);
    end
    else begin
        wb_read_test(P_UFM_CFGRXDR, exp_data);
        cfg_ufm_busy_r    <= wb_dat_o[7];
        repeat (4) @(posedge clk_gen_r);
    end
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (4) @(posedge clk_gen_r);
  end
endtask

`include "dependency/tb_tasks_i2c.v"
`include "dependency/tb_tasks_spi.v"

//----------------------------------------------------------------
// Test
//----------------------------------------------------------------
initial begin
    $timeformat(-9, 0, " ns", 12);
    
    t_init;
    t_reset;

    #200_000;   // Wait 150us before User Mode
    repeat(100) @ (posedge clk_gen_r);
    
    // Register Tests
    if (EFB_WB_IN) begin
    `include "dependency/tb_seq_reg.v"
    end
    
    // I2C1 Tests
    if (EFB_I2C1 == "ENABLED" && EFB_I2C1_CFG_TB == "I2C1_USER") begin
    `include "dependency/tb_seq_i2c1.v"
    end
    
    // I2C2 Tests
    if (EFB_I2C2 == "ENABLED") begin
    `include "dependency/tb_seq_i2c2.v"
    end // 
    
    // SPI Tests
    if (EFB_SPI == "ENABLED") begin
    `include "dependency/tb_seq_spi.v"
    end
    
    // Timer/ Counter Tests
    if (EFB_TC == "ENABLED" && TC_RESETN == "ENABLED" && (TC_SCLK_SEL == "PCLOCK" || TC_SCLK_SEL == "NCLOCK")) begin
    `include "dependency/tb_seq_tc.v"
    end
    
    // PLL Dynamic Reconfiguration Tests
    if (EFB_PLL_IN) begin
    `include "dependency/tb_seq_pll.v"
    end
    
    // UFM Tests
    if (EFB_UFM == "ENABLED" && EFB_WB_IN) begin
      if (SUBFAMILY == "LFMXO4D") begin
        `include "dependency/tb_seq_xo4d_ufm.v"
      end
      else begin
        `include "dependency/tb_seq_ufm.v"
      end
    end
    
    // UFM via I2C Tests
    if (EFB_I2C1 == "ENABLED" && EFB_I2C1_CFG_TB == "I2C1_CFG") begin
      if (SUBFAMILY == "LFMXO4D") begin
        `include "dependency/tb_seq_ufm_i2c_xo4d.v"
      end
      else begin
        `include "dependency/tb_seq_ufm_i2c.v"
      end
    end
    
     // UFM via SPI Tests
    if (EFB_UFM == "ENABLED" && EFB_SPI == "ENABLED" && SPI_MODE == "SLAVE") begin
      if (SUBFAMILY == "LFMXO4D") begin
        `include "dependency/tb_seq_ufm_spi_xo4d.v"
      end
      else begin
        `include "dependency/tb_seq_ufm_spi.v"
      end
    end
    
    // CFG Tests
    if (EFB_UFM == "ENABLED" && EFB_WB_IN) begin
      if (SUBFAMILY == "LFMXO4D") begin
        `include "dependency/tb_seq_xo4d_cfg.v"
      end
      else begin
        `include "dependency/tb_seq_cfg.v"
      end
    end

    // Tamper Tests
    if (SUBFAMILY == "LFMXO4D" && EFB_TAMPER_DETECTION_RESPONSE == "ENABLED") begin
      // `include "dependency/tb_seq_tamper.v"
    end

    @ (posedge clk_gen_r);
    @ (posedge clk_gen_r);
    
    if (~test_err_r) begin
      $display("-----------------------------------------------------");
      $display("---------------- SIMULATION PASSED ------------------");
      $display("-----------------------------------------------------");
    end
    else begin
      $display("-----------------------------------------------------");
      $display("!!!!!!!!!!!!!!!! SIMULATION FAILED !!!!!!!!!!!!!!!!!!");
      $display("-----------------------------------------------------");
    end
    @ (posedge clk_gen_r);
    $stop;
end

always @ (posedge clk_gen_r)
    if (test_err_r)
        test_err_r <= 1'b1;
    else if (wb_chk_r && i2c_1_chk_r && i2c_2_chk_r && wbt_chk_r && ~i2c_t_err_r && ~|spi_err_w && &pll_chk_w && tc_chk_tc_w && tc_chk_int_w)
        test_err_r <= 1'b0;
    else
        test_err_r <= 1'b1;

function [9:0] str_to_bin;
    input [79:0] ascii_string;
    integer i;
    begin
        str_to_bin = 10'd0;
        for (i = 0; i < 10; i = i + 1) begin
            if (ascii_string[8*i +: 8] == 8'h31)
                str_to_bin[i] = 1'b1;
            else if (ascii_string[8*i +: 8] == 8'h30)
                str_to_bin[i] = 1'b0;
        end
    end
endfunction

function integer str_to_dec;
    input [39:0] str;
    integer result;
    begin
        result = 0;
        if (str[39:32] != 8'h00) begin
            result = result + (str[39:32] - "0") * 10000;
        end
        if (str[31:24] != 8'h00) begin
            result = result + (str[31:24] - "0") * 1000;
        end
        if (str[23:16] != 8'h00) begin
            result = result + (str[23:16] - "0") * 100;
        end
        if (str[15:8] != 8'h00) begin
            result = result + (str[15:8] - "0") * 10;
        end
        if (str[7:0] != 8'h00) begin
            result = result + (str[7:0] - "0");
        end
        str_to_dec = result;
    end
endfunction

endmodule
`endif // __EFB_TB_TOP__

