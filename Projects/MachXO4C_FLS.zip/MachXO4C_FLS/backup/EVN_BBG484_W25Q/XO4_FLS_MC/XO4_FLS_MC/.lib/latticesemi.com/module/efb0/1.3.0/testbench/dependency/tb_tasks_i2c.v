task get_i2c_status;
  input stat;
  begin
    if (stat == 0) begin
        wb_read(P_I2C1_SR);
        i2c_1_tip_r     <= wb_dat_o[7];
        i2c_1_busy_r    <= wb_dat_o[6];
        i2c_1_rarc_r    <= wb_dat_o[5];
        i2c_1_srw_r     <= wb_dat_o[4];
        i2c_1_arbl_r    <= wb_dat_o[3];
        i2c_1_trrdy_r   <= wb_dat_o[2];
        i2c_1_troe_r    <= wb_dat_o[1];
        i2c_1_hgc_r     <= wb_dat_o[0];
    end
    else if (stat == 1) begin
        wb_read(P_I2C2_SR);
        i2c_2_tip_r     <= wb_dat_o[7];
        i2c_2_busy_r    <= wb_dat_o[6];
        i2c_2_rarc_r    <= wb_dat_o[5];
        i2c_2_srw_r     <= wb_dat_o[4];
        i2c_2_arbl_r    <= wb_dat_o[3];
        i2c_2_trrdy_r   <= wb_dat_o[2];
        i2c_2_troe_r    <= wb_dat_o[1];
        i2c_2_hgc_r     <= wb_dat_o[0];
    end
  end
endtask

task i2c1_write_1data;
  input [6:0] addr;
  input [7:0] data;
  begin
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_rarc_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C1_TXDR, {addr, 1'b0});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0 || i2c_1_busy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_TXDR, data);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_busy_r == 1'b1)
        get_i2c_status(0);
    @(posedge clk_gen_r);
  end
endtask

task i2c2_write_1data;
  input [6:0] addr;
  input [7:0] data;
  begin
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_rarc_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C2_TXDR, {addr, 1'b0});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0 || i2c_2_busy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_TXDR, data);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_busy_r == 1'b1)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  end
endtask

task i2c12_write_data;
  input [7:0] data0;
  input [7:0] data1;
  begin
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_rarc_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_rarc_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C1_TXDR, {P_I2C1_SLV_MODEL, 1'b0});
    @(posedge clk_gen_r);
    wb_write(P_I2C1_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_TXDR, {P_I2C2_SLV_MODEL, 1'b0});
    @(posedge clk_gen_r);
    wb_write(P_I2C2_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0 || i2c_1_busy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_TXDR, data0);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0 || i2c_2_busy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_TXDR, data1);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_busy_r == 1'b1)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_busy_r == 1'b1)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  end
endtask

task i2c1_write_4data;
  input [6:0] addr;
  input [7:0] data0;
  input [7:0] data1;
  input [7:0] data2;
  input [7:0] data3;
  begin
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_rarc_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_TXDR, {addr, 1'b0});
    @(posedge clk_gen_r);
    wb_write(P_I2C1_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0 || i2c_1_busy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_TXDR, data0);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_TXDR, data1);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_TXDR, data2);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_TXDR, data3);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);

    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    wb_write(P_I2C1_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_busy_r == 1'b1)
        get_i2c_status(0);
    @(posedge clk_gen_r);
  end
endtask

task i2c2_write_4data;
  input [6:0] addr;
  input [7:0] data0;
  input [7:0] data1;
  input [7:0] data2;
  input [7:0] data3;
  begin
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_rarc_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_TXDR, {addr, 1'b0});
    @(posedge clk_gen_r);
    wb_write(P_I2C2_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0 || i2c_2_busy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_TXDR, data0);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_TXDR, data1);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_TXDR, data2);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_TXDR, data3);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    wb_write(P_I2C2_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_busy_r == 1'b1)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  end
endtask

task i2c1_read_1data;
  input [6:0] addr;
  begin
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_rarc_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C1_TXDR, {addr, 1'b1});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h94);
    @(posedge clk_gen_r);

    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_srw_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    repeat (2) #P_I2C1_SCL_DLY;
    
    wb_write(P_I2C1_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_busy_r == 1'b1)
        get_i2c_status(0);
    @(posedge clk_gen_r);
  end
endtask

task i2c2_read_1data;
  input [6:0] addr;
  begin
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_rarc_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C2_TXDR, {addr, 1'b1});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h94);
    @(posedge clk_gen_r);

    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_srw_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    repeat (2) #P_I2C2_SCL_DLY;
    
    wb_write(P_I2C2_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_busy_r == 1'b1)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
  end
endtask

task i2c1_read_1data_test;
  input [6:0] addr;
  input [7:0] exp_data;
  begin
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_rarc_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C1_TXDR, {addr, 1'b1});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h94);
    @(posedge clk_gen_r);

    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_srw_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    repeat (2) #P_I2C1_SCL_DLY;
    
    wb_write(P_I2C1_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    while (~tx_1_flag_w) @(posedge clk_gen_r);
    i2c_1_chk_r = (i2c_1_shift_reg_w == exp_data);
    if(i2c_1_chk_r) begin
        if(DEBUG)
        $display("[%012t]   ### I2C1 Controller Expected Read Data - Expected: %h, Actual: %h", $time, exp_data, i2c_1_shift_reg_w);
    end
    else
        $display("[%012t]   !!! I2C1 Controller Read Data Error - Expected: %h, Actual: %h", $time, exp_data, i2c_1_shift_reg_w);
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_busy_r == 1'b1)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
  end
endtask

task i2c2_read_1data_test;
  input [6:0] addr;
  input [7:0] exp_data;
  begin
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_rarc_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C2_TXDR, {addr, 1'b1});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h94);
    @(posedge clk_gen_r);

    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_srw_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    repeat (2) #P_I2C2_SCL_DLY;
    
    wb_write(P_I2C2_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    while (~tx_2_flag_w) @(posedge clk_gen_r);
    i2c_2_chk_r = (i2c_2_shift_reg_w == exp_data);
    if (i2c_2_chk_r) begin
        if(DEBUG)
        $display("[%012t]   ### I2C2 Controller Expected Read Data - Expected: %h, Actual: %h", $time, exp_data, i2c_2_shift_reg_w);
    end 
    else
        $display("[%012t]   !!! I2C2 Controller Read Data Error - Expected: %h, Actual: %h", $time, exp_data, i2c_2_shift_reg_w);
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_busy_r == 1'b1)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
  end
endtask

task i2c1_read_4data;
  input [6:0] addr;
  begin
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_rarc_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C1_TXDR, {addr, 1'b1});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_srw_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0)
        get_i2c_status(0);
    
    while (i2c_1_tx_count_w < 3) begin
        @(posedge clk_gen_r);
    end
    
    repeat (2) #P_I2C1_SCL_DLY;
    
    wb_write(P_I2C1_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_busy_r == 1'b1)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
  end
endtask

task i2c2_read_4data;
  input [6:0] addr;
  begin
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_rarc_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C2_TXDR, {addr, 1'b1});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_srw_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0)
        get_i2c_status(1);
    
    while (i2c_2_tx_count_w < 3) begin
        @(posedge clk_gen_r);
    end
    
    repeat (2) #P_I2C2_SCL_DLY;
    
    wb_write(P_I2C2_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_busy_r == 1'b1)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
  end
endtask

task i2c1_1data_repeated_start;
  input [6:0] addr;
  input [7:0] data;
  begin
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_rarc_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C1_TXDR, {addr, 1'b0});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0 || i2c_1_busy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_TXDR, data);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_trrdy_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_TXDR, {addr, 1'b1});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h94);
    @(posedge clk_gen_r);

    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_srw_r == 1'b0)
        get_i2c_status(0);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C1_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    repeat (2) #P_I2C1_SCL_DLY;
    
    wb_write(P_I2C1_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    get_i2c_status(0);
    @(posedge clk_gen_r);
    while (i2c_1_busy_r == 1'b1)
        get_i2c_status(0);
    @(posedge clk_gen_r);
  end
endtask

task i2c2_1data_repeated_start;
  input [6:0] addr;
  input [7:0] data;
  begin
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_rarc_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  
    wb_write(P_I2C2_TXDR, {addr, 1'b0});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0 || i2c_2_busy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_TXDR, data);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_trrdy_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_TXDR, {addr, 1'b1});
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h94);
    @(posedge clk_gen_r);

    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_srw_r == 1'b0)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    repeat (2) #P_I2C2_SCL_DLY;
    
    wb_write(P_I2C2_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_busy_r == 1'b1)
        get_i2c_status(1);
    @(posedge clk_gen_r);
    
    get_i2c_status(1);
    @(posedge clk_gen_r);
    while (i2c_2_busy_r == 1'b1)
        get_i2c_status(1);
    @(posedge clk_gen_r);
  end
endtask

task get_i2c_mstr_status;
  input stat;
  begin
    if (stat == 0) begin
        wbt_read(P_I2C1_SR);
        i2c1_t_tip_r     <= wbt_dat_o[7];
        i2c1_t_busy_r    <= wbt_dat_o[6];
        i2c1_t_rarc_r    <= wbt_dat_o[5];
        i2c1_t_srw_r     <= wbt_dat_o[4];
        i2c1_t_arbl_r    <= wbt_dat_o[3];
        i2c1_t_trrdy_r   <= wbt_dat_o[2];
        i2c1_t_troe_r    <= wbt_dat_o[1];
        i2c1_t_hgc_r     <= wbt_dat_o[0];
    end
    else if (stat == 1) begin
        wbt_read(P_I2C2_SR);
        i2c2_t_tip_r     <= wbt_dat_o[7];
        i2c2_t_busy_r    <= wbt_dat_o[6];
        i2c2_t_rarc_r    <= wbt_dat_o[5];
        i2c2_t_srw_r     <= wbt_dat_o[4];
        i2c2_t_arbl_r    <= wbt_dat_o[3];
        i2c2_t_trrdy_r   <= wbt_dat_o[2];
        i2c2_t_troe_r    <= wbt_dat_o[1];
        i2c2_t_hgc_r     <= wbt_dat_o[0];
    end
    wbt_read(P_I2C1_RXDR);
  end
endtask

task i2c1_mstr_write_1data;
  input [9:0] addr;
  input [7:0] data;
  input       gen_call;
  begin
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_rarc_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  
    if(I2C1_ADDRESSING == "10BIT" && ~gen_call) begin
        wbt_write(P_I2C1_TXDR, {5'b11110, addr[9:8], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
    end
    else begin
        wbt_write(P_I2C1_TXDR, {addr[6:0], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
    end
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_busy_r == 1'b1)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  end
endtask

task i2c1_mstr_write_3data;
  input [9:0] addr;
  input [7:0] data0;
  input [7:0] data1;
  input [7:0] data2;
  input       gen_call;
  begin
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_rarc_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  
    if(I2C1_ADDRESSING == "10BIT" && ~gen_call) begin
        wbt_write(P_I2C1_TXDR, {5'b11110, addr[9:8], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
    end
    else begin
        wbt_write(P_I2C1_TXDR, {addr[6:0], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
    end
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data1);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data2);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);

    wbt_write(P_I2C1_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_busy_r == 1'b1)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  end
endtask

task i2c1_mstr_write_4data;
  input [9:0] addr;
  input [7:0] data0;
  input [7:0] data1;
  input [7:0] data2;
  input [7:0] data3;
  input       gen_call;
  begin
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_rarc_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  
    if(I2C1_ADDRESSING == "10BIT" && ~gen_call) begin
        wbt_write(P_I2C1_TXDR, {5'b11110, addr[9:8], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
    end
    else begin
        wbt_write(P_I2C1_TXDR, {addr[6:0], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
    end
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data1);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data2);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data3);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_busy_r == 1'b1)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  end
endtask

task i2c1_mstr_write_open;
  input [9:0] addr;
  input       gen_call;
  begin
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_rarc_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  
    if(I2C1_ADDRESSING == "10BIT" && ~gen_call) begin
        wbt_write(P_I2C1_TXDR, {5'b11110, addr[9:8], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
    end
    else begin
        wbt_write(P_I2C1_TXDR, {addr[6:0], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
    end
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  end
endtask

task i2c1_mstr_write_4data_open_read;
  input [9:0] addr;
  input [7:0] data0;
  input [7:0] data1;
  input [7:0] data2;
  input [7:0] data3;
  input       gen_call;
  input [7:0] rd_cycles;
  begin
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_rarc_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  
    if(I2C1_ADDRESSING == "10BIT" && ~gen_call) begin
        wbt_write(P_I2C1_TXDR, {5'b11110, addr[9:8], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
    end
    else begin
        wbt_write(P_I2C1_TXDR, {addr[6:0], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
    end
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0 || i2c1_t_busy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data1);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data2);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, data3);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_TXDR, {addr, 1'b1});
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h94);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_srw_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    repeat (rd_cycles-1) begin
        repeat (9) #P_I2C1_SCL_DLY;
    end
    #P_I2C1_SCL_DLY;
    #P_I2C1_SCL_DLY;
    
    wbt_write(P_I2C1_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_busy_r == 1'b1)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
  end
endtask

task i2c1_mstr_read_1data;
  input [9:0] addr;
  input [7:0] exp_data;
  reg [7:0] act_data;
  begin
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_rarc_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    if(I2C1_ADDRESSING == "10BIT") begin
        wbt_write(P_I2C1_TXDR, {5'b11110, addr[9:8], 1'b0});
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h14);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, {5'b11110, addr[9:8], 1'b1});
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        while (i2c1_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(0);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        wbt_write(P_I2C1_CMDR, 8'h24);
        @(posedge clk_gen_r);
    end
    else begin
        wbt_write(P_I2C1_TXDR, {addr, 1'b1});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C1_CMDR, 8'h94);
        @(posedge clk_gen_r);
    end
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_srw_r == 1'b0)
        get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C1_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    repeat (2) #P_I2C1_SCL_DLY;
    
    wbt_write(P_I2C1_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(0);
    @(posedge clk_gen_r);
    while (i2c1_t_busy_r == 1'b1) begin
        get_i2c_mstr_status(0);
        if (i2c_1_shift_cnt_w >= 4'd8) begin
            i2c_1_chk_r = (i2c_1_shift_reg_w == exp_data);
            act_data    = i2c_1_shift_reg_w;
        end
    end
    if(i2c_1_chk_r) begin
        if(DEBUG)
        $display("[%012t]   ### I2C1 Target Expected Read Data - Expected: %h, Actual: %h", $time, exp_data, act_data);
    end
    else
        $display("[%012t]   !!! I2C1 Target Read Data Error - Expected: %h, Actual: %h", $time, exp_data, act_data);
    @(posedge clk_gen_r);
  end
endtask

task i2c2_mstr_write_1data;
  input [9:0] addr;
  input [7:0] data;
  input       gen_call;
  begin
    get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    while (i2c2_t_rarc_r == 1'b0)
        get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
  
    if(I2C2_ADDRESSING == "10BIT" && ~gen_call) begin
        wbt_write(P_I2C2_TXDR, {5'b11110, addr[9:8], 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C2_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(1);
        @(posedge clk_gen_r);
        while (i2c2_t_trrdy_r == 1'b0 || i2c2_t_busy_r == 1'b0)
            get_i2c_mstr_status(1);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C2_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C2_CMDR, 8'h14);
        @(posedge clk_gen_r);
    end
    else begin
        wbt_write(P_I2C2_TXDR, {addr, 1'b0});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C2_CMDR, 8'h94);
        @(posedge clk_gen_r);
    end
    
    get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    while (i2c2_t_trrdy_r == 1'b0 || i2c2_t_busy_r == 1'b0)
        get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C2_TXDR, data);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C2_CMDR, 8'h14);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    while (i2c2_t_trrdy_r == 1'b0)
        get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C2_CMDR, 8'h44);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    while (i2c2_t_busy_r == 1'b1)
        get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
  end
endtask

task i2c2_mstr_read_1data;
  input [9:0] addr;
  input [7:0] exp_data;
  reg [7:0] act_data;
  begin
    get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    while (i2c2_t_rarc_r == 1'b0)
        get_i2c_mstr_status(1);
    @(posedge clk_gen_r);

    if(I2C2_ADDRESSING == "10BIT") begin
        wbt_write(P_I2C2_TXDR, {5'b11110, addr[9:8], 1'b0});
        @(posedge clk_gen_r);
        wbt_write(P_I2C2_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(1);
        @(posedge clk_gen_r);
        while (i2c2_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(1);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C2_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        wbt_write(P_I2C2_CMDR, 8'h14);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(1);
        @(posedge clk_gen_r);
        while (i2c2_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(1);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C2_TXDR, {5'b11110, addr[9:8], 1'b1});
        @(posedge clk_gen_r);
        wbt_write(P_I2C2_CMDR, 8'h94);
        @(posedge clk_gen_r);
        
        get_i2c_mstr_status(1);
        @(posedge clk_gen_r);
        while (i2c2_t_trrdy_r == 1'b0)
            get_i2c_mstr_status(1);
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C2_TXDR, addr[7:0]);
        @(posedge clk_gen_r);
        wbt_write(P_I2C2_CMDR, 8'h24);
        @(posedge clk_gen_r);
    end
    else begin
        wbt_write(P_I2C2_TXDR, {addr, 1'b1});
        @(posedge clk_gen_r);
        
        wbt_write(P_I2C2_CMDR, 8'h94);
        @(posedge clk_gen_r);
    end
    
    get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    while (i2c2_t_srw_r == 1'b0)
        get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    
    wbt_write(P_I2C2_CMDR, 8'h24);
    @(posedge clk_gen_r);
    
    repeat (2) #P_I2C2_SCL_DLY;
    
    wbt_write(P_I2C2_CMDR, 8'h6C);
    @(posedge clk_gen_r);
    
    get_i2c_mstr_status(1);
    @(posedge clk_gen_r);
    while (i2c2_t_busy_r == 1'b1) begin
        get_i2c_mstr_status(1);
        if (i2c_2_shift_cnt_w >= 4'd8) begin
            i2c_2_chk_r = (i2c_2_shift_reg_w == exp_data);
            act_data = i2c_2_shift_reg_w;
        end
    end
    if(i2c_2_chk_r) begin
        if(DEBUG)
        $display("[%012t]   ### I2C2 Target Expected Read Data - Expected: %h, Actual: %h", $time, exp_data, act_data);
    end
    else
        $display("[%012t]   !!! I2C2 Target Read Data Error - Expected: %h, Actual: %h", $time, exp_data, act_data);
    @(posedge clk_gen_r);
  end
endtask
