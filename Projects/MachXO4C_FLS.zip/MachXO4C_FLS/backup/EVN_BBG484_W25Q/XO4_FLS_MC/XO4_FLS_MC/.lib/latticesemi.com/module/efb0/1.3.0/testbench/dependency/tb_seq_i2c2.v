    $display("[%012t] ===== Secondary I2C Tests as Controller =====", $time);
    i2c_tgt_2_inst.enable_check_on_rx();
    i2c_tgt_2_inst.set_expected_data(7'h00, 8'hF5);
    i2c2_write_1data(P_I2C2_SLV_MODEL, 8'hF5);
    repeat(10) @ (posedge clk_gen_r);
    
    i2c2_read_1data_test(P_I2C2_SLV_MODEL, 8'hF5);
    repeat(10) @ (posedge clk_gen_r);
    
    i2c_tgt_2_inst.set_expected_data(7'h00, 8'h11);
    i2c_tgt_2_inst.set_expected_data(7'h01, 8'h22);
    i2c_tgt_2_inst.set_expected_data(7'h02, 8'h33);
    i2c_tgt_2_inst.set_expected_data(7'h03, 8'h44);
    i2c2_write_4data(P_I2C2_SLV_MODEL, 8'h11, 8'h22, 8'h33, 8'h44);
    $display("[%012t] --- I2C Controller Write Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    i2c2_read_4data(P_I2C2_SLV_MODEL);
    $display("[%012t] --- I2C Controller Read Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);

    i2c_tgt_2_inst.set_expected_data(7'h00, 8'h5F);
    i2c2_1data_repeated_start(P_I2C2_SLV_MODEL, 8'h5F);
    $display("[%012t] --- Repeated Start Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    t_reset;
    
    i2c_tgt_2_inst.set_expected_data(7'h00, 8'hA6);
    i2c2_write_1data(P_I2C2_SLV_MODEL, 8'hA6);
    repeat(10) @ (posedge clk_gen_r);
    i2c2_read_1data_test(P_I2C2_SLV_MODEL, 8'hA6);
    repeat(10) @ (posedge clk_gen_r);
    
    // Change Prescale
    $display("[%012t] --- Clock Prescale Test Done ---", $time);
    wb_write(P_I2C2_BR0, 8'hE7);
    wb_write(P_I2C2_BR1, 8'h03);
    i2c_tgt_2_inst.set_expected_data(7'h00, 8'hA7);
    i2c2_write_1data(P_I2C2_SLV_MODEL, 8'hA7);
    repeat(10) @ (posedge clk_gen_r);
    
    // Return config prescale
    wb_write(P_I2C2_BR0, P_I2C2_BR0_INIT);
    wb_write(P_I2C2_BR1, P_I2C2_BR1_INIT);
    repeat(10) @ (posedge clk_gen_r);

    // EFB as Target Tests
    $display("[%012t] ===== Secondary I2C Tests as Target =====", $time);
    wb_write(P_I2C2_CMDR, 8'h04);
    if(I2C2_ADDRESSING == "10BIT")
        i2c2_mstr_write_1data(P_I2C2_SLV_ADDR[9:0], 8'hF5, 0);
    else
        i2c2_mstr_write_1data(P_I2C2_SLV_ADDR[6:0], 8'hF5, 0);
    wb_read_test(P_I2C2_RXDR, 8'hF5);   // Confirm written data at RXDR
    $display("[%012t] --- I2C Target Write Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    wb_write(P_I2C2_TXDR, 8'hF5);
    if(I2C2_ADDRESSING == "10BIT")
        i2c2_mstr_read_1data(P_I2C2_SLV_ADDR[9:0], 8'hF5);
    else
        i2c2_mstr_read_1data(P_I2C2_SLV_ADDR[6:0], 8'hF5);
    $display("[%012t] --- I2C Target Read Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    wb_write(P_I2C2_CMDR, 8'h04);
    i2c2_mstr_write_1data(7'h00, 8'hF3, 1);
    if (I2C2_GEN_CALL == "ENABLED")
        wb_read_test(P_I2C2_GCDR, 8'hF3);   // Confirm written data at GCDR
    else
        wb_read_test(P_I2C2_GCDR, 8'h00);   // Confirm written data at GCDR
    $display("[%012t] --- General Call Enable Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    
    if (EFB_I2C1 == "ENABLED" && EFB_I2C1_CFG_TB == "I2C1_USER" && I2C1_CLK_DIVIDER == I2C2_CLK_DIVIDER) begin
        // I2C1 and I2C2 Simultaneous usage
        $display("[%012t] --- Primary + Secondary I2C Test Done ---", $time);
        i2c_tgt_1_inst.set_expected_data(7'h00, 8'hC5);
        i2c_tgt_2_inst.set_expected_data(7'h00, 8'hC6);
        i2c12_write_data(8'hC5, 8'hC6);
    end