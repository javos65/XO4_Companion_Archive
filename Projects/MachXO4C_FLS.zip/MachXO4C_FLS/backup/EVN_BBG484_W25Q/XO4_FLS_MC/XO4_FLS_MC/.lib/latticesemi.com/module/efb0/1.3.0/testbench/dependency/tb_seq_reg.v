    $display("[%012t] ===== Register Tests via User Interface =====", $time);
    
    if (EFB_PLL_IN) begin
    for (ii = 8'h00; ii <= 8'h1C; ii = ii + 1) begin
      wb_test_r = ii;
      if (wb_test_r == P_MC1_DELA)
        wb_read_test(wb_test_r, {1'b0, PLL0_CLKA_CPHA});
      else if (wb_test_r == P_MC1_DIVA)
        wb_read_test(wb_test_r, {1'b0, PLL0_CLKA_DIV-1});
      else if (wb_test_r == P_MC1_DELB)
        wb_read_test(wb_test_r, {1'b0, PLL0_CLKB_CPHA});
      else if (wb_test_r == P_MC1_DIVB)
        wb_read_test(wb_test_r, {1'b0, PLL0_CLKB_DIV-1});
      else if (wb_test_r ==  P_MC1_DELC || wb_test_r ==  P_MC1_DELD || wb_test_r ==  P_MC1_DIVC || wb_test_r ==  P_MC1_DIVD)
        wb_read_test(wb_test_r, 8'h01);
      else if (wb_test_r == P_MC1_CLKOS_TRIM)
        wb_read_test(wb_test_r, 8'h88);
      else if (wb_test_r == P_MC1_ENABLE_CLK)
        wb_read_test(wb_test_r, 8'h03);
      else if (wb_test_r == P_MC1_DIVREF)
        wb_read_test(wb_test_r, {1'b0, PLL0_CLKI_DIV-1});
      else if (wb_test_r == P_MC1_DIVFBK)
        wb_read_test(wb_test_r, {1'b0, PLL0_CLKFB_DIV-1});
      else if (wb_test_r == P_MC1_VCO_BYPASS_D0)
        wb_read_test(wb_test_r, 8'h0F);
      else if (wb_test_r == P_MC1_LOCK_STS)
        wb_read_test(wb_test_r, 8'h01);
      else
        wb_read_test(wb_test_r, 8'h00);
      @(posedge clk_gen_r);
    end
    if (EFB_PLL_NUM_IN > 1) begin
    for (ii = 8'h20; ii <= 8'h3C; ii = ii + 1) begin
      wb_test_r = ii;
      if (wb_test_r == P_MC2_DELA)
        wb_read_test(wb_test_r, {1'b0, PLL1_CLKA_CPHA});
      else if (wb_test_r == P_MC2_DIVA)
        wb_read_test(wb_test_r, {1'b0, PLL1_CLKA_DIV-1});
      else if (wb_test_r == P_MC2_DELB)
        wb_read_test(wb_test_r, {1'b0, PLL1_CLKB_CPHA});
      else if (wb_test_r == P_MC2_DIVB)
        wb_read_test(wb_test_r, {1'b0, PLL1_CLKB_DIV-1});
      else if (wb_test_r ==  P_MC2_DELC || wb_test_r ==  P_MC2_DELD || wb_test_r ==  P_MC2_DIVC || wb_test_r ==  P_MC2_DIVD)
        wb_read_test(wb_test_r, 8'h01);
      else if (wb_test_r == P_MC2_CLKOS_TRIM)
        wb_read_test(wb_test_r, 8'h88);
      else if (wb_test_r == P_MC2_ENABLE_CLK)
        wb_read_test(wb_test_r, 8'h03);
      else if (wb_test_r == P_MC2_DIVREF)
        wb_read_test(wb_test_r, {1'b0, PLL1_CLKI_DIV-1});
      else if (wb_test_r == P_MC2_DIVFBK)
        wb_read_test(wb_test_r, {1'b0, PLL1_CLKFB_DIV-1});
      else if (wb_test_r == P_MC2_VCO_BYPASS_D0)
        wb_read_test(wb_test_r, 8'h0F);
      else if (wb_test_r == P_MC2_LOCK_STS)
        wb_read_test(wb_test_r, 8'h01);
      else
        wb_read_test(wb_test_r, 8'h00);
      @(posedge clk_gen_r);
    end
    end
    $display("[%012t] --- PLL Registers Check Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end
    
    if (EFB_I2C1 == "ENABLED") begin
    for (ii = 8'h40; ii <= 8'h49; ii = ii + 1) begin
      wb_test_r = ii;
      if (wb_test_r == P_I2C1_SR)
        wb_read_test(wb_test_r, 8'h20);
      else if (wb_test_r == (P_I2C1_CR))
        wb_read_test(wb_test_r, {(EFB_I2C1 == "ENABLED"), (I2C1_GEN_CALL == "ENABLED"), (I2C1_WAKEUP == "ENABLED"), 5'd0});
      else if (wb_test_r == P_I2C1_BR0)
        wb_read_test(wb_test_r, P_I2C1_BR0_INIT);
      else if (wb_test_r == P_I2C1_BR1)
        wb_read_test(wb_test_r, P_I2C1_BR1_INIT);
      else
        wb_read_test(wb_test_r, 8'h00);
      @(posedge clk_gen_r);
    end
    $display("[%012t] --- I2C1 Registers Check Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end
    
    if (EFB_I2C2 == "ENABLED") begin
    for (ii = 8'h4A; ii <= 8'h53; ii = ii + 1) begin
      wb_test_r = ii;
      if (wb_test_r == P_I2C2_SR)
        wb_read_test(wb_test_r, 8'h20);
      else if (wb_test_r == (P_I2C2_CR))
        wb_read_test(wb_test_r, {(EFB_I2C2 == "ENABLED"), (I2C2_GEN_CALL == "ENABLED"), (I2C2_WAKEUP == "ENABLED"), 5'd0});
      else if (wb_test_r == P_I2C2_BR0)
        wb_read_test(wb_test_r, P_I2C2_BR0_INIT);
      else if (wb_test_r == P_I2C2_BR1)
        wb_read_test(wb_test_r, P_I2C2_BR1_INIT);
      else
        wb_read_test(wb_test_r, 8'h00);
      @(posedge clk_gen_r);
    end
    $display("[%012t] --- I2C2 Registers Check Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end
    
    if (EFB_SPI == "ENABLED") begin
    for (ii = 8'h54; ii <= 8'h5D; ii = ii + 1) begin
    wb_test_r = ii;
      if (wb_test_r == P_SPITXDR || wb_test_r == P_SPIRXDR)
        wb_read(wb_test_r);
      else if (wb_test_r == P_SPICR1)
        wb_read_test(wb_test_r, {(EFB_SPI == "ENABLED"), (SPI_WAKEUP == "ENABLED"), 1'b0, 1'b0, 4'h0});
      else if (wb_test_r == P_SPICR2) //////////////////////
        wb_read_test(wb_test_r, {2'b00, (SPI_SLAVE_HANDSHAKE == "ENABLED"), 1'b0, (SPI_SLAVE_HANDSHAKE == "ENABLED"), (SPI_CLK_INV == "ENABLED"), (SPI_PHASE_ADJ == "ENABLED"), (SPI_LSB_FIRST == "ENABLED")});
      else if (wb_test_r == P_SPIBR)
        wb_read_test(wb_test_r, {2'h0, P_SPI_BR_INIT[5:0]});
      else if (wb_test_r == P_SPISR)
        wb_read_test(wb_test_r, 8'h10);
      else if (wb_test_r == P_SPIIRQEN) ///////////////////////////
        wb_read_test(wb_test_r, {3'd0, (SPI_INTR_TXRDY == "ENABLED"), (SPI_INTR_RXRDY == "ENABLED"), (SPI_INTR_TXOVR == "ENABLED"), (SPI_INTR_RXOVR == "ENABLED"), 1'b0});
      else
        wb_read_test(wb_test_r, 8'h00);
    @(posedge clk_gen_r);
    end
    $display("[%012t] --- SPI Registers Check Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end
    
    if (EFB_TC == "ENABLED") begin
    for (ii = 8'h5E; ii <= 8'h6F; ii = ii + 1) begin
    wb_test_r = ii;
      if (wb_test_r == P_TCCR0)
        wb_read(wb_test_r);
        // wb_read_test(wb_test_r, {(TC_RESETN == "ENABLED"), 1'b0, P_TC_PRESCALE[2:0], P_TC_CLKEDGE, P_TC_CLKSEL, 1'b0});
      else if (wb_test_r == P_TCCR1)
        wb_read_test(wb_test_r, {1'b0, (TC_OVERFLOW == "ENABLED"), (TC_ICAPTURE == "ENABLED"), (TC_TOP_SEL == "ON"), P_TC_OCM, P_TC_MODE});
      else if (wb_test_r == P_TCTOPSET0)
        wb_read_test(wb_test_r, P_TC_TOP_SET[7:0]);
      else if (wb_test_r == P_TCTOPSET1)
        wb_read_test(wb_test_r, P_TC_TOP_SET[15:8]);
      else if (wb_test_r == P_TCOCRSET0)
        wb_read_test(wb_test_r, P_TC_OCR_SET[7:0]);
      else if (wb_test_r == P_TCOCRSET1)
        wb_read_test(wb_test_r, P_TC_OCR_SET[15:8]);
      else if (wb_test_r == P_TCCR2)
        wb_read_test(wb_test_r, 8'h00);
      else if (wb_test_r == P_TCIRQ)
        wb_read(wb_test_r);
      else if (wb_test_r == P_TCIRQEN)
        wb_read_test(wb_test_r, {5'd0, (TC_ICR_INT == "ON"), (TC_OCR_INT == "ON"), (TC_OV_INT == "ON")});
      else
        wb_read(wb_test_r);
    @(posedge clk_gen_r);
    end
    $display("[%012t] --- Timer/Counter Registers Check Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end
    
    if (EFB_UFM == "ENABLED") begin
    for (ii = 8'h70; ii <= 8'h75; ii = ii + 1) begin
    wb_test_r = ii;
      if (wb_test_r == P_UFM_CFGSR)
        wb_read_test(wb_test_r, 8'h28);
      else if (wb_test_r == P_UFM_CFGIRQ)
        wb_read_test(wb_test_r, 8'h20);
      else
        wb_read_test(wb_test_r, 8'h00);
    @(posedge clk_gen_r);
    end
    $display("[%012t] --- UFM Registers Check Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end
    