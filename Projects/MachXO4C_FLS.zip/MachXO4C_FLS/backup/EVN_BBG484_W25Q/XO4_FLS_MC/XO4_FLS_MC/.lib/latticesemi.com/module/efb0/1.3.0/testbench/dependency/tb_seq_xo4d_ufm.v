    if (EFB_CFG0 == "ENABLED") begin
    $display("[%012t] ===== CFG0 Tests via User Interface =====", $time);

    // --- Read 1 Page
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Set UFM Address to Start Page
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hB4);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {6'd0, 2'b00}); // CFG0 = 00_00
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {2'b00, P_CFG0_INIT_PAGE[13:8]});
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, P_CFG0_INIT_PAGE[7:0]);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h73);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    if (CFG0_INIT_ALL_ZEROS == "DISABLED") begin
        wb_read_test(P_UFM_CFGRXDR, 8'hFE);
        wb_read_test(P_UFM_CFGRXDR, 8'hDC);
        wb_read_test(P_UFM_CFGRXDR, 8'hBA);
        wb_read_test(P_UFM_CFGRXDR, 8'h98);
        wb_read_test(P_UFM_CFGRXDR, 8'h76);
        wb_read_test(P_UFM_CFGRXDR, 8'h54);
        wb_read_test(P_UFM_CFGRXDR, 8'h32);
        wb_read_test(P_UFM_CFGRXDR, 8'h10);
        wb_read_test(P_UFM_CFGRXDR, 8'h01);
        wb_read_test(P_UFM_CFGRXDR, 8'h23);
        wb_read_test(P_UFM_CFGRXDR, 8'h45);
        wb_read_test(P_UFM_CFGRXDR, 8'h67);
        wb_read_test(P_UFM_CFGRXDR, 8'h89);
        wb_read_test(P_UFM_CFGRXDR, 8'hAB);
        wb_read_test(P_UFM_CFGRXDR, 8'hCD);
        wb_read_test(P_UFM_CFGRXDR, 8'hEF);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- CFG Initial Data Test Done (Memory File)---", $time);
    end // not CFG0_INIT_ALL_ZEROS
    else begin
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- CFG Initial Data Test Done (All 0's)---", $time);
    end
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Write Test only if enough UFM pages
    if (P_CFG0_INIT_PAGES > 1) begin

    //--- Erase CFG0
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Erase command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);     // Erase command = 0x0E
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);     // CFG0 erase = XXXX_X000_XX00_0001_XXXX_XXXX
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h80, 0);
    // Check UFM Status
    ufm_poll_status();
    
    while (cfg_ufm_busy_r) begin
        #1_000_000; // Erase wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    $display("[%012t] --- CFG Erase Test Done ---", $time);
    
    //--- Write 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_CFG0_INIT_PAGE == 0) begin
        // Set CFG0 Address to 0000 (reset) - CFG0 xxxx x000 xx00 0001 xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h46);                 // Reset Flash Address = 0x46
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h01);                 
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set CFG0 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b00});     // CFG0 = 00_00
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b00, P_CFG0_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_CFG0_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Write command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h70);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h02);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h04);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h05);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h06);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h07);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h09);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Write command to Address 0001
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h70);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h11);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h12);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h13);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h14);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h15);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h16);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h17);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h18);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h19);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Write 2 Pages Done ---", $time);
    
    // --- Read 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_CFG0_INIT_PAGE == 0) begin
        // Set CFG0 Address to 0000 (reset) - CFG0 xxxx x000 xx00 0001 xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h46);                 // Reset Flash Address = 0x46
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h01);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set CFG0 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b00});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b00, P_CFG0_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_CFG0_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h73);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h01);
    wb_read_test(P_UFM_CFGRXDR, 8'h02);
    wb_read_test(P_UFM_CFGRXDR, 8'h03);
    wb_read_test(P_UFM_CFGRXDR, 8'h04);
    wb_read_test(P_UFM_CFGRXDR, 8'h05);
    wb_read_test(P_UFM_CFGRXDR, 8'h06);
    wb_read_test(P_UFM_CFGRXDR, 8'h07);
    wb_read_test(P_UFM_CFGRXDR, 8'h08);
    wb_read_test(P_UFM_CFGRXDR, 8'h09);
    wb_read_test(P_UFM_CFGRXDR, 8'h0A);
    wb_read_test(P_UFM_CFGRXDR, 8'h0B);
    wb_read_test(P_UFM_CFGRXDR, 8'h0C);
    wb_read_test(P_UFM_CFGRXDR, 8'h0D);
    wb_read_test(P_UFM_CFGRXDR, 8'h0E);
    wb_read_test(P_UFM_CFGRXDR, 8'h0F);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h10);
    wb_read_test(P_UFM_CFGRXDR, 8'h11);
    wb_read_test(P_UFM_CFGRXDR, 8'h12);
    wb_read_test(P_UFM_CFGRXDR, 8'h13);
    wb_read_test(P_UFM_CFGRXDR, 8'h14);
    wb_read_test(P_UFM_CFGRXDR, 8'h15);
    wb_read_test(P_UFM_CFGRXDR, 8'h16);
    wb_read_test(P_UFM_CFGRXDR, 8'h17);
    wb_read_test(P_UFM_CFGRXDR, 8'h18);
    wb_read_test(P_UFM_CFGRXDR, 8'h19);
    wb_read_test(P_UFM_CFGRXDR, 8'h1A);
    wb_read_test(P_UFM_CFGRXDR, 8'h1B);
    wb_read_test(P_UFM_CFGRXDR, 8'h1C);
    wb_read_test(P_UFM_CFGRXDR, 8'h1D);
    wb_read_test(P_UFM_CFGRXDR, 8'h1E);
    wb_read_test(P_UFM_CFGRXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Read 2 Pages Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end // enough CFG0_INIT_PAGES

    end // EFB_CFG0

    if (EFB_CFG1 == "ENABLED") begin
    $display("[%012t] ===== CFG1 Tests via User Interface =====", $time);
    
    // --- Read 1 Page
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Set UFM Address to Start Page
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hB4);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {6'd0, 2'b01}); // CFG1 = 01_00
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {2'b00, P_CFG1_INIT_PAGE[13:8]});
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, P_CFG1_INIT_PAGE[7:0]);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h73);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    if (CFG1_INIT_ALL_ZEROS == "DISABLED") begin
        wb_read_test(P_UFM_CFGRXDR, 8'hFE);
        wb_read_test(P_UFM_CFGRXDR, 8'hDC);
        wb_read_test(P_UFM_CFGRXDR, 8'hBA);
        wb_read_test(P_UFM_CFGRXDR, 8'h98);
        wb_read_test(P_UFM_CFGRXDR, 8'h76);
        wb_read_test(P_UFM_CFGRXDR, 8'h54);
        wb_read_test(P_UFM_CFGRXDR, 8'h32);
        wb_read_test(P_UFM_CFGRXDR, 8'h10);
        wb_read_test(P_UFM_CFGRXDR, 8'h01);
        wb_read_test(P_UFM_CFGRXDR, 8'h23);
        wb_read_test(P_UFM_CFGRXDR, 8'h45);
        wb_read_test(P_UFM_CFGRXDR, 8'h67);
        wb_read_test(P_UFM_CFGRXDR, 8'h89);
        wb_read_test(P_UFM_CFGRXDR, 8'hAB);
        wb_read_test(P_UFM_CFGRXDR, 8'hCD);
        wb_read_test(P_UFM_CFGRXDR, 8'hEF);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- CFG Initial Data Test Done (Memory File)---", $time);
    end // not CFG1_INIT_ALL_ZEROS
    else begin
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- CFG Initial Data Test Done (All 0's)---", $time);
    end
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Write Test only if enough UFM pages
    if (P_CFG1_INIT_PAGES > 1) begin

    //--- Erase CFG1
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Erase command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);     // Erase command = 0x0E
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h02);     // CFG1 erase = XXXX_X000_XX00_0010_XXXX_XXXX
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h80, 0);
    // Check UFM Status
    ufm_poll_status();
    
    while (cfg_ufm_busy_r) begin
        #1_000_000; // Erase wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    $display("[%012t] --- CFG Erase Test Done ---", $time);
    
    //--- Write 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_CFG1_INIT_PAGE == 0) begin
        // Set CFG1 Address to 0000 (reset) - CFG1 xxxx x000 xx00 0010 xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h46);                 // Reset Flash Address = 0x46
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h02);                 
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set CFG1 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b01});     // CFG1 = 01_00
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b00, P_CFG1_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_CFG1_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Write command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h70);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h02);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h04);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h05);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h06);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h07);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h09);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Write command to Address 0001
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h70);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h11);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h12);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h13);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h14);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h15);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h16);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h17);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h18);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h19);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Write 2 Pages Done ---", $time);
    
    // --- Read 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_CFG1_INIT_PAGE == 0) begin
        // Set CFG1 Address to 0000 (reset) - CFG1 xxxx x000 xx00 0010 xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h46);                 // Reset Flash Address = 0x46
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h02);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set CFG1 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b01});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b00, P_CFG1_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_CFG1_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h73);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h01);
    wb_read_test(P_UFM_CFGRXDR, 8'h02);
    wb_read_test(P_UFM_CFGRXDR, 8'h03);
    wb_read_test(P_UFM_CFGRXDR, 8'h04);
    wb_read_test(P_UFM_CFGRXDR, 8'h05);
    wb_read_test(P_UFM_CFGRXDR, 8'h06);
    wb_read_test(P_UFM_CFGRXDR, 8'h07);
    wb_read_test(P_UFM_CFGRXDR, 8'h08);
    wb_read_test(P_UFM_CFGRXDR, 8'h09);
    wb_read_test(P_UFM_CFGRXDR, 8'h0A);
    wb_read_test(P_UFM_CFGRXDR, 8'h0B);
    wb_read_test(P_UFM_CFGRXDR, 8'h0C);
    wb_read_test(P_UFM_CFGRXDR, 8'h0D);
    wb_read_test(P_UFM_CFGRXDR, 8'h0E);
    wb_read_test(P_UFM_CFGRXDR, 8'h0F);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h10);
    wb_read_test(P_UFM_CFGRXDR, 8'h11);
    wb_read_test(P_UFM_CFGRXDR, 8'h12);
    wb_read_test(P_UFM_CFGRXDR, 8'h13);
    wb_read_test(P_UFM_CFGRXDR, 8'h14);
    wb_read_test(P_UFM_CFGRXDR, 8'h15);
    wb_read_test(P_UFM_CFGRXDR, 8'h16);
    wb_read_test(P_UFM_CFGRXDR, 8'h17);
    wb_read_test(P_UFM_CFGRXDR, 8'h18);
    wb_read_test(P_UFM_CFGRXDR, 8'h19);
    wb_read_test(P_UFM_CFGRXDR, 8'h1A);
    wb_read_test(P_UFM_CFGRXDR, 8'h1B);
    wb_read_test(P_UFM_CFGRXDR, 8'h1C);
    wb_read_test(P_UFM_CFGRXDR, 8'h1D);
    wb_read_test(P_UFM_CFGRXDR, 8'h1E);
    wb_read_test(P_UFM_CFGRXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Read 2 Pages Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end // enough CFG1_INIT_PAGES

    end // EFB_CFG1

    if (EFB_UFM0 == "ENABLED") begin
    $display("[%012t] ===== UFM0 Tests via User Interface =====", $time);
    
    // --- Read 1 Page
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Set UFM Address to Start Page
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hB4);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {6'd0, 2'b00}); // UFM0 = 00_01
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {2'b01, P_UFM0_INIT_PAGE[13:8]});
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, P_UFM0_INIT_PAGE[7:0]);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    if (UFM0_INIT_ALL_ZEROS == "DISABLED") begin
        wb_read_test(P_UFM_CFGRXDR, 8'hFE);
        wb_read_test(P_UFM_CFGRXDR, 8'hDC);
        wb_read_test(P_UFM_CFGRXDR, 8'hBA);
        wb_read_test(P_UFM_CFGRXDR, 8'h98);
        wb_read_test(P_UFM_CFGRXDR, 8'h76);
        wb_read_test(P_UFM_CFGRXDR, 8'h54);
        wb_read_test(P_UFM_CFGRXDR, 8'h32);
        wb_read_test(P_UFM_CFGRXDR, 8'h10);
        wb_read_test(P_UFM_CFGRXDR, 8'h01);
        wb_read_test(P_UFM_CFGRXDR, 8'h23);
        wb_read_test(P_UFM_CFGRXDR, 8'h45);
        wb_read_test(P_UFM_CFGRXDR, 8'h67);
        wb_read_test(P_UFM_CFGRXDR, 8'h89);
        wb_read_test(P_UFM_CFGRXDR, 8'hAB);
        wb_read_test(P_UFM_CFGRXDR, 8'hCD);
        wb_read_test(P_UFM_CFGRXDR, 8'hEF);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (Memory File)---", $time);
    end // not UFM_INIT_ALL_ZEROS
    else begin
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (All 0's)---", $time);
    end
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Write Test only if enough UFM pages
    if (P_UFM0_INIT_PAGES > 1) begin

    //--- Erase UFM
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Erase command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCB);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h04); // UFM0 erase = XXX_XXXX_XX00_01XX_XXXX_XXXX
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h80, 0);
    // Check UFM Status
    ufm_poll_status();
    
    while (cfg_ufm_busy_r) begin
        #1_000_000; // Erase wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    $display("[%012t] --- UFM Erase Test Done ---", $time);
    
    //--- Write 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM0_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset) - UFM0 xxxx xxxx xx00 01xx xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h04);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM0 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b00});         // UFM0 = 00_01
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b01, P_UFM0_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM0_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Write command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h02);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h04);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h05);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h06);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h07);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h09);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Write command to Address 0001
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h11);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h12);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h13);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h14);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h15);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h16);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h17);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h18);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h19);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Write 2 Pages Done ---", $time);
    
    // --- Read 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM2_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset) - UFM0 xxxx xxxx xx00 01xx xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h04);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM0 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b00});         // UFM0 = 00_01
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b01, P_UFM0_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM0_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h01);
    wb_read_test(P_UFM_CFGRXDR, 8'h02);
    wb_read_test(P_UFM_CFGRXDR, 8'h03);
    wb_read_test(P_UFM_CFGRXDR, 8'h04);
    wb_read_test(P_UFM_CFGRXDR, 8'h05);
    wb_read_test(P_UFM_CFGRXDR, 8'h06);
    wb_read_test(P_UFM_CFGRXDR, 8'h07);
    wb_read_test(P_UFM_CFGRXDR, 8'h08);
    wb_read_test(P_UFM_CFGRXDR, 8'h09);
    wb_read_test(P_UFM_CFGRXDR, 8'h0A);
    wb_read_test(P_UFM_CFGRXDR, 8'h0B);
    wb_read_test(P_UFM_CFGRXDR, 8'h0C);
    wb_read_test(P_UFM_CFGRXDR, 8'h0D);
    wb_read_test(P_UFM_CFGRXDR, 8'h0E);
    wb_read_test(P_UFM_CFGRXDR, 8'h0F);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h10);
    wb_read_test(P_UFM_CFGRXDR, 8'h11);
    wb_read_test(P_UFM_CFGRXDR, 8'h12);
    wb_read_test(P_UFM_CFGRXDR, 8'h13);
    wb_read_test(P_UFM_CFGRXDR, 8'h14);
    wb_read_test(P_UFM_CFGRXDR, 8'h15);
    wb_read_test(P_UFM_CFGRXDR, 8'h16);
    wb_read_test(P_UFM_CFGRXDR, 8'h17);
    wb_read_test(P_UFM_CFGRXDR, 8'h18);
    wb_read_test(P_UFM_CFGRXDR, 8'h19);
    wb_read_test(P_UFM_CFGRXDR, 8'h1A);
    wb_read_test(P_UFM_CFGRXDR, 8'h1B);
    wb_read_test(P_UFM_CFGRXDR, 8'h1C);
    wb_read_test(P_UFM_CFGRXDR, 8'h1D);
    wb_read_test(P_UFM_CFGRXDR, 8'h1E);
    wb_read_test(P_UFM_CFGRXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Read 2 Pages Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end // enough UFM0_INIT_PAGES
    
    end // EFB_UFM0

    if (EFB_UFM1 == "ENABLED") begin
    $display("[%012t] ===== UFM1 Tests via User Interface =====", $time);
    
    // --- Read 1 Page
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Set UFM Address to Start Page
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hB4);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {6'd0, 2'b01}); // UFM1 = 01_01
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {2'b01, P_UFM1_INIT_PAGE[13:8]});
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, P_UFM1_INIT_PAGE[7:0]);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    if (UFM1_INIT_ALL_ZEROS == "DISABLED") begin
        wb_read_test(P_UFM_CFGRXDR, 8'hFE);
        wb_read_test(P_UFM_CFGRXDR, 8'hDC);
        wb_read_test(P_UFM_CFGRXDR, 8'hBA);
        wb_read_test(P_UFM_CFGRXDR, 8'h98);
        wb_read_test(P_UFM_CFGRXDR, 8'h76);
        wb_read_test(P_UFM_CFGRXDR, 8'h54);
        wb_read_test(P_UFM_CFGRXDR, 8'h32);
        wb_read_test(P_UFM_CFGRXDR, 8'h10);
        wb_read_test(P_UFM_CFGRXDR, 8'h01);
        wb_read_test(P_UFM_CFGRXDR, 8'h23);
        wb_read_test(P_UFM_CFGRXDR, 8'h45);
        wb_read_test(P_UFM_CFGRXDR, 8'h67);
        wb_read_test(P_UFM_CFGRXDR, 8'h89);
        wb_read_test(P_UFM_CFGRXDR, 8'hAB);
        wb_read_test(P_UFM_CFGRXDR, 8'hCD);
        wb_read_test(P_UFM_CFGRXDR, 8'hEF);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (Memory File)---", $time);
    end // not UFM_INIT_ALL_ZEROS
    else begin
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (All 0's)---", $time);
    end
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Write Test only if enough UFM pages
    if (P_UFM1_INIT_PAGES > 1) begin

    //--- Erase UFM
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Erase command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCB);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08); // UFM1 erase = XXX_XXXX_XX00_10XX_XXXX_XXXX
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h80, 0);
    // Check UFM Status
    ufm_poll_status();
    
    while (cfg_ufm_busy_r) begin
        #1_000_000; // Erase wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    $display("[%012t] --- UFM Erase Test Done ---", $time);
    
    //--- Write 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM1_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset) - UFM1 xxxx xxxx xx00 10xx xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h08);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM1 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b01}); // UFM1 = 01_01
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b01, P_UFM1_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM1_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Write command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h02);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h04);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h05);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h06);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h07);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h09);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Write command to Address 0001
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h11);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h12);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h13);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h14);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h15);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h16);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h17);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h18);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h19);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Write 2 Pages Done ---", $time);
    
    // --- Read 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM1_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset) - UFM1 xxxx xxxx xx00 10xx xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h08);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM1 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b01});     // UFM1 = 01_01
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b01, P_UFM1_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM1_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h01);
    wb_read_test(P_UFM_CFGRXDR, 8'h02);
    wb_read_test(P_UFM_CFGRXDR, 8'h03);
    wb_read_test(P_UFM_CFGRXDR, 8'h04);
    wb_read_test(P_UFM_CFGRXDR, 8'h05);
    wb_read_test(P_UFM_CFGRXDR, 8'h06);
    wb_read_test(P_UFM_CFGRXDR, 8'h07);
    wb_read_test(P_UFM_CFGRXDR, 8'h08);
    wb_read_test(P_UFM_CFGRXDR, 8'h09);
    wb_read_test(P_UFM_CFGRXDR, 8'h0A);
    wb_read_test(P_UFM_CFGRXDR, 8'h0B);
    wb_read_test(P_UFM_CFGRXDR, 8'h0C);
    wb_read_test(P_UFM_CFGRXDR, 8'h0D);
    wb_read_test(P_UFM_CFGRXDR, 8'h0E);
    wb_read_test(P_UFM_CFGRXDR, 8'h0F);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h10);
    wb_read_test(P_UFM_CFGRXDR, 8'h11);
    wb_read_test(P_UFM_CFGRXDR, 8'h12);
    wb_read_test(P_UFM_CFGRXDR, 8'h13);
    wb_read_test(P_UFM_CFGRXDR, 8'h14);
    wb_read_test(P_UFM_CFGRXDR, 8'h15);
    wb_read_test(P_UFM_CFGRXDR, 8'h16);
    wb_read_test(P_UFM_CFGRXDR, 8'h17);
    wb_read_test(P_UFM_CFGRXDR, 8'h18);
    wb_read_test(P_UFM_CFGRXDR, 8'h19);
    wb_read_test(P_UFM_CFGRXDR, 8'h1A);
    wb_read_test(P_UFM_CFGRXDR, 8'h1B);
    wb_read_test(P_UFM_CFGRXDR, 8'h1C);
    wb_read_test(P_UFM_CFGRXDR, 8'h1D);
    wb_read_test(P_UFM_CFGRXDR, 8'h1E);
    wb_read_test(P_UFM_CFGRXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Read 2 Pages Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end // enough UFM1_INIT_PAGES

    end // EFB_UFM1
    
    if (EFB_UFM2 == "ENABLED") begin
    $display("[%012t] ===== UFM2 Tests via User Interface =====", $time);
    
    // --- Read 1 Page
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Set UFM Address to Start Page
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hB4);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {6'd0, 2'b10}); // UFM2 = 10_00
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {2'b00, P_UFM2_INIT_PAGE[13:8]});
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, P_UFM2_INIT_PAGE[7:0]);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    if (UFM2_INIT_ALL_ZEROS == "DISABLED") begin
        wb_read_test(P_UFM_CFGRXDR, 8'hFE);
        wb_read_test(P_UFM_CFGRXDR, 8'hDC);
        wb_read_test(P_UFM_CFGRXDR, 8'hBA);
        wb_read_test(P_UFM_CFGRXDR, 8'h98);
        wb_read_test(P_UFM_CFGRXDR, 8'h76);
        wb_read_test(P_UFM_CFGRXDR, 8'h54);
        wb_read_test(P_UFM_CFGRXDR, 8'h32);
        wb_read_test(P_UFM_CFGRXDR, 8'h10);
        wb_read_test(P_UFM_CFGRXDR, 8'h01);
        wb_read_test(P_UFM_CFGRXDR, 8'h23);
        wb_read_test(P_UFM_CFGRXDR, 8'h45);
        wb_read_test(P_UFM_CFGRXDR, 8'h67);
        wb_read_test(P_UFM_CFGRXDR, 8'h89);
        wb_read_test(P_UFM_CFGRXDR, 8'hAB);
        wb_read_test(P_UFM_CFGRXDR, 8'hCD);
        wb_read_test(P_UFM_CFGRXDR, 8'hEF);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (Memory File)---", $time);
    end // not UFM_INIT_ALL_ZEROS
    else begin
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (All 0's)---", $time);
    end
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Write Test only if enough UFM pages
    if (P_UFM2_INIT_PAGES > 1) begin
    
    //--- Erase UFM
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Erase command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCB);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10); // UFM2 erase = XXX_XXXX_XX01_00XX_XXXX_XXXX
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h80, 0);
    // Check UFM Status
    ufm_poll_status();
    
    while (cfg_ufm_busy_r) begin
        #1_000_000; // Erase wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    $display("[%012t] --- UFM Erase Test Done ---", $time);
    
    //--- Write 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM2_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset) - UFM2 xxxx xxxx xx01 00xx xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h10);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM2 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b10});         // UFM2 = 10_00
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b00, P_UFM2_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM2_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Write command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h02);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h04);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h05);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h06);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h07);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h09);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Write command to Address 0001
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h11);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h12);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h13);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h14);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h15);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h16);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h17);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h18);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h19);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Write 2 Pages Done ---", $time);
    
    // --- Read 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM2_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset) - UFM2 xxxx xxxx xx01 00xx xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h10);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM2 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b10});         // UFM2 = 10_00
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b00, P_UFM2_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM2_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h01);
    wb_read_test(P_UFM_CFGRXDR, 8'h02);
    wb_read_test(P_UFM_CFGRXDR, 8'h03);
    wb_read_test(P_UFM_CFGRXDR, 8'h04);
    wb_read_test(P_UFM_CFGRXDR, 8'h05);
    wb_read_test(P_UFM_CFGRXDR, 8'h06);
    wb_read_test(P_UFM_CFGRXDR, 8'h07);
    wb_read_test(P_UFM_CFGRXDR, 8'h08);
    wb_read_test(P_UFM_CFGRXDR, 8'h09);
    wb_read_test(P_UFM_CFGRXDR, 8'h0A);
    wb_read_test(P_UFM_CFGRXDR, 8'h0B);
    wb_read_test(P_UFM_CFGRXDR, 8'h0C);
    wb_read_test(P_UFM_CFGRXDR, 8'h0D);
    wb_read_test(P_UFM_CFGRXDR, 8'h0E);
    wb_read_test(P_UFM_CFGRXDR, 8'h0F);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h10);
    wb_read_test(P_UFM_CFGRXDR, 8'h11);
    wb_read_test(P_UFM_CFGRXDR, 8'h12);
    wb_read_test(P_UFM_CFGRXDR, 8'h13);
    wb_read_test(P_UFM_CFGRXDR, 8'h14);
    wb_read_test(P_UFM_CFGRXDR, 8'h15);
    wb_read_test(P_UFM_CFGRXDR, 8'h16);
    wb_read_test(P_UFM_CFGRXDR, 8'h17);
    wb_read_test(P_UFM_CFGRXDR, 8'h18);
    wb_read_test(P_UFM_CFGRXDR, 8'h19);
    wb_read_test(P_UFM_CFGRXDR, 8'h1A);
    wb_read_test(P_UFM_CFGRXDR, 8'h1B);
    wb_read_test(P_UFM_CFGRXDR, 8'h1C);
    wb_read_test(P_UFM_CFGRXDR, 8'h1D);
    wb_read_test(P_UFM_CFGRXDR, 8'h1E);
    wb_read_test(P_UFM_CFGRXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Read 2 Pages Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end

    end // EFB_UFM3
    
    if (EFB_UFM3 == "ENABLED") begin
    $display("[%012t] ===== UFM3 Tests via User Interface =====", $time);
    
    // --- Read 1 Page
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Set UFM Address to Start Page
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hB4);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {6'd0, 2'b10}); // UFM3 = 10_01
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, {2'b01, P_UFM3_INIT_PAGE[13:8]});
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, P_UFM3_INIT_PAGE[7:0]);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    if (UFM3_INIT_ALL_ZEROS == "DISABLED") begin
        wb_read_test(P_UFM_CFGRXDR, 8'hFE);
        wb_read_test(P_UFM_CFGRXDR, 8'hDC);
        wb_read_test(P_UFM_CFGRXDR, 8'hBA);
        wb_read_test(P_UFM_CFGRXDR, 8'h98);
        wb_read_test(P_UFM_CFGRXDR, 8'h76);
        wb_read_test(P_UFM_CFGRXDR, 8'h54);
        wb_read_test(P_UFM_CFGRXDR, 8'h32);
        wb_read_test(P_UFM_CFGRXDR, 8'h10);
        wb_read_test(P_UFM_CFGRXDR, 8'h01);
        wb_read_test(P_UFM_CFGRXDR, 8'h23);
        wb_read_test(P_UFM_CFGRXDR, 8'h45);
        wb_read_test(P_UFM_CFGRXDR, 8'h67);
        wb_read_test(P_UFM_CFGRXDR, 8'h89);
        wb_read_test(P_UFM_CFGRXDR, 8'hAB);
        wb_read_test(P_UFM_CFGRXDR, 8'hCD);
        wb_read_test(P_UFM_CFGRXDR, 8'hEF);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (Memory File)---", $time);
    end // not UFM_INIT_ALL_ZEROS
    else begin
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        wb_read_test(P_UFM_CFGRXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        $display("[%012t] --- UFM Initial Data Test Done (All 0's)---", $time);
    end
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Write Test only if enough UFM pages
    if (P_UFM3_INIT_PAGES > 1) begin

    //--- Erase UFM
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    // Erase command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCB);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h20); // UFM3 erase = XXX_XXXX_XX10_00XX_XXXX_XXXX
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h80, 0);
    // Check UFM Status
    ufm_poll_status();
    
    while (cfg_ufm_busy_r) begin
        #1_000_000; // Erase wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    $display("[%012t] --- UFM Erase Test Done ---", $time);
    
    //--- Write 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM3_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset) - UFM3 xxxx xxxx xx10 00xx xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h20);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM3 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b10});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b01, P_UFM3_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM3_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Write command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h02);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h04);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h05);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h06);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h07);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h09);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h0F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Write command to Address 0001
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hC9);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h01);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    // Data
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h11);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h12);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h13);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h14);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h15);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h16);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h17);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h18);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h19);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1A);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1B);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1C);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1D);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1E);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    ufm_poll_busy_flag(8'h80, 0);
    
    while (cfg_ufm_busy_r) begin
        #10_000; // Write wait time
        ufm_poll_busy_flag(8'h80, 1);
    end
    
    ufm_poll_busy_flag(8'h00, 0);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Write 2 Pages Done ---", $time);
    
    // --- Read 2 Pages
    // Enable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGTXDR, 8'h74);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h08);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    #5_000; // Enable wait time
    
    // Check Busy flag
    ufm_poll_busy_flag(8'h00, 0);
    // Check UFM Status
    ufm_poll_status();
    
    if(P_UFM3_INIT_PAGE == 0) begin
        // Set UFM Address to 0000 (reset) - UFM3 xxxx xxxx xx10 00xx xxxx xxxx
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h47);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h20);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    else begin
        // Set UFM3 Address to Start Page
        wb_write(P_UFM_CFGCR, 8'h80);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'hB4);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {6'd0, 2'b10});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, {2'b01, P_UFM3_INIT_PAGE[13:8]});
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGTXDR, P_UFM3_INIT_PAGE[7:0]);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
        wb_write(P_UFM_CFGCR, 8'h00);
        repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    end
    
    // Read command
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hCA);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h10);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h03);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGSR);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    wb_read(P_UFM_CFGRXDR);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h00);
    wb_read_test(P_UFM_CFGRXDR, 8'h01);
    wb_read_test(P_UFM_CFGRXDR, 8'h02);
    wb_read_test(P_UFM_CFGRXDR, 8'h03);
    wb_read_test(P_UFM_CFGRXDR, 8'h04);
    wb_read_test(P_UFM_CFGRXDR, 8'h05);
    wb_read_test(P_UFM_CFGRXDR, 8'h06);
    wb_read_test(P_UFM_CFGRXDR, 8'h07);
    wb_read_test(P_UFM_CFGRXDR, 8'h08);
    wb_read_test(P_UFM_CFGRXDR, 8'h09);
    wb_read_test(P_UFM_CFGRXDR, 8'h0A);
    wb_read_test(P_UFM_CFGRXDR, 8'h0B);
    wb_read_test(P_UFM_CFGRXDR, 8'h0C);
    wb_read_test(P_UFM_CFGRXDR, 8'h0D);
    wb_read_test(P_UFM_CFGRXDR, 8'h0E);
    wb_read_test(P_UFM_CFGRXDR, 8'h0F);
    
    wb_read_test(P_UFM_CFGRXDR, 8'h10);
    wb_read_test(P_UFM_CFGRXDR, 8'h11);
    wb_read_test(P_UFM_CFGRXDR, 8'h12);
    wb_read_test(P_UFM_CFGRXDR, 8'h13);
    wb_read_test(P_UFM_CFGRXDR, 8'h14);
    wb_read_test(P_UFM_CFGRXDR, 8'h15);
    wb_read_test(P_UFM_CFGRXDR, 8'h16);
    wb_read_test(P_UFM_CFGRXDR, 8'h17);
    wb_read_test(P_UFM_CFGRXDR, 8'h18);
    wb_read_test(P_UFM_CFGRXDR, 8'h19);
    wb_read_test(P_UFM_CFGRXDR, 8'h1A);
    wb_read_test(P_UFM_CFGRXDR, 8'h1B);
    wb_read_test(P_UFM_CFGRXDR, 8'h1C);
    wb_read_test(P_UFM_CFGRXDR, 8'h1D);
    wb_read_test(P_UFM_CFGRXDR, 8'h1E);
    wb_read_test(P_UFM_CFGRXDR, 8'h1F);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Disable Configuration Interface
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h26);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    wb_write(P_UFM_CFGCR, 8'h80);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGTXDR, 8'hFF);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    wb_write(P_UFM_CFGCR, 8'h00);
    repeat (UFM_WAIT_CYCLE) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Read 2 Pages Test Done ---", $time);
    repeat(10) @ (posedge clk_gen_r);
    end // enough UFM3_INIT_PAGES

    end // EFB_UFM3