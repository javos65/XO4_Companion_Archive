`ifndef __TB_TIMER_CHK__
`define __TB_TIMER_CHK__

`timescale 1ps / 1ps
module tb_timer_checker #(
    parameter DEBUG = 1
)(
    input       clk_i,
    input       rstn_i,
    input       enable_i,
    input       tc_oc_i,
    input       tc_int_i,
    output reg  oc_chk_o,
    output reg  int_chk_o,
    output reg  timeout_o
);

    reg timeout_exp_r;
    reg inter_exp_r;
    reg timeout_count_en_r;
    reg [31:0] timeout_count_r;
    reg [31:0] timeout_max_r;
    reg timer_check_en_r;
    reg interr_check_en_r;
    
    initial begin
        timeout_exp_r = 1'b1;
        inter_exp_r   = 1'b0;
        timeout_o = 1'b0;
        timeout_count_en_r = 1'b0;
        timeout_count_r = 0;
        timeout_max_r = 0;
        timer_check_en_r = 1'b0;
        interr_check_en_r = 1'b0;
    end

    task set_exp_tc (
        input expected
    );
        begin
            timeout_exp_r = expected;
        end
    endtask
    
    task set_exp_int (
        input expected
    );
        begin
            inter_exp_r = expected;
        end
    endtask

    task timer_check;
        input enable;
        begin
            timer_check_en_r = enable;
            if (DEBUG && timer_check_en_r)
                $display("[%012t]   ### Timer/Counter tc_oc Check Enabled", $time);
        end
    endtask
    
    task interr_check;
        input enable;
        begin
            interr_check_en_r = enable;
            if (DEBUG && interr_check_en_r)
                $display("[%012t]   ### Timer/Counter tc_int Check Enabled", $time);
        end
    endtask

    // Continuous timer/counter output checking
    always @(posedge clk_i or negedge rstn_i) begin
        if (!rstn_i) begin
            oc_chk_o <= 1;
        end else if (enable_i && timer_check_en_r) begin
            if (tc_oc_i === timeout_exp_r) begin
                oc_chk_o <= 1;
            end else begin
                if (oc_chk_o == 1)
                    $display("[%012t]   !!! Timer/Counter Timeout Check Fail !!!", $time);
                oc_chk_o <= 0;
            end
        end
    end

    // Continuous interrupt checking
    always @(posedge clk_i or negedge rstn_i) begin
        if (!rstn_i) begin
            int_chk_o <= 1;
        end else if (enable_i && interr_check_en_r) begin
            if (tc_int_i === inter_exp_r) begin
                int_chk_o <= 1;
            end else begin
                if (int_chk_o == 1)
                    $display("[%012t]   !!! Timer/Counter Interrupt Check Fail !!!", $time);
                int_chk_o <= 0;
            end
        end
    end

    // Timeout counter logic
    always @(posedge clk_i or negedge rstn_i) begin
        if (!rstn_i) begin
            timeout_count_en_r <= 1'b0;
            timeout_count_r <= 0;
            timeout_o <= 1'b0;
        end else begin
            if (timeout_count_en_r) begin
                if (timeout_count_r >= timeout_max_r) begin
                    timeout_o <= 1'b1;
                    timeout_count_en_r <= 1'b0;
                    $display("[%012t]   ??? Timer/Counter Timeout - no assertion ???", $time);
                end else begin
                    timeout_count_r <= timeout_count_r + 1;
                end
            end
        end
    end
    
    // Start timeout counter
    task start_timeout_counter;
        input integer max_cycles;
        begin
            timeout_max_r = max_cycles;
            timeout_count_r = 0;
            timeout_o = 1'b0;
            timeout_count_en_r = 1'b1;
        end
    endtask
    
    // Stop timeout counter
    task stop_timeout_counter;
        begin
            timeout_count_en_r = 1'b0;
            if (DEBUG)
                $display("[%012t]   ### Timer/Counter Check Pass - assertion detected", $time);
        end
    endtask

endmodule
`endif
