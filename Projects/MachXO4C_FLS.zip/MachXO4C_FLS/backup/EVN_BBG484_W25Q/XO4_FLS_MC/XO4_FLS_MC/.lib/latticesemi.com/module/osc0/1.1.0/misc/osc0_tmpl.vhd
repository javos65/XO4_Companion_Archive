component osc0 is
    port(
        stdby_i: in std_logic;
        clk_out_o: out std_logic;
        sedstdby_o: out std_logic
    );
end component;

__: osc0 port map(
    stdby_i=>,
    clk_out_o=>,
    sedstdby_o=>
);
