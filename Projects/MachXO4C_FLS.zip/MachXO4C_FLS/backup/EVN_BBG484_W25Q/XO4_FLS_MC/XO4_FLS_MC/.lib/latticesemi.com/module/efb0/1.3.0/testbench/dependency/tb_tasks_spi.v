
task get_spi_status;
    begin
        wb_read(P_SPISR);
        spi_tip_r   <= wb_dat_o[7];
        spi_trdy_r  <= wb_dat_o[4];
        spi_rrdy_r  <= wb_dat_o[3];
        spi_roe_r   <= wb_dat_o[1];
        spi_mdf_r   <= wb_dat_o[0];
    end
endtask

task spi_1write;
    input [7:0] spi_cs;
    input [7:0] spi_data;
    reg [7:0] csn;
    
    begin
        case (spi_cs)
            0:   csn = 8'hFE;
            1:   csn = 8'hFD;
            2:   csn = 8'hFB;
            3:   csn = 8'hF7;
            4:   csn = 8'hEF;
            5:   csn = 8'hDF;
            6:   csn = 8'hBF;
            7:   csn = 8'h7F;
        default: csn = 8'hFF;
        endcase
    
        wb_write(P_SPICR2, 8'hC0);
        get_spi_status();
        while (spi_trdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        wb_write(P_SPICSR, csn);
        @(posedge clk_gen_r);
        
        wb_write(P_SPITXDR, spi_data);
        @(posedge clk_gen_r);
        get_spi_status();
        while (spi_rrdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        get_spi_status();
        while (spi_trdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        wb_write(P_SPICR2, 8'h80);
        @(posedge clk_gen_r);
        
        get_spi_status();
        while (spi_tip_r == 1'b1) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
    end
endtask

task spi_cmd_1write;
    input [7:0] spi_cs;
    input [7:0] spi_data;
    reg [7:0] csn;
    
    begin
        case (spi_cs)
            0:   csn = 8'hFE;
            1:   csn = 8'hFD;
            2:   csn = 8'hFB;
            3:   csn = 8'hF7;
            4:   csn = 8'hEF;
            5:   csn = 8'hDF;
            6:   csn = 8'hBF;
            7:   csn = 8'h7F;
        default: csn = 8'hFF;
        endcase
    
        wb_write(P_SPICR2, 8'hC0);
        get_spi_status();
        while (spi_trdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        wb_write(P_SPICSR, csn);
        @(posedge clk_gen_r);
        wb_write(P_SPITXDR, 8'hA5);
        @(posedge clk_gen_r);
        get_spi_status();
        while (spi_rrdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        wb_write(P_SPITXDR, spi_data);
        @(posedge clk_gen_r);
        get_spi_status();
        while (spi_rrdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        get_spi_status();
        while (spi_trdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        wb_write(P_SPICR2, 8'h80);
        @(posedge clk_gen_r);
        
        get_spi_status();
        while (spi_tip_r == 1'b1) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
    end
endtask

task spi_cmd_1read;
    input [7:0] spi_cs;
    input [7:0] spi_data;
    reg [7:0] csn;
    
    begin
        case (spi_cs)
            0:   csn = 8'hFE;
            1:   csn = 8'hFD;
            2:   csn = 8'hFB;
            3:   csn = 8'hF7;
            4:   csn = 8'hEF;
            5:   csn = 8'hDF;
            6:   csn = 8'hBF;
            7:   csn = 8'h7F;
        default: csn = 8'hFF;
        endcase
    
        wb_write(P_SPICR2, 8'hC0);
        get_spi_status();
        while (spi_trdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        wb_write(P_SPICSR, csn);
        @(posedge clk_gen_r);
        wb_write(P_SPITXDR, 8'hF7);
        @(posedge clk_gen_r);
        get_spi_status();
        while (spi_rrdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        get_spi_status();
        while (spi_rrdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        wb_write(P_SPITXDR, 8'h00);
        @(posedge clk_gen_r);
        
        repeat (8) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_status();
        while (spi_rrdy_r == 1'b0) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        wb_write(P_SPICR2, 8'h80);
        @(posedge clk_gen_r);
        
        get_spi_status();
        while (spi_tip_r == 1'b1) begin
            get_spi_status();
            @(posedge clk_gen_r);
        end
        
        wb_read_test(P_SPIRXDR, spi_data);
        @(posedge clk_gen_r);
    end
endtask

task get_spi_t_status;
    begin
        wbt_read(P_SPISR);
        spi_t_tip_r   <= wbt_dat_o[7];
        spi_t_trdy_r  <= wbt_dat_o[4];
        spi_t_rrdy_r  <= wbt_dat_o[3];
        spi_t_roe_r   <= wbt_dat_o[1];
        spi_t_mdf_r   <= wbt_dat_o[0];
    end
endtask

task spi_tst_1write;
    input [7:0] spi_cs;
    input [7:0] spi_data;
    reg [7:0] csn;
    
    begin
        case (spi_cs)
            0:   csn = 8'hFE;
            1:   csn = 8'hFD;
            2:   csn = 8'hFB;
            3:   csn = 8'hF7;
            4:   csn = 8'hEF;
            5:   csn = 8'hDF;
            6:   csn = 8'hBF;
            7:   csn = 8'h7F;
        default: csn = 8'hFF;
        endcase
    
        wbt_write(P_SPICR2, 8'hC0);
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPICSR, csn);
        @(posedge clk_gen_r);
        wbt_write(P_SPITXDR, spi_data);
        @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPICR2, 8'h80);
        @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_tip_r == 1'b1) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
    end
endtask

task spi_ufm_tst_3_cmd;
    input [7:0] spi_data0;
    input [7:0] spi_data1;
    input [7:0] spi_data2;
    
    begin
        wbt_write(P_SPICR2, 8'hC0);
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPITXDR, 8'h08);    // dummy
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        ufm_sn_r = 1'b0;
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data0);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data1);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data2);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPICR2, 8'h80);
        @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_tip_r == 1'b1) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
    end
endtask

task spi_ufm_tst_4_cmd;
    input [7:0] spi_data0;
    input [7:0] spi_data1;
    input [7:0] spi_data2;
    input [7:0] spi_data3;
    
    begin
        wbt_write(P_SPICR2, 8'hC0);
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPITXDR, 8'h08);    // dummy
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        ufm_sn_r = 1'b0;
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data0);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data1);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data2);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data3);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPICR2, 8'h80);
        @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_tip_r == 1'b1) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
    end
endtask

task spi_ufm_tst_4_cmd_open_read;
    input [7:0] spi_data0;
    input [7:0] spi_data1;
    input [7:0] spi_data2;
    input [7:0] spi_data3;
    
    begin
        wbt_write(P_SPICR2, 8'hC0);
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPITXDR, 8'h08);    // dummy
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        ufm_sn_r = 1'b0;
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data0);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data1);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data2);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data3);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    end
endtask

task spi_ufm_tst_4_cmd_open_write;
    input [7:0] spi_data0;
    input [7:0] spi_data1;
    input [7:0] spi_data2;
    input [7:0] spi_data3;
    
    begin
        wbt_write(P_SPICR2, 8'hC0);
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPITXDR, 8'h08);    // dummy
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        ufm_sn_r = 1'b0;
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data0);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data1);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data2);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data3);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    end
endtask

task spi_ufm_tst_8_cmd;
    input [7:0] spi_data0;
    input [7:0] spi_data1;
    input [7:0] spi_data2;
    input [7:0] spi_data3;
    input [7:0] spi_data4;
    input [7:0] spi_data5;
    input [7:0] spi_data6;
    input [7:0] spi_data7;
    
    begin
        wbt_write(P_SPICR2, 8'hC0);
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPITXDR, 8'h08);    // dummy
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        ufm_sn_r = 1'b0;
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data0);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data1);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data2);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data3);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data4);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data5);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data6);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data7);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    end
endtask

task spi_ufm_tst_8_cmd_open_read;
    input [7:0] spi_data0;
    input [7:0] spi_data1;
    input [7:0] spi_data2;
    input [7:0] spi_data3;
    input [7:0] spi_data4;
    input [7:0] spi_data5;
    input [7:0] spi_data6;
    input [7:0] spi_data7;
    
    begin
        wbt_write(P_SPICR2, 8'hC0);
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPITXDR, 8'h08);    // dummy
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        ufm_sn_r = 1'b0;
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data0);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data1);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data2);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data3);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data4);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data5);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data6);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, spi_data7);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPICR2, 8'h80);
        @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_tip_r == 1'b1) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
    end
endtask
