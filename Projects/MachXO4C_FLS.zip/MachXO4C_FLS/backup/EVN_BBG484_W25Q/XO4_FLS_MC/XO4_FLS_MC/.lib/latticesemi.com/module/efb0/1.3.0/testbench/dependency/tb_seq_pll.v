$display("[%012t] ===== PLL Dynamic Reconfig Tests =====", $time);

pll_0_op_checker.set_expected_period(8333,100);
pll_0_os_checker.set_expected_period(10000,100);
#10_000;
pll_chk_en_r[0] = 1;
pll_chk_en_r[1] = 1;
#20_000;
pll_0_op_checker.pll_check();
$display("[%012t] --- PLL0 (Primary Clock) Initial Configuration Check Done ---", $time);
#1000;
pll_0_os_checker.pll_check();
$display("[%012t] --- PLL0 (Secondary Clock) Initial Configuration Check Done ---", $time);
pll_chk_en_r[0] = 0;
pll_chk_en_r[1] = 0;

wb_write(P_MC1_ENABLE_CLK,  8'h00);
#1_000;

wb_write(P_MC1_DIVREF,  {1'b0, PLL0_TEST_CLKI_DIV-1});
wb_write(P_MC1_DIVFBK,  {1'b0, PLL0_TEST_CLKFB_DIV-1});
wb_write(P_MC1_DELA,    {1'b0, PLL0_TEST_CLKA_CPHA});
wb_write(P_MC1_DIVA,    {1'b0, PLL0_TEST_CLKA_DIV-1});
wb_write(P_MC1_DELB,    {1'b0, PLL0_TEST_CLKB_CPHA});
wb_write(P_MC1_DIVB,    {1'b0, PLL0_TEST_CLKB_DIV-1});
#1_000;

wb_write(P_MC1_ENABLE_CLK,  8'h03);
pll_0_op_checker.set_expected_period(20000,100);
pll_0_os_checker.set_expected_period(13333,100);
#10_000;
pll_chk_en_r[0] = 1;
pll_chk_en_r[1] = 1;
#20_000;
pll_0_op_checker.pll_check();
$display("[%012t] --- PLL0 (Primary Clock) Dynamic Reconfiguration Check Done ---", $time);
#1000;
pll_0_os_checker.pll_check();
$display("[%012t] --- PLL0 (Secondary Clock) Dynamic Reconfiguration Check Done ---", $time);
pll_chk_en_r[0] = 0;
pll_chk_en_r[1] = 0;

if (EFB_PLL_NUM_IN > 1) begin: _pll_1_seq
pll_1_op_checker.set_expected_period(12500,100);
pll_1_os_checker.set_expected_period(20000,100);
#10_000;
pll_chk_en_r[2] = 1;
pll_chk_en_r[3] = 1;
#20_000;
pll_1_op_checker.pll_check();
$display("[%012t] --- PLL1 (Primary Clock) Initial Configuration Check Done ---", $time);
#1000;
pll_1_os_checker.pll_check();
$display("[%012t] --- PLL1 (Secondary Clock) Initial Configuration Check Done ---", $time);
#10_000;
pll_chk_en_r[2] = 0;
pll_chk_en_r[3] = 0;

wb_write(P_MC2_ENABLE_CLK,  8'h00);
#1_000;

wb_write(P_MC2_DIVREF,  {1'b0, PLL1_TEST_CLKI_DIV-1});
wb_write(P_MC2_DIVFBK,  {1'b0, PLL1_TEST_CLKFB_DIV-1});
wb_write(P_MC2_DELA,    {1'b0, PLL1_TEST_CLKA_CPHA});
wb_write(P_MC2_DIVA,    {1'b0, PLL1_TEST_CLKA_DIV-1});
wb_write(P_MC2_DELB,    {1'b0, PLL1_TEST_CLKB_CPHA});
wb_write(P_MC2_DIVB,    {1'b0, PLL1_TEST_CLKB_DIV-1});
#1_000;

wb_write(P_MC2_ENABLE_CLK,  8'h03);
pll_1_op_checker.set_expected_period(8333,100);
pll_1_os_checker.set_expected_period(16666,100);
pll_chk_en_r[2] = 1;
pll_chk_en_r[3] = 1;
#20_000;
pll_1_op_checker.pll_check();
$display("[%012t] --- PLL1 (Primary Clock) Dynamic Reconfiguration Check Done ---", $time);
#1000;
pll_1_os_checker.pll_check();
$display("[%012t] --- PLL1 (Secondary Clock) Dynamic Reconfiguration Check Done ---", $time);
pll_chk_en_r[2] = 0;
pll_chk_en_r[3] = 0;
end
