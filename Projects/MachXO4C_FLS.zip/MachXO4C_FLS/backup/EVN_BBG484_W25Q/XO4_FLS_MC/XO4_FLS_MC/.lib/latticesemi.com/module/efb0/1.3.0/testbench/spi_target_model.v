`ifndef I2C_TARGET_MODEL
`define I2C_TARGET_MODEL

`timescale 1ns / 1ps

module spi_target_model (
    input  wire spi_clk,
    input  wire spi_scsn,   // Active low chip select (unique per target)
    input  wire spi_mosi,
    output wire spi_miso,   // Tri-state output for shared SPI bus
    output reg  spi_err_chk
);
    parameter DEBUG     = 0;
    parameter MDL_NAME  = "SPI_TARGET";
    parameter CPOL      = 0;  // Clock polarity: 0=idle low, 1=idle high
    parameter CPHA      = 0;  // Clock phase: 0=sample on leading edge, 1=sample on trailing edge
    parameter LSB_FIRST = 0;  // Bit ordering: 0=MSB first, 1=LSB first
    
    // FSM states
    reg [1:0] state;
    localparam ST_SPI_CMD = 2'd0;
    localparam ST_SPI_WR  = 2'd1;
    localparam ST_SPI_RD  = 2'd2;

    // SPI mode control signals
    wire sample_edge;  // Edge to sample data
    wire shift_edge;   // Edge to shift data
    
    // Determine sampling and shifting edges based on CPOL and CPHA
    // CPOL=0, CPHA=0: Sample on rising edge (leading), shift on falling edge (trailing)
    // CPOL=0, CPHA=1: Sample on falling edge (trailing), shift on rising edge (leading)
    // CPOL=1, CPHA=0: Sample on falling edge (leading), shift on rising edge (trailing)
    // CPOL=1, CPHA=1: Sample on rising edge (trailing), shift on falling edge (leading)
    assign sample_edge = (CPOL == CPHA) ? spi_clk : ~spi_clk;
    assign shift_edge  = (CPOL == CPHA) ? ~spi_clk : spi_clk;

    reg [7:0] shift_reg;
    reg [2:0] bit_cnt;
    reg [7:0] received_data;
    reg       data_valid;
    reg [7:0] expected_data;
    reg [7:0] stored_data;

    // Task to set expected data (no address)
    task set_expected_data;
        input [7:0] data;
        begin
            expected_data = data;
        end
    endtask

    // Task to check received data (no address)
    task check_received_data;
        input [7:0] data;
        begin
            if (data == expected_data) begin
                if (DEBUG)
                    $display("[%012t]   ### %s: Data Received - Expected: %02h, Actual: %02h", $time, MDL_NAME, expected_data, data);
            end
            else begin
                $display("[%012t]   !!! %s: Error on Received Data - Expected: %02h, Actual: %02h", $time, MDL_NAME, expected_data, data);
                spi_err_chk <= 1'b1;
            end
        end
    endtask
    
    initial begin
        spi_err_chk = 1'b0;
    end

    // Helper function to reverse bit order
    function [7:0] reverse_bits;
        input [7:0] data;
        integer i;
        begin
            for (i = 0; i < 8; i = i + 1)
                reverse_bits[i] = data[7-i];
        end
    endfunction

    // SPI shift-in and byte receive logic (sample edge)
    always @(posedge sample_edge or posedge spi_scsn) begin
        if (spi_scsn) begin
            bit_cnt        <= 3'd0;
            data_valid     <= 1'b0;
            received_data  <= 8'h00;
        end else begin
            if (bit_cnt == 3'd7) begin
                if (LSB_FIRST)
                    received_data <= {spi_mosi, shift_reg[7:1]};
                else
                    received_data <= {shift_reg[6:0], spi_mosi};
                data_valid    <= 1'b1;
                bit_cnt       <= 3'd0;
                if (state == ST_SPI_WR) begin
                    if (LSB_FIRST)
                        stored_data <= {spi_mosi, shift_reg[7:1]};
                    else
                        stored_data <= {shift_reg[6:0], spi_mosi};
                end
            end else begin
                bit_cnt    <= bit_cnt + 1;
                data_valid <= 1'b0;
            end
        end
    end

    // shift_reg logic (shift edge)
    always @(posedge shift_edge or posedge spi_scsn) begin
        if (spi_scsn) begin
            shift_reg <= 8'h00;
        end else if (data_valid && state == ST_SPI_CMD && received_data == 8'hF7) begin
            shift_reg <= stored_data;
        end else begin
            case (state)
                ST_SPI_CMD, ST_SPI_WR: begin
                    if (LSB_FIRST)
                        shift_reg <= {spi_mosi, shift_reg[7:1]};
                    else
                        shift_reg <= {shift_reg[6:0], spi_mosi};
                end
                ST_SPI_RD: begin
                    if (LSB_FIRST)
                        shift_reg <= {1'b0, shift_reg[7:1]};
                    else
                        shift_reg <= {shift_reg[6:0], 1'b0};
                end
            endcase
        end
    end

    // FSM: state transitions and control signals
    always @(posedge sample_edge or posedge spi_scsn) begin
        if (spi_scsn) begin
            state           <= ST_SPI_CMD;
        end else if (data_valid) begin
            case (state)
                ST_SPI_CMD: begin
                    if (received_data == 8'hA5)
                        state <= ST_SPI_WR;
                    else if (received_data == 8'hF7)
                        state <= ST_SPI_RD;
                end
                ST_SPI_WR: begin
                    check_received_data(received_data);
                    state <= ST_SPI_CMD;
                end
                ST_SPI_RD: begin
                    state <= ST_SPI_CMD;
                end
            endcase
        end
    end

    // Tri-state MISO output: drive only when selected (spi_scsn == 0)
    // Output MSB or LSB depending on configuration
    assign spi_miso = (spi_scsn === 1'b0) ? (LSB_FIRST ? shift_reg[0] : shift_reg[7]) : 1'bz;

endmodule

`endif
