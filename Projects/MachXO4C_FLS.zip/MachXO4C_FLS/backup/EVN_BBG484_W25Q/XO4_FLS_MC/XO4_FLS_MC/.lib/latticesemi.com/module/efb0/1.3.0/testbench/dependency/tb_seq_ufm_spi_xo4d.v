    $display("[%012t] ===== UFM Tests via SPI =====", $time);
    
    fork
    spi_ufm_tst_4_cmd_open_read(8'hE0, 8'h00, 8'h00, 8'h00);
    begin
        repeat (48) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    // Read
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, DEVICE_ID_TB[31:24]);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, DEVICE_ID_TB[23:16]);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, DEVICE_ID_TB[15:8]);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, DEVICE_ID_TB[7:0]);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        
        wbt_write(P_SPICR2, 8'h80);
        @(posedge clk_gen_r);
        
        get_spi_t_status();
        while (spi_t_tip_r == 1'b1) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
    end
    join
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    $display("[%012t] --- Read Device ID Code Test Done (functional check only) ---", $time);
    repeat(50) @ (posedge clk_gen_r);
    
    // Write Test only if enough UFM pages
    // Write 2 Pages test
    if (P_UFM_SEL_INIT_PAGES > 5) begin
    
    // Enable Configuration Interface
    spi_ufm_tst_4_cmd(8'h74, 8'h08, 8'h00, 8'h00);
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Set UFM Address (SPI is +4)
    spi_ufm_tst_8_cmd(8'hB4, 8'h00, 8'h00, 8'h00, 8'h40, {6'd0, P_UFM_SEL_ADDR_BIT[3:2]}, {P_UFM_SEL_ADDR_BIT[1:0], P_UFM_SEL_WRITE_SPI[21:16]}, P_UFM_SEL_WRITE_SPI[15:8]);
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    //Start - Write Command - 1st Page
    spi_ufm_tst_4_cmd_open_write(8'hC9, 8'h00, 8'h00, 8'h01);
    
    // Data0
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h40);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data1
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h41);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data2
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h42);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data3
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h43);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data4
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h44);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data5
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h45);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data6
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h46);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data7
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h47);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data8
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h48);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data9
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h49);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data10
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h4A);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data11
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h4B);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data12
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h4C);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data13
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h4D);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data14
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h4E);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data15
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h4F);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    
    wbt_write(P_SPICR2, 8'h80);
    @(posedge clk_gen_r);
    
    get_spi_t_status();
    while (spi_t_tip_r == 1'b1) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    // Write Finish
    
    // Wait Busy Flag
    while (spi_ufm_busy_r) begin
        fork
        spi_ufm_tst_4_cmd_open_read(8'hF0, 8'h00, 8'h00, 8'h00);
        begin
            repeat (48) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
            get_spi_t_status();
            while (spi_t_rrdy_r == 1'b0) begin
                get_spi_t_status();
                @(posedge clk_gen_r);
            end
            fork
                wbt_read(P_SPIRXDR);
                begin
                    while (~wbt_ack_o) @ (posedge clk_gen_r);
                    spi_ufm_busy_r <= wbt_dat_o[7];
                end
            join
            
            get_spi_t_status();
            while (spi_t_rrdy_r == 1'b0) begin
                get_spi_t_status();
                @(posedge clk_gen_r);
            end
            
            get_spi_t_status();
            while (spi_t_trdy_r == 1'b0) begin
                get_spi_t_status();
                @(posedge clk_gen_r);
            end
            
            wbt_write(P_SPICR2, 8'h80);
            @(posedge clk_gen_r);
            
            get_spi_t_status();
            while (spi_t_tip_r == 1'b1) begin
                get_spi_t_status();
                @(posedge clk_gen_r);
            end
            
            ufm_sn_r = 1'b1;
        end
        join
        #10_000;
    end
    
    //Start - Write Command - 2nd Page
    spi_ufm_tst_4_cmd_open_write(8'hC9, 8'h00, 8'h00, 8'h00);
    
    // Data0
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h50);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data1
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h51);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data2
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h52);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data3
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h53);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data4
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h54);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data5
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h55);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data6
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h56);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data7
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h57);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data8
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h58);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data9
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h59);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data10
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h5A);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data11
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h5B);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data12
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h5C);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data13
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h5D);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data14
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h5E);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Data15
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_read(P_SPIRXDR);
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    wbt_write(P_SPITXDR, 8'h5F);
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    get_spi_t_status();
    while (spi_t_rrdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    
    get_spi_t_status();
    while (spi_t_trdy_r == 1'b0) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    
    wbt_write(P_SPICR2, 8'h80);
    @(posedge clk_gen_r);
    
    get_spi_t_status();
    while (spi_t_tip_r == 1'b1) begin
        get_spi_t_status();
        @(posedge clk_gen_r);
    end
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    // Write Finish
    
    // Wait Busy Flag
    while (spi_ufm_busy_r) begin
        fork
        spi_ufm_tst_4_cmd_open_read(8'hF0, 8'h00, 8'h00, 8'h00);
        begin
            repeat (48) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
            get_spi_t_status();
            while (spi_t_rrdy_r == 1'b0) begin
                get_spi_t_status();
                @(posedge clk_gen_r);
            end
            fork
                wbt_read(P_SPIRXDR);
                begin
                    while (~wbt_ack_o) @ (posedge clk_gen_r);
                    spi_ufm_busy_r <= wbt_dat_o[7];
                end
            join
            
            get_spi_t_status();
            while (spi_t_rrdy_r == 1'b0) begin
                get_spi_t_status();
                @(posedge clk_gen_r);
            end
            
            get_spi_t_status();
            while (spi_t_trdy_r == 1'b0) begin
                get_spi_t_status();
                @(posedge clk_gen_r);
            end
            
            wbt_write(P_SPICR2, 8'h80);
            @(posedge clk_gen_r);
            
            get_spi_t_status();
            while (spi_t_tip_r == 1'b1) begin
                get_spi_t_status();
                @(posedge clk_gen_r);
            end
            
            ufm_sn_r = 1'b1;
        end
        join
        #10_000;
    end
    
    // Disable Configuration Interface
    spi_ufm_tst_3_cmd(8'h26, 8'h00, 8'h00);
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    spi_ufm_tst_4_cmd(8'hFF, 8'hFF, 8'hFF, 8'hFF);
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    $display("[%012t] --- UFM Write 2 Pages Done ---", $time);
    
    // Enable Configuration Interface
    spi_ufm_tst_4_cmd(8'h74, 8'h08, 8'h00, 8'h00);
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Set UFM Address (SPI is +4)
    spi_ufm_tst_8_cmd(8'hB4, 8'h00, 8'h00, 8'h00, 8'h40, {6'd0, P_UFM_SEL_ADDR_BIT[3:2]}, {P_UFM_SEL_ADDR_BIT[1:0], P_UFM_SEL_WRITE_SPI[21:16]}, P_UFM_SEL_WRITE_SPI[15:8]);
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Read Command - 1st page
    fork
    spi_ufm_tst_4_cmd_open_read(8'hCA, 8'h10, 8'h00, 8'h03);
    begin
        repeat (48) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    // Read Dummy Page
    repeat (16) begin
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read(P_SPIRXDR);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    end
        
    // Read0
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h40);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read1
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h41);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read2
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h42);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
     // Read3
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h43);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read4
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h44);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read5
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h45);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read6
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h46);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read7
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h47);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read8
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h48);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read9
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h49);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read10
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h4A);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read11
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h4B);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read12
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h4C);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read13
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h4D);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read14
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h4E);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read15
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h4F);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // 2nd Page
    // Read0
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h50);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read1
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h51);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read2
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h52);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read3
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h53);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read4
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h54);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read5
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h55);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read6
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h56);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read7
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h57);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read8
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h58);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read9
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h59);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read10
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h5A);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read11
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h5B);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read12
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h5C);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read13
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h5D);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read14
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h5E);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
        
    // Read15
        get_spi_t_status();
        while (spi_t_rrdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_read_test(P_SPIRXDR, 8'h5F);
        
        get_spi_t_status();
        while (spi_t_trdy_r == 1'b0) begin
            get_spi_t_status();
            @(posedge clk_gen_r);
        end
        wbt_write(P_SPITXDR, 8'h00);
        repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    end
    join
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    ufm_sn_r = 1'b1;
    
    // Disable Configuration Interface
    spi_ufm_tst_3_cmd(8'h26, 8'h00, 8'h00);
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    // Bypass (NOP)
    spi_ufm_tst_4_cmd(8'hFF, 8'hFF, 8'hFF, 8'hFF);
    ufm_sn_r = 1'b1;
    repeat (2) repeat (P_SPI_BR_INIT) @(posedge clk_gen_r);
    
    $display("[%012t] --- UFM Read 2 Pages Test Done ---", $time);
    repeat(50) @ (posedge clk_gen_r);
    
    end