// MachXO4 EFB SPI serial flash demo (MachXO4 Companion Board, LFMXO4-110HC-6BBG256I), RISC-V MC.
// Flash U7 = ISSI IS25LP064A-JBLE through the IS25LP064A_efb APB block and its BSP driver:
// ID, unique ID, status, block erase / write / read test.
// UART transmit as in MachXO4_TTS2: uart_init(), non-blocking driver calls and a
// transmit queue serviced by tx_service(), one character per pass. printf() writes
// into the queue through iob_init().

#include "hal.h"
#include "utils.h"
#include <stdio.h>
#include "sys_platform.h"
#include <riscv_errors.h>
#include "platform_init.h"
#include "iob.h"
#include "uart.h"
#include "gpio.h"
#include "IS25LP064A_efb.h"
#include "app/flash_demo.h"

#define UART_BASE   UART0_INST_BASE_ADDR
#define CPU_HZ      12000000u

/* Polling-loop iterations per heartbeat half period (about 0.5 s at 12 MHz) */
#define HEARTBEAT_LOOPS  63000u

static struct uart_instance uart0;
static struct gpio_instance led_gpio_inst;
static struct is25lp064a_efb_instance flash;
static uint32_t led_state;
static uint32_t heartbeat;

/* ---- transmit queue: as in MachXO4_TTS2 ---------------------------------------------------------------- */
#define TXQ_SIZE 4096u                /* power of two, larger than one hex dump of the demo */
static uint8_t  txq[TXQ_SIZE];
static uint32_t tx_wr, tx_rd;

static void tx_service(void)
{
	if (tx_rd != tx_wr) {
		if (uart_putc(&uart0, txq[tx_rd & (TXQ_SIZE - 1u)]) == 0) {
			tx_rd++;
		}
	}
}

/* gpio0 lines (all outputs, reset value 3'b110); flash CS# is the EFB spi_csn */
#define GPIO_LINE_LED        0u   /* heartbeat LED1 (D21), ball G14, active low */
#define GPIO_LINE_FLASH_WP   1u   /* flash WP#, N7 */
#define GPIO_LINE_FLASH_HOLD 2u   /* flash HOLD#, M7 */

/* gpio_output_write() masks the value with the line bit, so pass it shifted */
static void gpio_line_set(uint32_t line, uint32_t level)
{
	gpio_output_write(&led_gpio_inst, line, level ? (1u << line) : 0u);
}

static void heartbeat_toggle(void)
{
	led_state ^= 1u;
	gpio_line_set(GPIO_LINE_LED, led_state);
}

/* One pass of the main loop: send at most one character, run the heartbeat LED */
static void loop_pass(void)
{
	tx_service();
	if (++heartbeat >= HEARTBEAT_LOOPS) {
		heartbeat = 0;
		heartbeat_toggle();
	}
}

static void tx_put(uint8_t c)
{
	while ((tx_wr - tx_rd) >= TXQ_SIZE) {
		loop_pass();                  /* queue full: let the main loop send */
	}
	txq[tx_wr & (TXQ_SIZE - 1u)] = c;
	tx_wr++;
}

/* printf() output: into the transmit queue, LF sent as CR LF */
static int queue_putc(char c, FILE *file)
{
	(void) file;
	if (c == '\n')
		tx_put('\r');
	tx_put((uint8_t)c);
	return (unsigned char)c;
}

static int queue_getc(FILE *file)
{
	unsigned char c;
	(void) file;
	while (uart_getc(&uart0, &c) != 0) {
		loop_pass();
	}
	return c;
}

static int queue_flush(FILE *file)
{
	(void) file;
	while (tx_rd != tx_wr) {
		loop_pass();
	}
	return 0;
}

static void bsp_init(void)
{
	uart_init(&uart0, UART_BASE, CPU_HZ, UART0_INST_BAUD_RATE, 1u, 8u);
	uart0.blockingTx = 0;             /* never wait inside a call */
	uart0.blockingRx = 0;
	iob_init(queue_putc, queue_getc, queue_flush);

	led_gpio_inst.instance_name = LED_GPIO_INST_NAME;
	gpio_init(&led_gpio_inst, LED_GPIO_INST_BASE_ADDR, LED_GPIO_INST_LINES_NUM, LED_GPIO_INST_GPIO_DIRS);

	/* Flash WP# and HOLD# high (inactive) */
	gpio_line_set(GPIO_LINE_FLASH_WP, 1u);
	gpio_line_set(GPIO_LINE_FLASH_HOLD, 1u);
}

/* Send what is queued, then wait for any key on the UART, blinking the heartbeat LED D6 */
static void wait_key(void)
{
	unsigned char c;

	for (;;) {
		loop_pass();
		if (tx_rd == tx_wr && uart_getc(&uart0, &c) == 0)
			return;
	}
}

int main(void)
{
	uint32_t run = 0;

	bsp_init();
	heartbeat_toggle();

	printf("MachXO4 running \n");
	printf("\nMachXO4 EFB SPI serial flash demo (MachXO4 Companion Board, LFMXO4-110HC-6BBG256I)\n");
	printf("RISC-V MC + IS25LP064A_efb -> lscc_efb SPI -> IS25LP064A-JBLE, UART %u 8N1\n",
	       (unsigned)UART0_INST_BAUD_RATE);

	/* IS25LP064A_efb BSP driver: binds to the block and sets up the EFB SPI controller */
	is25lp064a_efb_init(&flash, IS25LP064A_EFB0_INST_BASE_ADDR);
	printf("IS25LP064A_efb0_inst @ 0x%04X, SCK %u Hz\n", (unsigned)IS25LP064A_EFB0_INST_BASE_ADDR,
	       (unsigned)is25lp064a_set_sck(&flash, CPU_HZ, 1500000u));

	while (true) {
		printf("\n=== Run %u : identification ===\n", (unsigned)run);
		if (flash_demo_identify(&flash) == 0)
			flash_demo_run(&flash, run);
		else
			printf("Block test skipped: identification failed.\n");
		run++;

		printf("\nPress any key to run again...\n");
		wait_key();
	}

	return 0;
}
