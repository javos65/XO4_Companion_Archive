/* IS25LP064A demo on the IS25LP064A_efb BSP driver: every flash access goes through
   the driver API (bsp/driver/IS25LP064A_efb). */
#include <stdio.h>
#include <stdint.h>
#include "IS25LP064A_efb.h"
#include "app/flash_demo.h"

/* One 4 KB block buffer (system memory is 32 KB); the read-back compare works in pages */
static uint8_t blk_buf[IS25LP064A_BLOCK_SIZE];
static uint8_t page_buf[IS25LP064A_PAGE_SIZE];

static uint8_t pattern(uint32_t i, uint32_t run)
{
    return (uint8_t)(i + (i >> 8) + run * 0x35u);
}

static void hex_dump(const char *title, uint32_t addr, const uint8_t *buf, uint32_t len)
{
    printf("%s\n", title);
    for (uint32_t row = 0; row < len; row += 16) {
        printf("  %06X:", (unsigned)(addr + row));
        for (uint32_t i = 0; i < 16 && row + i < len; i++)
            printf(" %02X", buf[row + i]);
        printf("\n");
    }
}

static int report(const char *tag, struct is25lp064a_efb_instance *flash, int rc)
{
    if (rc == IS25LP064A_OK)
        return 0;
    printf("%s FAIL : %s", tag, is25lp064a_strerror(rc));
    if (rc == IS25LP064A_ERR_SPI)
        printf(" (SPISR %02X)", (unsigned)flash->last_spisr);
    printf("\n");
    return -1;
}

static void print_sr(uint8_t sr)
{
    printf("[SR   ] SR %02X : SRWD %u  QE %u  BP3-0 %X  WEL %u  WIP %u\n", (unsigned)sr,
           (unsigned)((sr >> 7) & 1u), (unsigned)((sr >> 6) & 1u),
           (unsigned)((sr & IS25LP064A_SR_BP_MASK) >> IS25LP064A_SR_BP_SHIFT),
           (unsigned)((sr >> 1) & 1u), (unsigned)(sr & 1u));
}

int flash_demo_identify(struct is25lp064a_efb_instance *flash)
{
    uint8_t id[3] = { 0, 0, 0 };
    uint8_t uid[IS25LP064A_UID_SIZE];
    uint32_t jedec;
    int rc;

    rc = is25lp064a_read_jedec_id(flash, id);
    if (report("[ID   ]", flash, rc)) return -1;
    jedec = ((uint32_t)id[0] << 16) | ((uint32_t)id[1] << 8) | id[2];
    printf("[ID   ] JEDEC ID (9Fh) = %02X %02X %02X  -> %s\n", (unsigned)id[0], (unsigned)id[1],
           (unsigned)id[2], (jedec == IS25LP064A_JEDEC_ID) ? "IS25LP064A" : "unexpected (expected 9D 60 17)");
    if (jedec != IS25LP064A_JEDEC_ID)
        return -1;

    rc = is25lp064a_read_unique_id(flash, uid);
    if (report("[UID  ]", flash, rc)) return -1;
    printf("[UID  ] Unique ID (4Bh) =");
    for (uint32_t i = 0; i < IS25LP064A_UID_SIZE; i++)
        printf(" %02X", (unsigned)uid[i]);
    printf("\n");
    return 0;
}

int flash_demo_run(struct is25lp064a_efb_instance *flash, uint32_t run)
{
    const uint32_t block = FLASH_DEMO_BLOCK;
    const uint32_t addr = block * IS25LP064A_BLOCK_SIZE;
    uint8_t sr = 0, fr = 0;
    uint32_t bad = 0;
    int rc;

    printf("\n=== Run %u : IS25LP064A_efb BSP test, block %u @ 0x%06X (4 KB) ===\n",
           (unsigned)run, (unsigned)block, (unsigned)addr);

    /* 1. Status and function register, protection */
    if (report("[SR   ]", flash, is25lp064a_read_status(flash, &sr))) return -1;
    print_sr(sr);
    if (report("[FR   ]", flash, is25lp064a_read_function(flash, &fr))) return -1;
    printf("[FR   ] FR %02X : TBS %u (%s)\n", (unsigned)fr, (unsigned)((fr >> 1) & 1u),
           (fr & IS25LP064A_FR_TBS) ? "BP area at the bottom" : "BP area at the top");
    rc = is25lp064a_is_protected(flash, addr);
    if (rc < 0) return report("[PROT ]", flash, rc);
    printf("[PROT ] block %u is %s\n", (unsigned)block, rc ? "PROTECTED" : "not protected");

    /* 2. Write enable latch */
    rc = is25lp064a_write_enable(flash);
    {
        uint8_t on = flash->last_sr, off = 0;
        (void)is25lp064a_write_disable(flash);
        (void)is25lp064a_read_status(flash, &off);
        printf("[WEL  ] 06h -> SR %02X (WEL %s), 04h -> SR %02X (WEL %s)\n",
               (unsigned)on, (on & IS25LP064A_SR_WEL) ? "set" : "NOT set",
               (unsigned)off, (off & IS25LP064A_SR_WEL) ? "still set" : "cleared");
    }
    if (report("[WEL  ]", flash, rc)) return -1;

    /* 3. Read the block as it is */
    if (report("[READ ]", flash, is25lp064a_read_block(flash, block, blk_buf))) return -1;
    hex_dump("[READ ] read_block, before:", addr, blk_buf, FLASH_DEMO_SHOW_SIZE);

    /* 4. Erase the block and blank check it */
    printf("[ERASE] erase_block %u ... ", (unsigned)block);
    rc = is25lp064a_erase_block(flash, block);
    if (rc != IS25LP064A_OK) { printf("\n"); return report("[ERASE]", flash, rc); }
    printf("done, WIP cleared after %u status reads\n", (unsigned)flash->last_polls);
    rc = is25lp064a_blank_check(flash, addr, IS25LP064A_BLOCK_SIZE, &bad);
    if (rc == IS25LP064A_ERR_VERIFY) {
        printf("[BLANK] FAIL : first byte not FF at 0x%06X\n", (unsigned)bad);
        return -1;
    }
    if (report("[BLANK]", flash, rc)) return -1;
    printf("[BLANK] PASS : 4096 bytes FF\n");

    /* 5. Write the block (erase, program 16 pages, verify) with a run-dependent pattern */
    for (uint32_t i = 0; i < IS25LP064A_BLOCK_SIZE; i++)
        blk_buf[i] = pattern(i, run);
    printf("[WRITE] write_block %u (erase + program + verify) ... ", (unsigned)block);
    rc = is25lp064a_write_block(flash, block, blk_buf);
    if (rc != IS25LP064A_OK) { printf("\n"); return report("[WRITE]", flash, rc); }
    printf("PASS\n");

    /* 6. Read it back page by page with the fast read and compare with the pattern */
    for (uint32_t off = 0; off < IS25LP064A_BLOCK_SIZE; off += IS25LP064A_PAGE_SIZE) {
        if (report("[FREAD]", flash, is25lp064a_fast_read(flash, addr + off, page_buf,
                                                          IS25LP064A_PAGE_SIZE)))
            return -1;
        if (off == 0)
            hex_dump("[FREAD] fast_read, after write:", addr, page_buf, FLASH_DEMO_SHOW_SIZE);
        for (uint32_t i = 0; i < IS25LP064A_PAGE_SIZE; i++) {
            if (page_buf[i] != pattern(off + i, run)) {
                printf("[CHECK] FAIL : offset 0x%03X wrote %02X read %02X\n", (unsigned)(off + i),
                       (unsigned)pattern(off + i, run), (unsigned)page_buf[i]);
                return -1;
            }
        }
    }
    printf("[CHECK] PASS : 4096 bytes identical\n");

    /* 7. Leave the block erased */
    if (report("[ERASE]", flash, is25lp064a_erase_block(flash, block))) return -1;
    printf("[ERASE] block %u erased again\n", (unsigned)block);
    printf("[DONE ] all BSP steps PASS\n");
    return 0;
}
