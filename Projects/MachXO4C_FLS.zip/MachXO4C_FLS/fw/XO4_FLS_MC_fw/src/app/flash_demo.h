#ifndef FLASH_DEMO_H_
#define FLASH_DEMO_H_

#include <stdint.h>
#include "IS25LP064A_efb.h"

/* Test block agreed for the demo: the last 4 KB block (sector 2047, 7FF000h - 7FFFFFh) */
#define FLASH_DEMO_BLOCK        (IS25LP064A_BLOCK_COUNT - 1u)
/* Bytes shown in the hex dumps */
#define FLASH_DEMO_SHOW_SIZE    32u

/* Identification: JEDEC ID (raw bytes) and unique ID; returns 0 when the part is an IS25LP064A */
int flash_demo_identify(struct is25lp064a_efb_instance *flash);
/* Status/function register, WEL check, block erase, block write + verify, block read, final erase;
   every step printed on the UART. Returns 0 on PASS. */
int flash_demo_run(struct is25lp064a_efb_instance *flash, uint32_t run);

#endif /* FLASH_DEMO_H_ */
