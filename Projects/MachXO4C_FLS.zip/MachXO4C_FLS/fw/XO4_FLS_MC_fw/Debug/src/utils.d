src/utils.o: ../src/utils.c ../src/utils.h ../src/bsp/sys_platform.h \
 ../src/bsp/riscv_errors.h ../src/platform_init.h
../src/utils.h:
../src/bsp/sys_platform.h:
../src/bsp/riscv_errors.h:
../src/platform_init.h:
