src/terminal.o: ../src/terminal.c ../src/terminal.h \
 ../src/bsp/driver/riscv_mc/hal.h ../src/bsp/driver/riscv_mc/pic.h \
 ../src/bsp/driver/riscv_mc/util.h ../src/bsp/driver/riscv_mc/stack.h \
 ../src/bsp/driver/riscv_mc/reg_access.h ../src/bsp/driver/riscv_mc/iob.h \
 ../src/bsp/driver/riscv_mc/cache.h ../src/platform_init.h \
 ../src/bsp/sys_platform.h ../src/bsp/riscv_errors.h \
 ../src/bsp/driver/uart/uart.h
../src/terminal.h:
../src/bsp/driver/riscv_mc/hal.h:
../src/bsp/driver/riscv_mc/pic.h:
../src/bsp/driver/riscv_mc/util.h:
../src/bsp/driver/riscv_mc/stack.h:
../src/bsp/driver/riscv_mc/reg_access.h:
../src/bsp/driver/riscv_mc/iob.h:
../src/bsp/driver/riscv_mc/cache.h:
../src/platform_init.h:
../src/bsp/sys_platform.h:
../src/bsp/riscv_errors.h:
../src/bsp/driver/uart/uart.h:
