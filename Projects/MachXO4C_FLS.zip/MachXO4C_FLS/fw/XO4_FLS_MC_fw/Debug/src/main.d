src/main.o: ../src/main.c ../src/bsp/driver/riscv_mc/hal.h \
 ../src/bsp/driver/riscv_mc/pic.h ../src/bsp/driver/riscv_mc/util.h \
 ../src/bsp/driver/riscv_mc/stack.h \
 ../src/bsp/driver/riscv_mc/reg_access.h ../src/bsp/driver/riscv_mc/iob.h \
 ../src/bsp/driver/riscv_mc/cache.h ../src/utils.h \
 ../src/bsp/sys_platform.h ../src/bsp/riscv_errors.h \
 ../src/platform_init.h ../src/bsp/driver/riscv_mc/iob.h \
 ../src/bsp/driver/uart/uart.h ../src/bsp/driver/gpio/gpio.h \
 ../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.h \
 ../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb_regs.h \
 ../src/app/flash_demo.h
../src/bsp/driver/riscv_mc/hal.h:
../src/bsp/driver/riscv_mc/pic.h:
../src/bsp/driver/riscv_mc/util.h:
../src/bsp/driver/riscv_mc/stack.h:
../src/bsp/driver/riscv_mc/reg_access.h:
../src/bsp/driver/riscv_mc/iob.h:
../src/bsp/driver/riscv_mc/cache.h:
../src/utils.h:
../src/bsp/sys_platform.h:
../src/bsp/riscv_errors.h:
../src/platform_init.h:
../src/bsp/driver/riscv_mc/iob.h:
../src/bsp/driver/uart/uart.h:
../src/bsp/driver/gpio/gpio.h:
../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.h:
../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb_regs.h:
../src/app/flash_demo.h:
