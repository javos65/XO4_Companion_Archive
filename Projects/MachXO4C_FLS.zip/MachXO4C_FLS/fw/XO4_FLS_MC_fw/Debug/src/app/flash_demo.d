src/app/flash_demo.o: ../src/app/flash_demo.c \
 ../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.h \
 ../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb_regs.h \
 ../src/app/flash_demo.h
../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.h:
../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb_regs.h:
../src/app/flash_demo.h:
