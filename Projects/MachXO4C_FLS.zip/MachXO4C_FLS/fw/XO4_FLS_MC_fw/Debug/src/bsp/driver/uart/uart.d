src/bsp/driver/uart/uart.o: ../src/bsp/driver/uart/uart.c \
 ../src/bsp/driver/uart/uart.h ../src/bsp/driver/riscv_mc/hal.h \
 ../src/bsp/driver/riscv_mc/pic.h ../src/bsp/driver/riscv_mc/util.h \
 ../src/bsp/driver/riscv_mc/stack.h \
 ../src/bsp/driver/riscv_mc/reg_access.h ../src/bsp/driver/riscv_mc/iob.h \
 ../src/bsp/driver/riscv_mc/cache.h
../src/bsp/driver/uart/uart.h:
../src/bsp/driver/riscv_mc/hal.h:
../src/bsp/driver/riscv_mc/pic.h:
../src/bsp/driver/riscv_mc/util.h:
../src/bsp/driver/riscv_mc/stack.h:
../src/bsp/driver/riscv_mc/reg_access.h:
../src/bsp/driver/riscv_mc/iob.h:
../src/bsp/driver/riscv_mc/cache.h:
