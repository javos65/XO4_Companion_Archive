################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
C_SRCS += \
../src/bsp/driver/riscv_mc/cache.c \
../src/bsp/driver/riscv_mc/exit.c \
../src/bsp/driver/riscv_mc/interrupt.c \
../src/bsp/driver/riscv_mc/iob.c \
../src/bsp/driver/riscv_mc/pic.c \
../src/bsp/driver/riscv_mc/reg_access.c \
../src/bsp/driver/riscv_mc/timer.c \
../src/bsp/driver/riscv_mc/util.c 

S_UPPER_SRCS += \
../src/bsp/driver/riscv_mc/crt0.S 

OBJS += \
./src/bsp/driver/riscv_mc/cache.o \
./src/bsp/driver/riscv_mc/exit.o \
./src/bsp/driver/riscv_mc/interrupt.o \
./src/bsp/driver/riscv_mc/iob.o \
./src/bsp/driver/riscv_mc/pic.o \
./src/bsp/driver/riscv_mc/reg_access.o \
./src/bsp/driver/riscv_mc/timer.o \
./src/bsp/driver/riscv_mc/util.o \
./src/bsp/driver/riscv_mc/crt0.o 

C_DEPS += \
./src/bsp/driver/riscv_mc/cache.d \
./src/bsp/driver/riscv_mc/exit.d \
./src/bsp/driver/riscv_mc/interrupt.d \
./src/bsp/driver/riscv_mc/iob.d \
./src/bsp/driver/riscv_mc/pic.d \
./src/bsp/driver/riscv_mc/reg_access.d \
./src/bsp/driver/riscv_mc/timer.d \
./src/bsp/driver/riscv_mc/util.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/riscv_mc/%.o: ../src/bsp/driver/riscv_mc/%.c src/bsp/driver/riscv_mc/subdir.mk
	@echo 'Building file: $<'
	riscv-none-embed-gcc -march=rv32ic -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -DLSCC_STDIO_UART_APB -I"../src" -I"../src/app" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/IS25LP064A_efb" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/riscv_mc" -I"../src/bsp/driver/uart" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_DOUBLE_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo ' '

src/bsp/driver/riscv_mc/%.o: ../src/bsp/driver/riscv_mc/%.S src/bsp/driver/riscv_mc/subdir.mk
	@echo 'Assembling file: $<'
	riscv-none-embed-gcc -march=rv32ic -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -DLSCC_STDIO_UART_APB -I"../src" -I"../src/app" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/IS25LP064A_efb" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/riscv_mc" -I"../src/bsp/driver/uart" -c -o "$@" "$<"
	@echo ' '

