################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
C_SRCS += \
../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.c 

OBJS += \
./src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.o 

C_DEPS += \
./src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/IS25LP064A_efb/%.o: ../src/bsp/driver/IS25LP064A_efb/%.c src/bsp/driver/IS25LP064A_efb/subdir.mk
	@echo 'Building file: $<'
	riscv-none-embed-gcc -march=rv32ic -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -DLSCC_STDIO_UART_APB -I"../src" -I"../src/app" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/IS25LP064A_efb" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/riscv_mc" -I"../src/bsp/driver/uart" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_DOUBLE_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo ' '

