src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.o: \
 ../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.c \
 ../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.h \
 ../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb_regs.h
../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb.h:
../src/bsp/driver/IS25LP064A_efb/IS25LP064A_efb_regs.h:
