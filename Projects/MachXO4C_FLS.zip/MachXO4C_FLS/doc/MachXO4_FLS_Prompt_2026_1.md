# MachXO4 Serial Flash (FLS): Project Prompt (Propel and Radiant 2026.1)

This prompt builds a Propel RISC-V SoC on the MachXO4 COMPANION Board that reads, writes and erases the on-board serial flash through the hard EFB SPI controller, using the custom library block IS25LP064A_efb and its BSP driver. Every flash transaction is reported on the UART.
The board is new and there is no online data: use the schematics, the outline and the pin-out spreadsheet in the doc/ directory.
Device: LFMXO4-110HC-6BBG256I. Flash: ISSI IS25LP064A-JBLE (U7), data sheet doc/25LP064A.pdf.

## General rules

- Tools: Lattice Propel 2026.1.1 (SoC, IP catalog, IP Packager, RISC-V GCC toolchain) and Lattice Radiant 2026.1.1 (Synplify Pro synthesis). Use the Lattice Prompt MCP tools for IP installation, Propel sessions, firmware builds, Radiant builds, timing checks and programming.
- Device: LFMXO4-110HC-6BBG256I, speed grade 6, Industrial, on the MachXO4 Companion Board Rev A. Working directory: C:\lscc\workspace\MachXO4C_FLS.
- HDL: Verilog-2001. All I/O LVCMOS33 (banks 0 and 1 are 3.3 V on this board). The pins given in this prompt must not be changed.
- Record every decision, deviation, waiver and open item in design_plan.html. Deliver a project report and keep it current.
- Always ask for approval before programming the board.
- Use known tool paths and commands; do not search whole install trees. Never start the GUI programs ippack.exe or ippackc.exe from a shell.
- Ground every flash and EFB detail in the vendor documents in doc/ (IS25LP064A data sheet, FPGA-IPUG-02287 MachXO4 EFB Module IP User Guide, FPGA-TN-02403 MachXO4 Hardened Control Functions) before changing the design.
- Formal wording, no emojis, no personal data. Use C:\Users\<name>\ for any user folder. Cite an internal policy number only if one is supplied.

## A. Library block IS25LP064A_efb (custom IP)

### A.1 Package

- Install custom_IP\custom_IS25LP064A_efb_1.0.0.ipk into C:\Users\<name>\PropelIPLocal (ip_install_propel). VLNV: custom:module:IS25LP064A_efb:1.0.0, family LFMXO4.
- The installation is machine-wide; do not edit the installed files. Changes go into the source folder ip\custom_module_IS25LP064A_efb_1.0.0, are packaged again (ip\package_1.0.0\package.ps1, ippkg.exe) with a new version number, and are installed again.

### A.2 Function

- An APB-mapped block placed between the APB interconnect and the lscc_efb IP. Every APB signal is passed through 1:1 (no registers, no clock).
- APB_S0: APB slave to the interconnect, 10-bit address, 32-bit data, 1 KB window. The memory map lists the EFB SPI registers SPICR0 (0x150) to SPIIRQEN (0x174), offset = EFB register index x 4.
- APB_M0: APB master to the lscc_efb APB_S0, with its own address space (APB_M0_Address_Space).
- The block carries the BSP driver; Propel copies it into the firmware BSP (bsp/driver/IS25LP064A_efb).

### A.3 BSP driver (IS25LP064A_efb.c / .h / _regs.h)

- Instance struct is25lp064a_efb_instance, init function is25lp064a_efb_init(inst, base_addr), header IS25LP064A_efb.h. All functions are blocking, poll the controller, use no interrupts, and return 0 or a negative IS25LP064A_ERR_* code.
- Set-up: init, set_sck (SCK = PCLK / (divider + 1), divider at least 5), probe (JEDEC ID 9D 60 17).
- Identification and registers: read_jedec_id, read_unique_id (4Bh, 16 bytes), read_status, read_function, write_status, write_enable, write_disable, wait_ready, is_busy.
- Protection: set_protection (BP3-0), is_protected (data sheet Table 6.4, TBS from the function register).
- Read: read (03h), fast_read (0Bh, 8 dummy cycles), read_block, blank_check.
- Write: program_page (02h, one 256-byte page), program (split at page boundaries), write_block (erase, program, verify).
- Erase: erase_block / erase_sector (20h, 4 KB), erase_32k (52h), erase_64k (D8h), erase_chip (C7h, refused while BP3-0 is not 0).
- Power and reset: software_reset (66h + 99h), deep_power_down (B9h), release_power_down (ABh).
- Raw access: transfer (any command), efb_spisr, strerror.
- A "block" is one 4 KB sector: 2048 blocks of 4096 bytes, 256-byte pages.

### A.4 EFB SPI transaction (proven on the board)

- Writes to SPICR0, SPICR1, SPICR2, SPIBR and SPICSR reset the SPI core: write them once at init (SPICR2 = 80h, SPIBR, SPICSR = FEh, SPICR1 = 80h).
- One transaction: SPICR2 <= C0h (MSTR + MCSH), wait TRDY, SPICSR <= FEh; per byte: wait TRDY, SPITXDR <= byte, wait RRDY, read SPIRXDR; end: wait TRDY, SPICR2 <= 80h, wait until TIP is clear, then a short CE# high time.
- SPICR2[MCSH] needs an SPIBR divider above 4 (FPGA-IPUG-02287). Default SPIBR = 7: 12 MHz / 8 = 1.5 MHz SCK.

## B. SoC system

### B.1 Objective

Build a Propel RISC-V SoC that identifies the IS25LP064A, checks its registers and protection, and runs an erase / write / read test on one 4 KB block, reporting every step on the UART. Start from the Propel RISC-V MC template.

### B.2 SoC components (Propel 2026.1.1 catalog versions)

| Block          | IP and version                                                                     | Settings                                                                                  |
| -------------- | ---------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| Clock          | none (no PLL)                                                                      | external 12 MHz oscillator on T9 is the system clock                                      |
| CPU            | riscv_mc 2.9.0                                                                     | PIC enabled, 2 interrupts, timer enabled, debug unit on JTAG                              |
| System memory  | system_memory 2.6.0                                                                | EBR, AHB-Lite, 2 ports, ADDR_DEPTH 8192 x 32 (32 KB) at 0x0000, initialised with firmware |
| Bus            | ahb_lite_interconnect 1.6.0, ahb_lite_to_apb_bridge 1.2.0, apb_interconnect 1.5.0  | AHB-Lite for CPU and memory, APB with 3 slaves for the peripherals                        |
| UART           | uart 1.6.0 at 0xA000                                                               | 12 MHz, 19200 baud 8N1, no FIFO, interrupt to CPU IRQ0 (firmware polls)                   |
| Flash block    | custom:module:IS25LP064A_efb:1.0.0 at 0xA400                                       | APB_S0 on apb0 APB_M01 (1 KB), APB_M0 to efb0 APB_S0                                      |
| EFB            | lscc_efb 1.3.0 (behind IS25LP064A_efb)                                             | APB, 32-bit data, 10-bit address, 12 MHz, SPI only (controller), 1 chip select, spi_scsn tied to 1, interrupt to CPU IRQ1 |
| GPIO           | gpio 1.8.1 at 0xA800                                                               | 3 lines, all outputs, reset value 3'b110: LED1, flash WP#, flash HOLD#                    |

### B.3 Pins and constraints

| Signal        | Pin                       | Function                                                     |
| ------------- | ------------------------- | ------------------------------------------------------------ |
| clk_12m_i     | T9                        | 12 MHz board oscillator (F_12MHz), no pull                   |
| rstn_i        | D10                       | PB1 (SW2), active-low reset, pull-up on the board            |
| uart_rxd_i    | H15 (HAT40, JP15)         | UART RX from RASP_IO14_UART_TX, no pull                      |
| uart_txd_o    | J12 (HAT40, JP15)         | UART TX to RASP_IO15_UART_RX, no pull                        |
| led_d6_o[0]   | G14                       | LED1 (D21, green, active low): heartbeat                     |
| led_d6_o[1]   | N7                        | flash WP#, driven high                                       |
| led_d6_o[2]   | M7                        | flash HOLD#, driven high                                     |
| spi_clk_io    | P6                        | MCLK/CCLK: flash SCK                                         |
| spi_mosi_io   | P13                       | SISPI: flash SI                                              |
| spi_miso_io   | T6                        | SPISO: flash SO                                              |
| spi_csn_o[0]  | R5                        | CSSPIN: flash CE#                                            |

- The .pdc must contain ldc_set_sysconfig {MASTER_SPI_PORT=EFB_USER}. Without it the dual-purpose Master SPI pins (MCLK, SISPI, SPISO, CSSPIN) are released as GPIO after configuration and the EFB controller never receives data (SPISR stays 80h/90h, RRDY never sets). With EFB_USER, CSSPIN is reserved for the EFB chip select and cannot be used as a GPIO.
- Clocks: sys_clk 83.333 ns on clk_12m_i; spi_clk 333.333 ns on spi_clk_io (as the lscc_efb constraint file defines it); TCK 200 ns; all three asynchronous to each other. JTAG pins TCK, TMS, TDI, TDO in LVCMOS33.

### B.4 Firmware behaviour (C, rv32ic)

- main() uses only driver functions (UART, GPIO, IS25LP064A_efb); no direct register access in the application.
- UART output as in MachXO4_TTS2: uart_init(), non-blocking driver calls, a 4 KB transmit queue serviced by tx_service() one character per main-loop pass; printf() writes into the queue through iob_init(). Every line ends with CR LF.
- At start: drive WP# and HOLD# high, send "MachXO4 running \n" and a banner, call is25lp064a_efb_init(&flash, IS25LP064A_EFB0_INST_BASE_ADDR) and is25lp064a_set_sck(&flash, 12000000, 1500000).
- Each run, test block 2047 (0x7FF000, the last 4 KB):
  1. JEDEC ID (raw bytes, check 9D 60 17) and unique ID.
  2. Status register (SRWD, QE, BP3-0, WEL, WIP), function register (TBS), is_protected for the test block.
  3. Write enable latch: 06h sets WEL, 04h clears it.
  4. read_block and a hex dump of the first 32 bytes.
  5. erase_block with the number of status polls, then blank_check of all 4096 bytes.
  6. write_block with a run-dependent pattern (byte i = i + (i >> 8) + run x 35h), then fast_read page by page and compare all 4096 bytes.
  7. erase_block again, so the block is left erased; print "[DONE ] all BSP steps PASS".
- Then wait for any key on the UART and run again. The heartbeat LED blinks at about 1 Hz during all waits.
- Memory budget: one 4 KB block buffer only (system memory is 32 KB, stack 2.5 KB, heap 256 bytes).

### B.5 Build flow (two passes)

- Propel: insert IS25LP064A_efb0_inst between apb0 APB_M01 and efb0 APB_S0 (disconnect APB_M01 from efb0 first), assign 0xA400 to apb0 APB_M01 -> IS25LP064A_efb0_inst/APB_S0, then save, generate, save, DRC.
- Changing the device: sbp_design set_device does not change the design when run from a script. Set the deviceInfo fields (part LFMXO4-110HC-6BBG256I, speed 6, package BBG256, operation Industrial) and the EFB PACKAGE parameter in the .sbx, set the .rdf device attributes, then generate again.
- Firmware: compile with -march=rv32ic -mabi=ilp32, convert the binary with bin2mem (plain ASCII, no BOM), configure sysmem0 with INIT_MEM true, INIT_CHK hex, INIT_FILE_IN = the image, generate again and confirm with check_memory_init_applied. Generate the SGE again and take sys_platform.h and bsp/driver/IS25LP064A_efb from it into the firmware project.
- Radiant: the project lists the .ipx file of every generated instance, including lib/custom/module/IS25LP064A_efb0/1.0.0/IS25LP064A_efb0.ipx; update it when an instance is added or replaced. No Reveal .rvl attached.
- Gates: 0 failing endpoints in all corners at 12 MHz; resources within the device; constraint coverage reviewed (the asynchronous I/O ports are unconstrained and need a recorded waiver). validate_topology does not list custom: IPs; record a waiver for the IS25LP064A_efb node.

### B.6 Programming

- Program the JEDEC file into the internal flash (Erase, Program, Verify) over JTAG, cable USB2, port FTUSB-0 (FTDI channel A), TCK delay 3. Use a chain file in the format saved by the Radiant Programmer GUI with IOState HighZ, PreloadLength 760 and IOVectorData all ones, so that the outputs stay tri-stated during programming.
- The batch programmer reports "failed" because it misses its completion line; the line "Operation: successful" in %APPDATA%\LatticeSemi\DiamondNG\programmer.log is the result.

### B.7 Expected result

- UART: JEDEC ID 9D 60 17, a 16-byte unique ID, SR 00, FR 00, block 2047 not protected, WEL set and cleared, erase and blank check PASS, write_block PASS, fast_read compare PASS, "[DONE ] all BSP steps PASS".
