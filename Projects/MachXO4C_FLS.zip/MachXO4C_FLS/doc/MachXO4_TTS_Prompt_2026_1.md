chain# MachXO4 Text-to-Speech: Project Prompt (Propel and Radiant 2026.1)

This prompt builds a final application: a Propel RISC-V SoC that uses this block on the MachXO4 COMPANION Board.  
This bpoard is NEW and there is no online data.  
board is uing the LFMXO4-110HC-6BBG256I  
use the schematics and the pin-out xls-file in the doc/ directory

## General rules (both parts)

- Tools: Lattice Propel 2026.1.1 (SoC, IP catalog, RISC-V GCC toolchain) and Lattice Radiant 2026.1.1 with LSE synthesis; Questa 2026.1.1 for RTL simulation; Python 3 for models and test tools. Use the Lattice Prompt MCP tools for IP configuration, builds, timing checks and programming.
- Device: LFMXO4-110HC-6BBG256I, speed grade 6, on the MachXO4 Companion Board. Working directory: C:\lscc\workspace\MachXO4C_TTS.
- HDL: Verilog-2001. All I/O LVCMOS33. Pins givendirectory in this prompt must not be changed.
- Record every decision, deviation and open item in design_plan.html. Deliver a design report as HTML and as a Word document and keep it current.
- Save every step as its own release folder: bitstream, JEDEC file, programming chain file, programming script (dry run by default), README with SHA256 hashes and a sources archive.
- Always ask for approval before programming the board.
- Simulation rule: simulate when the speech engine (TTSCPU firmware, ROM tables or RTL) changes. A change that only affects the RISC-V firmware needs no simulation: compile, load the memory image, build, check timing, release.
- Use known tool paths and commands; do not search whole install trees. Never start the GUI programs ippack.exe or ippackc.exe from a shell.
- Formal wording, no emojis, no personal data. Cite an internal policy number only if one is supplied.

## SoC system for the final application

### B.1 Objective

Build a Propel RISC-V SoC that receives text over a UART and speaks it through the TTS_APB library block, with status messages, LEDs,  and a periodic jingle.. Use the standard 'hello world'tempalte in propel

### B.2 SoC components (Propel 2026.1.1 catalog versions)

| Block         | IP and version                                                                    | Settings                                                                                    |
| ------------- | --------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- |
| PLL           | pll 3.0.1                                                                         | 12 MHz in (pin T9), 24 MHz system clock                                                    |
| CPU           | riscv_sm 1.9.0                                                                    | RV32I, no multiplier; DEBUG_ENABLE false (its JTAG debug port blocks placement at site D10) |
| System memory | system_memory 2.6.0                                                               | ADDR_DEPTH 4096 (16 KB) at 0x0000, initialised with the firmware image                      |
| Bus           | ahb_lite_interconnect 1.5.0, ahb_lite_to_apb_bridge 1.2.0, apb_interconnect 1.4.0 | AHB-Lite for CPU and memory, APB for the peripherals                                        |
| UART          | uart 1.6.0 at 0x8000                                                              | RXRDY_ENA false (no RX ready pin), interrupt to the CPU                                     |
| LED GPIO      | gpio 1.8.1 at 0x8400                                                              | 5 lines: 3..0 LED outputs, 1 input: SW2, Reset                                  |
|               |                                                                                   |                                                                                             |
| TTS           | custom:module:tts_apb:1.5.0 at 0x8C00                                             | Library module : TTS_APB version 1.5, this includes BSP drivers                             |

### B.3 Top level and pins

- tts_top.v wraps the SoC: SW2 debounce (about 22 ms at 12 MHz) and reset, the "SW2 pressed" LED driven in hardware

| Signal         | Pin                       | Function                                                             |
| -------------- | ------------------------- | -------------------------------------------------------------------- |
| clk12_i        | T9                        | 12 MHz board clock                                                   |
| sw2_n_i        | D10                       | SW2, active low, restarts the design                                 |
|                |                           |                                                                      |
| rxd_i / txd_o  | H15/J12 (HAT40 Connector) | UART 19200 baud 8N1, no pull-ups.                                    |
| pwm_o          | H12 (Pmod_1 signal)       | Audio PWM to a BC547 amplifier and speaker                           |
| dled_n_o[0..3] | G14,E14,G15.G13           | Low = lit: heartbeat, SW2 pressed, speech active, character received |
|                |                           |                                                                      |

### B.4 Firmware behaviour (C, rv32i)

- main() uses only driver functions (UART, GPIO, TTS, timer); no direct register access. The TTS driver comes from the library block (BSP driver tts_apb).
- After reset: send "TTS OK." and speak the boot phrase "Lattice? Mag X-O for is running!"; characters received during the phrase are discarded and the queue is cleared afterwards.
- Each received character goes to the TTS block (line length up to 128). When a line is complete: send "TTS EXE", write START, wait until BUSY clears, send "TTS RDY". Every message ends with CR LF.
- Jingle every 10 minutes (RISC-V timer, assumed 24 MHz tick), when the TTS block is idle and no button phrase is pending, two tone phrases one after the other: 1: #1318,125# #1174,125# #881,100#,#1046,188# #991,188# #657,188# #881,125# #1046,125# #1174,125# #989,125#  2: #1318,125#-#1174,125#-#881,100#-#1046,125# #991,125# #657,125# #881,125# #1046,125#-#1174,125# #991,313#
- LEDs: heartbeat, speech active, character received;

### B.5 Build flow (two passes)

- Pass 1: create the SoC in Propel from a script, generate it and generate the system environment (SGE).
- Firmware: compile with -march=rv32i -mabi=ilp32, convert the binary to a memory image (bin2mem, plain ASCII without BOM), configure the system memory with INIT_MEM true, INIT_CHK hex and INIT_FILE_IN set to the image, generate again and confirm with check_memory_init_applied that the firmware is in the generated memory. Then generate the SGE again.
- Radiant: LSE, loop limit 20000, LSE memory initialisation search path set to the CPU testbench folder of the generated SoC. The Radiant project lists the .ipx file of every generated instance; update it when an instance is replaced.
- Gates: 0 failing endpoints in all corners at 24 MHz; resources within the device; constraint coverage reviewed (the asynchronous ports rxd_i, sw2_n_i,  are unconstrained and need a recorded waiver).
-

### B.6 Programming

- Program the JEDEC file into the internal flash (Erase, Program, Verify) over JTAG, cable USB2, port FTUSB-0, TCK delay 3. Use a chain file in the format saved by the Radiant Programmer GUI: I/O state HighZ and IOVectorData all ones, so that the outputs stay tri-stated during programming; set the JedecChecksum and FileTime of the new JEDEC file.
- The batch programmer prints "failed" because it misses its completion line; the programmer log line "Operation: successful" is the result. Check that no other program holds the FTDI cable.

### B.7 Audio hardware

- H12 through 680 ohm to the base of a BC547, 100 kohm from base to ground; the collector drives an 8 ohm speaker in parallel with a 1N4148, then 47 ohm 0.5 W to +5 V, with 100 uF across the supply. The board I/O is 3.3 V only.
