// Verilog netlist produced by program LSE 
// Netlist written on Fri Nov 20 17:56:16 2026
// Source file index table: 
// Object locations will have the form @<file_index>(<first_ line>[<left_column>],<last_line>[<right_column>])
// file 0 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc.v"
// file 1 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_distributed_ram.v"
// file 2 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_ecc.v"
// file 3 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_flag_and_cnts_logic.v"
// file 4 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_gray_reg.v"
// file 5 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_gray_synchronizer.v"
// file 6 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_harden.v"
// file 7 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_harden_prim.v"
// file 8 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_harden_rd_ctrl_logic.v"
// file 9 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_harden_rd_output_logic.v"
// file 10 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_harden_ring_counter.v"
// file 11 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_harden_wr_ctrl_logic.v"
// file 12 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_prim_gen.v"
// file 13 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_rd_ctrl_logic.v"
// file 14 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/fifo_dc/rtl/lscc_lfmxo4_fifo_dc_wr_ctrl_logic.v"
// file 15 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp/rtl/lscc_lfmxo4_ram_dp.v"
// file 16 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp/rtl/lscc_lfmxo4_ram_dp_behavioral.v"
// file 17 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp/rtl/lscc_lfmxo4_ram_dp_functions.vh"
// file 18 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp/rtl/lscc_lfmxo4_ram_dp_impl.v"
// file 19 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp/rtl/lscc_lfmxo4_ram_dp_lut_decode.v"
// file 20 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp_true/rtl/lscc_lfmxo4_ram_dp_true.v"
// file 21 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp_true/rtl/lscc_lfmxo4_ram_dp_true_behavioral.v"
// file 22 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp_true/rtl/lscc_lfmxo4_ram_dp_true_ecc_decoder.v"
// file 23 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp_true/rtl/lscc_lfmxo4_ram_dp_true_functions.vh"
// file 24 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp_true/rtl/lscc_lfmxo4_ram_dp_true_impl.v"
// file 25 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dp_true/rtl/lscc_lfmxo4_ram_dp_true_lut_decode.v"
// file 26 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dq/rtl/hsiao_ecc_decoder.v"
// file 27 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dq/rtl/hsiao_ecc_encoder.v"
// file 28 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dq/rtl/lscc_lfmxo4_ram_dq.v"
// file 29 "c:/lscc/radiant/2026.1.1/ip/lfmxo4/ram_dq/rtl/lscc_lfmxo4_ram_dq_lut_decode.v"
// file 30 "c:/lscc/radiant/2026.1.1/ip/common/adder/rtl/lscc_adder.v"
// file 31 "c:/lscc/radiant/2026.1.1/ip/common/adder_subtractor/rtl/lscc_add_sub.v"
// file 32 "c:/lscc/radiant/2026.1.1/ip/common/complex_mult/rtl/lscc_complex_mult.v"
// file 33 "c:/lscc/radiant/2026.1.1/ip/common/counter/rtl/lscc_cntr.v"
// file 34 "c:/lscc/radiant/2026.1.1/ip/common/distributed_dpram/rtl/lscc_distributed_dpram.v"
// file 35 "c:/lscc/radiant/2026.1.1/ip/common/distributed_rom/rtl/lscc_distributed_rom.v"
// file 36 "c:/lscc/radiant/2026.1.1/ip/common/distributed_spram/rtl/lscc_distributed_spram.v"
// file 37 "c:/lscc/radiant/2026.1.1/ip/common/fifo_dc/rtl/lscc_fifo_dc.v"
// file 38 "c:/lscc/radiant/2026.1.1/ip/common/mult_accumulate/rtl/lscc_mult_accumulate.v"
// file 39 "c:/lscc/radiant/2026.1.1/ip/common/mult_add_sub/rtl/lscc_mult_add_sub.v"
// file 40 "c:/lscc/radiant/2026.1.1/ip/common/mult_add_sub_sum/rtl/lscc_mult_add_sub_sum.v"
// file 41 "c:/lscc/radiant/2026.1.1/ip/common/multiplier/rtl/lscc_multiplier.v"
// file 42 "c:/lscc/radiant/2026.1.1/ip/common/ram_dp/rtl/lscc_ram_dp.v"
// file 43 "c:/lscc/radiant/2026.1.1/ip/common/ram_dp_true/rtl/lscc_ram_dp_true.v"
// file 44 "c:/lscc/radiant/2026.1.1/ip/common/ram_dq/rtl/lscc_ram_dq.v"
// file 45 "c:/lscc/radiant/2026.1.1/ip/common/ram_shift_reg/rtl/lscc_shift_register.v"
// file 46 "c:/lscc/radiant/2026.1.1/ip/common/rom/rtl/lscc_rom.v"
// file 47 "c:/lscc/radiant/2026.1.1/ip/common/subtractor/rtl/lscc_subtractor.v"
// file 48 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_add.v"
// file 49 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_addsub.v"
// file 50 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_complex_mult.v"
// file 51 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_counter.v"
// file 52 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_distributed_dpram.v"
// file 53 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_distributed_rom.v"
// file 54 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_distributed_shift_reg.v"
// file 55 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_distributed_spram.v"
// file 56 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_fifo_dc.v"
// file 57 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_mac.v"
// file 58 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_mult.v"
// file 59 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_multaddsub.v"
// file 60 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_multaddsubsum.v"
// file 61 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_ram_dp.v"
// file 62 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_ram_dp_be.v"
// file 63 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_ram_dp_true.v"
// file 64 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_ram_dq.v"
// file 65 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_ram_dq_be.v"
// file 66 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_rom.v"
// file 67 "c:/lscc/radiant/2026.1.1/ip/pmi/pmi_sub.v"

//
// Verilog Description of module ahbl2apb0
// module wrapper written out since it is a black-box. 
//

//

module ahbl2apb0 (clk_i, rst_n_i, ahbl_hsel_i, ahbl_hready_i, ahbl_haddr_i, 
            ahbl_hburst_i, ahbl_hsize_i, ahbl_hmastlock_i, ahbl_hprot_i, 
            ahbl_htrans_i, ahbl_hwdata_i, ahbl_hwrite_i, ahbl_hreadyout_o, 
            ahbl_hresp_o, ahbl_hrdata_o, apb_pready_i, apb_pslverr_i, 
            apb_prdata_i, apb_psel_o, apb_paddr_o, apb_pwrite_o, apb_pwdata_o, 
            apb_penable_o) /* synthesis ORIG_MODULE_NAME="ahbl2apb0", LATTICE_IP_GENERATED="1", cpe_box=1 */ ;
    input clk_i;
    input rst_n_i;
    input ahbl_hsel_i;
    input ahbl_hready_i;
    input [31:0]ahbl_haddr_i;
    input [2:0]ahbl_hburst_i;
    input [2:0]ahbl_hsize_i;
    input ahbl_hmastlock_i;
    input [3:0]ahbl_hprot_i;
    input [1:0]ahbl_htrans_i;
    input [31:0]ahbl_hwdata_i;
    input ahbl_hwrite_i;
    output ahbl_hreadyout_o;
    output ahbl_hresp_o;
    output [31:0]ahbl_hrdata_o;
    input apb_pready_i;
    input apb_pslverr_i;
    input [31:0]apb_prdata_i;
    output apb_psel_o;
    output [31:0]apb_paddr_o;
    output apb_pwrite_o;
    output [31:0]apb_pwdata_o;
    output apb_penable_o;
    
    
    
endmodule
