if {[catch {

# define run engine funtion
source [file join {C:/lscc/radiant/2026.1.1} scripts tcl flow run_engine.tcl]
# define global variables
global para
set para(gui_mode) "0"
set para(prj_dir) "C:/lscc/workspace/MachXO4C_TTS_FFT/radiant"
if {![file exists {C:/lscc/workspace/MachXO4C_TTS_FFT/radiant/impl_1}]} {
  file mkdir {C:/lscc/workspace/MachXO4C_TTS_FFT/radiant/impl_1}
}
cd {C:/lscc/workspace/MachXO4C_TTS_FFT/radiant/impl_1}
# synthesize IPs
# synthesize VMs
# propgate constraints
file delete -force -- tts_top_impl_1_cpe.ldc
::radiant::runengine::run_engine_newmsg cpe -syn lse -f "tts_top_impl_1.cprj" "tts0.cprj" "cpu0.cprj" "gpio0.cprj" "sysmem0.cprj" "uart0.cprj" "ahbl0.cprj" "ahbl2apb0.cprj" "apb0.cprj" "pll0.cprj" "mkr_rgb0.cprj" "fft0.cprj" "i2c0.cprj" -a "LFMXO4"  -o tts_top_impl_1_cpe.ldc
# synthesize top design
file delete -force -- tts_top_impl_1.vm tts_top_impl_1.ldc
::radiant::runengine::run_engine_newmsg synthesis -f "C:/lscc/workspace/MachXO4C_TTS_FFT/radiant/impl_1/tts_top_impl_1_lattice.synproj" -logfile "tts_top_impl_1_lattice.srp"
::radiant::runengine::run_postsyn [list -a LFMXO4 -p LFMXO4-110HC -t BBG256 -sp 6 -oc Industrial -top -ipsdc ipsdclist.txt -w -o tts_top_impl_1_syn.udb tts_top_impl_1.vm] [list tts_top_impl_1.ldc]

} out]} {
   ::radiant::runengine::runtime_log $out
   exit 1
}
