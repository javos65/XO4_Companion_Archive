prj_open {C:/lscc/workspace/MachXO4C_TTS_FFT/radiant/tts_top.rdf}
prj_add_source {C:/lscc/workspace/MachXO4C_TTS_FFT/soc/tts_soc/tts_soc/lib/custom/module/pwm_fft_inst0/1.0.0/pwm_fft_inst0.ipx}
puts "SOURCES_AFTER: [prj_list_source]"
prj_save
prj_close
