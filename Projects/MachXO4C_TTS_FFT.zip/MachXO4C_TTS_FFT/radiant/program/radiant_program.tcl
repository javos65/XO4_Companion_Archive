# lattice-prompt radiant_program -- generated; do not edit
puts "LCX_PGR_BEGIN"
if {[catch {pgr_project open {C:/lscc/workspace/MachXO4C_TTS_FFT/radiant/source/impl_1.xcf}} __e]} {
    puts "LCX_PGR_FAIL open: $__e"
    puts "LCX_PGR_END"
    exit 1
}
if {[catch {pgr_program set -cable USB2 -portaddress FTUSB-0} __e]} {
    puts "LCX_PGR_FAIL set: $__e"
    catch {pgr_project close}
    puts "LCX_PGR_END"
    exit 1
}
if {[catch {pgr_program run} __e]} {
    puts "LCX_PGR_FAIL run: $__e"
    catch {pgr_project close}
    puts "LCX_PGR_END"
    exit 1
}
catch {pgr_project close}
puts "LCX_PGR_END"
