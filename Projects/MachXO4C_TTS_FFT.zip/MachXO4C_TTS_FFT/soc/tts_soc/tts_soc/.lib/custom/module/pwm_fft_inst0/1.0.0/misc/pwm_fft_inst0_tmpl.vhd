component pwm_fft_inst0 is
    port(
        CORE_CLK: in std_logic;
        PCLK: in std_logic;
        PRESETN: in std_logic;
        PADDR: in std_logic_vector(9 downto 0);
        PSEL: in std_logic;
        PENABLE: in std_logic;
        PWRITE: in std_logic;
        PWDATA: in std_logic_vector(31 downto 0);
        PRDATA: out std_logic_vector(31 downto 0);
        PREADY: out std_logic;
        PSLVERR: out std_logic;
        PWM_IN: in std_logic
    );
end component;

__: pwm_fft_inst0 port map(
    CORE_CLK=>,
    PCLK=>,
    PRESETN=>,
    PADDR=>,
    PSEL=>,
    PENABLE=>,
    PWRITE=>,
    PWDATA=>,
    PRDATA=>,
    PREADY=>,
    PSLVERR=>,
    PWM_IN=>
);
