localparam PRESCALE_RESET = 29;
`define xo4f00
`define LFMXO4
`define LFMXO4_110HC
