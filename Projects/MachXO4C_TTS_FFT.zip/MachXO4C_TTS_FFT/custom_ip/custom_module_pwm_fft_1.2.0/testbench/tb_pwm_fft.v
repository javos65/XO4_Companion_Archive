// Testbench for PWM_FFT 1.0.0.
//
// A PWM source modelled on TTS_APB pwm10 (24 MHz clock, PERIOD 750 = 32 kHz carrier, 2 periods
// per 16 kHz sample, duty = sample * 750 >> 10, output gated by "play") drives PWM_IN.
// CORE_CLK = 24 MHz (the PWM clock), PCLK = 12 MHz phase aligned with it (as CLKOP / CLKOS of
// one PLL). Also reports the FFT processing time per frame.
//
// Checks (all through APB reads):
//   1. silence (PWM muted)          -> all 12 levels 0
//   2. tones on FFT bin centres     -> the expected band has the highest level (>= 6) and every
//                                      band that is not adjacent to it is at most 1
//   3. a tone 24 dB lower           -> the same band, 3 to 5 levels (about 4 x 6 dB lower)
//   4. ID register
// Prints "SCOREBOARD PASS" when every check passes, otherwise "SCOREBOARD FAIL".
`timescale 1ns/1ps
module tb_pwm_fft;
    // ------------------------------------------------------------ clocks and reset
    reg clk24 = 1'b0;
    always #20.833 clk24 = ~clk24;
    reg pclk = 1'b0;
    always @(posedge clk24) pclk <= ~pclk;
    reg presetn = 1'b0;

    // ------------------------------------------------------------ PWM source (pwm10 model)
    real    tone_hz  = 0.0;
    real    tone_amp = 0.0;
    reg     play     = 1'b0;
    integer n_smp    = 0;
    integer sample   = 512;
    integer cnt      = 0;
    integer rep      = 0;
    integer duty     = 0;
    reg     pwm_raw  = 1'b0;
    real    PI       = 3.14159265358979;

    always @(posedge clk24) begin
        if (cnt == 749) begin
            cnt  <= 0;
            duty <= (sample * 750) / 1024;
            if (rep == 1) begin
                rep    <= 0;
                n_smp  <= n_smp + 1;
                sample <= 512 + $rtoi(tone_amp * $sin(2.0 * PI * tone_hz * (n_smp + 1) / 16000.0));
            end else begin
                rep <= rep + 1;
            end
        end else begin
            cnt <= cnt + 1;
        end
        pwm_raw <= (cnt < duty);
    end
    wire pwm = pwm_raw & play;

    // ------------------------------------------------------------ DUT
    reg  [9:0]  paddr   = 10'd0;
    reg         psel    = 1'b0;
    reg         penable = 1'b0;
    reg         pwrite  = 1'b0;
    reg  [31:0] pwdata  = 32'd0;
    wire [31:0] prdata;
    wire        pready, pslverr;

    pwm_fft #(.WIN_CLKS(1500)) dut (
        .CORE_CLK(clk24), .PCLK(pclk), .PRESETN(presetn),
        .PADDR(paddr), .PSEL(psel), .PENABLE(penable), .PWRITE(pwrite), .PWDATA(pwdata),
        .PRDATA(prdata), .PREADY(pready), .PSLVERR(pslverr),
        .PWM_IN(pwm)
    );

    // ------------------------------------------------------------ APB tasks
    task apb_write(input [9:0] a, input [31:0] d);
        begin
            @(negedge pclk); paddr = a; pwdata = d; pwrite = 1'b1; psel = 1'b1; penable = 1'b0;
            @(negedge pclk); penable = 1'b1;
            @(negedge pclk); psel = 1'b0; penable = 1'b0; pwrite = 1'b0;
        end
    endtask

    task apb_read(input [9:0] a, output [31:0] d);
        begin
            @(negedge pclk); paddr = a; pwrite = 1'b0; psel = 1'b1; penable = 1'b0;
            @(negedge pclk); penable = 1'b1; #1 d = prdata;
            @(negedge pclk); psel = 1'b0; penable = 1'b0;
        end
    endtask

    // ------------------------------------------------------------ helpers
    integer errors = 0;
    integer checks = 0;
    reg [31:0] rdat;
    reg [3:0]  lv [0:11];
    reg [7:0]  raw [0:11];

    task wait_frames(input integer k);
        integer start, now;
        begin
            apb_read(10'h004, rdat);
            start = rdat[31:16];
            now   = start;
            while (now < start + k) begin
                #100000;                                  // 100 us
                apb_read(10'h004, rdat);
                now = rdat[31:16];
            end
        end
    endtask

    task read_levels;
        integer b;
        reg [31:0] lo, hi;
        begin
            apb_read(10'h00C, lo);
            apb_read(10'h010, hi);
            for (b = 0; b < 8; b = b + 1) lv[b] = lo[b*4 +: 4];
            for (b = 0; b < 4; b = b + 1) lv[8+b] = hi[b*4 +: 4];
            for (b = 0; b < 12; b = b + 1) begin
                apb_read(10'h040 + 4*b, rdat);
                raw[b] = rdat[7:0];
            end
            $display("  levels (band 1..12): %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",
                     lv[0], lv[1], lv[2], lv[3], lv[4], lv[5], lv[6], lv[7], lv[8], lv[9], lv[10], lv[11]);
            $display("  L = 4*log2(P)      : %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",
                     raw[0], raw[1], raw[2], raw[3], raw[4], raw[5], raw[6], raw[7], raw[8], raw[9], raw[10], raw[11]);
        end
    endtask

    task check(input cond, input [8*64-1:0] msg);
        begin
            checks = checks + 1;
            if (!cond) begin
                errors = errors + 1;
                $display("  CHECK FAILED: %0s", msg);
            end
        end
    endtask

    // tone on an FFT bin centre, expected band index 0..11, minimum and maximum level
    task tone_test(input integer bin, input real amp, input integer exp_band,
                   input integer lmin, input integer lmax);
        integer b, best, ok_far;
        begin
            tone_hz  = bin * 62.5;
            tone_amp = amp;
            play     = 1'b1;
            wait_frames(3);
            $display("[%0t] tone %0.1f Hz (bin %0d), amplitude %0.0f, expected band %0d",
                     $time, tone_hz, bin, amp, exp_band + 1);
            read_levels;
            best = 0;
            for (b = 1; b < 12; b = b + 1) if (raw[b] > raw[best]) best = b;
            ok_far = 1;
            for (b = 0; b < 12; b = b + 1)
                if ((b < exp_band - 1 || b > exp_band + 1) && lv[b] > 1) ok_far = 0;
            check(best == exp_band, "strongest band is the expected band");
            check(lv[exp_band] >= lmin && lv[exp_band] <= lmax, "level of the expected band in range");
            check(ok_far == 1, "bands not adjacent to the tone stay at level 0..1");
        end
    endtask

    // ------------------------------------------------------------ timing monitor
    // processing time: core busy from frame_go to publish; latency: frame_go to STATUS.READY
    real    t_go = 0.0, busy_min = 1.0e12, busy_max = 0.0, lat_max = 0.0;
    integer busy_n = 0;
    always @(posedge clk24) begin
        if (dut.frame_go && dut.c_en) t_go = $realtime;
        if (dut.state == dut.S_PUB) begin
            if ($realtime - t_go < busy_min) busy_min = $realtime - t_go;
            if ($realtime - t_go > busy_max) busy_max = $realtime - t_go;
            busy_n = busy_n + 1;
        end
    end
    always @(posedge dut.st_ready) begin
        if ($realtime - t_go > lat_max) lat_max = $realtime - t_go;
    end

    // ------------------------------------------------------------ test sequence
    integer b;
    initial begin
        repeat (20) @(posedge pclk);
        presetn = 1'b1;
        repeat (5) @(posedge pclk);

        apb_read(10'h000, rdat);
        check(rdat == 32'h5046_4654, "ID register at 0x00");
        apb_read(10'h004, rdat);
        check(rdat[15:0] == 16'h0203, "STATUS at 0x04: reset EN, WINDOW, DECAY = 2, not READY");
        apb_read(10'h008, rdat);
        check(rdat[7:0] == 8'd36 && rdat[12:8] == 5'd8, "SCALE reset value");
        apb_write(10'h004, 32'h0000_0003);              // CTRL: EN, Hann window, DECAY = 0 (follow)
        apb_read(10'h004, rdat);
        check(rdat[11:0] == 12'h003, "CTRL write read back in STATUS");

        // 1. silence: PWM muted
        play = 1'b0;
        wait_frames(3);
        $display("[%0t] silence (PWM muted)", $time);
        read_levels;
        for (b = 0; b < 12; b = b + 1) check(lv[b] == 4'd0, "silence: level 0");

        // 2. tones on bin centres (amplitude 400 of 512), 62.5 Hz per bin
        tone_test(4,   400.0, 0,  6, 7);                //  250 Hz -> band 1  (bins 1-7)
        tone_test(12,  400.0, 2,  6, 7);                //  750 Hz -> band 3  (bins 11-13)
        tone_test(32,  400.0, 6,  6, 7);                // 2000 Hz -> band 7  (bins 29-36)
        tone_test(80,  400.0, 10, 6, 7);                // 5000 Hz -> band 11 (bins 78-99)
        // 7625 Hz -> band 12 (bins 100-127). The PWM-to-sample window is not aligned with the TTS
        // sample ticks, so each sample mixes two neighbours: up to cos(pi*f/16k) = -22 dB near 8 kHz.
        tone_test(122, 400.0, 11, 3, 7);

        // 3. 24 dB lower: 400 / 16 = 25
        tone_test(32, 25.0, 6, 3, 5);

        // 4. STATUS READY clears on a LEVELS_LO read
        apb_read(10'h00C, rdat);
        apb_read(10'h004, rdat);
        check(rdat[12] == 1'b0, "READY cleared by LEVELS_LO read");

        $display("FFT processing per frame: min %0.1f us, max %0.1f us over %0d frames (CORE_CLK 24 MHz)",
                 busy_min / 1000.0, busy_max / 1000.0, busy_n);
        $display("Frame end to READY in the APB domain: max %0.2f us", lat_max / 1000.0);
        $display("%0d checks, %0d errors", checks, errors);
        if (errors == 0) $display("SCOREBOARD PASS");
        else             $display("SCOREBOARD FAIL");
        $finish;
    end
endmodule
