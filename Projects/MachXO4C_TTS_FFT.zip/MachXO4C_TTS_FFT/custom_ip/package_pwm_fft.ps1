# Packages PWM_FFT with the IP Packager engine on the command line (ippkg.exe).
# Output: pwm_fft_<version>.ipk next to this script (version read from metadata.xml),
# plus package\ippkg_out.txt / ippkg_err.txt in the IP folder.
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$blk  = (Resolve-Path (Join-Path $here 'custom_module_pwm_fft_1.2.0')).Path
$ver  = ([xml](Get-Content "$blk\metadata.xml")).ip.general.version
$env:FOUNDRY = 'C:\lscc\propel\2026.1.1\builder\rtf\ispfpga'
$pkg  = "$env:FOUNDRY\bin\nt64\ippkg.exe"
$meta = @("$blk\metadata.xml", "$blk\bus_interface.xml", "$blk\memory_map.xml")
$rtl  = @("$blk\rtl\pwm_fft.v")
$drv  = @('pwm_fft_regs.h','pwm_fft.c','pwm_fft.h','pwm_fft.xml') | % { "$blk\driver\$_" }
$out  = "$here\pwm_fft_$ver.ipk"
if (Test-Path $out) { Remove-Item $out }
$tmp = Join-Path $blk 'package'
New-Item -ItemType Directory -Force $tmp | Out-Null
$enc = New-Object Text.UTF8Encoding($false)
[IO.File]::WriteAllLines("$tmp\metadata_list.txt", [string[]]$meta, $enc)
[IO.File]::WriteAllLines("$tmp\rtl_list.txt",      [string[]]$rtl,  $enc)
[IO.File]::WriteAllLines("$tmp\driver_list.txt",   [string[]]$drv,  $enc)
& $pkg -metadata_files "$tmp\metadata_list.txt" -rtl_files "$tmp\rtl_list.txt" -driver_files "$tmp\driver_list.txt" `
    -help_file "$blk\doc\introduction.html" -o $out `
    1> "$tmp\ippkg_out.txt" 2> "$tmp\ippkg_err.txt"
"exit=$LASTEXITCODE"
Get-Content "$tmp\ippkg_out.txt","$tmp\ippkg_err.txt"
if (Test-Path $out) {
    Add-Type -A System.IO.Compression.FileSystem
    $z = [IO.Compression.ZipFile]::OpenRead($out); $z.Entries | % FullName; $z.Dispose()
}
