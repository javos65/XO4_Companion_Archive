################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
S_UPPER_SRCS += \
../src/bsp/driver/cpu/crt0.S \
../src/bsp/driver/cpu/entry.S \
../src/bsp/driver/cpu/start.S 

OBJS += \
./src/bsp/driver/cpu/crt0.o \
./src/bsp/driver/cpu/entry.o \
./src/bsp/driver/cpu/start.o 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/cpu/%.o: ../src/bsp/driver/cpu/%.S src/bsp/driver/cpu/subdir.mk
	@echo 'Assembling file: $<'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -Os -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -I"../src" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/cpu" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/riscv_sm" -I"../src/bsp/driver/tts_apb" -I"../src/bsp/driver/uart" -I"../src/config" -I"../src/hal" -I"../src/system" -c -o "$@" "$<"
	@echo ' '

