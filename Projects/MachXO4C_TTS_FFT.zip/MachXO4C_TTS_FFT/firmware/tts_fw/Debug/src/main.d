src/main.o: ../src/main.c ../src/config/soc_config.h \
 ../src/config/feature_flags.h ../src/bsp/sys_platform.h \
 ../src/bsp/riscv_errors.h ../src/bsp/driver/uart/uart.h \
 ../src/bsp/driver/gpio/gpio_regs.h ../src/bsp/driver/tts_apb/tts.h \
 ../src/bsp/driver/tts_apb/tts_regs.h ../src/bsp/driver/riscv_sm/timer.h \
 ../src/bsp/driver/pwm_fft/pwm_fft_regs.h \
 ../src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi_regs.h \
 ../src/bsp/driver/fxls8971_i2c/i2c_master_regs.h
../src/config/soc_config.h:
../src/config/feature_flags.h:
../src/bsp/sys_platform.h:
../src/bsp/riscv_errors.h:
../src/bsp/driver/uart/uart.h:
../src/bsp/driver/gpio/gpio_regs.h:
../src/bsp/driver/tts_apb/tts.h:
../src/bsp/driver/tts_apb/tts_regs.h:
../src/bsp/driver/riscv_sm/timer.h:
../src/bsp/driver/pwm_fft/pwm_fft_regs.h:
../src/bsp/driver/mkr_rgb_spi/mkr_rgb_spi_regs.h:
../src/bsp/driver/fxls8971_i2c/i2c_master_regs.h:
