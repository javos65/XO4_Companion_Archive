/*
 * MachXO4 Companion Board text-to-speech: RISC-V SM firmware (rv32i).
 *
 * The RISC-V handles the UART, the status messages and the LEDs, and drives the memory-mapped
 * TTS_APB library block. UART, TTS and timer use their drivers; GPIO, PWM_FFT and MKR_RGB_SPI
 * are driven by direct register access (smallest code, no driver state in RAM: 8 KB system memory).
 *
 * Sequence:
 *   reset            : send "TTS OK.", speak the boot phrase, discard everything received meanwhile,
 *                      then clear the queue
 *   text line (UART) : every received character is written to the TTS block (lines up to 128 characters)
 *   line complete    : send "TTS EXE", write START, wait until BUSY clears, send "TTS RDY"
 * Every message ends with CR LF.
 *
 * Jingle: every 10 minutes (RISC-V timer, 12 MHz tick), when the TTS block is idle and no UART line
 *   is half received, two tone phrases are played one after the other.
 *
 * GPIO (5 lines): lines 3..0 are the LEDs (driven low to light), line 4 is the debounced SW2 input.
 *   LED0 heartbeat, LED1 left to the hardware (SW2 pressed), LED2 speech active,
 *   LED3 changes state on every character received.
 *
 * Spectrum display (MKR RGB shield, 7 rows x 12 columns, APA102 chain via MKR_RGB_SPI):
 *   while the TTS block is busy, every new PWM_FFT frame (16 ms) is drawn as 12 bars,
 *   band 1 (50-500 Hz) left, bands 2..12 (logarithmic, 500 Hz to 8 kHz) to the right,
 *   bar height = level 0..7 from the bottom.
 *   Levels are computed here from the RAW band power (see FFT_FLOOR, band_adj), averaged over the
 *   last FFT_AVG frames (64 ms) for a fuller spectrum.
 *   Animation: each FFT frame sets a target height per bar; every ANIM_MS the displayed height
 *   moves one LED towards its target and the matrix is redrawn, so a bar ramps up or down
 *   (7 levels in 14 ms, within one 16 ms frame). When speech ends all targets go to 0 and the
 *   bars ramp down to an empty matrix.
 *   Each bar has its own colour; the top LED of a bar is at 35 % (APA102 global brightness
 *   BR_PEAK), the LEDs below it at 1 % (global brightness BR_BAR with the colour x 5/16).
 *   The two blocks are driven by direct register access (no frame buffer in RAM).
 *   XO4 logo (12 x 7 RGB565 table xo4[], global brightness LOGO_BR): shown for 1 s at start-up,
 *   before the start-up phrase (which then plays with the spectrum), and for 2 s on a tilt to the
 *   left. Otherwise the matrix is dark while no speech is playing.
 *
 * Accelerometer (FXLS8971CF, U5) on I2C through the FXLS8971_I2C block (0x9400, 100 kHz):
 *   at reset the WHO_AM_I register (0x13) is checked and the sensor is set to +/-2 g, 25 Hz, Active;
 *   UART report: "ACC ID 83 OK", "ACC ID xx BAD" (other value), "ACC NO ACK" (no answer at
 *   address 0x18), "ACC CFG ERR" or "ACC NO I2C" (I2C block ID not found).
 *   Tilt phrases: X/Y are sampled every 50 ms. When the board tilts more than 30 degrees, the
 *   strongest direction speaks once (UART "TILT FWD/LEFT/RIGHT/BACK"):
 *     forward "Xilinx is Shy-SU", left: XO4 logo for 2 s (no phrase),
 *     right "Downt wake me up!", backward "Lattice? Mag X-O for is running!" (start-up phrase).
 *   The next tilt is only accepted after the board was back within 5 degrees of horizontal;
 *   after reset the board must first be horizontal before the first tilt can trigger.
 *   A phrase waits while the TTS block is busy or a UART line is half received.
 */
#include <stdint.h>
#include "config/soc_config.h"
#include "bsp/sys_platform.h"
#include "bsp/driver/uart/uart.h"
#include "bsp/driver/gpio/gpio_regs.h"
#include "bsp/driver/tts_apb/tts.h"
#include "bsp/driver/riscv_sm/timer.h"
#include "bsp/driver/pwm_fft/pwm_fft_regs.h"
#include "bsp/driver/mkr_rgb_spi/mkr_rgb_spi_regs.h"
#include "bsp/driver/fxls8971_i2c/i2c_master_regs.h"

#define REG32(a)        (*(volatile uint32_t *)(uintptr_t)(a))

#define CPU_HZ          ((uint32_t)UART0_INST_CLOCK_HZ)    /* system clock: 12 MHz from the PLL */
#define TIMER_BASE      ((uint32_t)CPU0_INST_PICTIMER_START_ADDR)

#define GPIO_BASE       ((uint32_t)GPIO0_INST_BASE)
#define GPIO_DIRS       0x0Fu       /* direction 1 = output: lines 3..0 LEDs, line 4 input (SW2) */

#define LED_HEARTBEAT   0u
#define LED_SW2         1u          /* driven in hardware; firmware keeps it off */
#define LED_SPEECH      2u
#define LED_RXCHAR      3u

#define BOOT_PHRASE     "Lattice? Mag X-O for is running!\r"
#define UART_LINE_MAX   TTS_LINE_MAX
#define HEARTBEAT_SHIFT 17          /* LED toggles every 2^17 loop passes */

static struct uart_instance  uart0;
static struct tts_instance   tts0;
static struct timer_instance timer0;

/* ---- transmit queue: messages are sent without blocking the receive path ---- */
#define TXQ_SIZE 64u                /* power of two, larger than the longest messages plus CR LF */
static uint8_t  txq[TXQ_SIZE];
static uint32_t tx_wr, tx_rd;

static void tx_message(const char *s)
{
    while (*s) {
        txq[tx_wr & (TXQ_SIZE - 1u)] = (uint8_t)*s++;
        tx_wr++;
    }
    txq[tx_wr & (TXQ_SIZE - 1u)] = '\r'; tx_wr++;
    txq[tx_wr & (TXQ_SIZE - 1u)] = '\n'; tx_wr++;
}

static void tx_service(void)
{
    if (tx_rd != tx_wr) {
        if (uart_putc(&uart0, txq[tx_rd & (TXQ_SIZE - 1u)]) == 0) {
            tx_rd++;
        }
    }
}

/* ---- LEDs ---- */
static uint32_t led_state   = 0xFu;         /* bit = 1: LED off */
static uint32_t led_written = 0xFFFFFFFFu;
static uint32_t heartbeat;
static uint8_t  rx_toggle;

static void leds_write(void)
{
    if (led_state == led_written) return;
    REG32(GPIO_BASE + GPIO_WR_DATA) = led_state;   /* all four LED lines in one write */
    led_written = led_state;
}

static void led_set(uint32_t bit, uint32_t lit)
{
    if (lit) led_state &= ~(1u << bit); else led_state |= (1u << bit);
}

/* ---- jingle: two tone phrases, one after the other, every 10 minutes ---- */
#define CHIME_PERIOD_S   600u
#define CHIME_PHRASE1 "#1318,125# #1174,125# #881,100#,#1046,188# #991,188# #657,188# #881,125# #1046,125# #1174,125# #989,125#\r"
#define CHIME_PHRASE2 "#1318,125#-#1174,125#-#881,100#-#1046,125# #991,125# #657,125# #881,125# #1046,125#-#1174,125# #991,313#\r"
#define TIMER_CHECK_MASK 0xFFFu     /* read the timer every 4096 loop passes */
static uint64_t chime_next;
static uint64_t time_now;
static int      chime_pending;

/* ---- spectrum display ---- */
#define FFT_BASE        ((uint32_t)FFT0_INST_BASE_ADDR)
#define RGB_BASE        ((uint32_t)MKR_RGB0_INST_BASE_ADDR)
#define MATRIX_W        12u          /* columns = bands */
#define MATRIX_H        7u           /* rows = levels 1..7 */
#define BR_PEAK         11u          /* APA102 global brightness (0..31) of the top LED: 11/31 = 35 % */
#define BR_BAR          1u           /* LEDs below the top: 1/31 with colour x 5/16 = 1 % */
#define APA102_OFF      0xE0000000u
#define ANIM_MS         2u           /* one animation step (one LED up or down per bar) */
#define ANIM_TICKS      (CPU_HZ / 1000u * ANIM_MS)
#define MTIME_LO        (TIMER_BASE + TIMER_MTIME_LOW)   /* RISC-V timer, CPU_HZ ticks */

/* Level scale, computed here from the PWM_FFT RAW registers (L = 4 * log2(band power)).
 * Each band is first reduced by band_adj (width correction). Then: level 0 below FFT_FLOOR, level 1 at
 * FFT_FLOOR, one level more per FFT_STEP5 / 5 (3.6 = about 2.7 dB), level 7 at FFT_FLOOR + 22.
 * (33 % higher bars than the previous scale: floor 27, 4.8 per level.) */
#define FFT_FLOOR       26
#define FFT_STEP5       18           /* step per level x 5 (step 3.6) */

/* PWM_FFT 1.2.0 (256-point, 62.5 Hz bins): band 1 = bins 1-7 (50-500 Hz), bands 2..12 log-spaced
 * to 8 kHz; bins per band 7, 3, 3, 4, 4, 7, 8, 10, 14, 17, 22, 28.
 * Half width correction: 2 * log2(bins) relative to the narrowest band (3 bins), so wide bands
 * keep half of their summed-power advantage (about 3 dB per octave). */
static const uint8_t band_adj[MATRIX_W] = { 2, 0, 0, 1, 1, 2, 3, 3, 4, 5, 6, 6 };

/* 1: send the 12 RAW values (L = 4 * log2(band power)) as hex over the UART every 4th FFT frame
 * (64 ms) while speaking, for calibrating FFT_FLOOR / FFT_STEP5. Line: "R " + 12 x 2 hex digits.
 * 0: off (no UART spectrum output, dump code not compiled). */
#define SPEC_DEBUG      0

/* bar colours 0x00BBGGRR, band 1 (red) .. band 12 (magenta) */
static const uint32_t bar_rgb[MATRIX_W] = {
    0x0000FFu, 0x0074FFu, 0x00E9FFu, 0x00FFA2u, 0x00FF2Eu, 0x46FF00u,
    0xBAFF00u, 0xFFD000u, 0xFF5C00u, 0xFF0017u, 0xFF008Cu, 0xFF00FFu
};

/* Longer analysis time: the band power of the last FFT_AVG frames is averaged (in the power
 * domain, like one FFT over FFT_AVG x 16 ms), so a frame catches more of each speech sound. */
#define FFT_AVG         4u           /* frames averaged: 4 x 16 ms = 64 ms */
#define AVG_FULL        (FFT_AVG * 4096u)   /* power sum when all frames equal the loudest one */

static uint8_t  band_hist[FFT_AVG][MATRIX_W];   /* RAW values of the last FFT_AVG frames */
static uint8_t  hist_pos;            /* next history slot */
static uint8_t  band_tgt[MATRIX_W];  /* target level per band from the averaged FFT frames */
static uint8_t  band_lv[MATRIX_W];   /* displayed level per band (ramps towards band_tgt) */
static uint32_t fft_frame;           /* last PWM_FFT frame counter seen */
static uint32_t anim_next;           /* MTIME_LO value of the next animation step */

/* 4096 * 2^(-k/4): power of a frame k quarter-log2 steps below the loudest one */
static const uint16_t pow_q[4] = { 4096u, 3444u, 2896u, 2435u };

/* New PWM_FFT frame: stores the RAW values, averages the power of the last FFT_AVG frames per
 * band (L_avg = 4 * log2(mean power)) and turns the result into the new target height. */
static void spectrum_update(void)
{
    uint8_t *h = band_hist[hist_pos];
    uint32_t b, k, e, sum;
    int32_t  d, lv, lmax;

    if (++hist_pos >= FFT_AVG) hist_pos = 0u;
    for (b = 0; b < MATRIX_W; b++) h[b] = (uint8_t)REG32(FFT_BASE + PWM_FFT_REG_RAW(b));

    for (b = 0; b < MATRIX_W; b++) {
        /* power sum relative to the loudest frame (no overflow, no multiply) */
        lmax = 0;
        for (k = 0; k < FFT_AVG; k++) if (band_hist[k][b] > lmax) lmax = band_hist[k][b];
        sum = 0;
        for (k = 0; k < FFT_AVG; k++) {
            e = (uint32_t)lmax - band_hist[k][b];
            if (e < 52u) sum += (uint32_t)pow_q[e & 3u] >> (e >> 2);
        }
        /* back to quarter-log2 steps: L_avg = lmax + 4 * log2(sum / AVG_FULL), rounded */
        d = lmax;
        while (sum < AVG_FULL / 2u) { sum <<= 1; d -= 4; }
        if      (sum < (AVG_FULL *  8933u) >> 14) d -= 4;
        else if (sum < (AVG_FULL * 10624u) >> 14) d -= 3;
        else if (sum < (AVG_FULL * 12634u) >> 14) d -= 2;
        else if (sum < (AVG_FULL * 15024u) >> 14) d -= 1;

        d -= band_adj[b] + FFT_FLOOR;
        lv = 0;
        if (d >= 0) {
            d = (d << 2) + d;            /* x 5, so the step can be 4.8 */
            for (lv = 1; d >= FFT_STEP5 && lv < (int32_t)MATRIX_H; lv++) d -= FFT_STEP5;
        }
        band_tgt[b] = (uint8_t)lv;
    }
}

#if SPEC_DEBUG
/* Queues "R " + the 12 RAW values as 2 hex digits each (band 1 first) for the UART. */
static void spectrum_dump(void)
{
    static const char hex[] = "0123456789ABCDEF";
    char     m[2u + 2u * MATRIX_W + 1u];
    uint32_t b, v;

    m[0] = 'R';
    m[1] = ' ';
    for (b = 0; b < MATRIX_W; b++) {
        v = REG32(FFT_BASE + PWM_FFT_REG_RAW(b)) & 0xFFu;
        m[2u + 2u * b] = hex[v >> 4];
        m[3u + 2u * b] = hex[v & 0xFu];
    }
    m[2u + 2u * MATRIX_W] = '\0';
    tx_message(m);
}
#endif

/* One animation step: every bar moves one LED towards its target (idle: target 0).
 * Returns 1 when any bar moved (the matrix needs a redraw). */
static int spectrum_step(int idle)
{
    uint32_t b, k;
    int      moved = 0;

    for (b = 0; b < MATRIX_W; b++) {
        if (idle) {                  /* no speech: empty bars, forget the frame history */
            band_tgt[b] = 0;
            for (k = 0; k < FFT_AVG; k++) band_hist[k][b] = 0;
        }
        if (band_lv[b] < band_tgt[b])      { band_lv[b]++; moved = 1; }
        else if (band_lv[b] > band_tgt[b]) { band_lv[b]--; moved = 1; }
    }
    return moved;
}

/* Draws band_lv[] and starts the transfer.
 * LED index = row * 12 + column, row 0 = top. */
static void matrix_show(void)
{
    uint8_t  top[MATRIX_W];          /* row of the top LED of each bar (MATRIX_H = no bar) */
    uint32_t a = RGB_BASE + MKR_RGB_SPI_REG_PIX(0);
    uint32_t x, y;

    for (x = 0; x < MATRIX_W; x++) {
        top[x] = (uint8_t)(MATRIX_H - band_lv[x]);
    }
    for (y = 0; y < MATRIX_H; y++) {
        for (x = 0; x < MATRIX_W; x++, a += 4u) {
            REG32(a) = (y < top[x])  ? APA102_OFF :
                       (y == top[x]) ? (APA102_OFF | (BR_PEAK << 24) | bar_rgb[x]) :
                                       (APA102_OFF | (BR_BAR << 24) |
                                        (((bar_rgb[x] >> 2) & 0x3F3F3Fu) + ((bar_rgb[x] >> 4) & 0x0F0F0Fu)));
        }
    }
    REG32(RGB_BASE + MKR_RGB_SPI_REG_CTRL) = MKR_RGB_SPI_CTRL_START;
}

/* ---- accelerometer (FXLS8971CF) on I2C, direct register access ---- */
#define I2C_BASE        ((uint32_t)I2C0_INST_BASE_ADDR)
#define I2C_POLLS       100000u      /* STATUS polls before a byte command is declared timed out */
#define I2C_TIMEOUT     0xFFFFFFFFu  /* returned on timeout; has the RXNACK bit set, so it counts as an error */
#define ACC_ADDR        0x18u        /* 7-bit address, SA0 = 0 */
#define ACC_OUT_X_LSB   0x04u        /* X, Y, Z: 12-bit two's complement, LSB first */
#define ACC_WHO_AM_I    0x13u
#define ACC_ID_VALUE    0x83u
#define ACC_SYS_MODE    0x14u
#define ACC_SENS_CFG1   0x15u        /* bit0 ACTIVE, bits 2:1 range (0 = +/-2 g, 1024 LSB/g) */
#define ACC_SENS_CFG2   0x16u        /* 0: low-power mode, little endian */
#define ACC_SENS_CFG3   0x17u        /* WAKE_ODR[7:4], SLEEP_ODR[3:0] */
#define ACC_ODR_25HZ    0x77u

/* Tilt detection (+/-2 g range, 1024 LSB = 1 g). A tilt is seen when the horizontal component on
 * the forward/back or left/right axis exceeds sin(30 deg) x 1 g; the sensor is re-armed when both
 * axes are back below sin(5 deg) x 1 g (board flat again).
 * Tilting an edge down makes the reading on that axis negative (the sensor measures +1 g upwards). */
#define TILT_ON         512          /* 1024 x sin(30 deg) */
#define TILT_OFF        89           /* 1024 x sin(5 deg) */
#define TILT_POLL_TICKS (CPU_HZ / 20u)   /* sample every 50 ms */
/* Board orientation: value that grows when the board is tilted forward / to the right.
 * Change these two lines if the phrases come out on the wrong tilt directions. */
#define TILT_FWD(x, y)  (-(y))
#define TILT_RIGHT(x, y) (x)

enum { TILT_NONE = 0, TILT_F, TILT_L, TILT_R, TILT_B };
static const char *const tilt_phrase[5] = {
    "",
    "Xilinx is Shy-SU\r",            /* forward */
    "",                              /* left: no phrase, shows the XO4 logo instead */
    "Downt wake me up!\r",           /* right */
    BOOT_PHRASE                      /* backward: same as the start-up phrase */
};
static const char *const tilt_name[5] = { "", "TILT FWD", "TILT LEFT", "TILT RIGHT", "TILT BACK" };
static uint8_t  acc_ok;              /* sensor found and running */
static uint8_t  tilt_armed;          /* 1: board was horizontal, the next tilt may trigger;
                                        0 at reset, so the board must be flat once before the first trigger */
static uint8_t  tilt_pending;        /* phrase waiting for the TTS block to be free */
static uint32_t tilt_next;           /* MTIME_LO value of the next sample */

/* Runs one byte command (CMD bits) and returns STATUS when it is done, I2C_TIMEOUT otherwise. */
static uint32_t i2c_cmd(uint32_t cmd, uint32_t tx)
{
    uint32_t n, s;

    REG32(I2C_BASE + I2C_MASTER_REG_TXDATA) = tx;
    REG32(I2C_BASE + I2C_MASTER_REG_CMD)    = cmd;
    for (n = 0; n < I2C_POLLS; n++) {
        s = REG32(I2C_BASE + I2C_MASTER_REG_STATUS);
        if (!(s & I2C_MASTER_STATUS_BUSY)) return s;
    }
    return I2C_TIMEOUT;
}

#define I2C_NACK(s)     ((s) & I2C_MASTER_STATUS_RXNACK)

/* Burst read of n accelerometer registers from reg: START, addr+W, reg, repeated START, addr+R,
 * n bytes (NACK on the last), STOP. Returns 0, or -1 on a missing ACK or a bus timeout. */
static int acc_read(uint32_t reg, uint8_t *b, uint32_t n)
{
    uint32_t i;

    if (I2C_NACK(i2c_cmd(I2C_MASTER_CMD_START | I2C_MASTER_CMD_WRITE, ACC_ADDR << 1)) ||
        I2C_NACK(i2c_cmd(I2C_MASTER_CMD_WRITE, reg)) ||
        I2C_NACK(i2c_cmd(I2C_MASTER_CMD_START | I2C_MASTER_CMD_WRITE, (ACC_ADDR << 1) | 1u))) {
        (void)i2c_cmd(I2C_MASTER_CMD_STOP, 0u);      /* release the bus */
        return -1;
    }
    for (i = 0; i < n; i++) {
        if (i2c_cmd(I2C_MASTER_CMD_READ | ((i == n - 1u) ? (I2C_MASTER_CMD_NACK | I2C_MASTER_CMD_STOP) : 0u), 0u)
            == I2C_TIMEOUT) return -1;
        b[i] = (uint8_t)REG32(I2C_BASE + I2C_MASTER_REG_RXDATA);
    }
    return 0;
}

/* Writes one accelerometer register: START, addr+W, reg, value, STOP. Returns 0 or -1. */
static int acc_write(uint32_t reg, uint32_t v)
{
    if (I2C_NACK(i2c_cmd(I2C_MASTER_CMD_START | I2C_MASTER_CMD_WRITE, ACC_ADDR << 1)) ||
        I2C_NACK(i2c_cmd(I2C_MASTER_CMD_WRITE, reg))) {
        (void)i2c_cmd(I2C_MASTER_CMD_STOP, 0u);
        return -1;
    }
    return I2C_NACK(i2c_cmd(I2C_MASTER_CMD_WRITE | I2C_MASTER_CMD_STOP, v)) ? -1 : 0;
}

/* Checks WHO_AM_I, then sets +/-2 g, low-power mode, 25 Hz and Active (configuration is only
 * accepted in Standby). Reports the result on the UART and sets acc_ok. */
static void acc_init(void)
{
    static const char hex[] = "0123456789ABCDEF";
    static char m[] = "ACC ID xx BAD";
    uint8_t  v = 0xFFu;
    uint32_t n;

    if (REG32(I2C_BASE + I2C_MASTER_REG_ID) != I2C_MASTER_ID_VALUE) { tx_message("ACC NO I2C"); return; }
    if (REG32(I2C_BASE + I2C_MASTER_REG_STATUS) & I2C_MASTER_STATUS_OWNED) {
        (void)i2c_cmd(I2C_MASTER_CMD_STOP, 0u);      /* bus still owned after a CPU reset */
    }
    if (acc_read(ACC_WHO_AM_I, &v, 1u)) { tx_message("ACC NO ACK"); return; }
    if (v != ACC_ID_VALUE) {
        m[7] = hex[v >> 4];
        m[8] = hex[v & 0xFu];
        tx_message(m);
        return;
    }
    if (acc_write(ACC_SENS_CFG1, 0x00u)) { tx_message("ACC CFG ERR"); return; }   /* Standby, +/-2 g */
    for (n = 0; n < 100u; n++) {                                   /* wait for SYS_MODE = Standby */
        if (acc_read(ACC_SYS_MODE, &v, 1u) == 0 && (v & 3u) == 0u) break;
    }
    if (acc_write(ACC_SENS_CFG2, 0x00u) || acc_write(ACC_SENS_CFG3, ACC_ODR_25HZ) ||
        acc_write(ACC_SENS_CFG1, 0x01u)) { tx_message("ACC CFG ERR"); return; }
    acc_ok = 1u;
    tx_message("ACC ID 83 OK");
}

/* 12-bit two's complement sample from LSB, MSB */
static int32_t acc_s12(const uint8_t *p)
{
    int32_t v = ((int32_t)(p[1] & 0x0Fu) << 8) | p[0];
    return (v & 0x800) ? v - 0x1000 : v;
}

/* Every TILT_POLL_TICKS: reads X/Y, detects a tilt of more than 30 degrees (strongest axis wins)
 * while armed, queues its phrase once and waits until the board is back within 5 degrees. */
static void tilt_service(void)
{
    uint8_t  b[4];
    int32_t  x, y, f, r, af, ar;
    uint32_t d;

    if (!acc_ok || (int32_t)(REG32(MTIME_LO) - tilt_next) < 0) return;
    tilt_next = REG32(MTIME_LO) + TILT_POLL_TICKS;
    if (acc_read(ACC_OUT_X_LSB, b, 4u)) return;
    x  = acc_s12(&b[0]);
    y  = acc_s12(&b[2]);
    f  = TILT_FWD(x, y);
    r  = TILT_RIGHT(x, y);
    af = (f < 0) ? -f : f;
    ar = (r < 0) ? -r : r;

    if (!tilt_armed) {
        if (af < TILT_OFF && ar < TILT_OFF) tilt_armed = 1u;   /* back horizontal */
        return;
    }
    if (af < TILT_ON && ar < TILT_ON) return;
    if (af >= ar) d = (f > 0) ? TILT_F : TILT_B;
    else          d = (r > 0) ? TILT_R : TILT_L;
    tilt_armed   = 0u;
    tilt_pending = (uint8_t)d;
    tx_message(tilt_name[d]);
}

/* ---- XO4 logo, 12 x 7, RGB565 (row 0 = top): at start-up and on a tilt to the left ---- */
#define LOGO_BR         8u           /* APA102 global brightness of the logo: 8/31 = 25 % */
#define LOGO_BOOT_S     1u           /* seconds the logo is shown at start-up, before the start-up phrase */
#define LOGO_TILT_S     2u           /* seconds the logo is shown after a tilt to the left */
static const uint16_t xo4[MATRIX_H * MATRIX_W] = {
    0xFFFF, 0x0000, 0x0000, 0xFFFF, 0x0000, 0x3597, 0x3597, 0x0000, 0x0000, 0xFEE0, 0x0000, 0x0000,
    0xFFFF, 0x0000, 0x0000, 0xFFFF, 0x3597, 0x0000, 0x0000, 0x3597, 0x0000, 0xFEE0, 0x0000, 0x0000,
    0xFFFF, 0xFFFF, 0x0000, 0xFFFF, 0x3597, 0x0000, 0x0000, 0x3597, 0xFEE0, 0x0000, 0x0000, 0x0000,
    0x0000, 0xFFFF, 0xFFFF, 0x0000, 0x3597, 0x0000, 0x0000, 0x3597, 0xFEE0, 0x0000, 0xFEE0, 0x0000,
    0xFFFF, 0x0000, 0xFFFF, 0xFFFF, 0x3597, 0x0000, 0x0000, 0x3597, 0xFEE0, 0xFEE0, 0xFEE0, 0xFEE0,
    0xFFFF, 0x0000, 0x0000, 0xFFFF, 0x3597, 0x0000, 0x0000, 0x3597, 0x0000, 0x0000, 0xFEE0, 0x0000,
    0xFFFF, 0x0000, 0x0000, 0xFFFF, 0x0000, 0x3597, 0x3597, 0x0000, 0x0000, 0x0000, 0xFEE0, 0x0000
};

/* Draws the logo: RGB565 -> APA102 0xE0 | brightness, BB GG RR (5/6-bit colour scaled to 8 bits). */
static void logo_show(void)
{
    uint32_t a = RGB_BASE + MKR_RGB_SPI_REG_PIX(0);
    uint32_t i, v, r, g, b;

    for (i = 0; i < MATRIX_H * MATRIX_W; i++, a += 4u) {
        v = xo4[i];
        r = (v >> 11) & 0x1Fu;  r = (r << 3) | (r >> 2);
        g = (v >> 5)  & 0x3Fu;  g = (g << 2) | (g >> 4);
        b =  v        & 0x1Fu;  b = (b << 3) | (b >> 2);
        REG32(a) = APA102_OFF | (LOGO_BR << 24) | (b << 16) | (g << 8) | r;
    }
    REG32(RGB_BASE + MKR_RGB_SPI_REG_CTRL) = MKR_RGB_SPI_CTRL_START;
}

static void rx_discard(void)
{
    uint8_t c;
    while (uart_getc(&uart0, &c) == 0) { /* drop */ }
}

int main(void)
{
    uint8_t  c;
    uint32_t st;
    int      speaking = 0;
    int      booting  = 1;
    uint32_t line_len = 0;
    int      spec_ok;
    int      redraw = 1;             /* draw (clear) the matrix once after reset */
    int      logo_on = 0;            /* 1: the XO4 logo is on the matrix */
    int      logo_timed = 0;         /* 1: logo shown until logo_end (tilt left) */
    uint32_t logo_end = 0;           /* MTIME_LO value at which the logo ends */

    uart_init(&uart0, UART0_INST_BASE, CPU_HZ, UART0_INST_BAUDRATE,
              UART0_INST_STOP_BITS, UART0_INST_DATA_BITS);
    uart0.blockingTx = 0;
    uart0.blockingRx = 0;

    REG32(GPIO_BASE + GPIO_DIRECTION) = GPIO_DIRS;
    tts_init(&tts0, TTS0_INST_BASE);
    timer_init(&timer0, TIMER_BASE, CPU_HZ);
    timer_get_mtime(&timer0, &time_now);
    chime_next = time_now + (uint64_t)CHIME_PERIOD_S * CPU_HZ;
    leds_write();
    spec_ok = (REG32(FFT_BASE + PWM_FFT_REG_ID) == PWM_FFT_ID_VALUE) &&
              (REG32(RGB_BASE + MKR_RGB_SPI_REG_ID) == MKR_RGB_SPI_ID_VALUE);

    tx_message("TTS OK.");
    acc_init();

    /* start-up: XO4 logo for LOGO_BOOT_S seconds, then the start-up phrase with the spectrum */
    if (spec_ok) {
        logo_show();
        logo_on  = 1;
        logo_end = REG32(MTIME_LO) + LOGO_BOOT_S * CPU_HZ;
        while ((int32_t)(REG32(MTIME_LO) - logo_end) < 0) tx_service();
    }
    write_tts_phrase(&tts0, BOOT_PHRASE, sizeof(BOOT_PHRASE) - 1u);
    write_tts_control(&tts0, TTS_CTRL_START);
    speaking = 1;

    for (;;) {
        tx_service();
        st = read_tts_status(&tts0);

        if (booting) {
            rx_discard();
            if (!(st & TTS_STATUS_BUSY)) {          /* boot phrase finished */
                booting  = 0;
                speaking = 0;
                write_tts_control(&tts0, TTS_CTRL_CLEAR);
                rx_discard();
            }
        } else if (uart_getc(&uart0, &c) == 0) {
            write_tts_phrase(&tts0, (const char *)&c, 1u);
            if (c == (uint8_t)0x0D || c == (uint8_t)0x0A || ++line_len >= UART_LINE_MAX) line_len = 0;
            rx_toggle ^= 1u;
            led_set(LED_RXCHAR, rx_toggle);
        }

        if (!booting) {
            if (speaking && !(st & TTS_STATUS_BUSY)) {
                speaking = 0;
                tx_message("TTS RDY");
            } else if (!speaking && (st & TTS_STATUS_READY) && !(st & TTS_STATUS_BUSY)) {
                tx_message("TTS EXE");
                write_tts_control(&tts0, TTS_CTRL_START);
                speaking = 1;
            }
        }

        if ((heartbeat & TIMER_CHECK_MASK) == 0u) {
            timer_get_mtime(&timer0, &time_now);
            if (time_now >= chime_next) chime_pending = 1;
        }
        if (!booting && chime_pending && !speaking && line_len == 0 &&
            !(st & (TTS_STATUS_BUSY | TTS_STATUS_READY))) {
            /* both line buffers are free: phrase 2 starts right after phrase 1 */
            write_tts_phrase(&tts0, CHIME_PHRASE1, sizeof(CHIME_PHRASE1) - 1u);
            write_tts_phrase(&tts0, CHIME_PHRASE2, sizeof(CHIME_PHRASE2) - 1u);
            chime_pending = 0;
            chime_next = time_now + (uint64_t)CHIME_PERIOD_S * CPU_HZ;
        }

        /* tilt phrases: detected every 50 ms; a phrase is queued when the TTS block and the UART
         * line are free (it then starts like a typed line: READY -> "TTS EXE") */
        tilt_service();
        if (tilt_pending == TILT_L) {        /* tilt left: XO4 logo for LOGO_TILT_S seconds, no phrase */
            logo_timed   = 1;
            logo_on      = 0;
            logo_end     = REG32(MTIME_LO) + LOGO_TILT_S * CPU_HZ;
            tilt_pending = TILT_NONE;
        }
        if (!booting && tilt_pending && !speaking && line_len == 0 && !chime_pending &&
            !(st & (TTS_STATUS_BUSY | TTS_STATUS_READY))) {
            const char *p = tilt_phrase[tilt_pending];
            uint32_t    n = 0;
            while (p[n]) n++;
            write_tts_phrase(&tts0, p, n);
            tilt_pending = TILT_NONE;
        }

        /* spectrum: new bar targets every FFT frame (16 ms) while speaking, targets 0 otherwise;
         * every ANIM_MS (when the LED block is idle) each bar moves one LED towards its target */
        if (spec_ok) {
            if (st & TTS_STATUS_BUSY) {
                uint32_t f = PWM_FFT_STATUS_FRAMES(REG32(FFT_BASE + PWM_FFT_REG_STATUS));
                if (f != fft_frame) {
                    fft_frame = f;
                    spectrum_update();
#if SPEC_DEBUG
                    if ((f & 3u) == 0u) spectrum_dump();
#endif
                }
            }
            if ((int32_t)(REG32(MTIME_LO) - anim_next) >= 0 &&
                (REG32(RGB_BASE + MKR_RGB_SPI_REG_CTRL) & MKR_RGB_SPI_CTRL_READY)) {
                anim_next = REG32(MTIME_LO) + ANIM_TICKS;
                if (logo_timed && (int32_t)(REG32(MTIME_LO) - logo_end) >= 0) logo_timed = 0;
                if (logo_timed) {
                    if (!logo_on) {          /* tilt left: XO4 logo */
                        logo_show();
                        logo_on = 1;
                    }
                } else if (spectrum_step(!(st & TTS_STATUS_BUSY)) || redraw || logo_on) {
                    matrix_show();           /* spectrum bars; all off (dark) when idle */
                    redraw  = 0;
                    logo_on = 0;
                }
            }
        }

        led_set(LED_SPEECH, (st & TTS_STATUS_BUSY) != 0u);
        heartbeat++;
        led_set(LED_HEARTBEAT, (heartbeat >> HEARTBEAT_SHIFT) & 1u);
        led_set(LED_SW2, 0u);
        leds_write();
    }
}
