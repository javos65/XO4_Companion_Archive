# Prompt: MachXO4 Companion - Text-to-Speech with FFT spectrum, accelerometer tilt phrases and XO4 logo

Use this prompt to recreate the MachXO4C_TTS_FFT demo with Claude Code and the Lattice Propel / Radiant MCP
tools. It records every decision of the original sessions, including the values that were tuned on the board.

---

## 1. Hardware

- **FPGA board:** Lattice MachXO4-110-HC Companion board, Rev A, device **LFMXO4-110HC-6BBG256I**
  (speed grade 6, BBG256). Banks 0 and 1 are 3.3 V. Bank 2 is 3.3 V with jumper **J20 on 2-3** (default;
  1-2 would select 1.2 V).
- **LED matrix:** Arduino **MKR RGB Shield** (84 x APA102, **7 rows x 12 columns**, chain row by row, left to right,
  index = row x 12 + column, row 0 = top) on the Arduino MKR header (J22/J23).
- **Speaker:** PWM audio to a small amplifier on Pmod pin 0 (H12); the same PWM also on Arduino ARD_AREF (R9).
- **Accelerometer:** on-board NXP **FXLS8971CF** (U5) in I2C mode, 4.7 k pull-ups on SCL/SDA.
  BT_MODE is pulled to VDD on the board (sensor boots in motion-detection mode; firmware reconfigures it).
- **USB:** FTDI FT2232H. Channel A = JTAG (cable USB2, port FTUSB-0), channel B = UART (COM port, e.g. COM13).

### Pin map (verified on hardware)

| Signal | Pin | Bank | Notes |
|---|---|---|---|
| clk12_i | T9 | 2 | 12 MHz board clock |
| sw2_n_i | D10 | 0 | SW2, active low; debounced (2^18 cycles) and combined with a power-on reset in tts_top.v |
| rxd_i / txd_o | B11 / A12 | 0 | FTDI channel B UART |
| pwm_o | H12 | 1 | Speaker PWM, Pmod pin 0 |
| pwm_aref_o | R9 | 2 | Same PWM on Arduino ARD_AREF |
| led_sdi_o / led_cki_o | D14 / D7 | 1 / 0 | MKR A3 = ARD_D18 -> LEDSDI, MKR A4 = ARD_D19 -> LEDCKI; DRIVE=8, SLEWRATE=FAST |
| dled_n_o[3:0] | G13, G15, E14, G14 | 1 | Board LEDs, active low |
| acc_scl_io / acc_sda_io | B13 / A14 | 0 | I2C, open drain, PULLMODE=NONE |
| acc_sa0_o | B7 | 0 | Driven 0 -> I2C address 0x18 |
| acc_cs_n_o | B12 | 0 | WAKEUP/CS_B driven 1 (I2C mode) |

All I/O LVCMOS33. Inputs PULLMODE=NONE.

---

## 2. Custom IP (all VLNV `custom:module:<name>:<version>`, packages named `<name>_<version>.ipk`)

Every custom APB block uses: **ID register at 0x00, control/status at 0x04**.

| IP | Instance | Base | Key facts |
|---|---|---|---|
| tts_apb 2.0.0 | tts0_inst | 0x8C00 | English text-to-speech, two 128-character line buffers, formant synthesizer at 16 kHz, 10-bit PWM (32 kHz carrier). PCLK (APB) and TTS_CLK 24 MHz. ID 0x54545302; CTRL START/CLEAR, STATUS BUSY/READY/DONE/PLAY/DROP, DATA. |
| pwm_fft 1.2.0 | fft0_inst | 0x9000 | Recovers the 16 kHz samples from the TTS PWM (WIN_CLKS 1500), 256-point FFT every 16 ms, 12 bands (50-500 Hz, then 11 log bands to 8 kHz). RAW[b] at 0x40 + 4b = 4 x log2(band power). STATUS[31:16] frame counter. ID 0x50464654. |
| mkr_rgb_spi 1.0.0 | mkr_rgb0_inst | 0x8800 | APA102 driver, NUM_LEDS 84, PIX[i] at 0x0C + 4i = 0xE0000000 \| bright[4:0]<<24 \| BBGGRR. CTRL bit0 START, bit1 READY. CKI = PCLK/2 = 6 MHz. ID 0x52474231. |
| fxls8971_i2c 1.0.0 | i2c0_inst | 0x9400 | Byte-level I2C master. PRESCALE_RESET **29** -> f_SCL = 12 MHz / (4 x 30) = **100 kHz**. Registers ID 0x49324331, PRESCALE, CMD (START/STOP/WRITE/READ/NACK), TXDATA, RXDATA, STATUS (BUSY/RXNACK/DONE/OWNED/SCL/SDA). |

---

## 3. Propel SoC (`soc/tts_soc/tts_soc/tts_soc.sbx`)

- **CPU:** riscv_sm 1.9.0 (cpu0_inst), no multiply extension (rv32i).
- **Memory:** system_memory 2.6.0 (sysmem0_inst), **8 KB** (2048 x 32), two AHBL ports, firmware initialised.
- **Bus:** ahb_lite_interconnect 1.5.0 -> ahb_lite_to_apb_bridge 1.2.0 -> apb_interconnect 1.4.0 with **6 slaves**.
- **PLL** 3.0.1: 12 MHz in -> **clkop 24 MHz** (TTS_CLK, FFT CORE_CLK), **clkos 12 MHz** (CPU, AHB, APB, all PCLK).
- **Reset:** glue rst_and = rstn_i AND PLL lock -> cpu0 rst_n_i; cpu0 system_resetn_o resets everything else.
- **TTS PWM_OUT** net drives fft0 PWM_IN and the top-level port pwm_o.

| APB port | Instance | Base | Notes |
|---|---|---|---|
| M00 | uart0_inst (uart 1.6.0) | 0x8000 | **19200** baud 8N1, IRQ to cpu0 |
| M01 | gpio0_inst (gpio 1.8.1) | 0x8400 | 5 lines: [3:0] LEDs out, [4] debounced SW2 in |
| M02 | tts0_inst | 0x8C00 | |
| M03 | mkr_rgb0_inst | 0x8800 | |
| M04 | fft0_inst | 0x9000 | |
| M05 | i2c0_inst | 0x9400 | |

Rules learned in the sessions:
- Addresses are assigned on the **APB interconnect port** (`apb0_inst/APB_M0x` -> slave), never from the CPU master.
- After reconfiguring apb0 (slave count) or replacing a block, **re-assign all base addresses**.
- New peripherals extend the existing nets `pll0_inst_clkos_o_net` and `cpu0_inst_system_resetn_o_net`.
- The user installs .ipk packages and edits the SoC in Propel unless they say "you install"; nothing is built or
  programmed without the user's go.

### Top level and constraints

- `rtl/tts_top.v`: SW2 synchroniser + debounce, power-on reset (2^18 cycles), tts_soc instance, LED1 driven by SW2 in
  hardware, PWM wire to both pwm_o and pwm_aref_o, acc_sa0_o = 0, acc_cs_n_o = 1.
- `constraints/tts_top.pdc`: the pin map above. `constraints/tts_timing.sdc`: 12 MHz input clock, generated clocks.
- `radiant/tts_top.rdf`: includes the .ipx of every instance (tts0 2.0.0, fft0 1.2.0, mkr_rgb0 1.0.0, i2c0 1.0.0, ...).

---

## 4. Firmware (`firmware/tts_fw`, RISC-V SM, direct register access, 8 KB)

Linker: memory 0x0000-0x1FFF, heap 0x100, stack 0x600. Image must fit in 8 KB including bss, heap and stack.
Compile with `-march=rv32i`. Two-pass build: compile -> bin2mem (Debug/tts_fw.mem) -> add_firmware_to_proj
(sysmem0_inst) -> check_memory_init_applied -> Radiant build.

### Behaviour

1. **Start-up:** UART `TTS OK.`; accelerometer init (WHO_AM_I 0x83, +/-2 g, low-power mode, 25 Hz, Active),
   UART `ACC ID 83 OK` (or `ACC NO I2C`, `ACC NO ACK`, `ACC ID xx BAD`, `ACC CFG ERR`).
   The **XO4 logo** (12 x 7 RGB565 table `xo4[]`: white X, teal O 0x3597, yellow 4 0xFEE0 on black;
   global brightness 8/31 = 25 %) is shown for **1 s**, then the start-up phrase
   `"Lattice? Mag X-O for is running!"` is spoken with the spectrum. Afterwards the matrix is **dark**.
2. **UART text:** every received character goes to the TTS block; a line (CR/LF or 128 characters) is spoken.
   Messages: `TTS EXE` at start, `TTS RDY` when finished. 19200 8N1.
3. **Spectrum while speaking:** 12 bars, band 1 left (red) to band 12 right (magenta).
   - Level from RAW: band width correction `band_adj = {2,0,0,1,1,2,3,3,4,5,6,6}`, power average of the last
     **4 frames** (64 ms, updated every 16 ms), level 1 at **FFT_FLOOR 26**, one level per **3.6** units (STEP5 18),
     7 levels.
   - Animation: every 2 ms each bar moves one LED towards its target.
   - Brightness: top LED of a bar **35 %** (global 11/31), LEDs below **1 %** (global 1/31, colour x 5/16).
4. **Tilt (FXLS8971, X/Y every 50 ms):** trigger above **30 degrees** (|a| > 512 of 1024 counts/g), strongest axis wins;
   re-armed only when both axes are within **5 degrees** of flat (89 counts). After reset the board must be flat once
   before the first trigger. Axis mapping (verified): forward = -Y, right = +X.

   | Tilt | Action | UART |
   |---|---|---|
   | Forward | "Xilinx is Shy-SU" | `TILT FWD` |
   | Left | XO4 logo for **2 s**, no phrase | `TILT LEFT` |
   | Right | "Downt wake me up!" | `TILT RIGHT` |
   | Backward | start-up phrase | `TILT BACK` |

   A phrase waits until the TTS block is idle and no UART line is half received.
5. **Jingle:** every 10 minutes when idle, two tone phrases (`#Hz,ms#` commands).
6. **LEDs:** LED0 heartbeat, LED1 SW2 (hardware), LED2 speech active, LED3 toggles per received character.
7. No raw FFT data on the UART (`SPEC_DEBUG 0`).

---

## 5. Build, check and program

- Propel generate + DRC must pass; firmware memory init confirmed (`check_memory_init_applied`).
- Radiant: timing met at all corners (`radiant_parse_timing`, `validate_timing`).
- Program internal flash: `radiant_program` with xcf `radiant/source/impl_1.xcf`, **bit_path
  `radiant/impl_1/tts_top_impl_1.jed`** (the xcf points to a wrong relative path), confirm, force.
  The tool reports "failed" even on success: the real result is `Operation: successful.` at the end of
  `%APPDATA%\LatticeSemi\DiamondNG\programmer.log`.
- Serial terminal: `tools/uart_monitor.ps1 -Port COM13 -LogFile tools/uart.log` (19200 8N1, auto-reconnect).

## 6. Expected results (final build, programmed and confirmed on the board)

- Timing met at all corners (setup 100 C and -40 C, hold -40 C, 0 failing endpoints):
  clkop 24 MHz target, Fmax 28.3 MHz; clkos 12 MHz target, Fmax 36.3 MHz. Constraint coverage 99.92 %
  (only asynchronous board I/O unconstrained).
- Resources: 8,065 LUT4 (86 %), 3,314 registers (33 %), 46 of 48 block RAMs, 1 of 2 PLLs, 20 I/O.
- Firmware: 7,704 of 8,192 bytes (text 5,432, data 32, bss + heap + stack 2,240); about 490 bytes free.
- Pad report: pwm_o H12 (Bank 1) and pwm_aref_o R9 (Bank 2), both LVCMOS33.
- UART after reset: `TTS OK.` / `ACC ID 83 OK`.
- Confirmed on the board: XO4 logo (black background, 25 %) for 1 s at start-up, start-up phrase with the spectrum,
  dark matrix when idle, typed text spoken with the spectrum, all four tilt directions (forward "Xilinx is Shy-SU",
  left logo 2 s, right "Downt wake me up!", backward start-up phrase).

## 7. Notes from the sessions

- The firmware memory is nearly full (8 KB system memory, 2 block RAMs left in the device); keep new features small.
- The board's USB link (both FTDI channels) dropped twice; a direct USB port is more stable. A serial terminal on the
  UART channel does not block JTAG programming.
- A full report with block diagrams is in `report/MachXO4C_TTS_FFT_report.docx` (reports are Word documents,
  prompts are Markdown).
