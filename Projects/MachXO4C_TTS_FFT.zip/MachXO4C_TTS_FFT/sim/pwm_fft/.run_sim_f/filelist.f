C:/lscc/workspace/MachXO4C_TTS_FFT/custom_ip/custom_module_pwm_fft_1.2.0/rtl/pwm_fft.v
C:/lscc/workspace/MachXO4C_TTS_FFT/custom_ip/custom_module_pwm_fft_1.2.0/testbench/tb_pwm_fft.v
