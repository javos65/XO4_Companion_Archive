# One external clock: 12 MHz on clk12_i (T9). The PLL in the SoC derives the
# 24 MHz CPU/AHB clock (clkop) and the 12 MHz APB clock (clkos); Radiant derives
# those PLL output clocks from this input clock.
create_clock -name {clk12} -period 83.333 [get_ports clk12_i]

# Slow asynchronous board signals: synchronised inside the IPs (I2C pins with a 2-FF
# synchroniser, UART RX, GPIO inputs), push-button reset. No I/O timing requirement.
set_false_path -from [get_ports {rstn_i uart_rxd_i acc_scl_io acc_sda_io led_io[*] acc_gpio_io[*]}]
set_false_path -to   [get_ports {uart_txd_o acc_scl_io acc_sda_io led_io[*] acc_gpio_io[*]}]
