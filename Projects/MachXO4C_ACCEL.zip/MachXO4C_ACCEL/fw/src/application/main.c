// MachXO4 Companion board: FXLS8971CF accelerometer -> RISC-V SM -> UART (Raspberry Pi header)
//
// Based on the Propel SDK "Hello World" template (embeddedsw/helloworld): the same
// bsp_init() structure, terminal (printf over uart0_inst), PIC init and LED GPIO.
// Added: the FXLS8971_I2C IP (fxls0_inst, custom:module:fxls8971_i2c) with its BSP drivers.
// Output: banner and sensor info, a 3 s pause, then 10 lines per second "x,y,z," in g
// (e.g. "0.012,-0.003,1.001,"); the sensor is read at 100 Hz.
//
// UART: 19200 8N1 on H15 (RX) / J12 (TX) = Raspberry Pi header pins 8 (TXD) / 10 (RXD).
// Clocks: 12 MHz board clock (T9) -> PLL: 24 MHz CPU/AHB, 12 MHz APB (UART, GPIO, FXLS8971_I2C).

#include "hal.h"
#include "utils.h"
#include <stdio.h>
#include "sys_platform.h"
#include <riscv_errors.h>
#include "platform_init.h"
#include "device_info.h"
#include "terminal.h"
#include "gpio.h"
#include "timer.h"
#include "i2c_master.h"
#include "fxls8971.h"

/* ------------------------------------------------------------------ board wiring */
/* gpio0_inst: LED1..LED4 */
#define LED_COUNT            4u
/* gpio1_inst: accelerometer side-band signals */
#define ACC_GPIO_INT1        0u    /* in : INT1 / MOT_DET (data-ready pulse in motion detection mode) */
#define ACC_GPIO_INT2        1u    /* in : INT2 / BOOT_OUT */
#define ACC_GPIO_SA0         2u    /* out: I2C address bit 0 */
#define ACC_GPIO_WAKEUP      3u    /* out: SPI_CS_B / WAKE_UP, keep high in I2C mode */

/* APB clock (PLL clkos): taken from the SGE, it is the clock the UART was configured for */
#define APB_CLK_HZ           ((uint32_t)(UART0_INST_SYS_CLK * 1000000.0))   /* 12 MHz */
/* CPU clock (PLL clkop, pll0_inst gui_clkop_freq): the machine timer counts at this rate.
 * The SGE has no CPU-frequency macro, so it is stated here; keep it equal to the PLL setting. */
#define CPU_CLK_HZ           24000000u
#define I2C_SCL_HZ           400000u
#define PRINT_PERIOD_MS      100u

static struct gpio_instance led_gpio_inst;
static struct gpio_instance acc_gpio_inst;
static struct i2c_master_instance i2c_inst;
static struct timer_instance mtimer_inst;
static struct fxls8971_instance accel;

/* ------------------------------------------------------------------ time base (machine timer, CPU clock) */
static uint32_t millis(void)
{
	unsigned long long t = 0;
	timer_get_mtime(&mtimer_inst, &t);
	return (uint32_t)(t / (CPU_CLK_HZ / 1000u));
}

static void delay_ms(uint32_t ms)
{
	uint32_t start = millis();
	while ((uint32_t)(millis() - start) < ms) {
	}
}

/* prints a milli-g value as a g value with 3 decimals followed by a comma, e.g. "-0.012,"
 * (printf is built without float support, so the value is formatted from integers) */
static void print_g_csv(int32_t mg)
{
	uint32_t a = (uint32_t)((mg < 0) ? -mg : mg);
	printf("%s%lu.%03lu,", (mg < 0) ? "-" : "", (unsigned long)(a / 1000u), (unsigned long)(a % 1000u));
}

/* ------------------------------------------------------------------ init */
static int bsp_init(void)
{
	int ret;

	ret = terminal_init(IRQ_BAREMETAL_DEFAULT);

#if CPU_INST_0_PIC_ENABLE
	pic_init(CPU_INST_0_PICTIMER_START_ADDR);
#endif
	timer_init(&mtimer_inst, CPU_INST_0_PICTIMER_START_ADDR, CPU_CLK_HZ);

	/* LEDs */
	led_gpio_inst.instance_name = GPIO0_INST_NAME;
	gpio_init(&led_gpio_inst, GPIO0_INST_BASE_ADDR, GPIO0_INST_LINES_NUM, GPIO0_INST_GPIO_DIRS);

	/* accelerometer side-band: SA0 = 0 (address 0x18), WAKE_UP = 1 */
	acc_gpio_inst.instance_name = GPIO1_INST_NAME;
	gpio_init(&acc_gpio_inst, GPIO1_INST_BASE_ADDR, GPIO1_INST_LINES_NUM, GPIO1_INST_GPIO_DIRS);
	gpio_output_write(&acc_gpio_inst, ACC_GPIO_SA0, 0u);
	gpio_output_write(&acc_gpio_inst, ACC_GPIO_WAKEUP, 1u);

	/* FXLS8971_I2C block: soft I2C controller */
	i2c_inst.instance_name = FXLS0_INST_NAME;
	if (I2C_MASTER_OK != i2c_master_init(&i2c_inst, FXLS0_INST_BASE_ADDR)) {
		printf("ERROR: FXLS8971_I2C block not found at 0x%08lx\n", (unsigned long)FXLS0_INST_BASE_ADDR);
		return -1;
	}
	return ret;
}

static void leds(uint8_t pattern)
{
	uint32_t i;
	for (i = 0; i < LED_COUNT; i++) {
		gpio_output_write(&led_gpio_inst, i, (pattern >> i) & 1u);
	}
}

/* ------------------------------------------------------------------ main */
int main(void)
{
	struct fxls8971_data d = {0, 0, 0};
	uint32_t scl, last_print;
	int ret;
	uint8_t led = 1;

	bsp_init();

	printf(DEVICE_INFO);
	printf("MachXO4 Companion: FXLS8971CF accelerometer over soft I2C (%s @ 0x%08lx)\n",
	       FXLS0_INST_NAME, (unsigned long)FXLS0_INST_BASE_ADDR);

	scl = i2c_master_set_speed(&i2c_inst, APB_CLK_HZ, I2C_SCL_HZ);
	printf("Clocks: CPU %lu Hz, APB %lu Hz; I2C SCL %lu Hz; UART %u baud\n",
	       (unsigned long)CPU_CLK_HZ, (unsigned long)APB_CLK_HZ, (unsigned long)scl, (unsigned)UART0_INST_BAUD_RATE);

	/* the sensor needs up to TBOOT2 = 17.7 ms after power-up in motion detection mode */
	delay_ms(20);

	while (1) {
		if (I2C_MASTER_OK != i2c_master_probe(&i2c_inst, FXLS8971_ADDR_SA0_LOW)) {
			printf("FXLS8971: no ACK at address 0x%02x, retrying...\n", FXLS8971_ADDR_SA0_LOW);
			leds(0x9);
			delay_ms(1000);
			continue;
		}
		ret = fxls8971_init(&accel, &i2c_inst, FXLS8971_ADDR_SA0_LOW, FXLS8971_RANGE_2G, FXLS8971_ODR_100HZ);
		if (FXLS8971_OK == ret) {
			break;
		}
		printf("FXLS8971: init failed (code %d), retrying...\n", ret);
		leds(0x6);
		delay_ms(1000);
	}
	printf("FXLS8971: WHO_AM_I 0x%02x, PROD_REV %u.%u, range +/-2 g, ODR 100 Hz\n",
	       FXLS8971_WHO_AM_I_VALUE, (unsigned)(accel.prod_rev >> 4), (unsigned)(accel.prod_rev & 0x0Fu));
	/* pause before the data stream starts */
	delay_ms(3000);

	/* data stream: one line per sample period, "x,y,z," in g, 3 decimals */
	last_print = millis();
	while (1) {
		ret = fxls8971_data_ready(&accel);
		if (ret > 0) {
			(void)fxls8971_read_xyz(&accel, &d);   /* on an I2C error the previous sample is kept */
		}

		if ((uint32_t)(millis() - last_print) >= PRINT_PERIOD_MS) {
			last_print += PRINT_PERIOD_MS;

			print_g_csv(fxls8971_to_mg(&accel, d.x));
			print_g_csv(fxls8971_to_mg(&accel, d.y));
			print_g_csv(fxls8971_to_mg(&accel, d.z));
			printf("\n");

			leds(led);                       /* running light: alive indicator */
			led = (uint8_t)((led << 1) | (led >> 3)) & 0x0Fu;
		}
	}

	return 0;
}
