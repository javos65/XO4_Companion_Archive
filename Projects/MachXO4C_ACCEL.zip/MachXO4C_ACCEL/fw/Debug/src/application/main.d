src/application/main.o: ../src/application/main.c \
 ../src/bsp/driver/riscv_sm/hal.h ../src/bsp/driver/riscv_sm/pic.h \
 ../src/bsp/driver/riscv_sm/util.h ../src/bsp/driver/riscv_sm/stack.h \
 ../src/bsp/driver/riscv_sm/reg_access.h ../src/bsp/driver/riscv_sm/iob.h \
 ../src/application/utils.h ../src/bsp/sys_platform.h \
 ../src/bsp/riscv_errors.h ../src/application/platform_init.h \
 ../src/application/device_info.h ../src/application/terminal.h \
 ../src/bsp/driver/uart/uart.h ../src/bsp/driver/gpio/gpio.h \
 ../src/bsp/driver/riscv_sm/timer.h \
 ../src/bsp/driver/fxls8971_i2c/i2c_master.h \
 ../src/bsp/driver/fxls8971_i2c/i2c_master_regs.h \
 ../src/bsp/driver/fxls8971_i2c/fxls8971.h \
 ../src/bsp/driver/fxls8971_i2c/i2c_master.h
../src/bsp/driver/riscv_sm/hal.h:
../src/bsp/driver/riscv_sm/pic.h:
../src/bsp/driver/riscv_sm/util.h:
../src/bsp/driver/riscv_sm/stack.h:
../src/bsp/driver/riscv_sm/reg_access.h:
../src/bsp/driver/riscv_sm/iob.h:
../src/application/utils.h:
../src/bsp/sys_platform.h:
../src/bsp/riscv_errors.h:
../src/application/platform_init.h:
../src/application/device_info.h:
../src/application/terminal.h:
../src/bsp/driver/uart/uart.h:
../src/bsp/driver/gpio/gpio.h:
../src/bsp/driver/riscv_sm/timer.h:
../src/bsp/driver/fxls8971_i2c/i2c_master.h:
../src/bsp/driver/fxls8971_i2c/i2c_master_regs.h:
../src/bsp/driver/fxls8971_i2c/fxls8971.h:
../src/bsp/driver/fxls8971_i2c/i2c_master.h:
