# Project prompt: MachXO4 Companion board, RISC-V SM SoC with FXLS8971 accelerometer

Use the MachXO4 Companion evaluation board (LFMXO4-110HC-6BBG256I). The `doc/` folder holds the
schematic (`LFMXO4-110-COMPANION REVA_08172026_1815.pdf`), the IO mapping spreadsheet
(`XO4_Companion_Mapping.xlsx`) and the FXLS8971CF datasheet (`DS_fxls8971cf.pdf`).

Build a Propel SoC with a RISC-V SM CPU that reads the on-board NXP FXLS8971CF accelerometer over a
custom APB I2C controller and streams the X/Y/Z values over the FTDI USB-UART. Add a Python script
that shows the values as a live 3D vector.

## 1. Board connections

| Signal | FPGA pin | Notes |
|---|---|---|
| Clock 12 MHz (F_12MHz) | T9 | PCLKT2_1, from the FTDI crystal, jumper JP2 closed |
| Reset (push button PB1, SW2) | D10 | active low |
| UART RX (FPGA input) | B11 | net F_UART_TX = FTDI TX, FTDI channel B, jumpers J2/J3 set to UART |
| UART TX (FPGA output) | A12 | net F_UART_RX = FTDI RX |
| ACC_SCL / ACC_SDA | B13 / A14 | 4.7k pull-ups on the board, open drain |
| ACC_INT1 / ACC_INT2 | A11 / C11 | inputs, 4.7k pull-ups on the board |
| ACC_SA0 | B7 | drive 0, which gives I2C address 0x18 |
| ACC_WAKEUP (SPI_CS_B) | B12 | drive 1 |
| ACC_BT_MODE | A10 | not used; the board pull-up sets BT_MODE = VDD at power-up |
| LED1..LED4 | G14, E14, G15, G13 | active high |

- The UART net names are from the FTDI side, so FTDI TX goes to FPGA RX and FTDI RX to FPGA TX.
- Banks 0, 1 and 2 are 3.3 V: use LVCMOS33 on every pin.
- The accelerometer pins are hard-wired to fabric I/O, so the hardened EFB I2C cannot be used.

## 2. Custom IP: `custom:module:fxls8971_i2c:1.0.0`

Create the IP directly in `C:\Users\<name>\PropelIPLocal\custom_module_fxls8971_i2c_1.0.0`.

- **Function:** APB slave with a single-master soft I2C controller, written in Verilog, for the
  FXLS8971CF. It has one clock (PCLK) and open-drain I2C_SCL and I2C_SDA inout pins.
- **Engine:** byte-level commands (optional START or repeated START, one byte WRITE or READ with
  ACK/NACK, optional STOP). Support SCL clock stretching. Change SDA only a quarter period after
  SCL falls, never on the SCL edge itself.
- **Speed:** f_SCL = f_PCLK / (4 * (PRESCALE + 1)). Parameter PRESCALE_RESET sets the value after reset.
- **Registers:**

| Offset | Name | Content |
|---|---|---|
| 0x00 | ID | 0x49324331 |
| 0x04 | PRESCALE | bits 15..0 |
| 0x08 | CMD | bit0 START, bit1 STOP, bit2 WRITE, bit3 READ, bit4 NACK |
| 0x0C | TXDATA | byte to send |
| 0x10 | RXDATA | byte received |
| 0x14 | STATUS | bit0 BUSY, bit1 RXNACK, bit2 DONE, bit3 OWNED, bit4 SCL, bit5 SDA |

- **Package contents:** `metadata.xml` (custom-IP schema, both platforms, LFMXO4 support),
  `bus_interface.xml` (APB_S0), `memory_map.xml`, `rtl/`, `testbench/` and `doc/introduction.html`.
- **BSP driver (`driver/`):** must be part of the package, so Propel copies it into the BSP of
  every SoC that uses the IP.
  - `i2c_master.c/.h` and `i2c_master_regs.h`: init, set_speed, status, write, read, write_reg,
    read_reg, probe. Every wait has a timeout.
  - `fxls8971.c/.h`: init (WHO_AM_I = 0x83, Standby, low-power mode, range, data rate, Active),
    read_reg, write_reg, set_active, data_ready, read_xyz (12-bit two's complement), read_temp,
    to_mg.
  - `fxls8971_i2c.xml`: driver binding for the SGE.
- **Boot-mode note:** with BT_MODE = VDD the sensor boots in motion-detection mode at 0.78 Hz. The
  driver must switch it to Standby, set the data rate and range (low-power mode only), and make it
  Active again.
- **Documentation:** `introduction.html` describes the IP, its ports, the registers and every library
  function, with an example.
- **Packaging:** build a `.ipk` (zip of the files above) and an `.ippackagerproject`.
- **Verification:** verify the RTL with a self-checking testbench and an FXLS8971-like I2C target
  model (register pointer, auto-increment, WHO_AM_I, clock stretching, NACK on a wrong address).

## 3. Propel SoC (scratch build replicating the "General State Machine (RISC-V SM)" template)

- **Clocks:** 12 MHz on T9 feeds `pll` 3.0.1 (frequency mode, tolerance 0, lock port on):
  - clkop = 24 MHz for the CPU, AHB-Lite, system memory and the AHB side of the bridge
  - clkos = 12 MHz for the APB bus, UART, GPIO and FXLS8971_I2C
- **Reset:** cpu0 `rst_n_i` = `rstn_i AND pll lock` (equation glue logic). Distribute
  `cpu0/system_resetn_o` to all peripherals.
- **Blocks:**
  - `cpu0`: riscv_sm 1.9.0, DEBUG_ENABLE = false, PIC and timer on, IRQ_NUM = 3
  - `system0`: system_memory, 32 KB, AHB-Lite, 2 ports
  - `ahbl0` (1 master, 2 slaves), `ahbl2apb0` (APB_CLK_EN = true), `apb0` (1 master, 4 slaves)
  - `uart0`: 12 MHz, 19200 baud, 8N1
  - `gpio0`: 4 lines, outputs, LEDs
  - `gpio1`: 4 lines; [0] INT1 in, [1] INT2 in, [2] SA0 out = 0, [3] WAKEUP out = 1
  - `fxls0`: fxls8971_i2c, PRESCALE_RESET = 29 (100 kHz at 12 MHz)
- **Address map:**

| Block | Address |
|---|---|
| system0 | 0x00000000 |
| uart0 | 0x40000000 |
| gpio0 | 0x40001000 |
| gpio1 | 0x40002000 |
| fxls0 | 0x40003000 |

- **Interrupts:** uart0 on IRQ0, gpio0 on IRQ1, gpio1 on IRQ2.
- **Constraints:** a PDC with all pins from section 1, and an SDC with a 12 MHz clock on `clk12_i`
  (Radiant derives the PLL clocks) plus false paths on the slow asynchronous I/O.
- **Gates:** Propel DRC clean, Radiant timing met in all corners, 100% constraint coverage.

## 4. Firmware (Propel SDK project based on the "Hello World" template)

- **Startup:** print the device info block (processor, PIC, MTIMER, LED, terminal), then:
  - `MachXO4 Companion: FXLS8971CF accelerometer over soft I2C (fxls0_inst @ 0x40003000)`
  - `Clocks: CPU 24000000 Hz, APB 12000000 Hz; I2C SCL <n> Hz; UART 19200 baud`
  - `FXLS8971: WHO_AM_I 0x83, PROD_REV x.y, range +/-2 g, ODR 100 Hz`
- **Pause:** wait 3 seconds.
- **Data stream:** read the sensor at 100 Hz and print 10 lines per second with only the values in g,
  3 decimals, comma separated, with a comma after Z as well, for example `0.012,-0.003,1.001,`.
- **LEDs:** a running light as an alive indicator.
- **Timing:** use the machine timer (24 MHz CPU clock) for delays. Use the 12 MHz APB clock for the
  I2C speed: 400 kHz requested, which gives 375 kHz because the divider rounds so the bus is never
  faster than asked.
- **Build:** compile with `-march=rv32i`, because the RISC-V SM has no M extension. Route stdio to
  the UART (LSCC_STDIO_UART_APB). Load the image into system memory (two-pass build).

## 5. Programming

- **SRAM test:** `pgrcmd.exe -infile` with a chain file using operation "Fast Configuration".
- **Persistent:** internal flash with "Erase,Program,Verify" of the `.jed`.
- **Success check:** the log must contain "Operation: successful."

## 6. Python viewer (`scripts/accel_vector3d.py`)

- **Input:** read the "x,y,z," lines from the serial port (default 19200 baud, e.g. COM13) and
  ignore every other line.
- **3D view:** the acceleration vector as an arrow from the origin, its projections on the XY, XZ
  and YZ planes, and a trail of the last tip positions.
- **Text panel:** X, Y, Z, |a|, roll, pitch and the line rate.
- **Options:** `--port`, `--baud`, `--list`, `--demo` (simulated data), `--range`, `--trail`,
  `--echo`.
- **Requirements:** pyserial, matplotlib, numpy. Install with
  `python -m pip install --user pyserial matplotlib`.
