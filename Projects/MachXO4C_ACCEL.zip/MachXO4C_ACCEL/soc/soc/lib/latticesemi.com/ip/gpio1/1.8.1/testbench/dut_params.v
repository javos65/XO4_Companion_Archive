localparam FAMILY = "LFMXO4";
localparam IO_LINES_COUNT = 4;
localparam EXTERNAL_BUF = 0;
localparam OUT_RESET_VAL = "32'h00000008";
localparam DIRECTION_DEF_VAL = "32'h0000000C";
localparam IF_USER_INTF = "APB";
`define xo4f00
`define LFMXO4
`define LFMXO4_110HC
