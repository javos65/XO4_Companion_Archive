prj_open {C:/lscc/workspace/MachXO4C_ACCEL/soc/soc.rdf}
prj_add_source {C:/lscc/workspace/MachXO4C_ACCEL/constraints/soc_timing.sdc}
prj_add_source {C:/lscc/workspace/MachXO4C_ACCEL/constraints/xo4_companion_accel.pdc}
prj_save
prj_close
