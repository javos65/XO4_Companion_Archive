# PGE DGE script for soc
# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}
::ip_catalog::ip_catalog_location -add {C:\lscc\propel\2026.1.1\builder\rtf\ip}

sbp_design open -name {soc} -path {C:/lscc/workspace/MachXO4C_ACCEL/soc/soc/soc.sbx}
sbp_design save
sbp_design generate
sbp_design save
set _sbxAbs [file normalize {C:/lscc/workspace/MachXO4C_ACCEL/soc/soc/soc.sbx}]
set _dgeAbs [file normalize {C:/lscc/workspace/MachXO4C_ACCEL/soc}]
sbp_design pge dge -i $_sbxAbs -o $_dgeAbs -radiant
puts "DGE completed: soc"
exit