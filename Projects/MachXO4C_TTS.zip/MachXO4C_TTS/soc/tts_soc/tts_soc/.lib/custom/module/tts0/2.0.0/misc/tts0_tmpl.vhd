component tts0 is
    port(
        PCLK: in std_logic;
        TTS_CLK: in std_logic;
        RST_N: in std_logic;
        PADDR: in std_logic_vector(3 downto 0);
        PSEL: in std_logic;
        PENABLE: in std_logic;
        PWRITE: in std_logic;
        PWDATA: in std_logic_vector(31 downto 0);
        PRDATA: out std_logic_vector(31 downto 0);
        PREADY: out std_logic;
        PSLVERR: out std_logic;
        PWM_OUT: out std_logic
    );
end component;

__: tts0 port map(
    PCLK=>,
    TTS_CLK=>,
    RST_N=>,
    PADDR=>,
    PSEL=>,
    PENABLE=>,
    PWRITE=>,
    PWDATA=>,
    PRDATA=>,
    PREADY=>,
    PSLVERR=>,
    PWM_OUT=>
);
