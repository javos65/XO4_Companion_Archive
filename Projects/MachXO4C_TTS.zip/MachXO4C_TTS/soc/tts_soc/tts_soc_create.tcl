# Propel design script: tts_soc
# Session: 02c60977-3b01-47a4-8ff2-f63722d4507f
# Mode: open

sbp_design open -name {tts_soc} -path {C:/lscc/workspace/MachXO4C_TTS/soc/tts_soc/tts_soc/tts_soc.sbx}

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}
::ip_catalog::ip_catalog_location -add {C:\lscc\propel\2026.1.1\builder\rtf\ip}

sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4C_TTS\firmware\tts_fw\Debug\tts_fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:4096,BYTE_ENABLE_S0:True,BYTE_ENABLE_S1:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,EDIT_ADDRESS_S0:False,EDIT_ADDRESS_S1:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:2,REGMODE_S0:False,REGMODE_S1:False,RESET_MODE_S0:sync,RESET_MODE_S1:sync}
sbp_replace -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst} -component {tts_soc/sysmem0_inst}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: tts_soc"