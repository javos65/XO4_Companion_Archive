# Runs the TTS_APB 2.0.0 simulations in Questa (batch). Usage: .\run_sim.ps1 [-Tb tb_tts_eq|tb_tts_apb2] [-PclkHalf 41.6667]
param([string]$Tb = 'tb_tts_eq', [string]$PclkHalf = '41.6667')
$q    = 'C:\lscc\radiant\2026.1.1\questasim\win64'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ip   = Join-Path $here '..\..\ip\custom_module_tts_apb_2.0.0\rtl'
$work = "work_${Tb}_$($PclkHalf -replace '\.','p')"     # relative to $here (Questa rejects a full path as a library name)
Push-Location $here
if (Test-Path $work) { Remove-Item -Recurse -Force $work }
& "$q\vlib.exe" $work | Out-Null
$src = @("$ip\tts_apb.v", "$ip\ttscpu.v", "$ip\tts_roms.v", "$ip\tts_engine.v", "$ip\line_buf.v", "$ip\sample_fifo.v", "$ip\pwm10.v",
         "$here\tts_apb_v15.v", "$here\$Tb.v")
& "$q\vlog.exe" -quiet -work $work "+define+PCLK_HALF=$PclkHalf" $src
if ($LASTEXITCODE -ne 0) { Pop-Location; throw "vlog failed" }
& "$q\vsim.exe" -c -quiet "$work.$Tb" -do "run -all; quit -f"
Pop-Location
