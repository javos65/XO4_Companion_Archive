// TTS block as an APB slave: the speech engine of the project MachXO4_TTS (release v0.29) behind a small register file.
// The host (the RISC-V) only moves text and commands; it never touches the synthesizer.
//
//  Register map (word addresses, PADDR[3:2]):
//   0x00 ID      read     0x54545301
//   0x04 CTRL    write    bit0 START  speak the oldest complete line (ignored unless LINE_READY and not BUSY)
//                         bit1 CLEAR  discard all queued lines and any partial line (ignored while BUSY)
//   0x08 STATUS  read     bit0  BUSY        a line is being spoken (from START until the fade-out has finished)
//                         bit1  LINE_READY  a complete line is waiting
//                         bit2  DONE        sticky, set when a speech has finished, cleared by START or CLEAR
//                         bit3  PLAY        PWM output is active (speech or fade)
//                         bit4  DROP        sticky, set when the last START was refused, cleared by START or CLEAR
//                         bits 15..8 LEN    length of the oldest complete line, 1..128 (0 when none)
//   0x0C DATA    write    bits 7..0 one received character; the line buffer stores printable ASCII, a CR or LF ends the line,
//                         a line of 128 characters ends itself, a tone command #Hz,ms# is checked as in release v0.29
//                read     the character written last
//  A line is freed automatically when its speech has finished. Two lines can be queued; a third is dropped as a whole.
//
// The block has one output: PWM (10-bit samples at 16 kHz, 32 kHz carrier from 24 MHz, held low when idle).
module tts_apb_slave_v15 #(
    parameter PWM_PERIOD = 750,     // 24 MHz / 750 = 32 kHz carrier
    parameter PWM_REPEAT = 2        // two PWM periods per 16 kHz audio sample
) (
    input  wire        PCLK,        // 24 MHz
    input  wire        RST_N,
    input  wire [3:0]  PADDR,
    input  wire        PSEL,
    input  wire        PENABLE,
    input  wire        PWRITE,
    input  wire [31:0] PWDATA,
    output reg  [31:0] PRDATA,
    output wire        PREADY,
    output wire        PSLVERR,
    output wire        PWM_OUT
);
    wire rst = ~RST_N;

    assign PREADY  = 1'b1;          // no wait states: a transfer takes two clocks (setup, access)
    assign PSLVERR = 1'b0;

    wire wr = PSEL & PENABLE & PWRITE;

    // ---- registers --------------------------------------------------------------------------------
    reg  [7:0] last_data;
    reg        busy, done_flag, drop_flag;
    reg        ch_valid;            // one-clock pulse: a character is written to the line buffer
    reg        tts_start, buf_clear;
    wire       tts_done;
    wire       line_ready;
    wire [7:0] len;

    wire wr_ctrl = wr && (PADDR[3:2] == 2'd1);
    wire wr_data = wr && (PADDR[3:2] == 2'd3);
    wire do_start = wr_ctrl && PWDATA[0];
    wire do_clear = wr_ctrl && PWDATA[1];

    always @(posedge PCLK) begin
        ch_valid  <= 1'b0;
        tts_start <= 1'b0;
        buf_clear <= 1'b0;
        if (rst) begin
            busy      <= 1'b0;
            done_flag <= 1'b0;
            drop_flag <= 1'b0;
            last_data <= 8'd0;
        end else begin
            if (wr_data) begin
                last_data <= PWDATA[7:0];
                ch_valid  <= 1'b1;
            end
            if (do_start) begin
                done_flag <= 1'b0;
                drop_flag <= 1'b0;
                if (line_ready && !busy) begin
                    busy      <= 1'b1;
                    tts_start <= 1'b1;
                end else begin
                    drop_flag <= 1'b1;
                end
            end
            if (do_clear && !busy) begin
                buf_clear <= 1'b1;
                done_flag <= 1'b0;
                drop_flag <= 1'b0;
            end
            if (tts_done) begin
                busy      <= 1'b0;
                done_flag <= 1'b1;
            end
        end
    end

    // ---- reused project blocks ----------------------------------------------------------------------
    wire [6:0]  lb_addr;
    wire [7:0]  lb_data;
    wire [19:0] sample;
    wire        sample_tick, tts_play, pwm_raw;
    wire [7:0]  tts_fade;

    line_buf u_buf (
        .clk(PCLK), .rst(rst), .rx_data(last_data), .rx_valid(ch_valid),   // last_data and ch_valid are set by the same clock edge
        .consume(tts_done), .clear(buf_clear), .rd_addr(lb_addr), .rd_data(lb_data),
        .len(len), .line_ready(line_ready));

    tts_engine u_tts (
        .clk(PCLK), .rst(rst), .start(tts_start), .done(tts_done),
        .lb_addr(lb_addr), .lb_data(lb_data), .lb_len(len),
        .tick(sample_tick), .sample(sample), .play(tts_play), .fade(tts_fade));

    pwm10 #(.PERIOD(PWM_PERIOD), .REPEAT(PWM_REPEAT)) u_pwm (
        .clk(PCLK), .rst(rst), .sample_in(sample), .fade(tts_fade),
        .sample_tick(sample_tick), .pwm_out(pwm_raw));

    assign PWM_OUT = pwm_raw & tts_play;     // muted unless speech or its fades are played

    // ---- read side ------------------------------------------------------------------------------------
    always @(*) begin
        case (PADDR[3:2])
            2'd0:    PRDATA = 32'h54545301;
            2'd1:    PRDATA = 32'h0;
            2'd2:    PRDATA = {16'd0, (line_ready ? len : 8'd0), 3'd0, drop_flag, tts_play, done_flag, line_ready, busy};
            default: PRDATA = {24'd0, last_data};
        endcase
    end
endmodule
