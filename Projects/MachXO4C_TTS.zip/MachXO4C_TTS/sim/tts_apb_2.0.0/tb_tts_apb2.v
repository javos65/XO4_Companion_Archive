`timescale 1ns/1ps
// Register level test of the TTS block (tts_apb_slave): an APB master writes characters and commands and reads the status.
// Mirrors the system test tb_top.v of the original design: line, queued line, dropped third line, 128 character limit,
// empty lines, CR LF, tone commands, unterminated command, mute at idle, reset during speech.
// TTS_APB 2.0.0 version: PCLK and TTS_CLK are independent; the APB tasks honour PREADY wait states.
// PCLK period is set with +define+PCLK_HALF=<ns> (default 41.6667 ns = 12 MHz); TTS_CLK is 24 MHz.
`ifndef PCLK_HALF
`define PCLK_HALF 41.6667
`endif
module tb_tts_apb2;
    reg         PCLK = 1'b0;
    reg         TTS_CLK = 1'b0;
    reg         RST_N = 1'b0;
    reg  [3:0]  PADDR = 4'h0;
    reg         PSEL = 1'b0, PENABLE = 1'b0, PWRITE = 1'b0;
    reg  [31:0] PWDATA = 32'd0;
    wire [31:0] PRDATA;
    wire        PREADY, PSLVERR, PWM_OUT;
    integer     errors = 0;

    always #`PCLK_HALF PCLK = ~PCLK;        // APB clock
    always #20.8333 TTS_CLK = ~TTS_CLK;     // 24 MHz synthesizer clock

    tts_apb_slave dut (.PCLK(PCLK), .TTS_CLK(TTS_CLK), .RST_N(RST_N), .PADDR(PADDR), .PSEL(PSEL), .PENABLE(PENABLE), .PWRITE(PWRITE),
                       .PWDATA(PWDATA), .PRDATA(PRDATA), .PREADY(PREADY), .PSLVERR(PSLVERR), .PWM_OUT(PWM_OUT));

    // ---- APB master ---------------------------------------------------------------------------------
    task apb_write;
        input [3:0]  a;
        input [31:0] d;
        begin
            @(posedge PCLK); #1;
            PADDR = a; PWDATA = d; PWRITE = 1'b1; PSEL = 1'b1; PENABLE = 1'b0;
            @(posedge PCLK); #1;
            PENABLE = 1'b1;
            @(posedge PCLK);
            while (!PREADY) @(posedge PCLK);  // wait states
            #1;
            PSEL = 1'b0; PENABLE = 1'b0; PWRITE = 1'b0;
        end
    endtask

    reg [31:0] rdata;
    task apb_read;
        input [3:0] a;
        begin
            @(posedge PCLK); #1;
            PADDR = a; PWRITE = 1'b0; PSEL = 1'b1; PENABLE = 1'b0;
            @(posedge PCLK); #1;
            PENABLE = 1'b1;
            @(posedge PCLK);
            while (!PREADY) @(posedge PCLK);  // wait states
            rdata = PRDATA;                  // sampled at the end of the access phase
            #1;
            PSEL = 1'b0; PENABLE = 1'b0;
        end
    endtask

    localparam [3:0] R_ID = 4'h0, R_CTRL = 4'h4, R_STAT = 4'h8, R_DATA = 4'hC;
    localparam B_BUSY = 0, B_READY = 1, B_DONE = 2, B_PLAY = 3, B_DROP = 4;

    task put_char;  input [7:0] c;  begin apb_write(R_DATA, {24'd0, c}); end endtask
    task put_str;
        input [8*128-1:0] s;
        input integer n;
        integer i;
        begin for (i = n-1; i >= 0; i = i - 1) put_char(s[8*i +: 8]); end
    endtask
    task cmd_start;  begin apb_write(R_CTRL, 32'd1); end endtask
    task cmd_clear;  begin apb_write(R_CTRL, 32'd2); end endtask

    task wait_idle;                          // poll STATUS until BUSY is low
        integer n;
        begin
            n = 0;
            apb_read(R_STAT);
            while (rdata[B_BUSY] && n < 2000000) begin
                repeat (200) @(posedge PCLK);
                apb_read(R_STAT);
                n = n + 1;
            end
            if (rdata[B_BUSY]) begin $display("FAIL: BUSY never cleared"); errors = errors + 1; end
        end
    endtask

    task check;
        input cond;
        input [8*60-1:0] what;
        begin
            if (!cond) begin $display("FAIL: %0s", what); errors = errors + 1; end
            else       $display("ok   %0s", what);
        end
    endtask

    integer pwm_edges = 0, mark, k;
    always @(posedge PWM_OUT) pwm_edges = pwm_edges + 1;

    initial begin
        repeat (8) @(posedge PCLK);
        RST_N = 1'b1;
        repeat (8) @(posedge PCLK);

        $display("test 0: ID and reset state");
        apb_read(R_ID);   check(rdata == 32'h54545302, "ID register");
        apb_read(R_STAT); check(rdata == 32'd0, "STATUS is zero after reset");

        $display("test 1: one line");
        put_str("HI", 2); put_char(8'h0D);
        apb_read(R_STAT);
        check(rdata[B_READY] && rdata[15:8] == 8'd2 && !rdata[B_BUSY], "line ready, length 2");
        mark = pwm_edges;
        cmd_start;
        apb_read(R_STAT); check(rdata[B_BUSY], "BUSY after START");
        wait_idle;
        apb_read(R_STAT);
        check(rdata[B_DONE] && !rdata[B_BUSY] && !rdata[B_READY], "DONE set, line freed");
        check(pwm_edges - mark > 1000, "PWM active during speech");
        mark = pwm_edges; repeat (60000) @(posedge PCLK);
        check(pwm_edges == mark, "PWM muted after the speech");
        cmd_start;                           // nothing to speak
        apb_read(R_STAT); check(rdata[B_DROP] && !rdata[B_BUSY], "START without a line is refused (DROP)");

        $display("test 2: second line queued while speaking, third dropped");
        put_str("HI", 2); put_char(8'h0D);
        cmd_start;
        put_str("YO", 2); put_char(8'h0D);    // second bank
        put_str("NO", 2); put_char(8'h0D);    // both banks occupied: dropped as a whole
        wait_idle;
        apb_read(R_STAT); check(rdata[B_READY] && rdata[15:8] == 8'd2, "queued line is ready");
        cmd_start; wait_idle;
        apb_read(R_STAT); check(!rdata[B_READY] && rdata[B_DONE], "third line was dropped");

        $display("test 3: 128 characters without terminator");
        for (k = 0; k < 127; k = k + 1) put_char(8'h20);
        put_char("A");
        apb_read(R_STAT); check(rdata[B_READY] && rdata[15:8] == 8'd128, "128 character line complete, length 128");
        cmd_start; wait_idle;

        $display("test 3b: 132 characters: line ends at 128, the rest is a second line");
        for (k = 0; k < 127; k = k + 1) put_char(8'h20);
        put_char("B");
        put_str("XYZW", 4); put_char(8'h0D);
        apb_read(R_STAT); check(rdata[B_READY] && rdata[15:8] == 8'd128, "oldest line has 128 characters");
        cmd_start; wait_idle;
        apb_read(R_STAT); check(rdata[B_READY] && rdata[15:8] == 8'd4, "the remaining 4 characters are the queued second line");
        cmd_start; wait_idle;

        $display("test 3c: a long sentence of 128 characters is spoken");
        mark = pwm_edges;
        put_str("The quick brown fox jumps over the lazy dog, and the five boxing wizards jump quickly. How razorback jumping frogs can level six", 128); put_char(8'h0D);
        apb_read(R_STAT); check(rdata[B_READY] && rdata[15:8] == 8'd128, "sentence stored, length 128");
        cmd_start; wait_idle;
        apb_read(R_STAT); check(rdata[B_DONE] && !rdata[B_BUSY] && !rdata[B_READY], "long sentence finished");
        check(pwm_edges - mark > 100000, "PWM active during the long sentence");
        $display("test 4: empty lines and CR LF");
        put_char(8'h0D); put_char(8'h0A); put_char(8'h0D);
        apb_read(R_STAT); check(!rdata[B_READY], "empty lines ignored");
        put_str("LATE", 4); put_char(8'h0D); put_char(8'h0A);
        cmd_start; wait_idle;
        apb_read(R_STAT); check(!rdata[B_READY], "CR LF made one line");

        $display("test 5: tone commands");
        mark = pwm_edges;
        put_str("#1000,300##2000,100#", 20); put_char(8'h0D);
        cmd_start; wait_idle;
        check(pwm_edges - mark > 3000, "two tone commands played");

        $display("test 6: unterminated tone command");
        put_str("HI #1000,500", 12); put_char(8'h0D); put_char(8'h0A);
        apb_read(R_STAT); check(!rdata[B_READY], "line with open command ignored");
        put_str("OK", 2); put_char(8'h0D);
        apb_read(R_STAT); check(rdata[B_READY], "next line is accepted");
        cmd_start; wait_idle;

        $display("test 7: CLEAR and reset during speech");
        put_str("WELCOME HOME", 12); put_char(8'h0D);
        put_str("QUEUED", 6); put_char(8'h0D);
        cmd_clear;
        apb_read(R_STAT); check(!rdata[B_READY], "CLEAR discards the queue");
        put_str("WELCOME HOME", 12); put_char(8'h0D);
        cmd_start;
        repeat (40000) @(posedge PCLK);
        apb_read(R_STAT); check(rdata[B_BUSY], "speech running");
        RST_N = 1'b0; repeat (4) @(posedge PCLK); RST_N = 1'b1; repeat (4) @(posedge PCLK);
        apb_read(R_STAT); check(rdata == 32'd0, "reset stops the speech and clears everything");
        mark = pwm_edges; repeat (60000) @(posedge PCLK);
        check(pwm_edges == mark, "PWM muted after reset");
        put_str("OK", 2); put_char(8'h0A);
        cmd_start; wait_idle;
        apb_read(R_STAT); check(rdata[B_DONE], "new line works after reset");

        if (errors == 0) $display("tb_tts_apb PASS"); else $display("tb_tts_apb FAIL (%0d errors)", errors);
        $finish;
    end

    initial begin
        repeat (200) #100000000;
        $display("tb_tts_apb FAIL: timeout");
        $finish;
    end
endmodule
