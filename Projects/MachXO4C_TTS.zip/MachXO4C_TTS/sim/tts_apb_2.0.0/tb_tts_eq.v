`timescale 1ns/1ps
// Equivalence test: TTS_APB 1.5.0 (one 24 MHz clock) and TTS_APB 2.0.0 (PCLK 12 MHz, TTS_CLK 24 MHz) speak the same
// lines; the PWM outputs must be identical pulse for pulse (width of every high pulse, in 24 MHz clocks).
// PCLK of 2.0.0 is set with +define+PCLK_HALF=<ns> (default 41.6667 ns = 12 MHz).
`ifndef PCLK_HALF
`define PCLK_HALF 41.6667
`endif
module tb_tts_eq;
    reg clk24 = 1'b0, pclk = 1'b0, rst_n = 1'b0;
    always #20.8333 clk24 = ~clk24;
    always #`PCLK_HALF pclk = ~pclk;

    // ---- 1.5.0 bus ----
    reg  [3:0]  a1 = 0; reg s1 = 0, e1 = 0, w1 = 0; reg [31:0] d1 = 0;
    wire [31:0] q1; wire r1, x1, pwm1;
    tts_apb_slave_v15 dut1 (.PCLK(clk24), .RST_N(rst_n), .PADDR(a1), .PSEL(s1), .PENABLE(e1), .PWRITE(w1),
                            .PWDATA(d1), .PRDATA(q1), .PREADY(r1), .PSLVERR(x1), .PWM_OUT(pwm1));
    // ---- 2.0.0 bus ----
    reg  [3:0]  a2 = 0; reg s2 = 0, e2 = 0, w2 = 0; reg [31:0] d2 = 0;
    wire [31:0] q2; wire r2, x2, pwm2;
    tts_apb_slave dut2 (.PCLK(pclk), .TTS_CLK(clk24), .RST_N(rst_n), .PADDR(a2), .PSEL(s2), .PENABLE(e2), .PWRITE(w2),
                        .PWDATA(d2), .PRDATA(q2), .PREADY(r2), .PSLVERR(x2), .PWM_OUT(pwm2));

    // ---- pulse recorder (both outputs sampled with the 24 MHz synthesizer clock) ----
    localparam MAXP = 400000;
    integer wid1 [0:MAXP-1];
    integer wid2 [0:MAXP-1];
    integer n1 = 0, n2 = 0, c1 = 0, c2 = 0;
    always @(posedge clk24) begin
        if (pwm1) c1 = c1 + 1; else if (c1 != 0) begin if (n1 < MAXP) wid1[n1] = c1; n1 = n1 + 1; c1 = 0; end
        if (pwm2) c2 = c2 + 1; else if (c2 != 0) begin if (n2 < MAXP) wid2[n2] = c2; n2 = n2 + 1; c2 = 0; end
    end

    // ---- APB masters ----
    reg [31:0] rd1, rd2;
    task wr1; input [3:0] a; input [31:0] d; begin
        @(posedge clk24); #1 a1 = a; d1 = d; w1 = 1; s1 = 1; e1 = 0;
        @(posedge clk24); #1 e1 = 1;
        @(posedge clk24); while (!r1) @(posedge clk24); #1 s1 = 0; e1 = 0; w1 = 0; end endtask
    task rdd1; input [3:0] a; begin
        @(posedge clk24); #1 a1 = a; w1 = 0; s1 = 1; e1 = 0;
        @(posedge clk24); #1 e1 = 1;
        @(posedge clk24); while (!r1) @(posedge clk24); rd1 = q1; #1 s1 = 0; e1 = 0; end endtask
    task wr2; input [3:0] a; input [31:0] d; begin
        @(posedge pclk); #1 a2 = a; d2 = d; w2 = 1; s2 = 1; e2 = 0;
        @(posedge pclk); #1 e2 = 1;
        @(posedge pclk); while (!r2) @(posedge pclk); #1 s2 = 0; e2 = 0; w2 = 0; end endtask
    task rdd2; input [3:0] a; begin
        @(posedge pclk); #1 a2 = a; w2 = 0; s2 = 1; e2 = 0;
        @(posedge pclk); #1 e2 = 1;
        @(posedge pclk); while (!r2) @(posedge pclk); rd2 = q2; #1 s2 = 0; e2 = 0; end endtask

    // one line: characters, CR, START, wait until BUSY clears
    task say1; input [8*64-1:0] s; input integer n; integer i; begin
        for (i = n-1; i >= 0; i = i - 1) wr1(4'hC, {24'd0, s[8*i +: 8]});
        wr1(4'hC, 32'h0D); wr1(4'h4, 32'd1);
        rdd1(4'h8); while (rd1[0]) begin repeat (400) @(posedge clk24); rdd1(4'h8); end end endtask
    task say2; input [8*64-1:0] s; input integer n; integer i; begin
        for (i = n-1; i >= 0; i = i - 1) wr2(4'hC, {24'd0, s[8*i +: 8]});
        wr2(4'hC, 32'h0D); wr2(4'h4, 32'd1);
        rdd2(4'h8); while (rd2[0]) begin repeat (200) @(posedge pclk); rdd2(4'h8); end end endtask

    reg done1 = 0, done2 = 0;
    initial begin
        repeat (8) @(posedge clk24); rst_n = 1;
    end
    initial begin
        wait (rst_n); repeat (8) @(posedge clk24);
        say1("Hello world, how are you?", 25);
        say1("#1318,125# #1174,125#-#881,100#", 31);
        say1("Lattice? Mag X-O for is running!", 32);
        done1 = 1;
    end
    initial begin
        wait (rst_n); repeat (8) @(posedge pclk);
        say2("Hello world, how are you?", 25);
        say2("#1318,125# #1174,125#-#881,100#", 31);
        say2("Lattice? Mag X-O for is running!", 32);
        done2 = 1;
    end

    integer k, mism;
    initial begin
        wait (done1 && done2);
        repeat (1000) @(posedge clk24);
        mism = 0;
        if (n1 != n2) begin $display("FAIL: pulse count 1.5.0 = %0d, 2.0.0 = %0d", n1, n2); mism = mism + 1; end
        for (k = 0; k < n1 && k < n2 && k < MAXP; k = k + 1)
            if (wid1[k] != wid2[k]) begin
                if (mism < 10) $display("FAIL: pulse %0d width 1.5.0 = %0d, 2.0.0 = %0d", k, wid1[k], wid2[k]);
                mism = mism + 1;
            end
        $display("pulses compared: %0d (1.5.0) / %0d (2.0.0)", n1, n2);
        if (mism == 0 && n1 > 1000) $display("tb_tts_eq PASS: PWM output identical");
        else                        $display("tb_tts_eq FAIL (%0d mismatches)", mism);
        $finish;
    end
    initial begin repeat (100) #100000000; $display("tb_tts_eq FAIL: timeout"); $finish; end
endmodule
