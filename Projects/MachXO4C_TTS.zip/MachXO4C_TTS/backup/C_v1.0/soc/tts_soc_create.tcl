# Propel design script: tts_soc
# Session: 0a24f1bc-2226-4c39-9a26-245d22fa7ea4
# Mode: new

file delete -force {tts_soc}
sbp_create_project -name {tts_soc} -path {.} -device {LFMXO4-110HC-6BBG256I} -speed {6} -language {verilog} -board {NA}
# Blank template ships clk_i/rstn_i -- remove them, as Lattice's own create_soc_demo.tcl does.
catch { sbp_delete "tts_soc/clk_i" -type port }
catch { sbp_delete "tts_soc/rstn_i" -type port }

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}

sbp_config_ip -vlnv {latticesemi.com:module:pll0:3.0.1} -meta_vlnv {latticesemi.com:module:pll:3.0.1} -cfg_value {gui_config_mode:FREQUENCY,gui_freq_refclk:12,gui_clkop_freq:24,gui_clkop_tol:0,gui_en_lock_port:true}
sbp_config_ip -vlnv {latticesemi.com:ip:cpu0:1.9.0} -meta_vlnv {latticesemi.com:ip:riscv_sm:1.9.0} -cfg_value {DEBUG_ENABLE:false,PIC_ENABLE:true,TIMER_ENABLE:true,IRQ_NUM:1}
sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INTERFACE:AHBL,ADDR_DEPTH:4096,DATA_WIDTH:32,MEMORY_TYPE:EBR,PORT_COUNT:2,RESET_MODE_S0:sync,RESET_MODE_S1:sync}
sbp_config_ip -vlnv {latticesemi.com:module:ahbl0:1.5.0} -meta_vlnv {latticesemi.com:module:ahb_lite_interconnect:1.5.0} -cfg_value {TOTAL_MASTER_CNT:1,TOTAL_SLAVE_CNT:2}
sbp_config_ip -vlnv {latticesemi.com:module:ahbl2apb0:1.2.0} -meta_vlnv {latticesemi.com:module:ahb_lite_to_apb_bridge:1.2.0} -cfg_value {}
sbp_config_ip -vlnv {latticesemi.com:module:apb0:1.4.0} -meta_vlnv {latticesemi.com:module:apb_interconnect:1.4.0} -cfg_value {TOTAL_MASTER_CNT:1,TOTAL_SLAVE_CNT:3}
sbp_config_ip -vlnv {latticesemi.com:ip:uart0:1.6.0} -meta_vlnv {latticesemi.com:ip:uart:1.6.0} -cfg_value {SYS_CLOCK_FREQ:24,BAUD_RATE_TYPE:Standard,STANDARD_BAUD_RATE:19200,LCR_DATA_BITS:8,LCR_STOP_BITS:1,RXRDY_ENA:false}
sbp_config_ip -vlnv {latticesemi.com:ip:gpio0:1.8.1} -meta_vlnv {latticesemi.com:ip:gpio:1.8.1} -cfg_value {IO_LINES_COUNT:5,EXTERNAL_BUF:true,IF_USER_INTF:APB}
sbp_config_ip -vlnv {custom:module:tts0:1.5.0} -meta_vlnv {custom:module:tts_apb:1.5.0} -cfg_value {}
sbp_add_component -vlnv {latticesemi.com:module:pll0:3.0.1} -name {pll0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:cpu0:1.9.0} -name {cpu0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst}
sbp_add_component -vlnv {latticesemi.com:module:ahbl0:1.5.0} -name {ahbl0_inst}
sbp_add_component -vlnv {latticesemi.com:module:ahbl2apb0:1.2.0} -name {ahbl2apb0_inst}
sbp_add_component -vlnv {latticesemi.com:module:apb0:1.4.0} -name {apb0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:uart0:1.6.0} -name {uart0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:gpio0:1.8.1} -name {gpio0_inst}
sbp_add_component -vlnv {custom:module:tts0:1.5.0} -name {tts0_inst}
sbp_add_gluelogic -name rst_and_0 -logicinfo [sbp_create_glue_logic equation rst_and {} { {"expr":"A & B","module_name":"rst_and"}}]
sbp_add_port -direction in clk12_i
sbp_add_port -direction in rstn_i
sbp_add_port -direction in rxd_i
sbp_add_port -direction out txd_o
sbp_add_port -direction out pwm_o
sbp_add_port -from 4 -to 0 -direction out gpio_o
sbp_add_port -from 4 -to 0 -direction in gpio_i
sbp_add_port -from 4 -to 0 -direction out gpio_en_o
sbp_connect_net {tts_soc/clk12_i} {tts_soc/pll0_inst/clki_i}
sbp_connect_net {tts_soc/rstn_i} {tts_soc/rst_and_0/A}
sbp_connect_net {tts_soc/pll0_inst/lock_o} {tts_soc/rst_and_0/B}
sbp_connect_net {tts_soc/rst_and_0/O} {tts_soc/cpu0_inst/rst_n_i}
sbp_connect_net {tts_soc/rxd_i} {tts_soc/uart0_inst/rxd_i}
sbp_connect_net {tts_soc/uart0_inst/txd_o} {tts_soc/txd_o}
sbp_connect_net {tts_soc/tts0_inst/PWM_OUT} {tts_soc/pwm_o}
sbp_connect_net {tts_soc/gpio0_inst/gpio_o} {tts_soc/gpio_o}
sbp_connect_net {tts_soc/gpio_i} {tts_soc/gpio0_inst/gpio_i}
sbp_connect_net {tts_soc/gpio0_inst/gpio_en_o} {tts_soc/gpio_en_o}
sbp_connect_net {tts_soc/pll0_inst/clkop_o} {tts_soc/cpu0_inst/clk_i} {tts_soc/sysmem0_inst/ahbl_hclk_i} {tts_soc/ahbl0_inst/ahbl_hclk_i} {tts_soc/ahbl2apb0_inst/clk_i} {tts_soc/apb0_inst/apb_pclk_i} {tts_soc/uart0_inst/clk_i} {tts_soc/gpio0_inst/clk_i} {tts_soc/tts0_inst/PCLK}
sbp_connect_net {tts_soc/cpu0_inst/system_resetn_o} {tts_soc/sysmem0_inst/ahbl_hresetn_i} {tts_soc/ahbl0_inst/ahbl_hresetn_i} {tts_soc/ahbl2apb0_inst/rst_n_i} {tts_soc/apb0_inst/apb_presetn_i} {tts_soc/uart0_inst/rst_n_i} {tts_soc/gpio0_inst/resetn_i} {tts_soc/tts0_inst/RST_N}
sbp_connect_interface_net {tts_soc/cpu0_inst/AHBL_M0_INSTR} {tts_soc/sysmem0_inst/AHBL_S0}
sbp_connect_interface_net {tts_soc/cpu0_inst/AHBL_M1_DATA} {tts_soc/ahbl0_inst/AHBL_S00}
sbp_connect_interface_net {tts_soc/ahbl0_inst/AHBL_M00} {tts_soc/sysmem0_inst/AHBL_S1}
sbp_connect_interface_net {tts_soc/ahbl0_inst/AHBL_M01} {tts_soc/ahbl2apb0_inst/AHBL_S0}
sbp_connect_interface_net {tts_soc/ahbl2apb0_inst/APB_M0} {tts_soc/apb0_inst/APB_S00}
sbp_connect_interface_net {tts_soc/apb0_inst/APB_M00} {tts_soc/uart0_inst/APB_S0}
sbp_connect_interface_net {tts_soc/apb0_inst/APB_M01} {tts_soc/gpio0_inst/APB_S0}
sbp_connect_interface_net {tts_soc/apb0_inst/APB_M02} {tts_soc/tts0_inst/APB_S0}
sbp_connect_interface_net {tts_soc/uart0_inst/INT_M0} {tts_soc/cpu0_inst/IRQ_S0}
sbp_assign_addr_seg -offset 'h00000000 {tts_soc/cpu0_inst/AHBL_M0_INSTR} {tts_soc/sysmem0_inst/AHBL_S0}
sbp_assign_addr_seg -offset 'h00000000 {tts_soc/ahbl0_inst/AHBL_M00} {tts_soc/sysmem0_inst/AHBL_S1}
sbp_assign_addr_seg -offset 'h00008000 {tts_soc/apb0_inst/APB_M00} {tts_soc/uart0_inst/APB_S0}
sbp_assign_addr_seg -offset 'h00008400 {tts_soc/apb0_inst/APB_M01} {tts_soc/gpio0_inst/APB_S0}
sbp_assign_addr_seg -offset 'h00008C00 {tts_soc/apb0_inst/APB_M02} {tts_soc/tts0_inst/APB_S0}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: tts_soc"