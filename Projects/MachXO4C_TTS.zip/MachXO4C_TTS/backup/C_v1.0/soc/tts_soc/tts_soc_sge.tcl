# PGE SGE script for tts_soc
# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}
::ip_catalog::ip_catalog_location -add {C:\lscc\propel\2026.1.1\builder\rtf\ip}

sbp_design open -name {tts_soc} -path {C:/lscc/workspace/MachXO4C_TTS/soc/tts_soc/tts_soc/tts_soc.sbx}
sbp_design save
sbp_design generate
sbp_design save
set _sbxAbs [file normalize {C:/lscc/workspace/MachXO4C_TTS/soc/tts_soc/tts_soc/tts_soc.sbx}]
set _sgeAbs [file normalize {C:/lscc/workspace/MachXO4C_TTS/soc/tts_soc}]
sbp_design pge sge -i $_sbxAbs -o $_sgeAbs -nc
puts "pge sge returned without error: tts_soc"
exit