component pll0 is
    port(
        clki_i: in std_logic;
        clkop_o: out std_logic;
        lock_o: out std_logic
    );
end component;

__: pll0 port map(
    clki_i=>,
    clkop_o=>,
    lock_o=>
);
