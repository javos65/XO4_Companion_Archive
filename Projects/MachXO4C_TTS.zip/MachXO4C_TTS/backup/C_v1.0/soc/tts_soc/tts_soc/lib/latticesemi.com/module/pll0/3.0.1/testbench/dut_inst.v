    pll0 u_pll0(.clki_i(clki_i),
        .clkop_o(clkop_o),
        .lock_o(lock_o));
