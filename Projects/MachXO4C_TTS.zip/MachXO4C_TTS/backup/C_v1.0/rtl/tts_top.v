// ============================================================================
// tts_top.v - MachXO4 Companion Board (LFMXO4-110HC-6BBG256I) top level
//
// Wraps the Propel SoC tts_soc:
//   - SW2 (active low, pin D10): two-flop synchronizer and debounce of about
//     22 ms at 12 MHz (2^18 cycles); the debounced level resets the SoC.
//   - Power-on reset: the SoC is held in reset for 2^18 cycles after
//     configuration, independent of SW2.
//   - LED1 ("SW2 pressed") is driven in hardware from the debounced SW2.
//   - LED0, LED2, LED3 come from GPIO lines 0, 2, 3 (firmware: heartbeat,
//     speech active, character received). GPIO line 4 reads the debounced SW2.
//   LEDs are active low (low = lit).
// Verilog-2001.
// ============================================================================
module tts_top (
    input  wire       clk12_i,     // T9  12 MHz board clock
    input  wire       sw2_n_i,     // D10 SW2, active low
    input  wire       rxd_i,       // H15 UART RX (Raspberry Pi TX)
    output wire       txd_o,       // J12 UART TX (Raspberry Pi RX)
    output wire       pwm_o,       // H12 audio PWM (PMOD_1)
    output wire [3:0] dled_n_o     // G14, E14, G15, G13: LED1..LED4, low = lit
);

    localparam DB_BITS  = 18;      // 2^18 / 12 MHz = 21.8 ms
    localparam POR_BITS = 18;

    // ---- SW2 synchronizer ----
    reg [1:0] sw2_sync = 2'b11;
    always @(posedge clk12_i)
        sw2_sync <= {sw2_sync[0], sw2_n_i};

    // ---- SW2 debounce: accept a new level after it is stable for 2^DB_BITS cycles ----
    reg               sw2_db_n  = 1'b1;   // debounced SW2, active low
    reg [DB_BITS-1:0] db_cnt    = {DB_BITS{1'b0}};
    always @(posedge clk12_i) begin
        if (sw2_sync[1] == sw2_db_n) begin
            db_cnt <= {DB_BITS{1'b0}};
        end else begin
            db_cnt <= db_cnt + 1'b1;
            if (&db_cnt)
                sw2_db_n <= sw2_sync[1];
        end
    end

    // ---- power-on reset ----
    reg [POR_BITS-1:0] por_cnt  = {POR_BITS{1'b0}};
    reg                por_done = 1'b0;
    always @(posedge clk12_i) begin
        if (!por_done) begin
            por_cnt <= por_cnt + 1'b1;
            if (&por_cnt)
                por_done <= 1'b1;
        end
    end

    // ---- SoC reset (active low), registered ----
    reg soc_rstn = 1'b0;
    always @(posedge clk12_i)
        soc_rstn <= por_done & sw2_db_n;

    // ---- SoC ----
    wire [4:0] gpio_o;
    wire [4:0] gpio_en_o;
    wire [4:0] gpio_i = {sw2_db_n, 4'b1111};

    tts_soc u_soc (
        .clk12_i  (clk12_i),
        .rstn_i   (soc_rstn),
        .rxd_i    (rxd_i),
        .txd_o    (txd_o),
        .pwm_o    (pwm_o),
        .gpio_o   (gpio_o),
        .gpio_i   (gpio_i),
        .gpio_en_o(gpio_en_o)
    );

    // ---- LEDs (low = lit) ----
    assign dled_n_o[0] = gpio_o[0];      // heartbeat
    assign dled_n_o[1] = sw2_db_n;       // SW2 pressed (hardware)
    assign dled_n_o[2] = gpio_o[2];      // speech active
    assign dled_n_o[3] = gpio_o[3];      // character received

endmodule
