prj_open {C:/lscc/workspace/MachXO4C_TTS/radiant/tts_top.rdf}
prj_run_synthesis -forceOne
prj_run_map
prj_run_par
prj_run_bitstream
prj_save
prj_close
