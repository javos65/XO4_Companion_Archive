# Creates the Radiant project tts_top for the MachXO4 Companion Board.
# The Propel SoC tts_soc is linked in as a subsystem; rtl/tts_top.v is the top module.
# Synthesis tool: LSE. Sources are linked by reference, never copied.
set root "C:/lscc/workspace/MachXO4C_TTS"
set soc  "$root/soc/tts_soc/tts_soc"
cd "$root/radiant"

set DEVICE "LFMXO4-110HC-6BBG256I"
set rdf "$root/radiant/tts_top.rdf"

if { [file exists $rdf] == 1 } {
    prj_open $rdf
} else {
    prj_create -name "tts_top" -impl "impl_1" -dev $DEVICE -performance 6 -synthesis "lse"
    prj_save
}

# Every generated IP instance of the SoC (.ipx), found by glob so a replaced instance is picked up on rerun
set sources [lsort [glob -nocomplain "$soc/lib/*/*/*/*/*.ipx"]]
lappend sources "$soc/tts_soc.v" "$root/rtl/tts_top.v" "$root/constraints/tts_top.pdc" "$root/constraints/tts_timing.sdc"

foreach f $sources {
    if { [file exists $f] == 0 } { puts "ERROR: missing source $f"; continue }
    puts "adding $f"
    if { [catch {prj_add_source $f} msg] } { puts "source already in project: $f" }
}

prj_set_impl_opt -impl "impl_1" "top" "tts_top"
# LSE memory initialisation search path: the CPU testbench folder of the generated SoC
prj_set_strategy_value -strategy Strategy1 "lse_mem_init_file_path=$soc/lib/latticesemi.com/ip/cpu0/1.9.0/testbench"
prj_set_strategy_value -strategy Strategy1 "lse_loop_limit=20000"
prj_save
prj_close
puts "Radiant project created: $rdf"
