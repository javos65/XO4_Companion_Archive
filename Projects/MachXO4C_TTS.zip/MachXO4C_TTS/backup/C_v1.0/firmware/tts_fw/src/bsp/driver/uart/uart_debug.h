#ifndef UART_DEBUG_H_
#define UART_DEBUG_H_
#ifdef FEATURE_UART_DEBUG

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdio.h>
#include "config/sys_config.h"
#include "bsp/driver/cpu/cpu.h"

typedef uint8_t u8;

#ifndef BIT
#define BIT(n) (1u << (n))
#endif

#define UART_CPU_RELAX() __asm__ __volatile__("nop")

static inline uint32_t uart_lsr_read(uint32_t base) { return read32(base + 0x14); }
static inline uint32_t uart_rbr_read(uint32_t base) { return read32(base + 0x00); }
static inline void uart_thr_write(uint32_t base, uint8_t c) { write32(base + 0x00, (uint32_t)c); }

#define UART_LSR_DATA_RDY BIT(0)
#define UART_LSR_THRE     BIT(5)

#ifndef EAGAIN
#define EAGAIN 11
#endif

static inline void uart_putch(u8 c) {
    uint32_t guard = 2000000u;
    while (!(uart_lsr_read(UART_DEBUG_BASE_ADDR0) & UART_LSR_THRE)) {
        if (--guard == 0u) return;
        UART_CPU_RELAX();
    }
    uart_thr_write(UART_DEBUG_BASE_ADDR0, c);
}

static inline int uart_getc_nb(void) {
    if (uart_lsr_read(UART_DEBUG_BASE_ADDR0) & UART_LSR_DATA_RDY)
        return (int)uart_rbr_read(UART_DEBUG_BASE_ADDR0);
    return -EAGAIN;
}

static inline void uart_puts(const char *s) { while (*s) uart_putch((u8)*s++); }

static inline int uart_itoa(int32_t val, char *buf, int bufsize) {
    char temp[12]; int i = 0, neg = 0;
    if (val < 0) { neg = 1; val = -val; }
    do { temp[i++] = '0' + (val % 10); val /= 10; } while (val > 0 && i < 11);
    int len = 0;
    if (neg && len < bufsize - 1) buf[len++] = '-';
    while (i > 0 && len < bufsize - 1) buf[len++] = temp[--i];
    buf[len] = '\0';
    return len;
}

static inline int uart_utohex(uint32_t val, char *buf, int bufsize) {
    const char hex[] = "0123456789ABCDEF";
    char temp[9]; int i = 0;
    do { temp[i++] = hex[val & 0xF]; val >>= 4; } while (val > 0 && i < 8);
    int len = 0;
    while (i > 0 && len < bufsize - 1) buf[len++] = temp[--i];
    buf[len] = '\0';
    return len;
}

static inline void uart_vprintf(const char *fmt, va_list args) {
    while (*fmt) {
        if (*fmt == '%' && *(fmt + 1)) {
            fmt++;
            char buf[12]; int len = 0, width = 0; char pad = ' ';
            if (*fmt >= '0' && *fmt <= '9') {
                if (*fmt == '0') { pad = '0'; fmt++; }
                while (*fmt >= '0' && *fmt <= '9') { width = width * 10 + (*fmt - '0'); fmt++; }
            }
            while (*fmt == 'l' || *fmt == 'h') fmt++;
            switch (*fmt) {
            case 'd': case 'i':
                len = uart_itoa(va_arg(args, int32_t), buf, sizeof(buf));
                for (int i = 0; i < width - len; i++) uart_putch((u8)pad);
                for (int i = 0; i < len; i++) uart_putch((u8)buf[i]);
                break;
            case 'u':
                len = uart_itoa((int32_t)va_arg(args, uint32_t), buf, sizeof(buf));
                for (int i = 0; i < width - len; i++) uart_putch((u8)pad);
                for (int i = 0; i < len; i++) uart_putch((u8)buf[i]);
                break;
            case 'x': case 'X':
                len = uart_utohex(va_arg(args, uint32_t), buf, sizeof(buf));
                for (int i = 0; i < width - len; i++) uart_putch((u8)pad);
                for (int i = 0; i < len; i++) uart_putch((u8)buf[i]);
                break;
            case 's': { const char *s = va_arg(args, const char *); if (s) while (*s) uart_putch((u8)*s++); break; }
            case 'c': uart_putch((u8)va_arg(args, int)); break;
            case '%': uart_putch((u8)'%'); break;
            default: uart_putch((u8)'%'); uart_putch((u8)*fmt); break;
            }
        } else {
            uart_putch((u8)*fmt);
        }
        fmt++;
    }
}

static inline void uart_printf_nt(const char *fmt, ...) {
    va_list args; va_start(args, fmt); uart_vprintf(fmt, args); va_end(args);
}
static inline void uart_printf(const char *fmt, ...) {
    va_list args; va_start(args, fmt); uart_vprintf(fmt, args); va_end(args);
}

#define DEBUG_ENABLE 1
#if defined(DEBUG_ENABLE) && DEBUG_ENABLE
#define DEBUG_N(fmt, ...)   uart_printf_nt(fmt, ##__VA_ARGS__)
#define DEBUG_MSG(fmt, ...) uart_printf(fmt, ##__VA_ARGS__)
#else
#define DEBUG_N(fmt, ...)   do { } while (0)
#define DEBUG_MSG(fmt, ...) do { } while (0)
#endif

#endif /* FEATURE_UART_DEBUG */
#endif /* UART_DEBUG_H_ */
