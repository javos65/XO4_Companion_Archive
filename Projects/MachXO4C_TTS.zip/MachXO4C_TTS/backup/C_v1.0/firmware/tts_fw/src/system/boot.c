/* Boot-mode initialization stub (OSPI/LPDDR4 copy + jump lives here in a
   full boot image; the bring-up scaffold keeps it minimal). */
#include "config/sys_config.h"
