#ifndef PLATFORM_H_
#define PLATFORM_H_

#include <stdint.h>
#include "config/sys_config.h"

typedef enum { ePRIV_M = 1, ePRIV_S = 2, ePRIV_U = 4 } priv_e;
typedef void (*irq_handler)(void *);

void plic_init(void);
int  plic_int_register(uint8_t src, uint8_t priority, uint8_t mode,
                       irq_handler isr, void *context);

#endif /* PLATFORM_H_ */
