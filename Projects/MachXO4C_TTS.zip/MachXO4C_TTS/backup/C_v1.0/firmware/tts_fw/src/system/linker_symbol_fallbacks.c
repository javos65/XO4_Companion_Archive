#include <stdint.h>

/* Weak fallbacks for the driver-table section-boundary symbols. The linker
   script normally provides the real bounds; these keep the link resolving if
   a configuration omits them. */
__attribute__((weak)) const uintptr_t __soc_drivers_start = 0;
__attribute__((weak)) const uintptr_t __soc_drivers_end   = 0;
__attribute__((weak)) const uintptr_t __soc_app_drivers_start = 0;
__attribute__((weak)) const uintptr_t __soc_app_drivers_end   = 0;
