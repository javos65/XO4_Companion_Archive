#ifndef SOC_DRIVER_H_
#define SOC_DRIVER_H_

#include "config/feature_flags.h"
#include "config/soc_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SOC_DRIVER_REGISTER(name, compat_str, probe_fn)                   \
    __attribute__((used, section(".soc_drivers")))                        \
    static const soc_driver_t _soc_drv_##name = {                         \
        .compatible = (compat_str),                                       \
        .probe      = (probe_fn)                                          \
    }

#define SOC_APP_DRIVER_REGISTER(name, compat_str, probe_fn)               \
    __attribute__((used, section(".soc_app_drivers")))                    \
    static const soc_app_driver_ops_t _soc_app_drv_##name = {             \
        .compatible = (compat_str),                                       \
        .probe      = (probe_fn)                                          \
    }

extern const soc_driver_t __soc_drivers_start[];
extern const soc_driver_t __soc_drivers_end[];
extern const soc_app_driver_ops_t __soc_app_drivers_start[];
extern const soc_app_driver_ops_t __soc_app_drivers_end[];

int soc_init_all(char flag);
/* Probe ONE device: 0 = probed ok, -1 = its probe failed, -2 = no driver is
   registered for its compatible. soc_init_all() is this in a loop, so the two
   can never disagree; it exists because soc_init_all() returns only a count and
   a per-device report needs the three outcomes told apart. */
int soc_probe_one(const soc_device_t *dev);
int soc_app_init_all(void);
const soc_device_t *soc_device_by_compatible(const char *compatible);
const soc_device_t *soc_device_by_name(const char *name);

#ifdef __cplusplus
}
#endif

#endif /* SOC_DRIVER_H_ */
