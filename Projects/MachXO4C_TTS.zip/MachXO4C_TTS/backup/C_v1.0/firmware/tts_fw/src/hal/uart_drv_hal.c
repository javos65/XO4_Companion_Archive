#include <stdint.h>
#include "config/feature_flags.h"
#include "system/driver.h"
#include "bsp/driver/uart/uart_debug.h"

char get_uart_msg(void) {
    for (;;) {
        int ret = uart_getc_nb();
        if (ret >= 0) return (char)(uint8_t)ret;
    }
}

static int uart_probe(const soc_device_t *dev) {
    if (!dev || dev->base == 0) return -1;
    DEBUG_N("Probing UART controller '%s' @0x%08X irq=%d\r\n",
            dev->name, (unsigned)dev->base, dev->irq);
    return 0;
}

SOC_DRIVER_REGISTER(uart, "lattice,uart", uart_probe);
