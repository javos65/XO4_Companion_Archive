#include "config/feature_flags.h"
#include <string.h>
#include "system/driver.h"
#include "bsp/driver/uart/uart_debug.h"

int soc_probe_one(const soc_device_t *dev) {
    if (!dev) return -1;
    for (const soc_driver_t *d = __soc_drivers_start; d < __soc_drivers_end; d++) {
        if (d->compatible && strcmp(d->compatible, dev->compatible) == 0) {
            if (!d->probe) return -2;
            return d->probe(dev) == 0 ? 0 : -1;
        }
    }
    return -2;                      /* no driver registered for this compatible */
}

int soc_init_all(char flag) {
    int probed = 0;
    for (unsigned i = 0; i < soc_devices_count; i++) {
        const soc_device_t *dev = &soc_devices[i];
        if (flag == 1) {
            DEBUG_N("device %s (%s) at 0x%08X\r\n", dev->name, dev->compatible,
                    (unsigned)dev->base);
        }
        if (soc_probe_one(dev) == 0) {
            probed++;
        }
    }
    return probed;
}

const soc_device_t *soc_device_by_compatible(const char *compatible) {
    if (!compatible) return 0;
    for (unsigned i = 0; i < soc_devices_count; i++)
        if (strcmp(soc_devices[i].compatible, compatible) == 0)
            return &soc_devices[i];
    return 0;
}

const soc_device_t *soc_device_by_name(const char *name) {
    if (!name) return 0;
    for (unsigned i = 0; i < soc_devices_count; i++)
        if (strcmp(soc_devices[i].name, name) == 0)
            return &soc_devices[i];
    return 0;
}

int soc_app_init_all(void) {
    int probed = 0;
    for (unsigned i = 0; i < soc_app_drivers_count; i++) {
        const soc_app_driver_t *drv = &soc_app_drivers[i];
        for (const soc_app_driver_ops_t *ops = __soc_app_drivers_start;
             ops < __soc_app_drivers_end; ops++) {
            if (ops->compatible && strcmp(ops->compatible, drv->compatible) == 0) {
                if (ops->probe && ops->probe(drv) == 0) probed++;
                break;
            }
        }
    }
    return probed;
}
