#include "config/sys_config.h"
#include <stdio.h>
#include "bsp/driver/uart/uart_debug.h"

static int _uart_putc(char c, FILE *file) {
    (void)file;
    if (c == '\n') uart_putch('\r');
    uart_putch((uint8_t)c);
    return (unsigned char)c;
}

static int _uart_getc(FILE *file) { (void)file; return -1; }

static FILE __stdio_uart = FDEV_SETUP_STREAM(_uart_putc, _uart_getc, NULL, _FDEV_SETUP_RW);

FILE *const __iob[3] = { &__stdio_uart, &__stdio_uart, &__stdio_uart };

void _exit(int status) { (void)status; while (1) { } }
int getpid(void) { return 1; }
int kill(int pid, int sig) { (void)pid; (void)sig; return -1; }
