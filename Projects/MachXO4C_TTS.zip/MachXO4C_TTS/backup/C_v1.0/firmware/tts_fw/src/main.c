/*
 * MachXO4 Companion Board text-to-speech: RISC-V SM firmware (rv32i).
 *
 * The RISC-V handles the UART, the status messages and the LEDs, and drives the memory-mapped
 * TTS_APB library block. main() uses driver functions only (UART, GPIO, TTS, timer).
 *
 * Sequence:
 *   reset            : send "TTS OK.", speak the boot phrase, discard everything received meanwhile,
 *                      then clear the queue
 *   text line (UART) : every received character is written to the TTS block (lines up to 128 characters)
 *   line complete    : send "TTS EXE", write START, wait until BUSY clears, send "TTS RDY"
 * Every message ends with CR LF.
 *
 * Jingle: every 10 minutes (RISC-V timer, 24 MHz tick), when the TTS block is idle and no UART line
 *   is half received, two tone phrases are played one after the other.
 *
 * GPIO (5 lines): lines 3..0 are the LEDs (driven low to light), line 4 is the debounced SW2 input.
 *   LED0 heartbeat, LED1 left to the hardware (SW2 pressed), LED2 speech active,
 *   LED3 changes state on every character received.
 */
#include <stdint.h>
#include "config/soc_config.h"
#include "bsp/sys_platform.h"
#include "bsp/driver/uart/uart.h"
#include "bsp/driver/gpio/gpio.h"
#include "bsp/driver/tts_apb/tts.h"
#include "bsp/driver/riscv_sm/timer.h"

#define CPU_HZ          ((uint32_t)UART0_INST_CLOCK_HZ)    /* system clock: 24 MHz from the PLL */
#define TIMER_BASE      ((uint32_t)CPU0_INST_PICTIMER_START_ADDR)

#define GPIO_LINES      5u
#define GPIO_DIRS       0x0Fu       /* lines 3..0 outputs (LEDs), line 4 input (SW2) */
#define LED_COUNT       4u

#define LED_HEARTBEAT   0u
#define LED_SW2         1u          /* driven in hardware; firmware keeps it off */
#define LED_SPEECH      2u
#define LED_RXCHAR      3u

#define BOOT_PHRASE     "Lattice? Mag X-O for is running!\r"
#define UART_LINE_MAX   TTS_LINE_MAX
#define HEARTBEAT_SHIFT 17          /* LED toggles every 2^17 loop passes */

static struct uart_instance  uart0;
static struct gpio_instance  gpio0;
static struct tts_instance   tts0;
static struct timer_instance timer0;

/* ---- transmit queue: messages are sent without blocking the receive path ---- */
#define TXQ_SIZE 32u                /* power of two, larger than the longest message plus CR LF */
static uint8_t  txq[TXQ_SIZE];
static uint32_t tx_wr, tx_rd;

static void tx_message(const char *s)
{
    while (*s) {
        txq[tx_wr & (TXQ_SIZE - 1u)] = (uint8_t)*s++;
        tx_wr++;
    }
    txq[tx_wr & (TXQ_SIZE - 1u)] = '\r'; tx_wr++;
    txq[tx_wr & (TXQ_SIZE - 1u)] = '\n'; tx_wr++;
}

static void tx_service(void)
{
    if (tx_rd != tx_wr) {
        if (uart_putc(&uart0, txq[tx_rd & (TXQ_SIZE - 1u)]) == 0) {
            tx_rd++;
        }
    }
}

/* ---- LEDs ---- */
static uint32_t led_state   = 0xFu;         /* bit = 1: LED off */
static uint32_t led_written = 0xFFFFFFFFu;
static uint32_t heartbeat;
static uint8_t  rx_toggle;

static void leds_write(void)
{
    uint32_t i;
    if (led_state == led_written) return;
    for (i = 0; i < LED_COUNT; i++) {
        gpio_output_write(&gpio0, i, led_state & (1u << i));
    }
    led_written = led_state;
}

static void led_set(uint32_t bit, uint32_t lit)
{
    if (lit) led_state &= ~(1u << bit); else led_state |= (1u << bit);
}

/* ---- jingle: two tone phrases, one after the other, every 10 minutes ---- */
#define CHIME_PERIOD_S   600u
#define CHIME_PHRASE1 "#1318,125# #1174,125# #881,100#,#1046,188# #991,188# #657,188# #881,125# #1046,125# #1174,125# #989,125#\r"
#define CHIME_PHRASE2 "#1318,125#-#1174,125#-#881,100#-#1046,125# #991,125# #657,125# #881,125# #1046,125#-#1174,125# #991,313#\r"
#define TIMER_CHECK_MASK 0xFFFu     /* read the timer every 4096 loop passes */
static uint64_t chime_next;
static uint64_t time_now;
static int      chime_pending;

static void rx_discard(void)
{
    uint8_t c;
    while (uart_getc(&uart0, &c) == 0) { /* drop */ }
}

int main(void)
{
    uint8_t  c;
    uint32_t st;
    int      speaking = 0;
    int      booting  = 1;
    uint32_t line_len = 0;

    uart_init(&uart0, UART0_INST_BASE, CPU_HZ, UART0_INST_BAUDRATE,
              UART0_INST_STOP_BITS, UART0_INST_DATA_BITS);
    uart0.blockingTx = 0;
    uart0.blockingRx = 0;

    gpio_init(&gpio0, GPIO0_INST_BASE, GPIO_LINES, GPIO_DIRS);
    tts_init(&tts0, TTS0_INST_BASE);
    timer_init(&timer0, TIMER_BASE, CPU_HZ);
    timer_get_mtime(&timer0, &time_now);
    chime_next = time_now + (uint64_t)CHIME_PERIOD_S * CPU_HZ;
    leds_write();

    tx_message("TTS OK.");
    write_tts_phrase(&tts0, BOOT_PHRASE, sizeof(BOOT_PHRASE) - 1u);
    write_tts_control(&tts0, TTS_CTRL_START);
    speaking = 1;

    for (;;) {
        tx_service();
        st = read_tts_status(&tts0);

        if (booting) {
            rx_discard();
            if (!(st & TTS_STATUS_BUSY)) {          /* boot phrase finished */
                booting  = 0;
                speaking = 0;
                write_tts_control(&tts0, TTS_CTRL_CLEAR);
                rx_discard();
            }
        } else if (uart_getc(&uart0, &c) == 0) {
            write_tts_phrase(&tts0, (const char *)&c, 1u);
            if (c == (uint8_t)0x0D || c == (uint8_t)0x0A || ++line_len >= UART_LINE_MAX) line_len = 0;
            rx_toggle ^= 1u;
            led_set(LED_RXCHAR, rx_toggle);
        }

        if (!booting) {
            if (speaking && !(st & TTS_STATUS_BUSY)) {
                speaking = 0;
                tx_message("TTS RDY");
            } else if (!speaking && (st & TTS_STATUS_READY) && !(st & TTS_STATUS_BUSY)) {
                tx_message("TTS EXE");
                write_tts_control(&tts0, TTS_CTRL_START);
                speaking = 1;
            }
        }

        if ((heartbeat & TIMER_CHECK_MASK) == 0u) {
            timer_get_mtime(&timer0, &time_now);
            if (time_now >= chime_next) chime_pending = 1;
        }
        if (!booting && chime_pending && !speaking && line_len == 0 &&
            !(st & (TTS_STATUS_BUSY | TTS_STATUS_READY))) {
            /* both line buffers are free: phrase 2 starts right after phrase 1 */
            write_tts_phrase(&tts0, CHIME_PHRASE1, sizeof(CHIME_PHRASE1) - 1u);
            write_tts_phrase(&tts0, CHIME_PHRASE2, sizeof(CHIME_PHRASE2) - 1u);
            chime_pending = 0;
            chime_next = time_now + (uint64_t)CHIME_PERIOD_S * CPU_HZ;
        }

        led_set(LED_SPEECH, (st & TTS_STATUS_BUSY) != 0u);
        heartbeat++;
        led_set(LED_HEARTBEAT, (heartbeat >> HEARTBEAT_SHIFT) & 1u);
        led_set(LED_SW2, 0u);
        leds_write();
    }
}
