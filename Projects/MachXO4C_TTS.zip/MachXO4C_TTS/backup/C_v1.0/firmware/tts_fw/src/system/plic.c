#include <stdint.h>
#include <stddef.h>
#include "config/sys_config.h"
#include "system/platform.h"

#define PLIC_INT_SRC_MIN  1
#define PLIC_INT_SRC_MAX  31

#ifndef PLIC_BASE_ADDR
#define PLIC_BASE_ADDR 0xFC000000L
#endif
#define PLIC_PRIORITY(id)     (*(volatile uint32_t *)(PLIC_BASE_ADDR + (id) * 4))
#define PLIC_ENABLE_M(hart)   (*(volatile uint32_t *)(PLIC_BASE_ADDR + 0x2000))
#define PLIC_ENABLE_S(hart)   (*(volatile uint32_t *)(PLIC_BASE_ADDR + 0x2000 + 0x80))
#define PLIC_MTHRESHOLD(hart) (*(volatile uint32_t *)(PLIC_BASE_ADDR + 0x200000 + (hart) * 0x1000))

#define MIE_MEIE  (1 << 11)

static inline uint32_t r_mie(void) { uint32_t x; __asm__ volatile("csrr %0, mie" : "=r"(x)); return x; }
static inline void w_mie(uint32_t x) { __asm__ volatile("csrw mie, %0" :: "r"(x)); }

typedef struct { irq_handler isr; void *context; } plic_int_entry_t;
static plic_int_entry_t plic_int_table[PLIC_INT_SRC_MAX + 1];

static inline int r_tp(void) { int hart; __asm__ volatile("mv %0, tp" : "=r"(hart)); return hart; }

int plic_int_register(uint8_t src, uint8_t priority, uint8_t mode,
                      irq_handler isr, void *context) {
    int hart = r_tp();
    if (src < PLIC_INT_SRC_MIN || src > PLIC_INT_SRC_MAX) return 1;
    plic_int_table[src].isr = isr;
    plic_int_table[src].context = context;
    PLIC_PRIORITY(src) = priority;
    if (mode & ePRIV_M) PLIC_ENABLE_M(hart) |= 1 << src;
    if (mode & ePRIV_S) PLIC_ENABLE_S(hart) |= 1 << src;
    return 0;
}

void plic_init(void) {
    int hart = r_tp();
    PLIC_MTHRESHOLD(hart) = 0;
    w_mie(r_mie() | MIE_MEIE);
}
