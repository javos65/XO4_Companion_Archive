src/system/boot.o: ../src/system/boot.c ../src/config/sys_config.h \
 ../src/config/feature_flags.h ../src/config/memory_map.h \
 ../src/config/ip_params.h
../src/config/sys_config.h:
../src/config/feature_flags.h:
../src/config/memory_map.h:
../src/config/ip_params.h:
