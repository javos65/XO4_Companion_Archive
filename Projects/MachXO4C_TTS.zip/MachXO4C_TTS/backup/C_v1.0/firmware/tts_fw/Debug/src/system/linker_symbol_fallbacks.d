src/system/linker_symbol_fallbacks.o: \
 ../src/system/linker_symbol_fallbacks.c
