src/system/driver.o: ../src/system/driver.c ../src/config/feature_flags.h \
 ../src/system/driver.h ../src/config/soc_config.h \
 ../src/bsp/driver/uart/uart_debug.h ../src/config/sys_config.h \
 ../src/config/feature_flags.h ../src/config/memory_map.h \
 ../src/config/ip_params.h ../src/bsp/driver/cpu/cpu.h
../src/config/feature_flags.h:
../src/system/driver.h:
../src/config/soc_config.h:
../src/bsp/driver/uart/uart_debug.h:
../src/config/sys_config.h:
../src/config/feature_flags.h:
../src/config/memory_map.h:
../src/config/ip_params.h:
../src/bsp/driver/cpu/cpu.h:
