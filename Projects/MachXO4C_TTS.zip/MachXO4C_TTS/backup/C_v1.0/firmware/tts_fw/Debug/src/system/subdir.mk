################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
C_SRCS += \
../src/system/boot.c \
../src/system/driver.c \
../src/system/linker_symbol_fallbacks.c \
../src/system/picolibc_stubs.c \
../src/system/plic.c 

OBJS += \
./src/system/boot.o \
./src/system/driver.o \
./src/system/linker_symbol_fallbacks.o \
./src/system/picolibc_stubs.o \
./src/system/plic.o 

C_DEPS += \
./src/system/boot.d \
./src/system/driver.d \
./src/system/linker_symbol_fallbacks.d \
./src/system/picolibc_stubs.d \
./src/system/plic.d 


# Each subdirectory must supply rules for building sources it contributes
src/system/%.o: ../src/system/%.c src/system/subdir.mk
	@echo 'Building file: $<'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -I"../src" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/cpu" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/riscv_sm" -I"../src/bsp/driver/tts_apb" -I"../src/bsp/driver/uart" -I"../src/config" -I"../src/hal" -I"../src/system" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_DOUBLE_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo ' '

