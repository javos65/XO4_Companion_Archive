src/config/soc_devices.o: ../src/config/soc_devices.c \
 ../src/config/feature_flags.h ../src/config/soc_config.h
../src/config/feature_flags.h:
../src/config/soc_config.h:
