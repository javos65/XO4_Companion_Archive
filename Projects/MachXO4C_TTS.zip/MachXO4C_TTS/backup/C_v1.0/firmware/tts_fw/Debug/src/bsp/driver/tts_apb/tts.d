src/bsp/driver/tts_apb/tts.o: ../src/bsp/driver/tts_apb/tts.c \
 ../src/bsp/driver/tts_apb/tts.h ../src/bsp/driver/tts_apb/tts_regs.h \
 ../src/bsp/driver/reg_access.h
../src/bsp/driver/tts_apb/tts.h:
../src/bsp/driver/tts_apb/tts_regs.h:
../src/bsp/driver/reg_access.h:
