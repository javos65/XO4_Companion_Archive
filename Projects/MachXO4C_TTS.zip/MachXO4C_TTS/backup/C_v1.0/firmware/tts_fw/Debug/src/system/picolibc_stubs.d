src/system/picolibc_stubs.o: ../src/system/picolibc_stubs.c \
 ../src/config/sys_config.h ../src/config/feature_flags.h \
 ../src/config/memory_map.h ../src/config/ip_params.h \
 ../src/bsp/driver/uart/uart_debug.h ../src/bsp/driver/cpu/cpu.h
../src/config/sys_config.h:
../src/config/feature_flags.h:
../src/config/memory_map.h:
../src/config/ip_params.h:
../src/bsp/driver/uart/uart_debug.h:
../src/bsp/driver/cpu/cpu.h:
