src/main.o: ../src/main.c ../src/config/soc_config.h \
 ../src/config/feature_flags.h ../src/bsp/sys_platform.h \
 ../src/bsp/riscv_errors.h ../src/bsp/driver/uart/uart.h \
 ../src/bsp/driver/gpio/gpio.h ../src/bsp/driver/tts_apb/tts.h \
 ../src/bsp/driver/tts_apb/tts_regs.h ../src/bsp/driver/riscv_sm/timer.h
../src/config/soc_config.h:
../src/config/feature_flags.h:
../src/bsp/sys_platform.h:
../src/bsp/riscv_errors.h:
../src/bsp/driver/uart/uart.h:
../src/bsp/driver/gpio/gpio.h:
../src/bsp/driver/tts_apb/tts.h:
../src/bsp/driver/tts_apb/tts_regs.h:
../src/bsp/driver/riscv_sm/timer.h:
