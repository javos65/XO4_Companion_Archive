# Timing constraints for tts_top (MachXO4 Companion Board).
# One external clock: 12 MHz on clk12_i (T9). The PLL inside the SoC derives the 24 MHz system clock.
create_clock -name clk12 -period 83.333 [get_ports {clk12_i}]
