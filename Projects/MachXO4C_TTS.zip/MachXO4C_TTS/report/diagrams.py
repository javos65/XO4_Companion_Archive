"""SVG diagrams of the project report. Each function returns (svg_text, width, height).

Colour code used in every figure:
  blue   - 12 MHz CPU / bus clock domain (PCLK)
  orange - 24 MHz synthesizer clock domain (TTS_CLK)
  grey   - board, top level and tool steps
  green  - clock-domain crossing logic
"""
from xml.sax.saxutils import escape

FONT = "Arial, Helvetica, sans-serif"
C = {
    "blue": "#dbe8f6", "blue_e": "#2f6aa3",
    "orange": "#fde6cf", "orange_e": "#c0661a",
    "green": "#dff2e4", "green_e": "#2e7d4f",
    "grey": "#eef0f3", "grey_e": "#6b7280",
    "ink": "#1f2937", "white": "#ffffff",
}


class Svg:
    def __init__(self, w, h):
        self.w, self.h, self.p = w, h, []

    def rect(self, x, y, w, h, fill, edge, dash=False, r=6, sw=1.5):
        d = ' stroke-dasharray="6 4"' if dash else ""
        self.p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" '
                      f'stroke="{edge}" stroke-width="{sw}"{d}/>')

    def text(self, x, y, s, size=13, bold=False, anchor="middle", color=None, italic=False):
        wgt = ' font-weight="bold"' if bold else ""
        sty = ' font-style="italic"' if italic else ""
        self.p.append(f'<text x="{x}" y="{y}" font-family="{FONT}" font-size="{size}"{wgt}{sty} '
                      f'text-anchor="{anchor}" fill="{color or C["ink"]}">{escape(s)}</text>')

    def box(self, x, y, w, h, lines, kind="grey", bold_first=True, size=13, dash=False):
        self.rect(x, y, w, h, C[kind], C[kind + "_e"], dash=dash)
        n = len(lines)
        lh = size + 4
        y0 = y + h / 2 - (n - 1) * lh / 2 + size * 0.35
        for i, s in enumerate(lines):
            self.text(x + w / 2, y0 + i * lh, s, size=size, bold=(bold_first and i == 0))

    def line(self, pts, color=None, width=1.6, arrow=True, dash=False, both=False):
        color = color or C["ink"]
        ps = " ".join(f"{x},{y}" for x, y in pts)
        mk = f' marker-end="url(#a_{color[1:]})"' if arrow else ""
        if both:
            mk += f' marker-start="url(#s_{color[1:]})"'
        d = ' stroke-dasharray="5 4"' if dash else ""
        self.p.append(f'<polyline points="{ps}" fill="none" stroke="{color}" stroke-width="{width}"{mk}{d}/>')

    def label(self, x, y, s, size=11, anchor="middle", color=None, bold=False):
        self.text(x, y, s, size=size, anchor=anchor, color=color or C["grey_e"], bold=bold)

    def render(self):
        cols = {C["ink"], C["blue_e"], C["orange_e"], C["green_e"], C["grey_e"]}
        defs = "".join(
            f'<marker id="a_{c[1:]}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" '
            f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{c}"/></marker>'
            f'<marker id="s_{c[1:]}" viewBox="0 0 10 10" refX="1" refY="5" markerWidth="7" markerHeight="7" '
            f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{c}"/></marker>' for c in cols)
        return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.w} {self.h}" width="{self.w}" '
                f'height="{self.h}"><defs>{defs}</defs><rect width="{self.w}" height="{self.h}" fill="#ffffff"/>'
                + "".join(self.p) + "</svg>")


def legend(s, x, y):
    items = [("blue", "12 MHz CPU / bus (PCLK)"), ("orange", "24 MHz synthesizer (TTS_CLK)"),
             ("green", "clock-domain crossing"), ("grey", "board / top level")]
    for i, (k, t) in enumerate(items):
        xx = x + i * 215
        s.rect(xx, y, 22, 14, C[k], C[k + "_e"], r=3)
        s.text(xx + 30, y + 12, t, size=12, anchor="start")


# ------------------------------------------------------------------ Figure 1: system architecture
def system_architecture():
    s = Svg(1120, 720)
    s.text(560, 26, "System architecture: tts_top on the MachXO4 Companion Board (LFMXO4-110HC-6BBG256I)", 16, True)
    # board pins
    s.rect(14, 50, 128, 590, C["white"], C["grey_e"], dash=True)
    s.text(78, 70, "Board pins", 13, True)
    pins = [("clk12_i  T9", 120), ("sw2_n_i  D10", 190), ("rxd_i  H15", 420), ("txd_o  J12", 460),
            ("pwm_o  H12", 560), ("dled_n_o[3:0]", 612)]
    for t, y in pins:
        s.rect(22, y - 15, 112, 26, C["grey"], C["grey_e"], r=4)
        s.text(78, y + 3, t, 12)
    s.label(78, 634, "G14 E14 G15 G13", 10)
    # tts_top
    s.rect(160, 44, 946, 640, C["white"], C["ink"], dash=True)
    s.text(176, 64, "tts_top (rtl/tts_top.v, Verilog-2001)", 13, True, anchor="start")
    s.box(178, 160, 170, 64, ["SW2 synchronizer", "+ debounce 21.8 ms"], "grey")
    s.box(214, 250, 134, 52, ["Power-on reset", "21.8 ms"], "grey")
    s.box(178, 330, 170, 46, ["AND -> soc_rstn"], "grey", bold_first=False)
    s.box(178, 580, 170, 64, ["LED mapping", "LED2 = SW2 (hardware)"], "grey")
    # tts_soc
    s.rect(370, 80, 722, 590, "#fafbfc", C["ink"], dash=True)
    s.text(386, 100, "tts_soc (Propel 2026.1.1 SoC)", 13, True, anchor="start")
    s.box(392, 118, 170, 84, ["PLL 3.0.1", "12 MHz in", "CLKOP 24 MHz", "CLKOS 12 MHz"], "grey", size=12)
    s.box(392, 300, 170, 54, ["rst_and", "rstn_i AND lock"], "grey", size=12)
    s.box(610, 118, 190, 84, ["CPU riscv_sm 1.9.0", "RV32I, PIC, timer", "debug off"], "blue")
    s.box(860, 118, 210, 84, ["System memory 2.6.0", "16 KB EBR, 2 ports", "0x0000 (firmware)"], "blue")
    s.box(610, 236, 460, 38, ["AHB-Lite interconnect 1.5.0 (1 master, 2 slaves)"], "blue", bold_first=False)
    s.box(700, 304, 280, 38, ["AHB-Lite to APB bridge 1.2.0"], "blue", bold_first=False)
    s.box(610, 372, 460, 38, ["APB interconnect 1.4.0 (1 master, 3 slaves)"], "blue", bold_first=False)
    s.box(610, 448, 140, 84, ["UART 1.6.0", "0x8000", "19200 8N1", "IRQ"], "blue", size=12)
    s.box(770, 448, 140, 84, ["GPIO 1.8.1", "0x8400", "5 lines"], "blue", size=12)
    # TTS_APB split box
    s.rect(930, 448, 140, 200, C["orange"], C["orange_e"])
    s.rect(930, 448, 140, 64, C["blue"], C["blue_e"])
    s.text(1000, 470, "TTS_APB 2.0.0", 13, True)
    s.text(1000, 488, "0x8C00", 12)
    s.text(1000, 505, "APB side (PCLK)", 11)
    s.rect(940, 520, 120, 26, C["green"], C["green_e"], r=4)
    s.text(1000, 538, "async FIFO", 11)
    s.text(1000, 568, "speech engine", 12, True)
    s.text(1000, 586, "TTSCPU, ROMs,", 11)
    s.text(1000, 602, "sample FIFO, PWM", 11)
    s.text(1000, 626, "(TTS_CLK 24 MHz)", 11)
    # bus connections
    s.line([(705, 202), (705, 236)])
    s.line([(800, 160), (860, 160)])
    s.label(830, 152, "instr", 10)
    s.line([(965, 236), (965, 202)])
    s.line([(840, 274), (840, 304)])
    s.line([(840, 342), (840, 372)])
    s.line([(680, 410), (680, 448)])
    s.line([(840, 410), (840, 448)])
    s.line([(1000, 410), (1000, 448)])
    # clocks
    s.line([(134, 120), (392, 140)], color=C["grey_e"])
    s.line([(562, 140), (585, 140), (585, 100), (1085, 100), (1085, 600), (1070, 600)], color=C["orange_e"], width=2.2)
    s.label(840, 94, "CLKOP 24 MHz -> TTS_CLK", 11, color=C["orange_e"], bold=True)
    s.line([(562, 180), (600, 180)], color=C["blue_e"], width=2.2, arrow=False)
    s.label(500, 222, "CLKOS 12 MHz -> CPU, memory,", 11, color=C["blue_e"], bold=True)
    s.label(500, 236, "bus, UART, GPIO, TTS PCLK", 11, color=C["blue_e"], bold=True)
    # resets and I/O
    s.line([(134, 190), (178, 190)])
    s.line([(196, 224), (196, 330)])
    s.line([(281, 302), (281, 330)])
    s.line([(348, 353), (370, 353), (392, 327)])
    s.label(372, 372, "rstn_i", 10)
    s.line([(420, 202), (420, 300)], color=C["grey_e"], dash=True)
    s.label(426, 290, "lock", 10, anchor="start")
    s.line([(562, 327), (590, 327), (590, 192), (610, 192)])
    s.label(566, 345, "CPU reset", 10, anchor="start")
    s.line([(134, 420), (610, 470)], both=False)
    s.line([(610, 512), (134, 460)])
    s.line([(930, 600), (480, 600), (480, 560), (134, 560)], color=C["orange_e"])
    s.label(700, 594, "PWM_OUT", 10, color=C["orange_e"])
    s.line([(840, 532), (840, 660), (300, 660), (300, 644)], color=C["blue_e"])
    s.label(570, 655, "gpio_o[3:0]: heartbeat, speech, character", 10, color=C["blue_e"])
    s.line([(178, 612), (134, 612)])
    legend(s, 180, 696)
    return s.render(), s.w, s.h


# ------------------------------------------------------------------ Figure 2: clocks and resets
def clocks_resets():
    s = Svg(1000, 430)
    s.text(500, 26, "Clock and reset structure", 16, True)
    s.box(20, 70, 140, 56, ["clk12_i (T9)", "12 MHz board clock"], "grey", size=12)
    s.box(220, 60, 170, 76, ["PLL 3.0.1", "VCO 528 MHz"], "grey")
    s.box(470, 50, 230, 40, ["CLKOP 24 MHz (div 22)"], "orange", bold_first=True)
    s.box(470, 106, 230, 40, ["CLKOS 12 MHz (div 44)"], "blue", bold_first=True)
    s.box(760, 40, 220, 58, ["TTS_APB TTS_CLK", "line buffers, TTSCPU, PWM"], "orange", size=12)
    s.box(760, 112, 220, 74, ["CPU, system memory,", "AHB-Lite, APB, UART, GPIO,", "TTS_APB PCLK"], "blue",
          bold_first=False, size=12)
    s.line([(160, 98), (220, 98)])
    s.line([(390, 80), (470, 70)], color=C["orange_e"], width=2)
    s.line([(390, 116), (470, 126)], color=C["blue_e"], width=2)
    s.line([(700, 70), (760, 69)], color=C["orange_e"], width=2)
    s.line([(700, 126), (760, 140)], color=C["blue_e"], width=2)
    s.label(20, 152, "clk12_i also clocks the SW2 debounce and the power-on reset in tts_top", 11, anchor="start")
    # reset chain
    s.text(20, 230, "Reset chain", 14, True, anchor="start")
    y = 260
    s.box(20, y, 120, 56, ["SW2 (D10)", "active low"], "grey", size=12)
    s.box(170, y, 140, 56, ["2-flop sync +", "debounce 21.8 ms"], "grey", bold_first=False, size=12)
    s.box(170, y + 80, 140, 44, ["Power-on 21.8 ms"], "grey", bold_first=False, size=12)
    s.box(340, y + 20, 100, 56, ["AND +", "register"], "grey", bold_first=False, size=12)
    s.box(470, y + 20, 120, 56, ["rst_and", "AND PLL lock"], "grey", size=12)
    s.box(620, y + 20, 140, 56, ["CPU reset", "system_resetn_o"], "blue", size=12)
    s.box(790, y, 190, 44, ["Bus, UART, GPIO"], "blue", bold_first=False, size=12)
    s.box(790, y + 60, 190, 72, ["TTS_APB RST_N", "sync into PCLK and", "TTS_CLK domains"], "green", size=12)
    s.line([(140, y + 28), (170, y + 28)])
    s.line([(310, y + 28), (340, y + 40)])
    s.line([(310, y + 102), (340, y + 60)])
    s.line([(440, y + 48), (470, y + 48)])
    s.line([(590, y + 48), (620, y + 48)])
    s.line([(760, y + 40), (790, y + 22)], color=C["blue_e"])
    s.line([(760, y + 56), (790, y + 92)], color=C["blue_e"])
    s.label(390, y + 98, "soc_rstn", 11)
    legend(s, 120, 410)
    return s.render(), s.w, s.h


# ------------------------------------------------------------------ Figure 3: TTS_APB 2.0.0 internals
def tts_apb_internals():
    s = Svg(1120, 600)
    s.text(560, 26, "TTS_APB 2.0.0 (custom:module:tts_apb:2.0.0): internal structure", 16, True)
    # domains
    s.rect(14, 46, 330, 520, "#f3f8fd", C["blue_e"], dash=True)
    s.text(179, 68, "PCLK domain (any frequency)", 13, True, color=C["blue_e"])
    s.rect(360, 46, 220, 520, "#f3fbf5", C["green_e"], dash=True)
    s.text(470, 68, "Clock-domain crossing", 13, True, color=C["green_e"])
    s.rect(596, 46, 510, 520, "#fef6ee", C["orange_e"], dash=True)
    s.text(851, 68, "TTS_CLK domain (24 MHz)", 13, True, color=C["orange_e"])
    # PCLK side
    s.box(30, 90, 300, 62, ["APB slave APB_S0", "PADDR[3:0] PSEL PENABLE PWRITE", "PWDATA PRDATA PREADY"], "blue", size=12)
    s.box(30, 180, 300, 86, ["Register file", "0x00 ID 0x54545302   0x04 CTRL", "0x08 STATUS   0x0C DATA",
                             "last character written"], "blue", size=12)
    s.box(30, 296, 300, 62, ["FIFO write side", "push {CLEAR, START, char}", "write pointer (gray)"], "blue", size=12)
    s.box(30, 388, 300, 62, ["Status capture", "p_stat, p_cnt (entries executed)"], "blue", size=12)
    s.box(30, 480, 300, 66, ["PREADY wait states", "write: FIFO full", "STATUS read: snapshot not current"],
          "blue", size=12)
    # crossing
    s.box(378, 260, 184, 110, ["Async command FIFO", "8 x 10 bit", "gray pointers,", "2-flop synchronizers"],
          "green", size=12)
    s.box(378, 390, 184, 92, ["Status snapshot", "request / acknowledge", "{LEN, flags, count}"], "green", size=12)
    s.box(378, 100, 184, 76, ["Reset synchronizers", "RST_N into both", "domains"], "green", size=12)
    # TTS side
    s.box(612, 260, 200, 110, ["Command execution", "one entry, then 3 idle", "clocks; START / CLEAR",
                               "BUSY DONE DROP"], "orange", size=12)
    s.box(612, 100, 200, 120, ["Line buffers", "2 x 128 characters", "(ping-pong, CR/LF ends", "a line, tone commands)"],
          "orange", size=12)
    s.box(850, 90, 240, 210, ["TTSCPU speech processor", "32-bit, 16 registers,", "serial multiplier",
                              "program ROM 2048 x 32", "byte ROM 8 KB (rules,", "phonemes), table ROM", "data RAM 1024 x 32"],
          "orange", size=12)
    s.box(850, 324, 240, 54, ["Sample FIFO", "16 x 20 bit (16 kHz samples)"], "orange", size=12)
    s.box(850, 398, 240, 54, ["Fade in / out", "no clicks at start and end"], "orange", size=12)
    s.box(850, 472, 240, 62, ["PWM 10 bit", "32 kHz carrier (750 clocks)"], "orange", size=12)
    s.text(1000, 590, "PWM_OUT -> pin H12", 12, True, color=C["orange_e"])
    # arrows
    s.line([(180, 152), (180, 180)], color=C["blue_e"], both=True)
    s.line([(180, 266), (180, 296)], color=C["blue_e"])
    s.line([(330, 327), (378, 315)], color=C["blue_e"])
    s.line([(562, 315), (612, 315)], color=C["green_e"], width=2)
    s.line([(712, 260), (712, 220)], color=C["orange_e"])
    s.label(718, 245, "characters", 10, anchor="start")
    s.line([(812, 160), (850, 160)], color=C["orange_e"])
    s.label(831, 152, "text", 10)
    s.line([(812, 300), (850, 230)], color=C["orange_e"])
    s.label(820, 285, "start", 10, anchor="start")
    s.line([(970, 300), (970, 324)], color=C["orange_e"])
    s.line([(970, 378), (970, 398)], color=C["orange_e"])
    s.line([(970, 452), (970, 472)], color=C["orange_e"])
    s.line([(970, 534), (970, 575)], color=C["orange_e"], width=2)
    s.line([(712, 370), (712, 436), (562, 436)], color=C["orange_e"])
    s.label(640, 430, "status", 10)
    s.line([(378, 436), (330, 419)], color=C["green_e"])
    s.line([(30, 419), (22, 419), (22, 223), (30, 223)], color=C["blue_e"])
    s.label(26, 380, "STATUS", 10, anchor="start")
    return s.render(), s.w, s.h + 6


# ------------------------------------------------------------------ Figure 4: IPK build and integration flow
def ipk_flow():
    s = Svg(1120, 420)
    s.text(560, 26, "TTS_APB 2.0.0: IPK module build and integration flow", 16, True)
    row1 = [("TTS_APB 1.5.0", ["PropelIPLocal", "one clock"], "grey"),
            ("Source folder", ["ip\\custom_module_", "tts_apb_2.0.0"], "orange"),
            ("RTL change", ["tts_apb.v: TTS_CLK,", "FIFO, snapshot"], "orange"),
            ("Questa simulation", ["tb_tts_apb2: 26/26", "tb_tts_eq: identical"], "green"),
            ("Packaging", ["ippkg.exe + list files", "-> .ipk (16 files)"], "orange")]
    row2 = [("IP Catalog install", ["PropelIPLocal", "tts_apb 2.0.0"], "grey"),
            ("Propel SoC", ["tts_soc script,", "PLL 24 / 12 MHz"], "blue"),
            ("SGE + firmware", ["driver tts_apb,", "rv32i, bin2mem"], "blue"),
            ("Radiant build", ["LSE, timing met,", "bitstream + JEDEC"], "grey"),
            ("Release C_v1.1", ["programmed,", "confirmed on board"], "green")]
    w, h, gap, x0 = 190, 92, 34, 20
    for i, (t, sub, k) in enumerate(row1):
        x = x0 + i * (w + gap)
        s.box(x, 70, w, h, [t] + sub, k, size=12)
        if i:
            s.line([(x - gap + 2, 116), (x - 2, 116)])
    xl = x0 + 4 * (w + gap) + w / 2
    s.line([(xl, 162), (xl, 200), (x0 + w / 2, 200), (x0 + w / 2, 236)])
    for i, (t, sub, k) in enumerate(row2):
        x = x0 + i * (w + gap)
        s.box(x, 240, w, h, [t] + sub, k, size=12)
        if i:
            s.line([(x - gap + 2, 286), (x - 2, 286)])
    s.label(560, 370, "Engine files (ttscpu, tts_roms, tts_engine, line_buf, sample_fifo, pwm10) unchanged; "
                      "driver API unchanged, ID 0x54545302", 12)
    s.label(560, 392, "Installed copy: C:\\Users\\<name>\\PropelIPLocal\\custom_module_tts_apb_2.0.0", 12)
    return s.render(), s.w, s.h


FIGURES = {
    "fig_system": (system_architecture, "Figure 1. System architecture of tts_top and the Propel SoC."),
    "fig_clocks": (clocks_resets, "Figure 2. Clock and reset structure."),
    "fig_tts_apb": (tts_apb_internals, "Figure 3. Internal structure of the TTS_APB 2.0.0 IPK module."),
    "fig_ipk_flow": (ipk_flow, "Figure 4. IPK module build and integration flow."),
}
