"""Generates the report as HTML and Word (.docx) from the content model in report_content.py.

Run:  python -I make_report.py
Writes <basename>.html and <basename>.docx beside this script (basename from report_content.py). Uses the Python standard
library only (the Word file is written as plain WordprocessingML parts in a ZIP archive).
"""
import os
import zipfile
from html import escape
from xml.sax.saxutils import escape as xesc

HERE = os.path.dirname(os.path.abspath(__file__))

import re
import subprocess
import sys
sys.path.insert(0, HERE)        # python -I does not add the script folder to the import path
from report_content import R   # content model (edit report_content.py, then rerun this script)
import diagrams                 # SVG figures (diagrams.FIGURES)

# ---------------------------------------------------------------- figures (SVG for HTML, PNG for Word)
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
FIGDIR = os.path.join(HERE, "fig")
FIG = {}


def render_figs():
    """Writes fig/<name>.svg and renders fig/<name>.png (2x) with headless Edge."""
    os.makedirs(FIGDIR, exist_ok=True)
    profile = os.path.join(os.environ.get("TEMP", HERE), "edge_render_profile")
    for name, (fn, caption) in diagrams.FIGURES.items():
        svg, w, h = fn()
        svg_path = os.path.join(FIGDIR, name + ".svg")
        png_path = os.path.join(FIGDIR, name + ".png")
        with open(svg_path, "w", encoding="utf-8") as f:
            f.write(svg)
        if os.path.exists(png_path):
            os.remove(png_path)
        subprocess.run([EDGE, "--headless=new", "--disable-gpu", "--no-first-run", "--hide-scrollbars",
                        f"--user-data-dir={profile}", "--force-device-scale-factor=2", f"--window-size={w},{h}",
                        f"--screenshot={png_path}", "file:///" + svg_path.replace("\\", "/")],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
        if not os.path.exists(png_path):
            raise RuntimeError("figure not rendered: " + png_path)
        FIG[name] = {"svg": svg, "w": w, "h": h, "caption": caption, "png": png_path}

# ---------------------------------------------------------------- HTML
def html_table(cols, rows):
    head = "".join(f"<th>{escape(c)}</th>" for c in cols)
    body = "".join("<tr>" + "".join(f"<td>{escape(c)}</td>" for c in r) + "</tr>" for r in rows)
    return f'<div class="tw"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def make_html():
    parts = []
    for s in R["sections"]:
        out = [f"<section><h2>{escape(s['h'])}</h2>"]
        out += [f"<p>{escape(p)}</p>" for p in s.get("p", [])]
        for name in s.get("fig", []):
            fg = FIG[name]
            svg = re.sub(r' width="\d+" height="\d+"', "", fg["svg"], count=1)
            out.append(f'<figure><div class="svgw">{svg}</div><figcaption>{escape(fg["caption"])}</figcaption></figure>')
        if s.get("list"):
            out.append("<ul>" + "".join(f"<li>{escape(x)}</li>" for x in s["list"]) + "</ul>")
        if s.get("table"):
            out.append(html_table(*s["table"]))
        out.append("</section>")
        parts.append("".join(out))
    css = """
:root{--bg:#f6f7f9;--sf:#fff;--ink:#16191f;--ink2:#4b5563;--rule:#d9dee5;--acc:#1d5471;--th:#eef2f6}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#0f1218;--sf:#161a21;--ink:#e6eaf0;--ink2:#a5aebb;--rule:#2b313b;--acc:#79b5d8;--th:#1d222b}}
:root[data-theme="dark"]{--bg:#0f1218;--sf:#161a21;--ink:#e6eaf0;--ink2:#a5aebb;--rule:#2b313b;--acc:#79b5d8;--th:#1d222b}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 system-ui,"Segoe UI",sans-serif}
main{max-width:960px;margin:0 auto;padding:24px 16px 64px}h1{font-size:28px;margin:0 0 4px}.sub{color:var(--ink2);margin:0 0 24px}
section{background:var(--sf);border:1px solid var(--rule);border-radius:6px;padding:16px 20px;margin:0 0 16px}
h2{font-size:18px;color:var(--acc);margin:0 0 10px}.tw{overflow-x:auto}
figure{margin:12px 0 16px}.svgw{background:#fff;border:1px solid var(--rule);border-radius:4px;overflow-x:auto;padding:4px}
.svgw svg{display:block;width:100%;height:auto;min-width:640px}figcaption{color:var(--ink2);font-size:13px;margin-top:6px}
table{border-collapse:collapse;width:100%;font-size:14px}th,td{border:1px solid var(--rule);padding:6px 8px;text-align:left;vertical-align:top}th{background:var(--th)}
"""
    return ("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            f"<title>TTS Project Report</title><style>{css}</style></head><body><main>"
            f"<h1>{escape(R['title'])}</h1><p class=\"sub\">{escape(R['subtitle'])} &middot; {escape(R['date'])}</p>"
            + "\n".join(parts) + "</main></body></html>")

# ---------------------------------------------------------------- Word (WordprocessingML)
W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
FULL = 9026  # A4 text width in twips with 1-inch margins
WIDTHS = {2: [2600, 6426], 3: [2000, 3400, 3626], 4: [1700, 2500, 3226, 1600]}


def run(text, bold=False, size=None, color=None):
    rpr = ""
    if bold or size or color:
        rpr = "<w:rPr>" + ("<w:b/>" if bold else "") + (f'<w:color w:val="{color}"/>' if color else "") + \
              (f'<w:sz w:val="{size}"/>' if size else "") + "</w:rPr>"
    return f'<w:r>{rpr}<w:t xml:space="preserve">{xesc(text)}</w:t></w:r>'


def para(text="", style=None, bullet=False, after=None, **kw):
    ppr = ""
    if style or bullet or after is not None:
        ppr = "<w:pPr>" + (f'<w:pStyle w:val="{style}"/>' if style else "") + \
              ('<w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr>' if bullet else "") + \
              (f'<w:spacing w:after="{after}"/>' if after is not None else "") + "</w:pPr>"
    return f"<w:p>{ppr}{run(text, **kw) if text else ''}</w:p>"


COL_OVERRIDE = {("Signal", "Pin", "Function"): [1900, 900, 6226],
                ("ID", "Deviation", "Reason"): [900, 3700, 4426]}


def word_table(cols, rows):
    w = COL_OVERRIDE.get(tuple(cols), WIDTHS[len(cols)])
    bd = '<w:top w:val="single" w:sz="4" w:color="BFC6D0"/><w:left w:val="single" w:sz="4" w:color="BFC6D0"/>' \
         '<w:bottom w:val="single" w:sz="4" w:color="BFC6D0"/><w:right w:val="single" w:sz="4" w:color="BFC6D0"/>' \
         '<w:insideH w:val="single" w:sz="4" w:color="BFC6D0"/><w:insideV w:val="single" w:sz="4" w:color="BFC6D0"/>'

    def cell(t, i, head):
        shd = '<w:shd w:val="clear" w:color="auto" w:fill="E8EDF3"/>' if head else ""
        return (f'<w:tc><w:tcPr><w:tcW w:w="{w[i]}" w:type="dxa"/>{shd}</w:tcPr>'
                f'<w:p><w:pPr><w:spacing w:after="0"/></w:pPr>{run(t, bold=head, size=19)}</w:p></w:tc>')
    grid = "".join(f'<w:gridCol w:w="{x}"/>' for x in w)
    hdr = '<w:tr><w:trPr><w:tblHeader/></w:trPr>' + "".join(cell(c, i, True) for i, c in enumerate(cols)) + "</w:tr>"
    body = "".join("<w:tr>" + "".join(cell(c, i, False) for i, c in enumerate(r)) + "</w:tr>" for r in rows)
    return (f'<w:tbl><w:tblPr><w:tblW w:w="{FULL}" w:type="dxa"/><w:tblBorders>{bd}</w:tblBorders>'
            '<w:tblLayout w:type="fixed"/><w:tblCellMar><w:left w:w="100" w:type="dxa"/>'
            f'<w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>{grid}</w:tblGrid>{hdr}{body}</w:tbl>')


EMU_PER_TWIP = 635


def figure_para(fg, n, rid):
    """Inline picture (full text width) plus an italic caption paragraph."""
    cx = FULL * EMU_PER_TWIP
    cy = int(cx * fg["h"] / fg["w"])
    pic = (f'<w:p><w:pPr><w:keepNext/><w:spacing w:before="120" w:after="40"/><w:jc w:val="center"/></w:pPr><w:r><w:drawing>'
           f'<wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/>'
           f'<wp:docPr id="{n}" name="Figure {n}"/><wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/>'
           f'</wp:cNvGraphicFramePr><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
           f'<pic:pic><pic:nvPicPr><pic:cNvPr id="{n}" name="figure{n}.png"/><pic:cNvPicPr/></pic:nvPicPr>'
           f'<pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
           f'<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
           f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic>'
           f'</wp:inline></w:drawing></w:r></w:p>')
    cap = (f'<w:p><w:pPr><w:spacing w:after="200"/><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:i/><w:color w:val="4B5563"/>'
           f'<w:sz w:val="18"/></w:rPr><w:t xml:space="preserve">{xesc(fg["caption"])}</w:t></w:r></w:p>')
    return pic + cap


def make_docx(path):
    b = [para(R["title"], style="Title"), para(f"{R['subtitle']}, {R['date']}", after=240, color="4B5563")]
    media = []                                   # (rid, zip name, png path)
    for s in R["sections"]:
        b.append(para(s["h"], style="Heading1"))
        b += [para(p, after=120) for p in s.get("p", [])]
        for name in s.get("fig", []):
            n = len(media) + 1
            rid = f"rIdImg{n}"
            media.append((rid, f"media/figure{n}.png", FIG[name]["png"]))
            b.append(figure_para(FIG[name], n, rid))
        b += [para(x, bullet=True, after=60) for x in s.get("list", [])]
        if s.get("table"):
            b.append(word_table(*s["table"]))
            b.append(para(after=120))
    sect = ('<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" '
            'w:left="1440" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>')
    ns = (W + ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'
          ' xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"'
          ' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"'
          ' xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"')
    document = f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {ns}><w:body>{"".join(b)}{sect}</w:body></w:document>'
    styles = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles {W}>'
              '<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>'
              '<w:sz w:val="21"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="80" w:line="264" '
              'w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>'
              '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>'
              '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/>'
              '<w:pPr><w:keepNext/><w:spacing w:before="0" w:after="80"/></w:pPr><w:rPr><w:b/><w:sz w:val="40"/></w:rPr></w:style>'
              '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/>'
              '<w:next w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="280" w:after="120"/><w:outlineLvl w:val="0"/>'
              '</w:pPr><w:rPr><w:b/><w:color w:val="1D5471"/><w:sz w:val="28"/></w:rPr></w:style></w:styles>')
    numbering = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering {W}>'
                 '<w:abstractNum w:abstractNumId="0"><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="bullet"/>'
                 '<w:lvlText w:val="\u2022"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="540" w:hanging="270"/></w:pPr>'
                 '</w:lvl></w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num></w:numbering>')
    ctypes = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
              '<Default Extension="xml" ContentType="application/xml"/>'
              '<Default Extension="png" ContentType="image/png"/>'
              '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
              '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
              '<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>'
              '</Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '</Relationships>')
    doc_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>'
                + "".join(f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                          f'relationships/image" Target="{zname}"/>' for rid, zname, _ in media)
                + '</Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ctypes)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", document)
        z.writestr("word/styles.xml", styles)
        z.writestr("word/numbering.xml", numbering)
        z.writestr("word/_rels/document.xml.rels", doc_rels)
        for _, zname, png in media:
            z.write(png, "word/" + zname)


if __name__ == "__main__":
    render_figs()
    with open(os.path.join(HERE, R["basename"] + ".html"), "w", encoding="utf-8", newline="\n") as f:
        f.write(make_html())
    make_docx(os.path.join(HERE, R["basename"] + ".docx"))
    print("written: " + R["basename"] + ".html, " + R["basename"] + ".docx")
