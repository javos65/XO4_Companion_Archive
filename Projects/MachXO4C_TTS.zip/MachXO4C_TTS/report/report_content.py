"""Content model of the project report (release C_v1.1). Rendered by make_report.py as HTML and Word."""

R = {
    "basename": "project_report",
    "title": "MachXO4 Companion Board Text-to-Speech SoC",
    "subtitle": "Project report, release C_v1.1",
    "date": "2026-11-18",
    "sections": [
        {"h": "1. Summary", "p": [
            "A Propel RISC-V SoC on the MachXO4 Companion Board receives text over a UART and speaks it through a custom "
            "speech peripheral, TTS_APB. The speech engine runs entirely inside the FPGA: a small speech processor converts "
            "text to phonemes and a formant synthesizer produces 16 kHz audio on one PWM pin.",
            "In this project the TTS_APB library block was adapted from version 1.5.0 (one clock) to version 2.0.0 (separate "
            "bus and synthesizer clocks), and the SoC was built for the new board with a 24 MHz synthesizer clock and a "
            "12 MHz CPU and bus clock. Release C_v1.1 is built, programmed into the internal flash and confirmed working on "
            "the board by the project owner."],
         "table": (["Item", "Result"], [
             ["Device", "LFMXO4-110HC-6BBG256I (MachXO4, 256-ball BGA, speed grade 6)"],
             ["Speech block", "TTS_APB 2.0.0 (custom:module:tts_apb:2.0.0), packaged as .ipk and installed in Propel"],
             ["Clocks", "Synthesizer 24 MHz (Fmax 27.2 MHz); CPU and bus 12 MHz (Fmax 34.2 MHz)"],
             ["Timing", "0 failing endpoints in all three corners"],
             ["Resources", "6116 LUT4 (65%), 2068 registers (22%), 44 of 48 block RAMs (92%), 1 of 2 PLLs"],
             ["Simulation", "Register-level test 26 of 26 checks; PWM output identical to 1.5.0 (213944 pulses)"],
             ["Hardware", "Programmed (Operation successful) and confirmed working on the board"]])},

        {"h": "2. Goal and requirements", "list": [
            "Speak English text received over a UART (19200 baud 8N1) through a speaker on one PWM pin, with status "
            "messages TTS OK., TTS EXE and TTS RDY, LEDs, and a tone jingle every 10 minutes.",
            "Target the new MachXO4 Companion Board (LFMXO4-110HC-6BBG256I); no online board data exists, so the schematic "
            "and the pin-out workbook are the only pin reference.",
            "Reuse the existing speech engine as a Propel library block with a BSP driver; the RISC-V firmware uses driver "
            "functions only.",
            "Decouple the speech timing from the CPU clock: the synthesizer gets its own 24 MHz clock so the CPU and bus "
            "clock can be chosen freely.",
            "Tools: Lattice Propel 2026.1.1, Radiant 2026.1.1 (LSE), Questa 2026.1.1, RISC-V GCC 10.2.0. HDL Verilog-2001, "
            "all I/O LVCMOS33.",
            "Every step is released with bitstream, JEDEC file, chain file, programming script, README with SHA256 hashes "
            "and a sources archive; decisions and deviations are recorded in design_plan.html."]},

        {"h": "3. System architecture", "p": [
            "The 12 MHz board clock feeds a PLL with two outputs. CLKOP (24 MHz) clocks only the synthesizer side of "
            "TTS_APB. CLKOS (12 MHz) clocks the RISC-V CPU, the system memory, the AHB-Lite and APB bus, the UART, the GPIO "
            "and the APB side of TTS_APB. The CPU fetches instructions from port 0 of the system memory and reaches port 1 "
            "and the peripherals through an AHB-Lite interconnect, an AHB-Lite to APB bridge and an APB interconnect."],
         "fig": ["fig_system", "fig_clocks"],
         "table": (["Instance", "IP and version", "Settings", "Address"], [
             ["pll0_inst", "pll 3.0.1", "12 MHz in; CLKOP 24 MHz (div 22), CLKOS 12 MHz (div 44), lock port", "-"],
             ["cpu0_inst", "riscv_sm 1.9.0", "RV32I, debug off, PIC and timer on, 1 IRQ", "PIC/timer 0xFFFF0000"],
             ["sysmem0_inst", "system_memory 2.6.0", "16 KB EBR, 2 AHB-Lite ports, firmware initialised", "0x0000"],
             ["ahbl0_inst", "ahb_lite_interconnect 1.5.0", "1 master, 2 slaves", "-"],
             ["ahbl2apb0_inst", "ahb_lite_to_apb_bridge 1.2.0", "-", "-"],
             ["apb0_inst", "apb_interconnect 1.4.0", "1 master, 3 slaves", "-"],
             ["uart0_inst", "uart 1.6.0", "12 MHz clock, 19200 8N1, IRQ to CPU", "0x8000"],
             ["gpio0_inst", "gpio 1.8.1", "5 lines: 3..0 LEDs, 4 SW2 input", "0x8400"],
             ["tts0_inst", "custom:module:tts_apb:2.0.0", "PCLK 12 MHz, TTS_CLK 24 MHz", "0x8C00"],
             ["rst_and_0", "glue logic", "rstn_i AND PLL lock to the CPU reset", "-"]])},

        {"h": "4. Top level, pins and constraints", "p": [
            "rtl/tts_top.v wraps the SoC: SW2 two-flop synchronizer and 21.8 ms debounce, 21.8 ms power-on reset, and the "
            "SW2-pressed LED driven in hardware. Inputs have no internal pull (PULLMODE NONE), so an idle UART RX is not "
            "pulled low."],
         "table": (["Signal", "Pin", "Function"], [
             ["clk12_i", "T9", "12 MHz board clock (F_12MHz)"],
             ["sw2_n_i", "D10", "SW2, active low, restarts the design"],
             ["rxd_i", "H15", "UART RX from Raspberry Pi TX (HAT40)"],
             ["txd_o", "J12", "UART TX to Raspberry Pi RX (HAT40)"],
             ["pwm_o", "H12", "Audio PWM, PMOD_1, to the BC547 amplifier"],
             ["dled_n_o[3:0]", "G13, G15, E14, G14", "LED4 character, LED3 speech, LED2 SW2, LED1 heartbeat (low = lit)"]])},

        {"h": "5. IPK module: TTS_APB", "p": [
            "TTS_APB is the speech engine packaged as a Propel library block (.ipk) with an APB slave interface, a BSP "
            "driver and documentation. Version 1.5.0 existed in the Propel library; version 2.0.0 was built in this project "
            "in its own IP directory (ip\\custom_module_tts_apb_2.0.0)."],
         "fig": ["fig_tts_apb"],
         "list": [
             "Speech engine (unchanged from 1.5.0): TTSCPU, a small 32-bit processor with a serial multiplier, runs the "
             "letter-to-sound, prosody and formant synthesis firmware from block-RAM ROMs; a sample FIFO feeds a 10-bit PWM "
             "(32 kHz carrier, 16 kHz samples). Two 128-character line buffers let one line be received while another is "
             "spoken.",
             "Why 2.0.0: in 1.5.0 the APB interface and the synthesizer share one clock, so a different CPU and bus clock "
             "changes the speech. The synthesizer needs 24 MHz (about 920 of the 1500 clocks per sample are used), so it "
             "gets its own clock input TTS_CLK; PCLK can be any frequency.",
             "Clock domain crossing: APB writes pass in order through an 8-entry asynchronous command FIFO with gray-coded "
             "pointers; the status returns as a request/acknowledge snapshot; PREADY inserts wait states while the FIFO is "
             "full and on a STATUS read until all earlier writes are reflected; RST_N is synchronised into each domain. "
             "Only the top file tts_apb.v changed; the engine files are byte-identical.",
             "Registers: ID 0x54545302, CTRL (START, CLEAR), STATUS (BUSY, READY, DONE, PLAY, DROP, LEN), DATA. Driver "
             "functions tts_init, read_tts_status, write_tts_control and write_tts_phrase are unchanged; TTS_ID_VALUE is "
             "updated.",
             "Documentation: doc/introduction.html with a Clocks section (ports, why 24 MHz, crossing, integration) and "
             "revision 2.0.",
             "Packaging: ippkg.exe (command-line IP Packager engine) with list files for metadata, RTL and driver, "
             "producing custom_module_tts_apb_2.0.0.ipk (16 files). Installed through the Propel IP Catalog into "
             "C:\\Users\\<name>\\PropelIPLocal; confirmed with an IP catalog search."],
         "table": (["Verification (Questa)", "Result"], [
             ["tb_tts_apb2: 1.5.0 register-level test with wait states, PCLK 12 MHz, TTS_CLK 24 MHz", "26 of 26 checks ok"],
             ["tb_tts_eq: 1.5.0 and 2.0.0 side by side on speech, tone commands and the boot phrase",
              "213944 PWM pulses identical"]])},

        {"h": "6. Firmware", "list": [
            "C for rv32i (no multiplier), Propel SDK project generated from the SGE; main() uses driver functions only and "
            "takes addresses and the 12 MHz clock from the generated soc_config.h.",
            "Reset: \"TTS OK.\" and the boot phrase; characters received meanwhile are discarded.",
            "Text: each character goes to TTS_APB; per line \"TTS EXE\", START, wait for BUSY to clear, \"TTS RDY\".",
            "Jingle: two tone phrases every 10 minutes (RISC-V timer at 12 MHz) when the block is idle.",
            "Image: 5444 bytes of 16384, embedded in the system memory and confirmed in the generated RTL."]},

        {"h": "7. Build flow", "fig": ["fig_ipk_flow"], "list": [
            "TTS_APB 2.0.0: RTL change, simulation, packaging with ippkg.exe, installation in the Propel IP catalog.",
            "Propel: SoC created from a script, generated, DRC passed, SGE generated.",
            "Firmware: project generated from the SGE, compiled (rv32i), converted with bin2mem, loaded into the system "
            "memory, SoC and SGE regenerated.",
            "Radiant: project created by a Tcl script (LSE, loop limit 20000, memory search path, all .ipx files), "
            "synthesis, map, place and route, bitstream and JEDEC file.",
            "Release C_v1.1: bitstream, JEDEC, chain file, programming script, README with SHA256 hashes, sources archive."]},

        {"h": "8. Results", "table": (["Measure", "Value"], [
            ["Timing", "0 failing endpoints (setup 100 C, setup -40 C, hold -40 C)"],
            ["TTS clock (CLKOP)", "Target 24 MHz, Fmax 27.2 MHz"],
            ["CPU and bus clock (CLKOS)", "Target 12 MHz, Fmax 34.2 MHz"],
            ["LUT4", "6116 of 9400 (65%)"],
            ["Registers", "2068 of 9400 (22%)"],
            ["Block RAM", "44 of 48 (92%): TTS_APB 24, system memory 16, CPU 4"],
            ["PLL", "1 of 2"],
            ["Firmware", "5444 of 16384 bytes (33%)"],
            ["Constraint coverage", "99.93%; asynchronous and slow I/O waived"],
            ["Programming", "Internal flash, Erase, Program, Verify: Operation successful"],
            ["Hardware", "Speech, status messages, LEDs confirmed working by the project owner"]])},

        {"h": "9. Block RAM by IP block", "table": (["IP block", "EBR"], [
            ["TTS_APB: program ROM (2048 x 32)", "8"],
            ["TTS_APB: byte ROM (letter-to-sound rules, phoneme tables)", "8"],
            ["TTS_APB: TTSCPU data RAM (1024 x 32)", "4"],
            ["TTS_APB: table ROM (1024 x 16)", "2"],
            ["TTS_APB: text line buffers (2 x 128)", "2"],
            ["system_memory (16 KB)", "16"],
            ["riscv_sm CPU (internal memory, most likely the register file)", "4"],
            ["Free", "4"]])},

        {"h": "10. Releases", "table": (["Release", "Content"], [
            ["C_v1.0", "TTS_APB 1.5.0, one 24 MHz system clock; built, programmed and confirmed working"],
            ["C_v1.1", "TTS_APB 2.0.0, PLL 24 MHz synthesizer and 12 MHz CPU/bus clock, UART at 12 MHz; built, "
                       "programmed and confirmed working"]])},

        {"h": "11. Deviations (all accepted)", "table": (["ID", "Deviation", "Reason"], [
            ["DV-1", "Firmware makefiles changed from rv32im to rv32i", "CPU has no multiplier; generator has no ISA option"],
            ["DV-2", "riscv_sm/crt0.S removed from the firmware project", "Duplicate _start broke the link"],
            ["DV-3", "PULLMODE NONE on clk12_i, sw2_n_i, rxd_i", "Default pull-down would hold an idle UART RX low"]])},

        {"h": "12. Notes and next steps", "list": [
            "Block RAM is the limiting resource (4 free). Reducing the system memory from 16 KB to 8 KB would free 8 blocks "
            "and still hold the 5.4 KB firmware with stack and data.",
            "The CPU and bus clock can be raised (Fmax 34.2 MHz) without affecting the speech; the UART and timer follow "
            "the configured clock.",
            "Programming is done with the release script (pgrcmd); the result is read from programmer.log. The IP install "
            "step can stay silent long after it has finished; an IP catalog search confirms it.",
            "The project prompt (doc/MachXO4_TTS_Prompt_2026_1.md) describes both parts and rebuilds this result."]},
    ],
}
