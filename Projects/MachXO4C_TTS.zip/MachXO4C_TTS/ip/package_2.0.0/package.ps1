# Packages TTS_APB 2.0.0 with the IP Packager engine on the command line (ippkg.exe; not the GUI programs).
# Output: custom_module_tts_apb_2.0.0.ipk in this folder, plus ippkg_out.txt / ippkg_err.txt.
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$blk  = (Resolve-Path (Join-Path $here '..\custom_module_tts_apb_2.0.0')).Path
$env:FOUNDRY = 'C:\lscc\propel\2026.1.1\builder\rtf\ispfpga'
$pkg  = "$env:FOUNDRY\bin\nt64\ippkg.exe"
$meta = @("$blk\metadata.xml", "$blk\bus_interface.xml", "$blk\memory_map.xml")
$rtl  = @('tts_apb.v','ttscpu.v','tts_roms.v','sample_fifo.v','tts_engine.v','pwm10.v','line_buf.v') | % { "$blk\rtl\$_" }
$drv  = @('tts_regs.h','tts.c','tts.h','tts_apb.xml') | % { "$blk\driver\$_" }
$out  = "$here\custom_module_tts_apb_2.0.0.ipk"
if (Test-Path $out) { Remove-Item $out }
# the -*_files options take a list file (one path per line), as in the 1.5.0 package folder
$enc = New-Object Text.UTF8Encoding($false)
[IO.File]::WriteAllLines("$here\metadata_list.txt", [string[]]$meta, $enc)
[IO.File]::WriteAllLines("$here\rtl_list.txt",      [string[]]$rtl,  $enc)
[IO.File]::WriteAllLines("$here\driver_list.txt",   [string[]]$drv,  $enc)
& $pkg -metadata_files "$here\metadata_list.txt" -rtl_files "$here\rtl_list.txt" -driver_files "$here\driver_list.txt" `
    -help_file "$blk\doc\introduction.html" -o $out `
    1> "$here\ippkg_out.txt" 2> "$here\ippkg_err.txt"
"exit=$LASTEXITCODE"
Get-Content "$here\ippkg_out.txt","$here\ippkg_err.txt"
if (Test-Path $out) {
    Add-Type -A System.IO.Compression.FileSystem
    $z = [IO.Compression.ZipFile]::OpenRead($out); $z.Entries | % FullName; $z.Dispose()
}
