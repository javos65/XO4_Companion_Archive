MachXO4 Companion Board TTS, release C_v1.0 (TTS_APB library block 1.5.0), built 2026-11-15
Status:   BUILT AND PROGRAMMED, functions confirmed working on the board by the project owner (2026-11-15).
          Programmed into the internal flash twice on 2026-11-15, both with the approval of the project owner:
            15:28:39-15:29:32  batch programmer (pgrcmd/programmerc, USB2 FTUSB-0, 7.5 MHz)
            15:32:13-15:33:04  Radiant Programmer GUI, by the project owner
          Both runs: "JTAG Chain Verification. No Errors.", Erase,Program,Verify, "Operation: successful."
          Programmer log: %APPDATA%\LatticeSemi\DiamondNG\programmer.log (previous run rotated to programmer-old.log).
Device:   LFMXO4-110HC-6BBG256I (speed grade 6), MachXO4 Companion Board Rev A.
Tools:    Lattice Propel 2026.1.1 and Radiant 2026.1.1 (LSE, loop limit 20000), RISC-V GCC 10.2.0 (Propel SDK).

Design:
  - Propel RISC-V SoC tts_soc: pll 3.0.1 (12 -> 24 MHz), riscv_sm 1.9.0 (RV32I, debug off), system_memory 2.6.0 (16 KB at 0x0000,
    initialised with the firmware), AHB-Lite/APB fabric, uart 1.6.0 at 0x8000 (19200 8N1, IRQ), gpio 1.8.1 at 0x8400 (5 lines),
    custom:module:tts_apb:1.5.0 at 0x8C00.
  - Top level rtl/tts_top.v: SW2 synchronizer and 21.8 ms debounce, 21.8 ms power-on reset, SW2-pressed LED in hardware.
  - Pins (all LVCMOS33): clk12_i T9, sw2_n_i D10, rxd_i H15 (Raspberry Pi TX), txd_o J12 (Raspberry Pi RX), pwm_o H12 (PMOD_1),
    dled_n_o[3:0] G13, G15, E14, G14 (LED4..LED1). Inputs clk12_i, sw2_n_i and rxd_i have no internal pull (PULLMODE=NONE).
  - Firmware (rv32i): "TTS OK." and boot phrase at reset; characters to the TTS block; TTS EXE / START / TTS RDY per line;
    jingle every 10 minutes when idle; LEDs heartbeat (LED1), speech active (LED3), character received (LED4); LED2 = SW2 pressed.

Results:  0 failing endpoints in all three corners (setup 100 C, setup -40 C, hold -40 C); 24 MHz system clock Fmax 27.864 MHz.
          1982 registers (21 percent), 6071 LUT4 (65 percent), 44 of 48 block RAMs (92 percent), 1 of 2 PLLs.
          Place and route 0 errors. Firmware 5432 bytes of 16384; memory initialisation confirmed in the generated RTL.
          Constraint coverage 99.93 percent; unconstrained asynchronous/slow I/O waived (rxd_i, sw2_n_i, txd_o, pwm_o, dled_n_o).

Deviations (accepted): DV-1 firmware makefiles changed to -march=rv32i; DV-2 duplicate riscv_sm/crt0.S removed from the firmware
          project copy; DV-3 PULLMODE=NONE on the inputs. Details in design_plan.html.

Programming: use program_C_v1.0.xcf (internal flash, Erase,Program,Verify; JTAG cable USB2, port FTUSB-0, TCK delay 3;
          I/O state HighZ, IOVectorData all ones; JedecChecksum 0x1CA0, FileTime 11/15/26 15:18:39).
          program_C_v1.0.ps1 is a dry run unless -Confirm is given. The programmer may print "failed"; the log line
          "Operation: successful" is the result. Check that no other program holds the FTDI cable.
          The chain file is the one saved by the Radiant Programmer GUI for this board (IDCode 0x712be043, PreloadLength 760,
          IOVectorData 760 bits, USB ID of channel A), with the JEDEC path pointed at this release folder.
          The batch tool's own transcript does not contain the result; read the programmer log named under Status.

Files:
  MachXO4C_TTS_C_v1.0.bit            bitstream, 149056 bytes
  MachXO4C_TTS_C_v1.0.jed            JEDEC file for the Programmer, 2097063 bytes
  program_C_v1.0.xcf                 programming chain file
  program_C_v1.0.ps1                 wrapper for pgrcmd (dry run by default)
  MachXO4C_TTS_C_v1.0_sources.zip    rtl, constraints, doc (prompt, schematics, pin-out), firmware sources and image,
                                     Propel script, .sbx and SoC top, Radiant project, strategy and setup script, design_plan.html
  timing_report_C_v1.0.twr           timing report
  resource_report_C_v1.0.mrp         map (resource) report

SHA256:
  bit  FB7D388853377703BF2DC0948417C36075F7FC16EDA4C0F9B0D99CFB3C1E3B82
  jed  F151FE5D1292CA535283462DC2EA041DA05CA03FC3440234AFF743CA1C048586
  zip  D56B9180D35537E6C2F730A78B1705180F67DCBE85ED100F4B7FF1D5592F25C6
  xcf  FA257D7CACF96EDCA73F7C33C0066394C4AC0E51463DDF9E238D6A6899DCF6B1
