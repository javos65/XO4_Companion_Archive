# Programs MachXO4C_TTS_C_v1.2.jed into the internal flash of the LFMXO4-110HC (Companion Board) over JTAG
# (erase, program, verify). Run only with the board connected and powered, and only when you intend to
# overwrite the stored design. Dry run unless -Confirm is given.
# The programmer may print "failed" because it misses its completion line; the log line
# "Operation: successful" is the result. Make sure no other program holds the FTDI cable.
param([switch]$Confirm)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$pgr  = 'C:\lscc\radiant\2026.1.1\programmer\bin\nt64\pgrcmd.exe'
$xcf  = Join-Path $here 'program_C_v1.2.xcf'
if (-not $Confirm) {
    Write-Host "Dry run. Add -Confirm to program the board."
    Write-Host "$pgr -infile `"$xcf`""
    exit 0
}
& $pgr -infile $xcf
