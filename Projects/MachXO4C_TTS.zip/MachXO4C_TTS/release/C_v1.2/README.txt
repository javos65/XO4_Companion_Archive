MachXO4 Companion Board TTS, release C_v1.2 (TTS_APB library block 2.0.0), built 2026-11-18
Status:   BUILT AND PROGRAMMED (2026-11-18 19:40:14-19:41:06, program_C_v1.2.ps1 -Confirm, with the approval of the
          project owner): "JTAG Chain Verification. No Errors.", Erase,Program,Verify, "Operation: successful."
          Functions not yet confirmed on the board.
Device:   LFMXO4-110HC-6BBG256I (speed grade 6), MachXO4 Companion Board Rev A.
Tools:    Lattice Propel 2026.1.1 and Radiant 2026.1.1 (LSE, loop limit 20000), RISC-V GCC 10.2.0.

Changes from C_v1.1:
  - UART moved from the HAT40 header to the FTDI USB UART (FT2232H channel B), all in Bank 0 (3.3 V):
      rxd_i  B11  (F_UART_TX, FTDI transmit)      was H15
      txd_o  A12  (F_UART_RX, FTDI receive)       was J12
    The FTDI UART is routed through jumpers J2/J3 (UART position) and JP11/JP12 (closed) on the board.
  - Speaker PWM moved to the Arduino header: pwm_o E6 (ARD_6, Bank 0), was H12.
  - System memory 8 KB (ADDR_DEPTH 2048, changed in the Propel SoC after C_v1.1); frees 8 block RAMs.
  - Firmware rebuilt for 8 KB: configuration and linker script regenerated from the SGE (memory 0x2000, stack top
    0x2000), stack reduced from 0xA00 to 0x600 (1.5 KB) so the image fits: 7700 of 8192 bytes
    (text 5436, data 8, bss+heap+stack 2256). Firmware behaviour unchanged.
  - RTL, TTS_APB 2.0.0, clocks (TTS 24 MHz, CPU/bus 12 MHz) unchanged.

Results:  0 failing endpoints in all three corners (setup 100 C, setup -40 C, hold -40 C).
          TTS clock 24 MHz: Fmax 28.528 MHz. CPU/bus clock 12 MHz: Fmax 31.091 MHz.
          2065 registers (22 percent), 5981 LUT4 (64 percent), 36 of 48 block RAMs (75 percent), 1 of 2 PLLs.
          Place and route 0 errors; pad report: rxd_i B11, txd_o A12, pwm_o E6, all Bank 0, LVCMOS33.
          Firmware memory initialisation confirmed in the generated RTL. Constraint coverage 99.93 percent
          (asynchronous and slow I/O waived as before).

Programming: program_C_v1.2.xcf (GUI-saved chain file of C_v1.1 with JEDEC path, FileTime 11/18/26 19:38:07 and
          JedecChecksum 0x30EE updated). Internal flash, Erase,Program,Verify; USB2 FTUSB-0; TCK delay 3; I/O HighZ.
          program_C_v1.2.ps1 is a dry run unless -Confirm is given. The result is the line "Operation: successful"
          in %APPDATA%\LatticeSemi\DiamondNG\programmer.log.
          Note: the FTDI chip carries both JTAG (channel A, FTUSB-0) and the UART (channel B); close any terminal on
          the UART port before programming if the programmer reports the cable as busy.

Files:
  MachXO4C_TTS_C_v1.2.bit            bitstream, 138800 bytes
  MachXO4C_TTS_C_v1.2.jed            JEDEC file, 2097062 bytes
  program_C_v1.2.xcf                 programming chain file
  program_C_v1.2.ps1                 wrapper for pgrcmd (dry run by default)
  MachXO4C_TTS_C_v1.2_sources.zip    rtl, constraints, doc, report, TTS_APB 2.0.0 folder and package, simulation,
                                     firmware sources and image, SoC .sbx and top, Radiant project, design_plan.html
  timing_report_C_v1.2.twr           timing report
  resource_report_C_v1.2.mrp         map (resource) report

SHA256:
  bit  7685BF00CE86AD0BE51181823EA54968E3D8408C1343D86441431B53F663E334
  jed  3F5121CE1E11F161B661CDBE04C5BE419B9E57DD236DB940B506B8E82C9A9420
  zip  F6C60B09799986C658B57F61C43BDCDA86C5712166765D3B0183EB1939F1EE3E
  xcf  78465FF2BD28147648B885E2D2C4FAD7A5E12F8AECDE3F683A3F1B6FBD0AD675
