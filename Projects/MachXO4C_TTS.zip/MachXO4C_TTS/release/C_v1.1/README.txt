MachXO4 Companion Board TTS, release C_v1.1 (TTS_APB library block 2.0.0), built 2026-11-15
Status:   BUILT AND PROGRAMMED, functions confirmed working on the board by the project owner (2026-11-15).
          Programmed into the internal flash twice on 2026-11-15, both with the approval of the project owner:
            17:48-17:49        Radiant Programmer GUI, by the project owner, with program_C_v1.1.xcf
            17:51:01-17:51:53  program_C_v1.1.ps1 -Confirm (pgrcmd, USB2 FTUSB-0, 7.5 MHz)
          Both runs: "Operation: successful." (second run: "JTAG Chain Verification. No Errors.", Erase,Program,Verify).
          Programmer log: %APPDATA%\LatticeSemi\DiamondNG\programmer.log (previous run rotated to programmer-old.log).
          Note: the lattice-prompt radiant_program tool hung before starting the programmer; pgrcmd directly works.
Device:   LFMXO4-110HC-6BBG256I (speed grade 6), MachXO4 Companion Board Rev A.
Tools:    Lattice Propel 2026.1.1 and Radiant 2026.1.1 (LSE, loop limit 20000), RISC-V GCC 10.2.0, Questa 2026.1.1.

Changes from C_v1.0:
  - TTS_APB 2.0.0 (custom:module:tts_apb:2.0.0, own folder ip\custom_module_tts_apb_2.0.0): two independent clocks,
    PCLK (APB, any frequency) and TTS_CLK (synthesizer, 24 MHz). Asynchronous 8-entry command FIFO (gray pointers) from
    the APB to the synthesizer domain, request/acknowledge status snapshot back; PREADY stalls a write while the FIFO is
    full and a STATUS read until it covers every earlier write. ID 0x54545302 (driver TTS_ID_VALUE updated).
    Speech engine (ttscpu, tts_roms, tts_engine, line_buf, sample_fifo, pwm10) unchanged.
  - PLL: CLKOP 24 MHz (divider 22) to TTS_APB TTS_CLK only; CLKOS 12 MHz (divider 44) to the CPU, memory, AHB/APB bus,
    UART, GPIO and TTS_APB PCLK.
  - UART: SYS_CLOCK_FREQ 12 MHz, 19200 8N1. Firmware rebuilt with the regenerated configuration (UART divider and the
    RISC-V timer for the 10-minute jingle now use 12 MHz).
  - Pins, top level (rtl/tts_top.v) and firmware behaviour unchanged.

Simulation (Questa, sim\tts_apb_2.0.0, PCLK 12 MHz, TTS_CLK 24 MHz):
  - tb_tts_apb2: the 1.5.0 register-level test with wait-state support: all 26 checks ok, "tb_tts_apb PASS".
  - tb_tts_eq: 1.5.0 and 2.0.0 side by side on three lines (speech, tone commands, boot phrase):
    213944 PWM pulses compared, "tb_tts_eq PASS: PWM output identical".

Results:  0 failing endpoints in all three corners (setup 100 C, setup -40 C, hold -40 C).
          TTS clock 24 MHz: Fmax 27.199 MHz. CPU/bus clock 12 MHz: Fmax 34.210 MHz. Board clock 12 MHz: 150 MHz.
          2068 registers (22 percent), 6116 LUT4 (65 percent), 44 of 48 block RAMs (92 percent), 1 of 2 PLLs.
          Place and route 0 errors. Firmware 5444 bytes of 16384; memory initialisation confirmed in the generated RTL.
          Constraint coverage 99.93 percent; unconstrained asynchronous/slow I/O waived as in C_v1.0.

Programming: program_C_v1.1.xcf (chain file of C_v1.0 saved by the Radiant Programmer GUI, JEDEC path, FileTime
          11/15/26 17:00:22 and JedecChecksum 0xDCEC updated). Internal flash, Erase,Program,Verify; USB2 FTUSB-0; TCK delay 3;
          I/O HighZ. program_C_v1.1.ps1 is a dry run unless -Confirm is given. The result is the line "Operation: successful"
          in %APPDATA%\LatticeSemi\DiamondNG\programmer.log.

Files:
  MachXO4C_TTS_C_v1.1.bit            bitstream, 149456 bytes
  MachXO4C_TTS_C_v1.1.jed            JEDEC file, 2097063 bytes
  program_C_v1.1.xcf                 programming chain file
  program_C_v1.1.ps1                 wrapper for pgrcmd (dry run by default)
  MachXO4C_TTS_C_v1.1_sources.zip    rtl, constraints, doc, report, TTS_APB 2.0.0 folder and package (.ipk, package.ps1),
                                     simulation (testbenches, run_sim.ps1), firmware sources and image, Propel script, .sbx
                                     and SoC top, Radiant project and setup script, design_plan.html
  timing_report_C_v1.1.twr           timing report
  resource_report_C_v1.1.mrp         map (resource) report

SHA256:
  bit  A73158079A3FF25AF13B0B0189685D06BFB1ADF37F93CB65CDBCC3A6B162638A
  jed  8F4C446B0A928B750D0644D82BECCAD28FF4B7DC34E32DF14BCF690697CEC9A9
  zip  2F3EBEC38E5FA8AF6A57FF226CFB91F551E8877DB6913707A98BB83CA10450CA
  xcf  D6119AD71AB0D9B81BD037062BB7512B0A11384A291643EC114F1FAECD031C8D
