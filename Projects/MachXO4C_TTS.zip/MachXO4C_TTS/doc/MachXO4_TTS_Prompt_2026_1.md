# MachXO4 Text-to-Speech: Project Prompt (Propel and Radiant 2026.1)

This prompt rebuilds the project in two parts. Part A adapts the existing speech engine library block TTS_APB 1.5.0 into TTS_APB 2.0.0 with two independent clocks. Part B builds the final application: a Propel RISC-V SoC on the MachXO4 Companion Board that uses TTS_APB 2.0.0.

The MachXO4 Companion Board is new and has no online data. Use the schematic (LFMXO4-110-COMPANION REVA) and the pin-out workbook (XO4_Companion_Mapping.xlsx) in the doc/ directory as the only pin and board reference.

Reference result: release C_v1.2 (C_v1.1 was built, programmed and confirmed working on the board; C_v1.2 moves the UART to the FTDI bridge, the speaker to the Arduino header and the system memory to 8 KB).

## General rules (both parts)

- Tools: Lattice Propel 2026.1.1 (SoC, IP catalog, RISC-V GCC toolchain) and Lattice Radiant 2026.1.1 with LSE synthesis; Questa 2026.1.1 for RTL simulation; Python 3 for models, test tools and reports. Use the Lattice Prompt MCP tools for IP configuration, builds and timing checks.
- Device: LFMXO4-110HC-6BBG256I (MachXO4, 256-ball package, speed grade 6, industrial) on the MachXO4 Companion Board Rev A. Working directory: C:\lscc\workspace\MachXO4C_TTS.
- Local IP catalog: installed IP lands in C:\Users\<name>\PropelIPLocal (the PropelIPLocal folder of the user who runs Propel).
- HDL: Verilog-2001. All I/O LVCMOS33. The pins given in this prompt must not be changed.
- Record every decision, deviation and open item in design_plan.html. Deliver a design report as HTML and as a Word document, generated from one content model, and keep it current.
- Save every step as its own release folder: bitstream, JEDEC file, programming chain file, programming script (dry run by default), README with SHA256 hashes and a sources archive. Back up the working state of the previous release before a rebuild overwrites the SoC or the Radiant project.
- Always ask for approval before programming the board.
- Simulation rule: simulate when the speech engine block (TTS_APB RTL, TTSCPU firmware or ROM tables) changes. A change that only affects the RISC-V firmware needs no simulation: compile, load the memory image, build, check timing, release.
- Use known tool paths and commands; do not search whole install trees. Never start the GUI programs ippack.exe or ippackc.exe from a shell.
- Formal wording, no emojis, no personal data. Cite an internal policy number only if one is supplied.

## Part A: TTS_APB 2.0.0 library block with two clocks

### A.1 Objective

TTS_APB 1.5.0 (custom:module:tts_apb:1.5.0) clocks its APB register file and its speech synthesizer from the same clock (PCLK, 24 MHz). A faster or slower CPU and bus clock would change the speech. Create TTS_APB 2.0.0 with two independent clock inputs: PCLK for the APB interface (any frequency) and TTS_CLK for the synthesizer (24 MHz).

### A.2 Why the synthesizer stays at 24 MHz

- The audio timing is derived from the synthesizer clock: PWM period 750 clocks (32 kHz carrier) and 1500 clocks per 16 kHz audio sample.
- TTSCPU needs about 920 of these 1500 clocks per sample on average. At 12 MHz only 750 clocks are available, which is too few. TTS_CLK is therefore 24 MHz.

### A.3 Source and folder

- Start from the 1.5.0 block (C:\Users\<name>\PropelIPLocal\custom_module_tts_apb_1.5.0). Copy metadata.xml, bus_interface.xml, memory_map.xml, rtl/, driver/ and doc/ into a separate IP directory: ip\custom_module_tts_apb_2.0.0. Do not copy the IP Packager project files or the old .ipk. Never edit an installed version in place.
- The speech engine files (ttscpu.v, tts_roms.v, tts_engine.v, line_buf.v, sample_fifo.v, pwm10.v) stay byte-identical. Only the top file tts_apb.v (module tts_apb_slave) changes.

### A.4 RTL changes (tts_apb.v)

- Ports: PCLK (APB, any frequency), TTS_CLK (synthesizer, 24 MHz), RST_N, the APB_S0 bus (PADDR[3:0], PSEL, PENABLE, PWRITE, PWDATA, PRDATA, PREADY, PSLVERR) and PWM_OUT.
- PCLK domain: the APB register file. DATA and CTRL writes are pushed, in order, into an 8-entry asynchronous command FIFO (10-bit entries: {CLEAR, START, character}; gray-coded pointers with two-flop synchronizers).
- TTS_CLK domain: the line buffers, TTSCPU, sample FIFO, fade logic and PWM. The FIFO is executed one entry at a time with three idle clocks after each entry, so the effect of an entry (line complete, BUSY, DROP) is visible before the next one is evaluated. START and CLEAR follow the 1.5.0 rules.
- Status return: a request/acknowledge snapshot carries {LEN, DROP, PLAY, DONE, READY, BUSY} and the count of executed entries back to the PCLK domain.
- Wait states: PREADY is low on a DATA or CTRL write while the FIFO is full, and on a STATUS read until the snapshot covers every write made before it. Firmware then reads the same status sequence as with 1.5.0.
- Reset: RST_N (active low, PCLK domain) is synchronised into each clock domain (asynchronous assert, synchronous release).
- Declare every signal that crosses between the domains before its first use (Verilog-2001).

### A.5 Register map (unchanged except the ID)

| Offset | Register | Content |
|---|---|---|
| 0x00 | ID | Read only: 0x54545302 |
| 0x04 | CTRL | Write: bit 0 START (speak the completed line), bit 1 CLEAR (discard queued text, ignored while busy) |
| 0x08 | STATUS | Bit 0 BUSY, bit 1 READY (complete line waiting), bit 2 DONE (sticky), bit 3 PLAY, bit 4 DROP (sticky), bits 15..8 LEN (length of the oldest complete line, 1..128, 0 when none) |
| 0x0C | DATA | Write: one text character; read: last character written |

### A.6 Metadata, driver and documentation

- metadata.xml: version 2.0.0; add the port TTS_CLK (dir in, conn_mod tts_apb_slave). platform_version, min_radiant_version and min_esi_version stay at 2025.2.
- driver/tts_regs.h: TTS_ID_VALUE 0x54545302. driver/tts_apb.xml: version 2.0.0. The driver functions (tts_init, read_tts_status, write_tts_control, write_tts_phrase) are unchanged.
- doc/introduction.html: ID 0x54545302; a "Clocks" section with a table of the two clock ports, why TTS_CLK must be 24 MHz, the clock domain crossing (command FIFO, status snapshot, wait states, reset synchronisation) and integration notes (PCLK and RST_N from the APB clock and reset, TTS_CLK from a 24 MHz source such as a second PLL output; declare the clocks asynchronous when their sources are unrelated); revision history entry 2.0.

### A.7 Verification (Questa, sim\tts_apb_2.0.0)

- tb_tts_apb2: the 1.5.0 register-level testbench (ID and reset, one line, queue and drop, 128-character lines, CR LF and empty lines, tone commands, unterminated tone command, CLEAR and reset during speech) with APB tasks that honour PREADY wait states, PCLK 12 MHz and TTS_CLK 24 MHz. Pass: all 26 checks ok.
- tb_tts_eq: 1.5.0 (module renamed tts_apb_slave_v15) and 2.0.0 side by side on the same three lines (speech, tone commands, boot phrase); every PWM high-pulse width is recorded in 24 MHz clocks and compared. Pass: the pulse sequences are identical (reference: 213944 pulses).
- run_sim.ps1 runs either testbench (vlib/vlog/vsim in batch, library name relative to the sim folder). The Questa license allows one session at a time: run the testbenches one after the other.

### A.8 Packaging and installation

- Package with the IP Packager engine on the command line: C:\lscc\propel\2026.1.1\builder\rtf\ispfpga\bin\nt64\ippkg.exe -metadata_files metadata_list.txt -rtl_files rtl_list.txt -driver_files driver_list.txt -help_file <block>\doc\introduction.html -o custom_module_tts_apb_2.0.0.ipk, with FOUNDRY set to C:\lscc\propel\2026.1.1\builder\rtf\ispfpga. The -*_files options take list files with one path per line (ip\package_2.0.0\package.ps1 writes them). Check the contents of the .ipk.
- Install the .ipk through the Propel IP Catalog; it lands in C:\Users\<name>\PropelIPLocal\custom_module_tts_apb_2.0.0. The install tool can stay silent for a long time after the install has finished: confirm the result with an IP catalog search for tts_apb 2.0.0 instead of waiting. If the install does not complete, add the IP library manually in Propel.

## Part B: SoC system for the final application

### B.1 Objective

Build a Propel RISC-V SoC that receives text over a UART and speaks it through the TTS_APB 2.0.0 library block, with status messages, LEDs and a periodic jingle. No installed Propel template targets MachXO4 with a RISC-V hello-world SoC; create the SoC from a Propel script with the components below.

### B.2 SoC components (Propel 2026.1.1 catalog versions)

| Block | IP and version | Settings |
|---|---|---|
| PLL | pll 3.0.1 | 12 MHz in (pin T9). CLKOP 24 MHz (divider 22) to TTS_APB TTS_CLK only. CLKOS 12 MHz (divider 44) as the CPU and bus clock. Lock port enabled. |
| CPU | riscv_sm 1.9.0 | RV32I, no multiplier; DEBUG_ENABLE false (its JTAG debug port blocks placement at site D10); PIC and timer enabled; IRQ_NUM 1 |
| System memory | system_memory 2.6.0 | AHB-Lite, 2 ports, ADDR_DEPTH 2048 (8 KB) EBR at 0x0000, initialised with the firmware image |
| Bus | ahb_lite_interconnect 1.5.0 (1 master, 2 slaves), ahb_lite_to_apb_bridge 1.2.0, apb_interconnect 1.4.0 (1 master, 3 slaves) | AHB-Lite for CPU and memory, APB for the peripherals |
| UART | uart 1.6.0 at 0x8000 | SYS_CLOCK_FREQ 12 MHz, 19200 baud 8N1, RXRDY_ENA false (no RX ready pin), interrupt to the CPU |
| GPIO | gpio 1.8.1 at 0x8400 | 5 lines, external buffer: lines 3..0 LED outputs, line 4 input (debounced SW2) |
| TTS | custom:module:tts_apb:2.0.0 at 0x8C00 | PCLK from CLKOS (12 MHz), TTS_CLK from CLKOP (24 MHz); includes the BSP driver tts_apb |
| Reset glue | equation A & B | rstn_i AND PLL lock to the CPU reset; the CPU system reset output resets the bus and peripherals |

- SoC ports: clk12_i, rstn_i, rxd_i, txd_o, pwm_o, gpio_o[4:0], gpio_i[4:0], gpio_en_o[4:0].
- The CPU timer interrupt and the GPIO interrupt stay unconnected (timer and SW2 are polled); record the reason.

### B.3 Top level and pins

- rtl/tts_top.v wraps the SoC: SW2 two-flop synchronizer and debounce of 2^18 cycles at 12 MHz (21.8 ms); power-on reset of 2^18 cycles after configuration; SoC reset = registered (power-on done AND debounced SW2). The "SW2 pressed" LED is driven in hardware from the debounced SW2. gpio_i[4] reads the debounced SW2, gpio_i[3:0] are tied high; gpio_en_o is unused.

| Signal | Pin | Function |
|---|---|---|
| clk12_i | T9 | 12 MHz board clock (F_12MHz) |
| sw2_n_i | D10 | SW2 (PB1), active low, restarts the design |
| rxd_i | B11 (F_UART_TX, Bank 0) | UART RX from the FTDI USB UART transmit line, 19200 baud 8N1, no pull-up |
| txd_o | A12 (F_UART_RX, Bank 0) | UART TX to the FTDI USB UART receive line |
| pwm_o | E6 (ARD_6, Arduino header, Bank 0) | Audio PWM to a BC547 amplifier and speaker |
| dled_n_o[0..3] | G14, E14, G15, G13 (LED1..LED4) | Low = lit: heartbeat, SW2 pressed, speech active, character received |

- Constraints (constraints\tts_top.pdc): the pins above, IO_TYPE LVCMOS33 on every port, PULLMODE NONE on clk12_i, sw2_n_i and rxd_i (Radiant otherwise defaults inputs to a pull-down, which would hold an idle UART RX low). Write one IO_TYPE line per bus bit.
- Timing (constraints\tts_timing.sdc): create_clock 83.333 ns on clk12_i; the PLL clocks are derived.

### B.4 Firmware behaviour (C, rv32i)

- main() uses only driver functions (UART, GPIO, TTS, timer); no direct register access. Base addresses and the clock frequency come from the generated soc_config.h (UART0_INST_CLOCK_HZ = 12 MHz). The TTS driver comes from the library block (BSP driver tts_apb, TTS_ID_VALUE 0x54545302).
- After reset: send "TTS OK." and speak the boot phrase "Lattice? Mag X-O for is running!"; characters received during the phrase are discarded and the queue is cleared afterwards.
- Each received character goes to the TTS block (line length up to 128). When a line is complete: send "TTS EXE", write START, wait until BUSY clears, send "TTS RDY". Every message ends with CR LF.
- Jingle every 10 minutes (RISC-V timer at the 12 MHz CPU clock), when the TTS block is idle and no UART line is half received: two tone phrases one after the other: 1: #1318,125# #1174,125# #881,100#,#1046,188# #991,188# #657,188# #881,125# #1046,125# #1174,125# #989,125#  2: #1318,125#-#1174,125#-#881,100#-#1046,125# #991,125# #657,125# #881,125# #1046,125#-#1174,125# #991,313#
- GPIO: gpio_init with 5 lines and directions 0x0F. LEDs: LED1 heartbeat, LED3 speech active, LED4 toggles on every received character; LED2 is left off for the hardware SW2 indicator.

### B.5 Build flow (two passes)

- Pass 1: create the SoC in Propel from a script (save, generate, save, DRC) and generate the system environment (SGE).
- Firmware project (firmware\tts_fw): generate the Propel SDK project from the SGE (gsrd_bootloader mode) and author src/main.c. After every firmware_gen_build: replace -march=rv32im by -march=rv32i in the generated Debug makefiles (the generator has no ISA option and the CPU has no multiplier), and remove src/bsp/driver/riscv_sm/crt0.S from the project copy (it duplicates _start of src/bsp/driver/cpu/crt0.S). After an SGE change: regenerate the configuration (firmware_gen_soc_config) and refresh src/bsp/sys_platform.h and the tts_apb driver from the SGE.
- Firmware: compile with -march=rv32i -mabi=ilp32, convert the binary to a memory image (bin2mem with an output path, plain ASCII without BOM), set INIT_MEM true, INIT_CHK hex and INIT_FILE_IN on the system memory, generate again and confirm with check_memory_init_applied that the firmware is in the generated memory. Then generate the SGE again.
- Memory budget (8 KB system memory): regenerate the linker script from the SGE and set _STACK_SIZE to 0x600 (1.5 KB) in src/bsp/boot/linker.ld; the image then uses 7700 of 8192 bytes (text 5436, data 8, bss, heap and stack 2256). With the default stack of 0xA00 the link overflows by 544 bytes.
- Radiant: radiant\setup_tts_top.tcl creates the project tts_top (LSE, top tts_top, loop limit 20000, LSE memory initialisation search path set to the CPU testbench folder of the generated SoC) and lists the .ipx file of every generated instance found by glob. Recreate the project when an instance is replaced (for example tts0 1.5.0 by 2.0.0).
- Gates: 0 failing endpoints in all corners for both clocks (24 MHz TTS clock, 12 MHz CPU and bus clock); resources within the device; constraint coverage reviewed with a recorded waiver for the asynchronous and slow ports (rxd_i, sw2_n_i, txd_o, pwm_o, dled_n_o).
- Reference result (C_v1.2): TTS clock Fmax 28.5 MHz, CPU and bus clock Fmax 31.1 MHz; 2065 registers (22 percent), 5981 LUT4 (64 percent), 36 of 48 block RAMs (75 percent: TTS_APB 24, system memory 8, CPU 4), 1 of 2 PLLs; firmware 7.5 KB of 8 KB including stack.

### B.6 Programming

- Program the JEDEC file into the internal flash (Erase, Program, Verify) over JTAG, cable USB2, port FTUSB-0, TCK delay 3. Use the chain file saved by the Radiant Programmer GUI for this board (IDCode 0x712be043, PreloadLength 760, IOVectorData of 760 bits all ones, I/O state HighZ, so the outputs stay tri-stated during programming); for a new release only the JEDEC path, FileTime and JedecChecksum change.
- The FTDI FT2232H carries JTAG on channel A (FTUSB-0) and the UART on channel B; the UART reaches the FPGA through jumpers J2/J3 (UART position) and JP11/JP12 (closed). Close any terminal program on the UART port if the programmer reports the cable as busy.
- Program with the release script: program_<release>.ps1 -Confirm runs C:\lscc\radiant\2026.1.1\programmer\bin\nt64\pgrcmd.exe -infile <chain file>. Without -Confirm it is a dry run.
- The result is the line "Operation: successful." in %APPDATA%\LatticeSemi\DiamondNG\programmer.log (the previous run is rotated to programmer-old.log); read it before reporting. Check that no other program holds the FTDI cable.

### B.7 Audio hardware

- E6 (ARD_6) through 680 ohm to the base of a BC547, 100 kohm from base to ground; the collector drives an 8 ohm speaker in parallel with a 1N4148, then 47 ohm 0.5 W to +5 V, with 100 uF across the supply. The board I/O is 3.3 V only.
