SENSE HAT  information:  
schematic see doc/ directory

**Preparation:**
5V HAT : JP6 close
3V3 HAT : JP3 close

**HAT IO Usage:**

++I2C:++
GPIO2   pin 3   SDA
GPIO3   pin 5   SCL

SDA/SCL I2C bus maps to

0x5c: lps25h -- LPS25H Pressure/Temperature sensor  
0x5f: hts221 -- HTS221 Humidity/Temperature sensor  
0x1c: lsm9ds1 -- IMU (Magnetometer)  
0x6a: lsm9ds1 -- IMU (Accelerometer and Gyro)  
0x46: led2472g -- shift register driving the LED Matrix -> run through ATTINY88-MUR  
0x39: TC3400 Color Sensor (not the TCS34725 , Addrss and Id are different)

++SPI:++
GPIO10  pin 19  MOSI
GPIO9   pin 21  MISO
GPI11   pin 23  SCK
GPIO8   pin 24  CEO / CSN

Reset:
GPIO25  Pin 22  PROG RST_N

++INT Pins:++
GPIO23  pin 16  INT1
GPIO24  pin18   INT2

++EEPROM I2C++
HATID_SD pin 27  ID_SD  maps to CAT24C32WI-GT3 SDA 
HATID_SC pin 28  ID_SC  map to  CAT24C32WI-GT3 SCL

**Led Matrix Drive :**
The LED2472G does not connect directly to the Raspberry Pi's I2C bus. Instead, the ATTINY88-MUR acts as an I2C target at 7-bit address 0x46, translating I2C register writes into the 4-wire SPI/shift-register signals required by the LED2472G.

I2C Protocol & Register Map (0x46)

To update the 8×8 RGB LED matrix, write a block of 193 bytes to I2C address 0x46 (or write to individual pixel registers).
-Byte 0 (Start Register Address): 0x00 (sets the internal auto-incrementing register pointer to the start of the framebuffer).
-Bytes 1–192 (Pixel Color Data): 192 bytes representing 8 rows × 3 color planes × 8 columns (8 × 24 = 192).
-Color Depth: Each byte uses 6-bit color (0x00 to 0x3F, i.e., 0–63). Keep the top two bits (bits 6–7) set to 0, as the ATTINY88 firmware uses them internally during multiplexing.

Row Memory Layout (Per Row y from 0 to 7)

Each row occupies 24 consecutive bytes starting at offset (y * 24) + 1 in the 193-byte payload (or register (y * 24) on the ATtiny):
-Bytes 0..7 of row: Red values for columns x = 0..7
-Bytes 8..15 of row: Green values for columns x = 0..7
-Bytes 16..23 of row: Blue values for columns x = 0..7

**Joystick Read:**
To read the 5-button joystick (SKRHABE010) over I2C, read 1 byte from register 0xF2 on the ATTINY88-MUR at 7-bit address 0x46.

Register 0xF2 Bitmask

The returned byte is an active-high bitmask where each bit corresponds to a direction or press (1 = pressed, 0 = released).

Bit	Hex Mask	Direction / Action
Bit 0	    0x01	Down
Bit 1	    0x02	Right
Bit 2	    0x04	Up
Bit 3	    0x08	Center (Enter / Click)
Bit 4	    0x10	Left
Bits 5-7	0xE0	Unused (0)

**Official Raspberry Pi HAT ID EEPROM (CAT24C32 on I2C Bus 0 - seperate bus)**

Per the Raspberry Pi HAT specification, the board also carries a dedicated CAT24C32WI-GT3 EEPROM chip (U6) wired to the reserved ID I2C pins (ID_SD / GPIO 0 and ID_SC / GPIO 1, physical pins 27 and 28) at address 0x50.

- Stored HAT ID Metadata:
  - Vendor: Raspberry Pi
  - Product: Sense HAT
  - Product ID: 0x0001
  - Product Version: 0x0001 (or 0x0002 for Rev 2)
  - UUID: Unique per board (or generated at boot/programming)
  - Device Tree Overlay: Embedded rpi-sense overlay so Raspberry Pi OS auto-loads the drivers at boot.

****Interrupt lines:**
On the Raspberry Pi Sense HAT, the two interrupt lines-BCM GPIO 23 (physical pin 16) and BCM GPIO 24 (physical pin 18)—signal the Raspberry Pi when hardware events occur so the CPU does not have to continuously poll the I2C bus.

- BCM GPIO 23 (KEYS_INT - Physical Pin 16): 
Driven by the ATTINY88-MUR (U2). 
The ATTINY88 asserts this line whenever the 5-button joystick (SKRHABE010) changes state (pressed or released), prompting the Linux input driver (rpisense-js) to read register 0xF2 over I2C.
- BCM GPIO 24 (IMU_INT - Physical Pin 18): 
Driven by the LSM9DS1 9-DOF IMU (U4, accelerometer/gyroscope/magnetometer). 
It triggers hardware interrupts for motion-sensing events such as new data ready, free-fall detection, wake-up thresholds, or FIFO buffer limits.

Hardware Behavior:
Active-High / Edge-Triggered: Both lines sit idle at logic low (0V) and pulse or transition high (3.3V) when an event fires.

**Reset**
PROG_RST_N is the active-low hardware reset line connected between Raspberry Pi BCM GPIO 25 (physical pin 22) and ATTINY88-MUR pin PC6 (RESET).
How PROG_RST_N Behaves

- Active-Low Logic (_N): The _N suffix denotes active-low operation. Driving the pin low (0V) resets the ATTINY88-MUR; letting it sit high (3.3V) allows the microcontroller to run normally.
- Normal Operation (3.3V / High): An onboard 10 kΩ pull-up resistor (R4) tied to the 3V3 rail holds PROG_RST_N high by default. This keeps the ATTINY88 running its LED/joystick firmware even if Raspberry Pi GPIO 25 is left floating as an input.
- Hardware Reset (Momentary Low Pulse): Driving BCM GPIO 25 low (0V) and releasing it back to high resets the ATTINY88, clearing its LED framebuffer and rebooting its internal firmware.
- ISP Firmware Flashing (Held Low): To flash or read the ATTINY88 over SPI using avrdude, the programmer holds PROG_RST_N continuously low (0V). While RESET is held low, the ATtiny88's internal CPU stops executing code and switches its SPI pins (PB3/MOSI, PB4/MISO, PB5/SCK) into In-System Programming (ISP) mode.

**SPI interface:**
SPI (Serial Peripheral Interface), the SPI lines on the Raspberry Pi Sense HAT are wired exclusively to the ATTINY88-MUR (U2) for In-System Programming (ISP)—flashing or updating the microcontroller's firmware directly from the Raspberry Pi.
During normal Sense HAT operation (controlling the LEDs, reading the joystick, and polling sensors), the SPI bus is idle and unused. It is only used when programming the ATtiny88
unused 

Mapping to FPGA XO4 Companion Board :

GPIO2   pin 3   SDA         Maps to RASP_IO02_SDA1    ball J15
GPIO3   pin 5   SCL         Maps to RASP_IO03_SCL1    ball K16
GPIO23  pin 16  INT1        Maps to RASP_IO23         ball K14
GPIO24  pin18   INT2        Maps to RASP_IO24         ball L14
PIO25  Pin 22  PROG RST_N   Maps to RASP_IO25         ball M14

