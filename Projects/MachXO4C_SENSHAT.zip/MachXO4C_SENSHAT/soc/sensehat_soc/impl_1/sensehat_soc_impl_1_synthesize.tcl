if {[catch {

# define run engine funtion
source [file join {C:/lscc/radiant/2026.1.1} scripts tcl flow run_engine.tcl]
# define global variables
global para
set para(gui_mode) "0"
set para(prj_dir) "C:/lscc/workspace/MachXO4C_SENSHAT/soc/sensehat_soc"
if {![file exists {C:/lscc/workspace/MachXO4C_SENSHAT/soc/sensehat_soc/impl_1}]} {
  file mkdir {C:/lscc/workspace/MachXO4C_SENSHAT/soc/sensehat_soc/impl_1}
}
cd {C:/lscc/workspace/MachXO4C_SENSHAT/soc/sensehat_soc/impl_1}
# synthesize IPs
# synthesize VMs
# propgate constraints
file delete -force -- sensehat_soc_impl_1_cpe.ldc
::radiant::runengine::run_engine_newmsg cpe -syn synpro -f "sensehat_soc_impl_1.cprj" "rst24.cprj" "apb0.cprj" "ahbl2apb0.cprj" "efb0.cprj" "sh0.cprj" "cpu0.cprj" "uart0.cprj" "sysmem0.cprj" "ahbl0.cprj" "pll0.cprj" "rst12.cprj" "gpio0.cprj" -a "LFMXO4"  -o sensehat_soc_impl_1_cpe.ldc
# synthesize top design
file delete -force -- sensehat_soc_impl_1.vm sensehat_soc_impl_1.ldc
if {[file normalize "C:/lscc/workspace/MachXO4C_SENSHAT/soc/sensehat_soc/impl_1/sensehat_soc_impl_1_synplify.tcl"] != [file normalize "./sensehat_soc_impl_1_synplify.tcl"]} {
  file copy -force "C:/lscc/workspace/MachXO4C_SENSHAT/soc/sensehat_soc/impl_1/sensehat_soc_impl_1_synplify.tcl" "./sensehat_soc_impl_1_synplify.tcl"
}
if {[ catch {::radiant::runengine::run_engine synpwrap -prj "sensehat_soc_impl_1_synplify.tcl" -log "sensehat_soc_impl_1.srf"} result options ]} {
    file delete -force -- sensehat_soc_impl_1.vm sensehat_soc_impl_1.ldc
    return -options $options $result
}
::radiant::runengine::run_postsyn [list -a LFMXO4 -p LFMXO4-110HC -t BBG256 -sp 6 -oc Industrial -top -ipsdc ipsdclist.txt -w -o sensehat_soc_impl_1_syn.udb sensehat_soc_impl_1.vm] [list sensehat_soc_impl_1.ldc]

} out]} {
   ::radiant::runengine::runtime_log $out
   exit 1
}
