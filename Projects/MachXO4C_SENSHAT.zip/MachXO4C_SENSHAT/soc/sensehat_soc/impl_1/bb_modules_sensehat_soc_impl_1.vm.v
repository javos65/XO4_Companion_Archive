`timescale 100 ps/100 ps
module EFB (
  WBCLKI,
  WBRSTI,
  WBCYCI,
  WBSTBI,
  WBWEI,
  WBADRI7,
  WBADRI6,
  WBADRI5,
  WBADRI4,
  WBADRI3,
  WBADRI2,
  WBADRI1,
  WBADRI0,
  WBDATI7,
  WBDATI6,
  WBDATI5,
  WBDATI4,
  WBDATI3,
  WBDATI2,
  WBDATI1,
  WBDATI0,
  PLL0DATI7,
  PLL0DATI6,
  PLL0DATI5,
  PLL0DATI4,
  PLL0DATI3,
  PLL0DATI2,
  PLL0DATI1,
  PLL0DATI0,
  PLL0ACKI,
  PLL1DATI7,
  PLL1DATI6,
  PLL1DATI5,
  PLL1DATI4,
  PLL1DATI3,
  PLL1DATI2,
  PLL1DATI1,
  PLL1DATI0,
  PLL1ACKI,
  I2C1SCLI,
  I2C1SDAI,
  I2C2SCLI,
  I2C2SDAI,
  SPISCKI,
  SPIMISOI,
  SPIMOSII,
  SPISCSN,
  TCCLKI,
  TCRSTN,
  TCIC,
  UFMSN,
  WBDATO7,
  WBDATO6,
  WBDATO5,
  WBDATO4,
  WBDATO3,
  WBDATO2,
  WBDATO1,
  WBDATO0,
  WBACKO,
  PLLCLKO,
  PLLRSTO,
  PLL0STBO,
  PLL1STBO,
  PLLWEO,
  PLLADRO4,
  PLLADRO3,
  PLLADRO2,
  PLLADRO1,
  PLLADRO0,
  PLLDATO7,
  PLLDATO6,
  PLLDATO5,
  PLLDATO4,
  PLLDATO3,
  PLLDATO2,
  PLLDATO1,
  PLLDATO0,
  I2C1SCLO,
  I2C1SCLOEN,
  I2C1SDAO,
  I2C1SDAOEN,
  I2C2SCLO,
  I2C2SCLOEN,
  I2C2SDAO,
  I2C2SDAOEN,
  I2C1IRQO,
  I2C2IRQO,
  SPISCKO,
  SPISCKEN,
  SPIMISOO,
  SPIMISOEN,
  SPIMOSIO,
  SPIMOSIEN,
  SPIMCSN0,
  SPIMCSN1,
  SPIMCSN2,
  SPIMCSN3,
  SPIMCSN4,
  SPIMCSN5,
  SPIMCSN6,
  SPIMCSN7,
  SPICSNEN,
  SPIIRQO,
  TCINT,
  TCOC,
  WBCUFMIRQ,
  CFGWAKE,
  CFGSTDBY
)
;
input WBCLKI ;
input WBRSTI ;
input WBCYCI ;
input WBSTBI ;
input WBWEI ;
input WBADRI7 ;
input WBADRI6 ;
input WBADRI5 ;
input WBADRI4 ;
input WBADRI3 ;
input WBADRI2 ;
input WBADRI1 ;
input WBADRI0 ;
input WBDATI7 ;
input WBDATI6 ;
input WBDATI5 ;
input WBDATI4 ;
input WBDATI3 ;
input WBDATI2 ;
input WBDATI1 ;
input WBDATI0 ;
input PLL0DATI7 ;
input PLL0DATI6 ;
input PLL0DATI5 ;
input PLL0DATI4 ;
input PLL0DATI3 ;
input PLL0DATI2 ;
input PLL0DATI1 ;
input PLL0DATI0 ;
input PLL0ACKI ;
input PLL1DATI7 ;
input PLL1DATI6 ;
input PLL1DATI5 ;
input PLL1DATI4 ;
input PLL1DATI3 ;
input PLL1DATI2 ;
input PLL1DATI1 ;
input PLL1DATI0 ;
input PLL1ACKI ;
input I2C1SCLI ;
input I2C1SDAI ;
input I2C2SCLI ;
input I2C2SDAI ;
input SPISCKI ;
input SPIMISOI ;
input SPIMOSII ;
input SPISCSN ;
input TCCLKI ;
input TCRSTN ;
input TCIC ;
input UFMSN ;
output WBDATO7 ;
output WBDATO6 ;
output WBDATO5 ;
output WBDATO4 ;
output WBDATO3 ;
output WBDATO2 ;
output WBDATO1 ;
output WBDATO0 ;
output WBACKO ;
output PLLCLKO ;
output PLLRSTO ;
output PLL0STBO ;
output PLL1STBO ;
output PLLWEO ;
output PLLADRO4 ;
output PLLADRO3 ;
output PLLADRO2 ;
output PLLADRO1 ;
output PLLADRO0 ;
output PLLDATO7 ;
output PLLDATO6 ;
output PLLDATO5 ;
output PLLDATO4 ;
output PLLDATO3 ;
output PLLDATO2 ;
output PLLDATO1 ;
output PLLDATO0 ;
output I2C1SCLO ;
output I2C1SCLOEN ;
output I2C1SDAO ;
output I2C1SDAOEN ;
output I2C2SCLO ;
output I2C2SCLOEN ;
output I2C2SDAO ;
output I2C2SDAOEN ;
output I2C1IRQO ;
output I2C2IRQO ;
output SPISCKO ;
output SPISCKEN ;
output SPIMISOO ;
output SPIMISOEN ;
output SPIMOSIO ;
output SPIMOSIEN ;
output SPIMCSN0 ;
output SPIMCSN1 ;
output SPIMCSN2 ;
output SPIMCSN3 ;
output SPIMCSN4 ;
output SPIMCSN5 ;
output SPIMCSN6 ;
output SPIMCSN7 ;
output SPICSNEN ;
output SPIIRQO ;
output TCINT ;
output TCOC ;
output WBCUFMIRQ ;
output CFGWAKE ;
output CFGSTDBY ;
endmodule /* EFB */

module EHXPLLJ (
  CLKI,
  CLKFB,
  PHASESEL1,
  PHASESEL0,
  PHASEDIR,
  PHASESTEP,
  LOADREG,
  STDBY,
  PLLWAKESYNC,
  RST,
  RESETM,
  RESETC,
  RESETD,
  ENCLKOP,
  ENCLKOS,
  ENCLKOS2,
  ENCLKOS3,
  PLLCLK,
  PLLRST,
  PLLSTB,
  PLLWE,
  PLLDATI7,
  PLLDATI6,
  PLLDATI5,
  PLLDATI4,
  PLLDATI3,
  PLLDATI2,
  PLLDATI1,
  PLLDATI0,
  PLLADDR4,
  PLLADDR3,
  PLLADDR2,
  PLLADDR1,
  PLLADDR0,
  CLKOP,
  CLKOS,
  CLKOS2,
  CLKOS3,
  LOCK,
  INTLOCK,
  REFCLK,
  PLLDATO7,
  PLLDATO6,
  PLLDATO5,
  PLLDATO4,
  PLLDATO3,
  PLLDATO2,
  PLLDATO1,
  PLLDATO0,
  PLLACK,
  DPHSRC,
  CLKINTFB
)
;
input CLKI ;
input CLKFB ;
input PHASESEL1 ;
input PHASESEL0 ;
input PHASEDIR ;
input PHASESTEP ;
input LOADREG ;
input STDBY ;
input PLLWAKESYNC ;
input RST ;
input RESETM ;
input RESETC ;
input RESETD ;
input ENCLKOP ;
input ENCLKOS ;
input ENCLKOS2 ;
input ENCLKOS3 ;
input PLLCLK ;
input PLLRST ;
input PLLSTB ;
input PLLWE ;
input PLLDATI7 ;
input PLLDATI6 ;
input PLLDATI5 ;
input PLLDATI4 ;
input PLLDATI3 ;
input PLLDATI2 ;
input PLLDATI1 ;
input PLLDATI0 ;
input PLLADDR4 ;
input PLLADDR3 ;
input PLLADDR2 ;
input PLLADDR1 ;
input PLLADDR0 ;
output CLKOP ;
output CLKOS ;
output CLKOS2 ;
output CLKOS3 ;
output LOCK ;
output INTLOCK ;
output REFCLK ;
output PLLDATO7 ;
output PLLDATO6 ;
output PLLDATO5 ;
output PLLDATO4 ;
output PLLDATO3 ;
output PLLDATO2 ;
output PLLDATO1 ;
output PLLDATO0 ;
output PLLACK ;
output DPHSRC ;
output CLKINTFB ;
endmodule /* EHXPLLJ */

