run_tcl -fg sensehat_soc_impl_1_synplify.tcl
