prj_open {C:/lscc/workspace/MachXO4C_SENSHAT/soc/sensehat_soc/sensehat_soc.rdf}
prj_add_source {C:/lscc/workspace/MachXO4C_SENSHAT/constraints/sensehat_soc.pdc}
prj_add_source {C:/lscc/workspace/MachXO4C_SENSHAT/constraints/sensehat_soc.sdc}
prj_save
prj_close
