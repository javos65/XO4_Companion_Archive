set device "LFMXO4-110HC"
set device_int "xo4f9400"
set package "BBG256"
set package_int "BBG256"
set speed "6"
set speed_int "6"
set operation "Industrial"
set family "LFMXO4"
set architecture "xo4f00"
set partnumber "LFMXO4-110HC-6BBG256I"
set WRAPPER_INST "lscc_efb_inst"
set FAMILY "LFMXO4"
set SUBFAMILY "LFMXO4"
set DEVICE "LFMXO4-110HC"
set DEV_DENSITY "110"
set DEVICE_ID_TB 19619907
set EFB_WB_IN 1
set EFB_INTERFACE_IN "APB"
set APB_DATA_WIDTH 32
set APB_ADDR_WIDTH 10
set EFB_WB_CLK_FREQ_TB 12.000000
set EFB_WB_CLK_FREQ "12.0"
set EFB_I2C1_CFG_TB "I2C1_USER"
set EFB_I2C1 "DISABLED"
set EFB_I2C2 "ENABLED"
set EFB_SPI "DISABLED"
set EFB_TC "DISABLED"
set EFB_TC_PORTMODE "NO_WB"
set EFB_PLL_IN 0
set EFB_PLL_NUM_IN 1
set EFB_UFM "DISABLED"
set EFB_UFM_BOOT "INT_SINGLE_BOOT_CFG0"
set EFB_CFG0 "DISABLED"
set EFB_UFM0 "DISABLED"
set EFB_CFG1 "DISABLED"
set EFB_UFM1 "DISABLED"
set EFB_UFM2 "DISABLED"
set EFB_UFM3 "DISABLED"
set EFB_TAMPER_DETECTION_RESPONSE "DISABLED"
set I2C1_GEN_CALL "DISABLED"
set I2C1_WAKEUP "DISABLED"
set I2C1_BUS_PERF "100kHz"
set I2C1_CLK_DIVIDER "30"
set I2C1_ADDRESSING "7BIT"
set I2C1_SLAVE_ADDR "0b1000001"
set I2C2_GEN_CALL "DISABLED"
set I2C2_WAKEUP "DISABLED"
set I2C2_BUS_PERF "100kHz"
set I2C2_CLK_DIVIDER "30"
set I2C2_ADDRESSING "7BIT"
set I2C2_SLAVE_ADDR "0b1000010"
set SPI_MODE "SLAVE"
set SPI_WAKEUP "DISABLED"
set SPI_CLK_DIVIDER "12"
set SPI_CS_NUM 1
set SPI_LSB_FIRST "DISABLED"
set SPI_CLK_INV "DISABLED"
set SPI_PHASE_ADJ "DISABLED"
set SPI_SLAVE_HANDSHAKE "DISABLED"
set SPI_INTR_TXRDY "DISABLED"
set SPI_INTR_RXRDY "DISABLED"
set SPI_INTR_TXOVR "DISABLED"
set SPI_INTR_RXOVR "DISABLED"
set TC_MODE "CTCM"
set TC_OC_MODE "TOGGLE"
set TC_RESETN "ENABLED"
set TC_SCLK_SEL "PCLOCK"
set TC_CCLK_SEL "1"
set TC_OV_INT "OFF"
set TC_OCR_INT "OFF"
set TC_ICR_INT "OFF"
set TC_OVERFLOW "DISABLED"
set TC_ICAPTURE "DISABLED"
set TC_TOP_SEL "OFF"
set TC_TOP_SET "65535"
set TC_OCR_SET "32767"
set UFM_INIT_PAGES "1"
set UFM_INIT_START_PAGE "3581"
set UFM_INIT_ALL_ZEROS "ENABLED"
set UFM_INIT_FILE_NAME "NONE"
set UFM_INIT_FILE_FORMAT "HEX"
set CFG0_INIT_PAGES "1"
set CFG0_INIT_START_PAGE "12540"
set CFG0_INIT_ALL_ZEROS "ENABLED"
set CFG0_INIT_FILE_NAME "NONE"
set CFG0_INIT_FILE_FORMAT "HEX"
set UFM0_INIT_PAGES "1"
set UFM0_INIT_START_PAGE "3581"
set UFM0_INIT_ALL_ZEROS "ENABLED"
set UFM0_INIT_FILE_NAME "NONE"
set UFM0_INIT_FILE_FORMAT "HEX"
set CFG1_INIT_PAGES "1"
set CFG1_INIT_START_PAGE "12540"
set CFG1_INIT_ALL_ZEROS "ENABLED"
set CFG1_INIT_FILE_NAME "NONE"
set CFG1_INIT_FILE_FORMAT "HEX"
set UFM1_INIT_PAGES "1"
set UFM1_INIT_START_PAGE "3581"
set UFM1_INIT_ALL_ZEROS "ENABLED"
set UFM1_INIT_FILE_NAME "NONE"
set UFM1_INIT_FILE_FORMAT "HEX"
set UFM2_INIT_PAGES "1"
set UFM2_INIT_START_PAGE "1149"
set UFM2_INIT_ALL_ZEROS "ENABLED"
set UFM2_INIT_FILE_NAME "NONE"
set UFM2_INIT_FILE_FORMAT "HEX"
set UFM3_INIT_PAGES "1"
set UFM3_INIT_START_PAGE "190"
set UFM3_INIT_ALL_ZEROS "ENABLED"
set UFM3_INIT_FILE_NAME "NONE"
set UFM3_INIT_FILE_FORMAT "HEX"
set EFB_TAMPER_TYPE_PASSWORD "DISABLED"
set EFB_TAMPER_TYPE_LOCKED_FLASH_SRAM "DISABLED"
set EFB_TAMPER_TYPE_MANUFACTURE_MODE "DISABLED"
set EFB_TAMPER_SRC_JTAG "DISABLED"
set EFB_TAMPER_SRC_SSPI "DISABLED"
set EFB_TAMPER_SRC_SI2C "DISABLED"
set EFB_TAMPER_SRC_WB "DISABLED"
set EFB_TAMPER_PORT_LOCK "DISABLED"


# Clock Constraints
set WB_CLKI_PERIOD [expr {1000.0 / $EFB_WB_CLK_FREQ_TB}]
set SPI_CLK_PERIOD [expr {$SPI_CLK_DIVIDER*1000.0 / $EFB_WB_CLK_FREQ_TB}]

if { $radiant(stage) == "presyn" } {

if {$EFB_INTERFACE_IN == "WISHBONE"} {
    create_clock -name {wb_clk_i} -period $WB_CLKI_PERIOD [get_ports wb_clk_i]
}

if {$EFB_INTERFACE_IN == "APB"} {
    create_clock -name {clk_i} -period $WB_CLKI_PERIOD [get_ports clk_i]
}

if {$EFB_I2C1 == "ENABLED"} {
    if {$I2C1_BUS_PERF == "50kHz"} {
        create_clock -name {i2c1_scl} -period 20000 [get_ports i2c1_scl]
    }
    if {$I2C1_BUS_PERF == "100kHz"} {
        create_clock -name {i2c1_scl} -period 10000 [get_ports i2c1_scl]
    }
    if {$I2C1_BUS_PERF == "400kHz"} {
        create_clock -name {i2c1_scl} -period 2500 [get_ports i2c1_scl]
    }
}

if {$EFB_I2C2 == "ENABLED"} {
    if {$I2C2_BUS_PERF == "50kHz"} {
        create_clock -name {i2c2_scl} -period 20000 [get_ports i2c2_scl]
    }
    if {$I2C2_BUS_PERF == "100kHz"} {
        create_clock -name {i2c2_scl} -period 10000 [get_ports i2c2_scl]
    }
    if {$I2C2_BUS_PERF == "400kHz"} {
        create_clock -name {i2c2_scl} -period 2500 [get_ports i2c2_scl]
    }
}

if {$EFB_SPI == "ENABLED"} {
    create_clock -name {spi_clk} -period $SPI_CLK_PERIOD [get_ports spi_clk]
}

if {$EFB_TC == "ENABLED"} {
    create_clock -name {tc_clki} -period 10 [get_ports tc_clki]
}

if {$EFB_TAMPER_DETECTION_RESPONSE == "ENABLED"} {
    create_clock -name {tamper_detect_clk} -period 10 [get_ports tamper_detect_clk]
}

}