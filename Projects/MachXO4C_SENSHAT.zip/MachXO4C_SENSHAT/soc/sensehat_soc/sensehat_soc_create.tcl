# Propel design script: sensehat_soc
# Session: 65da77fd-ea23-43b6-8831-1b416feb1aa7
# Mode: open

sbp_design open -name {sensehat_soc} -path {C:/lscc/workspace/MachXO4C_SENSHAT/soc/sensehat_soc/sensehat_soc/sensehat_soc.sbx}

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}

sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4C_SENSHAT\firmware\sensehat_fw\Debug\sensehat_fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:4096,BYTE_ENABLE_S0:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:1,REGMODE_S0:False,RESET_MODE_S0:sync}
sbp_replace -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst} -component {sensehat_soc/sysmem0_inst}
sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4C_SENSHAT\firmware\sensehat_fw\Debug\sensehat_fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:4096,BYTE_ENABLE_S0:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:1,REGMODE_S0:False,RESET_MODE_S0:sync}
sbp_replace -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst} -component {sensehat_soc/sysmem0_inst}
sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4C_SENSHAT\firmware\sensehat_fw\Debug\sensehat_fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:4096,BYTE_ENABLE_S0:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:1,REGMODE_S0:False,RESET_MODE_S0:sync}
sbp_replace -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst} -component {sensehat_soc/sysmem0_inst}
sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4C_SENSHAT\firmware\sensehat_fw\Debug\sensehat_fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:4096,BYTE_ENABLE_S0:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:1,REGMODE_S0:False,RESET_MODE_S0:sync}
sbp_replace -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst} -component {sensehat_soc/sysmem0_inst}
sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4C_SENSHAT\firmware\sensehat_fw\Debug\sensehat_fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:4096,BYTE_ENABLE_S0:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:1,REGMODE_S0:False,RESET_MODE_S0:sync}
sbp_replace -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst} -component {sensehat_soc/sysmem0_inst}
sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4C_SENSHAT\firmware\sensehat_fw\Debug\sensehat_fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:4096,BYTE_ENABLE_S0:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:1,REGMODE_S0:False,RESET_MODE_S0:sync}
sbp_replace -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst} -component {sensehat_soc/sysmem0_inst}
sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {INIT_MEM:true,INIT_CHK:hex,INIT_FILE_IN:C:\lscc\workspace\MachXO4C_SENSHAT\firmware\sensehat_fw\Debug\sensehat_fw.mem,ACCESS_TYPE_S0:R/W,ADDR_DEPTH:4096,BYTE_ENABLE_S0:True,DATA_STREAMER_EN:False,DATA_WIDTH:32,ECC_ENABLE:False,INTERFACE:AHBL,MEMORY_TYPE:EBR,PORT_COUNT:1,REGMODE_S0:False,RESET_MODE_S0:sync}
sbp_replace -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst} -component {sensehat_soc/sysmem0_inst}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: sensehat_soc"