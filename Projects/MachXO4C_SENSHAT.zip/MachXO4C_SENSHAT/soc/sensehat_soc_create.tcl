# Propel design script: sensehat_soc
# Session: 0c85258c-cec9-4265-ab61-48c8b3a2e3fa
# Mode: new

file delete -force {sensehat_soc}
sbp_create_project -name {sensehat_soc} -path {.} -device {LFMXO4-110HC-6BBG256I} -speed {6} -language {verilog} -board {NA}
# Blank template ships clk_i/rstn_i -- remove them, as Lattice's own create_soc_demo.tcl does.
catch { sbp_delete "sensehat_soc/clk_i" -type port }
catch { sbp_delete "sensehat_soc/rstn_i" -type port }

# Register IP catalog search paths for headless mode
::ip_catalog::ip_catalog_location -add {C:\Users\jvos\PropelIPLocal}

catch { sbp_delete "sensehat_soc/clk_i" -type port }
catch { sbp_delete "sensehat_soc/rstn_i" -type port }
sbp_config_ip -vlnv {latticesemi.com:module:pll0:3.0.1} -meta_vlnv {latticesemi.com:module:pll:3.0.1} -cfg_value {gui_config_mode:FREQUENCY,gui_freq_refclk:12,gui_clkop_freq:24,gui_clkop_tol:0.0,gui_clkos_en:true,gui_clkos_freq:12,gui_clkos_tol:0.0,gui_en_lock_port:true}
sbp_config_ip -vlnv {latticesemi.com:ip:cpu0:1.9.0} -meta_vlnv {latticesemi.com:ip:riscv_sm:1.9.0} -cfg_value {DEBUG_ENABLE:false,PIC_ENABLE:true,IRQ_NUM:1,TIMER_ENABLE:true}
sbp_config_ip -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -meta_vlnv {latticesemi.com:ip:system_memory:2.6.0} -cfg_value {ADDR_DEPTH:4096,PORT_COUNT:1}
sbp_config_ip -vlnv {latticesemi.com:module:ahbl0:1.5.0} -meta_vlnv {latticesemi.com:module:ahb_lite_interconnect:1.5.0} -cfg_value {TOTAL_MASTER_CNT:2,TOTAL_SLAVE_CNT:2}
sbp_config_ip -vlnv {latticesemi.com:module:ahbl2apb0:1.2.0} -meta_vlnv {latticesemi.com:module:ahb_lite_to_apb_bridge:1.2.0} -cfg_value {ADDR_WIDTH:16,DATA_WIDTH:32,APB_CLK_EN:true}
sbp_config_ip -vlnv {latticesemi.com:module:apb0:1.4.0} -meta_vlnv {latticesemi.com:module:apb_interconnect:1.4.0} -cfg_value {TOTAL_MASTER_CNT:1,TOTAL_SLAVE_CNT:3,M_ADDR_WIDTH:16,DATA_WIDTH:32}
sbp_config_ip -vlnv {latticesemi.com:ip:uart0:1.6.0} -meta_vlnv {latticesemi.com:ip:uart:1.6.0} -cfg_value {SYS_CLOCK_FREQ:12,LCR_DATA_BITS:8,LCR_STOP_BITS:1,BAUD_RATE_TYPE:Standard,STANDARD_BAUD_RATE:19200,FIFO:false,RXRDY_ENA:false,TXRDY_ENA:false}
sbp_config_ip -vlnv {latticesemi.com:ip:gpio0:1.8.1} -meta_vlnv {latticesemi.com:ip:gpio:1.8.1} -cfg_value {IO_LINES_COUNT:6,EXTERNAL_BUF:false,IF_USER_INTF:APB}
sbp_config_ip -vlnv {latticesemi.com:module:efb0:1.3.0} -meta_vlnv {latticesemi.com:module:lscc_efb:1.3.0} -cfg_value {EFB_WB_IN:true,EFB_INTERFACE_IN:APB,APB_DATA_WIDTH:32,APB_ADDR_WIDTH:10,EFB_WB_CLK_FREQ_TB:12,EFB_I2C1_IN:false,EFB_I2C2_IN:true,I2C2_BUS_PERF:100kHz,EFB_SPI_IN:false,EFB_TC_IN:false,EFB_UFM_IN:false}
sbp_config_ip -vlnv {custom:module:sh0:1.0.0} -meta_vlnv {custom:module:SenseHat_efb:1.0.0} -cfg_value {}
sbp_config_ip -vlnv {latticesemi.com:module:rst24:1.1.0} -meta_vlnv {latticesemi.com:module:lscc_reset:1.1.0} -cfg_value {RESET_MODE:ASYNC,SYNC_STAGE:2}
sbp_config_ip -vlnv {latticesemi.com:module:rst12:1.1.0} -meta_vlnv {latticesemi.com:module:lscc_reset:1.1.0} -cfg_value {RESET_MODE:ASYNC,SYNC_STAGE:2}
sbp_add_component -vlnv {latticesemi.com:module:pll0:3.0.1} -name {pll0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:cpu0:1.9.0} -name {cpu0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:sysmem0:2.6.0} -name {sysmem0_inst}
sbp_add_component -vlnv {latticesemi.com:module:ahbl0:1.5.0} -name {ahbl0_inst}
sbp_add_component -vlnv {latticesemi.com:module:ahbl2apb0:1.2.0} -name {ahbl2apb0_inst}
sbp_add_component -vlnv {latticesemi.com:module:apb0:1.4.0} -name {apb0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:uart0:1.6.0} -name {uart0_inst}
sbp_add_component -vlnv {latticesemi.com:ip:gpio0:1.8.1} -name {gpio0_inst}
sbp_add_component -vlnv {latticesemi.com:module:efb0:1.3.0} -name {efb0_inst}
sbp_add_component -vlnv {custom:module:sh0:1.0.0} -name {sh0_inst}
sbp_add_component -vlnv {latticesemi.com:module:rst24:1.1.0} -name {rst24_inst}
sbp_add_component -vlnv {latticesemi.com:module:rst12:1.1.0} -name {rst12_inst}
sbp_replace -vlnv {latticesemi.com:module:pll0:3.0.1} -name {pll0_inst} -component {sensehat_soc/pll0_inst}
sbp_add_gluelogic -name rst_and_0 -logicinfo [sbp_create_glue_logic equation rst_and {} { {"expr":"a & b","module_name":"rst_and"}}]
sbp_add_port -direction in clk12_i
sbp_add_port -direction in sw2_n_i
sbp_add_port -direction in rxd_i
sbp_add_port -direction out txd_o
sbp_add_port -direction inout i2c2_scl
sbp_add_port -direction inout i2c2_sda
sbp_add_port -from 5 -to 0 -direction inout gpio_io
sbp_connect_net {sensehat_soc/clk12_i} {sensehat_soc/pll0_inst/clki_i}
sbp_connect_net {sensehat_soc/pll0_inst/clkop_o} {sensehat_soc/cpu0_inst/clk_i} {sensehat_soc/sysmem0_inst/ahbl_hclk_i} {sensehat_soc/ahbl0_inst/ahbl_hclk_i} {sensehat_soc/ahbl2apb0_inst/clk_i} {sensehat_soc/rst24_inst/dest_clk}
sbp_connect_net {sensehat_soc/pll0_inst/clkos_o} {sensehat_soc/ahbl2apb0_inst/pclk_i} {sensehat_soc/apb0_inst/apb_pclk_i} {sensehat_soc/uart0_inst/clk_i} {sensehat_soc/gpio0_inst/clk_i} {sensehat_soc/efb0_inst/clk_i} {sensehat_soc/rst12_inst/dest_clk}
sbp_connect_net {sensehat_soc/sw2_n_i} {sensehat_soc/rst_and_0/a}
sbp_connect_net {sensehat_soc/pll0_inst/lock_o} {sensehat_soc/rst_and_0/b}
sbp_connect_net {sensehat_soc/rst_and_0/O} {sensehat_soc/rst24_inst/src_rst_n} {sensehat_soc/rst12_inst/src_rst_n}
sbp_connect_net {sensehat_soc/rst24_inst/dest_rst_n} {sensehat_soc/cpu0_inst/rst_n_i} {sensehat_soc/sysmem0_inst/ahbl_hresetn_i} {sensehat_soc/ahbl0_inst/ahbl_hresetn_i} {sensehat_soc/ahbl2apb0_inst/rst_n_i}
sbp_connect_net {sensehat_soc/rst12_inst/dest_rst_n} {sensehat_soc/ahbl2apb0_inst/presetn_i} {sensehat_soc/apb0_inst/apb_presetn_i} {sensehat_soc/uart0_inst/rst_n_i} {sensehat_soc/gpio0_inst/resetn_i} {sensehat_soc/efb0_inst/rstn_i}
sbp_connect_net {sensehat_soc/rxd_i} {sensehat_soc/uart0_inst/rxd_i}
sbp_connect_net {sensehat_soc/uart0_inst/txd_o} {sensehat_soc/txd_o}
sbp_connect_net {sensehat_soc/efb0_inst/i2c2_scl} {sensehat_soc/i2c2_scl}
sbp_connect_net {sensehat_soc/efb0_inst/i2c2_sda} {sensehat_soc/i2c2_sda}
sbp_connect_net {sensehat_soc/gpio0_inst/gpio_io} {sensehat_soc/gpio_io}
sbp_connect_interface_net {sensehat_soc/cpu0_inst/AHBL_M0_INSTR} {sensehat_soc/ahbl0_inst/AHBL_S00}
sbp_connect_interface_net {sensehat_soc/cpu0_inst/AHBL_M1_DATA} {sensehat_soc/ahbl0_inst/AHBL_S01}
sbp_connect_interface_net {sensehat_soc/ahbl0_inst/AHBL_M00} {sensehat_soc/sysmem0_inst/AHBL_S0}
sbp_connect_interface_net {sensehat_soc/ahbl0_inst/AHBL_M01} {sensehat_soc/ahbl2apb0_inst/AHBL_S0}
sbp_connect_interface_net {sensehat_soc/ahbl2apb0_inst/APB_M0} {sensehat_soc/apb0_inst/APB_S00}
sbp_connect_interface_net {sensehat_soc/apb0_inst/APB_M00} {sensehat_soc/uart0_inst/APB_S0}
sbp_connect_interface_net {sensehat_soc/apb0_inst/APB_M01} {sensehat_soc/gpio0_inst/APB_S0}
sbp_connect_interface_net {sensehat_soc/apb0_inst/APB_M02} {sensehat_soc/sh0_inst/APB_S0}
sbp_connect_interface_net {sensehat_soc/sh0_inst/APB_M0} {sensehat_soc/efb0_inst/APB_S0}
sbp_connect_interface_net {sensehat_soc/uart0_inst/INT_M0} {sensehat_soc/cpu0_inst/IRQ_S0}
sbp_assign_addr_seg -offset 'h00000000 {sensehat_soc/ahbl0_inst/AHBL_M00} {sensehat_soc/sysmem0_inst/AHBL_S0}
sbp_assign_addr_seg -offset 'h00008000 {sensehat_soc/apb0_inst/APB_M00} {sensehat_soc/uart0_inst/APB_S0}
sbp_assign_addr_seg -offset 'h00008400 {sensehat_soc/apb0_inst/APB_M01} {sensehat_soc/gpio0_inst/APB_S0}
sbp_assign_addr_seg -offset 'h00008800 {sensehat_soc/apb0_inst/APB_M02} {sensehat_soc/sh0_inst/APB_S0}

# Save and validate
sbp_design save
sbp_design generate
sbp_design save
sbp_design drc

puts "Script completed: sensehat_soc"