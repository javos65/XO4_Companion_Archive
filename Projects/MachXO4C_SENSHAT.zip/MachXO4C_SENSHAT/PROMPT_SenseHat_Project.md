# Project Build Prompt: MachXO4 Companion Board with Raspberry Pi Sense HAT

## 1. Role and Objective

You are a Lattice FPGA design consultant using the Lattice Propel and Radiant 2026.1 toolchain through the available MCP tools. Build, from scratch, a RISC-V SoC on the MachXO4 Companion board that reads and drives a Raspberry Pi Sense HAT over I2C, with status feedback over UART. Deliver a working bitstream loaded into the FPGA, the firmware, a custom BSP IP package and documentation.

## 2. Mandatory Workflow Rules

- Read `lattice://operational_advisory` and `lattice://workflow` before building; load each phase resource when entering that phase.
- Treat `validate_topology` and `validate_timing` as hard gates. Do not report completion unless both pass.
- Open a design plan (`design_plan_open`) and record every decision, including deviations.
- Do not invent IP parameters, pin locations or register maps. Ground each of them in the datasheets in `doc/`, the board schematic, or the IP catalogue.
- Confirm with the user before any outward-facing or hard-to-reverse action (for example flash programming).

## 3. Target Hardware

- **Board:** MachXO4 Companion board, device LFMXO4-110HC-6BBG256I.
- **Add-on:** Raspberry Pi Sense HAT (V2) on the 40-pin header.
- **Serial:** on-board FTDI USB-UART, 19200 baud, 8N1.
- **Programming:** SRAM programming with `pgrcmd.exe -infile constraints\program_sram.xcf`. The MCP `radiant_program` returns an empty transcript on this host, so use `pgrcmd`.

## 4. SoC Architecture

- **CPU:** `riscv_sm` at 24 MHz. It has no M extension, so compile with `-march=rv32i -mabi=ilp32`. Multiply and divide come from libgcc. Verify with `objdump` that the image contains no hardware mul/div instructions.
- **Peripheral clock:** 12 MHz.
- **System memory:** `sysmem0`, 16 KB, initialised with the firmware (two-pass build).
- **UART:** FTDI-connected, 19200 8N1.
- **GPIO:** 7 lines.
  - Lines 0-3: board LEDs (outputs, mask 0x0F).
  - Line 5: Sense HAT reset (output).
  - Line 6: INT1, the HAT KEYS_INT joystick interrupt (input, ball K14, LVCMOS33, no pull, active high, GPIO23 on the header).
- **Interrupt:** `gpio0_inst/INTR` connects to `cpu0_inst/IRQ_S0` (PIC source 0). Edge type, rising polarity, write-1-to-clear status. The ISR only clears the status and increments a counter; the main loop does the I2C work.
- **I2C:** the MachXO4 EFB secondary I2C (I2C2) at 100 kHz, wired to the HAT. The EFB is instantiated through the `lscc_efb` IP.
- **Custom IP `SenseHat_efb` 1.0.0:** a passthrough wrapper around the EFB I2C that provides the BSP drivers. It depends on `lscc_efb` and must be documented as such.
- **Constraints:** `constraints\sensehat_soc.pdc` (pin locations, LVCMOS33) and `constraints\sensehat_soc.sdc` (clocks, false paths on asynchronous GPIO).

## 5. Sense HAT Devices on the I2C Bus

| Device | Address | ID register | Expected ID |
|---|---|---|---|
| ATTINY88 (LED matrix and joystick) | 0x46 | none | none |
| LPS25H pressure and temperature | 0x5C | 0x0F | 0xBD |
| HTS221 humidity and temperature | 0x5F | 0x0F | 0xBC |
| LSM9DS1 accelerometer and gyroscope | 0x6A | 0x0F | 0x68 |
| LSM9DS1 magnetometer | 0x1C | 0x0F | 0x3D |
| TCS3400 colour sensor (TCS34725 is the wrong family) | 0x39 | 0x92 | 0x90 (mask 0xFC) |

Device facts to respect:

- **ATTINY88:** the LED framebuffer is 193 bytes (a leading offset byte plus 64 pixels in 3 bytes each). The joystick register is 0xF2 (DOWN 0x01, RIGHT 0x02, UP 0x04, CENTER 0x08, LEFT 0x10).
- **LPS25H and HTS221:** set sub-address bit 7 (0x80) for auto-increment. The HTS221 needs its factory calibration read from 0x30-0x3F.
- **LSM9DS1:** read the magnetometer one register per transfer.
- **TCS3400:** absolute register addresses with no command byte. Write the reserved CONFIG bit (register 0x8D = 0x40). Wait 3 ms between PON and AEN. Read the channel data as 2-byte pairs starting on even addresses.

## 6. Firmware Requirements

### 6.1 Build and size

- Compile flags: `-Os -msave-restore -flto -ffunction-sections -fdata-sections`, with `--gc-sections` at link time. The goal is the smallest firmware. Target about 10 KB of code.
- Linker: heap 0x40, stack 0x800, 16 KB memory region.
- Propel regenerates makefiles with `-O2`, so reapply the flags in `Debug/makefile` and every `Debug/**/*.mk` after regeneration.

### 6.2 BSP drivers (in `src/bsp/driver/SenseHat_efb/`)

- `SenseHat_efb.{c,h}` and `SenseHat_efb_regs.h`: I2C init, write, write-read, block write, reset, and the LED matrix and joystick functions.
- `lps25h`, `hts221`, `lsm9ds1` (accelerometer/gyro and magnetometer) and `tcs3400`. Also provide `tcs34725` as an alternative for the TCS3472x family.
- Integer arithmetic only, with documented error codes per driver.

### 6.3 Application behaviour (`src/main.c`)

- **Start-up UART output, in this order:**
  1. `SENSE HAT KNIGHT RIDER 1.0 (RISC-V SM 24 MHz, EFB I2C2 100 kHz, 19200 8N1)`
  2. `I2C init: ok, SCL 100 kHz`
  3. `HAT reset done`
  4. `I2C scan 0x08..0x77:`, followed by a table with the columns Device, Address, ID and Status. Status is OK or NOT OK. Rows are ATTINY88, LPS25H, HTS221, LSM9DS1 A/G, LSM9DS1 Mag and TCS3400.
- **LED matrix:** a Knight Rider sweep with a fading trail that bounces automatically.
  - Joystick UP and DOWN move the trail between rows.
  - Joystick LEFT and RIGHT step the colour through 8 hues (red, orange, yellow, green, cyan, blue, violet, magenta) and print the hue name.
  - CENTER pauses the sweep.
- **Joystick:** read register 0xF2 when the INT1 interrupt counter changes, plus a 1 s safety poll.
- **Sensor report:** each time the joystick is pressed, print one UART line each for pressure and temperature, humidity and temperature, acceleration (mg), angular rate (mdps), IMU temperature, magnetic field (mgauss), and the colour sensor (clear, red, green, blue, normalised RGB, saturation flag).
- **Heartbeat:** drive one board LED only at 500 ms. All other board LEDs stay off.

## 7. Build Procedure

1. Open a design plan and record the architecture.
2. Create the Propel session and the SoC (`sensehat_soc`) with the CPU, `sysmem0`, GPIO, UART, timer, PIC and `lscc_efb`, wired as in section 4.
3. Install the `SenseHat_efb` IP from the local IP library.
4. Generate the SoC and run `propel_check_generated_sources`.
5. Generate, build and compile the firmware (`firmware_gen_project`, `firmware_gen_build`, `firmware_compile` with clean builds, since a stale ELF may otherwise be reported).
6. Bake the firmware into `sysmem0` with `add_firmware_to_proj` and confirm with `check_memory_init_applied`.
7. Run the Radiant build (`radiant_build_detached` and `radiant_build_wait`).
8. Pass `validate_topology` and `validate_timing`. There must be zero failing endpoints.
9. Program the SRAM with `pgrcmd` and verify the UART output on the FTDI port.

## 8. IP Package Deliverable

- Package: `custom_SenseHat_efb_1.0.0.ipk`, a flat zip. Entries: `address_space.xml`, `bus_interface.xml`, `memory_map.xml`, `metadata.xml`, `doc/EULA.txt`, `doc/introduction.html`, `driver/*`, `rtl/SenseHat_efb.v`.
- `introduction.html` must explain the Sense HAT, the address window, all devices, every driver function with an example, and the dependency on the `lscc_efb` IP.
- Install a copy in the local Propel IP library.

## 9. Acceptance Criteria

- The UART shows the start-up lines and the table with all six devices OK.
- The heartbeat LED blinks and the other board LEDs are off.
- Joystick UP, DOWN, LEFT and RIGHT change the trail row and hue as described, and each press prints the sensor report.
- The timing gate passes, the code size is at or below about 10 KB, and the image has no hardware mul/div.
- The design plan records all decisions, including the `rv32i` fix, INT1, the sensors and the optimisation settings.

## 10. Known Pitfalls

- Pitfall: an `rv32im` build fails at run time. Fix: use `rv32i`.
- Pitfall: the TCS3400 (ID 0x90) is not a TCS34725. Fix: use the TCS3400 register map without a command byte.
- Pitfall: changing the INT1 connection with `sbp_delete` or `sbp_add_port` fails. Fix: use `sbp_modify_port`; the interface name is `INTR`.
- Pitfall: editing generated makefiles by string replace can fail silently with CRLF line endings. Fix: use targeted edits.
- Pitfall: the programmed image is volatile. Fix: write the flash only after the user confirms.

## 11. Compliance Note

No internal policy numbers were identified for this project, so none are cited. If your organisation assigns policy numbers to firmware release, design review or third-party datasheet use, add them to the design plan before release.
