# Patch: add Sense HAT INT1 (RASP_IO23, ball K14) as GPIO line 6 and route the GPIO interrupt to the CPU PIC.
sbp_disconnect_net {sensehat_soc/gpio0_inst/gpio_io} {sensehat_soc/gpio_io}
sbp_config_ip -vlnv {latticesemi.com:ip:gpio0:1.8.1} -meta_vlnv {latticesemi.com:ip:gpio:1.8.1} -cfg_value {IO_LINES_COUNT:7,EXTERNAL_BUF:false,IF_USER_INTF:APB}
sbp_replace -vlnv {latticesemi.com:ip:gpio0:1.8.1} -name {gpio0_inst} -component {sensehat_soc/gpio0_inst}
sbp_modify_port -name sensehat_soc/gpio_io -from 6 -to 0 -direction inout
sbp_connect_net {sensehat_soc/gpio0_inst/gpio_io} {sensehat_soc/gpio_io}
sbp_disconnect_interface_net {sensehat_soc/uart0_inst/INT_M0} {sensehat_soc/cpu0_inst/IRQ_S0}
sbp_connect_interface_net {sensehat_soc/gpio0_inst/INTR} {sensehat_soc/cpu0_inst/IRQ_S0}
