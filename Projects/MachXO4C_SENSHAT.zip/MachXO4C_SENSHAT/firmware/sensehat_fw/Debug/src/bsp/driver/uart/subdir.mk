################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables
C_SRCS += \
../src/bsp/driver/uart/uart.c 

OBJS += \
./src/bsp/driver/uart/uart.o 

C_DEPS += \
./src/bsp/driver/uart/uart.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/uart/%.o: ../src/bsp/driver/uart/%.c src/bsp/driver/uart/subdir.mk
	@echo 'Building file: $<'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -msave-restore -Os -fmessage-length=0 -fsigned-char -flto -ffunction-sections -fdata-sections  -g3 -DPLATFORM_PROPEL -I"../src" -I"../src/bsp" -I"../src/bsp/boot" -I"../src/bsp/driver" -I"../src/bsp/driver/cpu" -I"../src/bsp/driver/gpio" -I"../src/bsp/driver/riscv_sm" -I"../src/bsp/driver/SenseHat_efb" -I"../src/bsp/driver/uart" -I"../src/config" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_DOUBLE_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo ' '

