src/bsp/driver/SenseHat_efb/SenseHat_efb.o: \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb.c \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h
../src/bsp/driver/SenseHat_efb/SenseHat_efb.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h:
