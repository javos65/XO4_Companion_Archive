src/bsp/driver/SenseHat_efb/lsm9ds1.o: \
 ../src/bsp/driver/SenseHat_efb/lsm9ds1.c \
 ../src/bsp/driver/SenseHat_efb/lsm9ds1.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h
../src/bsp/driver/SenseHat_efb/lsm9ds1.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h:
