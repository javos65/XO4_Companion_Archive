src/bsp/driver/SenseHat_efb/hts221.o: \
 ../src/bsp/driver/SenseHat_efb/hts221.c \
 ../src/bsp/driver/SenseHat_efb/hts221.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h
../src/bsp/driver/SenseHat_efb/hts221.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h:
