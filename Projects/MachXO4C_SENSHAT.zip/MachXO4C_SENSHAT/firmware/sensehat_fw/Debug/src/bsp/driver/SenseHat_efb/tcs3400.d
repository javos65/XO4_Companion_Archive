src/bsp/driver/SenseHat_efb/tcs3400.o: \
 ../src/bsp/driver/SenseHat_efb/tcs3400.c \
 ../src/bsp/driver/SenseHat_efb/tcs3400.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h
../src/bsp/driver/SenseHat_efb/tcs3400.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h:
