src/bsp/driver/SenseHat_efb/tcs34725.o: \
 ../src/bsp/driver/SenseHat_efb/tcs34725.c \
 ../src/bsp/driver/SenseHat_efb/tcs34725.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h
../src/bsp/driver/SenseHat_efb/tcs34725.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h:
