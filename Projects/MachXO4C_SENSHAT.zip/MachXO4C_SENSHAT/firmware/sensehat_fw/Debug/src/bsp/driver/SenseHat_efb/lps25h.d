src/bsp/driver/SenseHat_efb/lps25h.o: \
 ../src/bsp/driver/SenseHat_efb/lps25h.c \
 ../src/bsp/driver/SenseHat_efb/lps25h.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h
../src/bsp/driver/SenseHat_efb/lps25h.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h:
