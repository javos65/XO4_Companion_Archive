src/main.o: ../src/main.c ../src/bsp/driver/SenseHat_efb/SenseHat_efb.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h \
 ../src/bsp/driver/SenseHat_efb/lps25h.h \
 ../src/bsp/driver/SenseHat_efb/SenseHat_efb.h \
 ../src/bsp/driver/SenseHat_efb/hts221.h \
 ../src/bsp/driver/SenseHat_efb/lsm9ds1.h \
 ../src/bsp/driver/SenseHat_efb/tcs3400.h ../src/bsp/driver/uart/uart.h \
 ../src/bsp/driver/gpio/gpio.h ../src/bsp/driver/gpio/gpio_regs.h \
 ../src/bsp/driver/riscv_sm/timer.h ../src/bsp/driver/riscv_sm/pic.h \
 ../src/bsp/driver/riscv_sm/util.h ../src/bsp/driver/riscv_sm/stack.h
../src/bsp/driver/SenseHat_efb/SenseHat_efb.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb_regs.h:
../src/bsp/driver/SenseHat_efb/lps25h.h:
../src/bsp/driver/SenseHat_efb/SenseHat_efb.h:
../src/bsp/driver/SenseHat_efb/hts221.h:
../src/bsp/driver/SenseHat_efb/lsm9ds1.h:
../src/bsp/driver/SenseHat_efb/tcs3400.h:
../src/bsp/driver/uart/uart.h:
../src/bsp/driver/gpio/gpio.h:
../src/bsp/driver/gpio/gpio_regs.h:
../src/bsp/driver/riscv_sm/timer.h:
../src/bsp/driver/riscv_sm/pic.h:
../src/bsp/driver/riscv_sm/util.h:
../src/bsp/driver/riscv_sm/stack.h:
