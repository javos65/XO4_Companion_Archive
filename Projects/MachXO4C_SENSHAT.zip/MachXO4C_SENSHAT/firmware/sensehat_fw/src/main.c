/* Sense HAT Knight Rider, firmware 1.0.
 *
 * RISC-V SM at 24 MHz, peripherals (APB, EFB, UART) at 12 MHz. A red dot with a fading trail
 * sweeps back and forth across the 8x8 RGB LED matrix of the Raspberry Pi Sense HAT. The matrix
 * and the joystick sit behind the ATTINY88 at I2C address 0x46, reached through the SenseHat_efb
 * driver (EFB secondary I2C, 100 kHz). Status goes to the FTDI UART (19200 baud 8N1).
 *
 * Joystick: up / down move the trail up / down, left / right step the colour through 8 hues,
 * centre pauses. Only LED1 is used (heartbeat), LED2..LED4 stay off.
 * Polling only, no interrupts, no printf (integer formatting is local to keep the image small).
 *
 * Addresses: UART 0x8000, GPIO 0x8400, SenseHat_efb 0x8800, PIC/timer 0xFFFF0000.
 * GPIO lines: bits 0..3 LED1..LED4 (active low), bit 4 SW1 (active low, input),
 *             bit 5 Sense HAT PROG_RST_N (pseudo open-drain: output low = reset, input = released).
 */
#include <stddef.h>
#include <stdint.h>
#include "bsp/driver/SenseHat_efb/SenseHat_efb.h"
#include "bsp/driver/SenseHat_efb/lps25h.h"
#include "bsp/driver/SenseHat_efb/hts221.h"
#include "bsp/driver/SenseHat_efb/lsm9ds1.h"
#include "bsp/driver/SenseHat_efb/tcs3400.h"
#include "bsp/driver/uart/uart.h"
#include "bsp/driver/gpio/gpio.h"
#include "bsp/driver/gpio/gpio_regs.h"
#include "bsp/driver/riscv_sm/timer.h"
#include "bsp/driver/riscv_sm/pic.h"

/* ---- board constants ---- */
#define UART_BASE        0x00008000u
#define GPIO_BASE        0x00008400u
#define SENSEHAT_BASE    0x00008800u    /* SenseHat_efb -> lscc_efb */
#define TIMER_BASE       0xFFFF0000u
#define CPU_HZ           24000000u      /* CPU clock; machine timer assumed to tick at this rate */
#define APB_HZ           12000000u      /* APB / EFB WISHBONE clock */
#define UART_BAUD        19200u         /* divisor 39 at 12 MHz: exact */
#define I2C_HZ           100000u

#define GPIO_LINES       7u
#define GPIO_OUT_MASK    0x0Fu          /* bits 0..3 outputs (LEDs); bit 4 SW1, bit 5 HAT reset, bit 6 INT1 are inputs */
#define LED_HEARTBEAT    0u
#define HAT_RESET_LINE   5u
#define HAT_INT1_LINE    6u             /* Sense HAT KEYS_INT (RASP_IO23, K14): high when the joystick changes */
#define GPIO_IRQ_SRC     S_INT_PIC0     /* GPIO int_o -> CPU IRQ_S0 -> PIC source 0 */
#define JOY_POLL_MS      1000u          /* slow safety poll, only reports a change that INT1 missed */

/* ---- effect parameters ---- */
#define ROW_TOP          3u             /* the bar is drawn on rows 3 and 4 */
#define ROW_BOTTOM       4u
#define HEAD_LEVEL       31u            /* at or below 31: valid for both 5-bit and 6-bit colour readings */
#define STEP_MS_DEFAULT  70u
#define STEP_MS_MIN      20u
#define STEP_MS_MAX      300u
#define STEP_MS_DELTA    10u
#define HEARTBEAT_MS     500u
#define STATUS_FRAMES    200u           /* one status line every 200 frames */
#define FAIL_RESET_LIMIT 5u             /* consecutive failed frames before the HAT is reset */

static struct uart_instance          uart;
static struct gpio_instance          gpio;
static struct timer_instance         tmr;
static struct sensehat_efb_instance  hat;
static struct hts221_instance        hts;                    /* HTS221 calibration */
static uint8_t                       have_lps, have_hts, have_ag, have_mag, have_col;   /* sensor present and initialised */
static volatile uint32_t             int1_events;            /* counted by the ISR, consumed by the main loop */
static uint8_t                       fb[SENSEHAT_FB_BYTES];
static uint8_t                       level[SENSEHAT_COLS];   /* red level per column, decays every step */
static uint8_t                       row_top = ROW_TOP;      /* upper row of the 2-row bar, moved by the joystick */

/* ------------------------------------------------------------------ console */
static void put_ch(char c) { (void)uart_putc(&uart, (unsigned char)c); }
static void put_str(const char *s) { while (*s) put_ch(*s++); }
static void put_crlf(void) { put_ch('\r'); put_ch('\n'); }

static void put_num(uint32_t v)
{
    char buf[11];
    int n = 0;
    do { buf[n++] = (char)('0' + (v % 10u)); v /= 10u; } while (v != 0u && n < 10);
    while (n > 0) put_ch(buf[--n]);
}

static void put_hex2(uint8_t v)
{
    put_ch("0123456789ABCDEF"[(v >> 4) & 0xFu]);
    put_ch("0123456789ABCDEF"[v & 0xFu]);
}

/* ------------------------------------------------------------------ time base */
static uint64_t now_ticks(void)
{
    unsigned long long v = 0;
    (void)timer_get_mtime(&tmr, &v);
    return (uint64_t)v;
}

/* busy wait on the machine timer; also the EFB driver's real-time wait hook */
static void udelay(uint32_t us)
{
    uint64_t end = now_ticks() + (uint64_t)us * (CPU_HZ / 1000000u);
    while ((int64_t)(now_ticks() - end) < 0) { }
}

static void mdelay(uint32_t ms) { udelay(ms * 1000u); }

/* ------------------------------------------------------------------ GPIO helpers */
/* Lattice GPIO driver 1.8.1 (hardware-checked on the INA236 design): gpio_output_write() masks the
 * value with the line's bit (1 << line) without shifting, so the value must already be in bit
 * position `line`; gpio_input_get() returns the whole input register, not one bit. */
static void led_heartbeat(int on)
{
    /* LED1..LED4 are active low (GPIO bits 0..3). One write sets all four: LED2..LED4 are always
     * off (bits high); only LED1 follows the heartbeat. The other GPIO lines are inputs. */
    uint32_t v = 0x0Eu | (on ? 0u : 1u);
    *(volatile uint32_t *)(GPIO_BASE + GPIO_WR_DATA) = v;
}

/* Hue steps: red, orange, yellow, green, cyan, blue, violet, magenta. Weights 0..8 of the full
 * brightness for red, green and blue. */
#define HUE_COUNT 8u
static const uint8_t hue_rgb[HUE_COUNT][3] = {
    {8, 0, 0}, {8, 3, 0}, {8, 8, 0}, {0, 8, 0}, {0, 8, 8}, {0, 0, 8}, {4, 0, 8}, {8, 0, 8}
};
static const char *const hue_name[HUE_COUNT] = {
    "red", "orange", "yellow", "green", "cyan", "blue", "violet", "magenta"
};
static uint8_t hue;

/* INT1 interrupt service routine (called from irq_callback through the PIC). Runs in interrupt
 * context, so it only acknowledges the GPIO interrupt and counts the event; the I2C joystick read
 * happens in the main loop. INT_STATUS is write-1-to-clear. */
static void int1_isr(void *ctx)
{
    (void)ctx;
    *(volatile uint32_t *)(GPIO_BASE + GPIO_INT_STATUS) = 1u << HAT_INT1_LINE;
    int1_events++;
}

/* GPIO line 6: input, edge type, rising edge (INT_METHOD bit = 1 selects rising in the Lattice
 * GPIO RTL), then routed to the PIC. */
static void int1_init(void)
{
    volatile uint32_t *r = (volatile uint32_t *)GPIO_BASE;
    uint32_t bit = 1u << HAT_INT1_LINE;

    r[GPIO_INT_ENABLE / 4u] &= ~bit;
    r[GPIO_INT_TYPE / 4u]   &= ~bit;       /* edge */
    r[GPIO_INT_METHOD / 4u] |= bit;        /* rising */
    r[GPIO_INT_STATUS / 4u]  = bit;        /* clear anything pending */
    (void)pic_init(TIMER_BASE);            /* PIC and machine timer share 0xFFFF0000 */
    (void)pic_isr_register(GPIO_IRQ_SRC, int1_isr, &gpio);
    r[GPIO_INT_ENABLE / 4u] |= bit;
}

/* Resets the ATTINY88: drive PROG_RST_N low for 10 ms, release it (the HAT pull-up R4 holds it
 * high) and give the firmware 100 ms to boot. The ATTINY88 clears its LED framebuffer. */
static void hat_reset(void)
{
    (void)gpio_output_write(&gpio, HAT_RESET_LINE, 0u);
    (void)gpio_set_direction(&gpio, HAT_RESET_LINE, GPIO_OUTPUT);
    mdelay(10u);
    (void)gpio_set_direction(&gpio, HAT_RESET_LINE, GPIO_INPUT);
    mdelay(100u);
}

/* ------------------------------------------------------------------ Sense HAT helpers */
static void report_error(const char *what, int rc)
{
    put_str(what);
    put_str(": ");
    put_str(sensehat_strerror(rc));
    put_str(" (SR=0x");
    put_hex2(hat.last_sr);
    put_ch(')');
    put_crlf();
}

/* ---- start-up device table: Device, Address, ID, Status ---- */
static void put_pad(const char *s, uint32_t width)
{
    uint32_t n = 0;
    while (*s) { put_ch(*s++); n++; }
    while (n++ < width) put_ch(' ');
}

/* Reads one ID register; returns 1 and the ID when the device answered. */
static int read_id(uint8_t addr, uint8_t reg, uint8_t *id)
{
    return sensehat_i2c_write_read(&hat, addr, &reg, 1u, id, 1u) == SENSEHAT_OK;
}

static void table_row(const char *dev, uint8_t addr, int has_id, uint8_t id, int ok)
{
    put_pad(dev, 13u);
    put_str("0x"); put_hex2(addr); put_str("     ");
    if (has_id) { put_str("0x"); put_hex2(id); put_str("  "); } else { put_str("--    "); }
    put_str(ok ? "OK" : "NOT OK");
    put_crlf();
}

/* Builds the frame: red bar on rows ROW_TOP..ROW_BOTTOM, brightness from level[] */
static void render(void)
{
    sensehat_fb_clear(fb);
    for (uint8_t x = 0; x < SENSEHAT_COLS; x++) {
        if (level[x] == 0u)
            continue;
        for (uint8_t y = row_top; y <= (uint8_t)(row_top + 1u); y++)
            sensehat_fb_set_pixel(fb, x, y,
                                  (uint8_t)((level[x] * hue_rgb[hue][0]) >> 3),
                                  (uint8_t)((level[x] * hue_rgb[hue][1]) >> 3),
                                  (uint8_t)((level[x] * hue_rgb[hue][2]) >> 3));
    }
}

/* signed fixed point with two decimals: 2831 -> "28.31" */
static void put_fixed2(int32_t v)
{
    uint32_t u;
    if (v < 0) { put_ch('-'); u = (uint32_t)(-v); } else { u = (uint32_t)v; }
    put_num(u / 100u);
    put_ch('.');
    put_ch((char)('0' + (u % 100u) / 10u));
    put_ch((char)('0' + (u % 10u)));
}

static void put_int(int32_t v)
{
    if (v < 0) { put_ch('-'); v = -v; }
    put_num((uint32_t)v);
}

static void put_xyz(const char *name, const int32_t v[3], const char *unit)
{
    put_str(name); put_str(" x "); put_int(v[0]); put_str(" y "); put_int(v[1]);
    put_str(" z "); put_int(v[2]); put_ch(' '); put_str(unit);
    put_crlf();
}

/* Starts the sensors one by one and prints the device table. A sensor that is missing or does not
 * initialise shows NOT OK and is skipped in later reports. The ATTINY88 has no ID register. */
static void sensors_init(int attiny_ok)
{
    uint8_t id = 0;
    int has;

    put_pad("Device", 13u); put_pad("Address", 9u); put_pad("ID", 6u); put_str("Status"); put_crlf();
    table_row("ATTINY88", SENSEHAT_ADDR_MCU, 0, 0u, attiny_ok);

    has = read_id(SENSEHAT_ADDR_PRESSURE, 0x0Fu, &id);
    have_lps = (lps25h_init(&hat) == SENSEHAT_OK);
    table_row("LPS25H", SENSEHAT_ADDR_PRESSURE, has, id, have_lps);

    has = read_id(SENSEHAT_ADDR_HUMIDITY, 0x0Fu, &id);
    have_hts = (hts221_init(&hat, &hts) == SENSEHAT_OK);
    table_row("HTS221", SENSEHAT_ADDR_HUMIDITY, has, id, have_hts);

    has = read_id(SENSEHAT_ADDR_IMU, 0x0Fu, &id);
    have_ag = (lsm9ds1_ag_init(&hat) == SENSEHAT_OK);
    table_row("LSM9DS1 A/G", SENSEHAT_ADDR_IMU, has, id, have_ag);

    has = read_id(SENSEHAT_ADDR_MAG, 0x0Fu, &id);
    have_mag = (lsm9ds1_mag_init(&hat) == SENSEHAT_OK);
    table_row("LSM9DS1 Mag", SENSEHAT_ADDR_MAG, has, id, have_mag);

    has = read_id(TCS3400_ADDR, 0x92u, &id);
    have_col = (tcs3400_init(&hat, TCS3400_ATIME_103MS, TCS3400_GAIN_16X) == SENSEHAT_OK);   /* 103 ms, 16x */
    table_row("TCS3400", TCS3400_ADDR, has, id, have_col);
}

/* Reads every sensor and sends one block to the UART. Called only when the joystick is moved. */
static void sensors_report(void)
{
    int rc;
    struct lps25h_data p;
    struct hts221_data h;
    struct lsm9ds1_ag_data ag;
    struct lsm9ds1_mag_data m;
    struct tcs3400_data c;

    if (have_lps) {
        rc = lps25h_read(&hat, &p);
        if (rc == SENSEHAT_OK) {
            put_str("LPS25H  pressure "); put_fixed2(p.pressure_x100);
            put_str(" hPa, temperature "); put_fixed2(p.temp_x100); put_str(" C"); put_crlf();
        } else { report_error("LPS25H read", rc); }
    }
    if (have_hts) {
        rc = hts221_read(&hat, &hts, &h);
        if (rc == SENSEHAT_OK) {
            put_str("HTS221  humidity "); put_fixed2(h.humidity_x100);
            put_str(" %RH, temperature "); put_fixed2(h.temp_x100); put_str(" C"); put_crlf();
        } else { report_error("HTS221 read", rc); }
    }
    if (have_ag) {
        rc = lsm9ds1_ag_read(&hat, &ag);
        if (rc == SENSEHAT_OK) {
            put_xyz("LSM9DS1 accel", ag.accel_mg, "mg");
            put_xyz("LSM9DS1 gyro ", ag.gyro_mdps, "mdps");
            put_str("LSM9DS1 temperature "); put_fixed2(ag.temp_x100); put_str(" C"); put_crlf();
        } else { report_error("LSM9DS1 accel/gyro read", rc); }
    }
    if (have_mag) {
        rc = lsm9ds1_mag_read(&hat, &m);
        if (rc == SENSEHAT_OK) {
            put_xyz("LSM9DS1 mag  ", m.field_mgauss, "mgauss");
        } else { report_error("LSM9DS1 mag read", rc); }
    }
    if (have_col) {
        rc = tcs3400_read(&hat, &c);
        if (rc == SENSEHAT_OK) {
            put_str("TCS3400  clear "); put_num(c.clear);
            put_str(" red "); put_num(c.red); put_str(" green "); put_num(c.green);
            put_str(" blue "); put_num(c.blue);
            put_str(" rgb "); put_num(c.r8); put_ch(','); put_num(c.g8); put_ch(','); put_num(c.b8);
            if (c.saturated) put_str(" SATURATED");
            put_crlf();
        } else { report_error("TCS3400 read", rc); }
    }
}

static void print_joystick(uint8_t m)
{
    put_str("JOY 0x");
    put_hex2(m);
    if (m & SENSEHAT_JOY_UP)     put_str(" UP");
    if (m & SENSEHAT_JOY_DOWN)   put_str(" DOWN");
    if (m & SENSEHAT_JOY_LEFT)   put_str(" LEFT");
    if (m & SENSEHAT_JOY_RIGHT)  put_str(" RIGHT");
    if (m & SENSEHAT_JOY_CENTER) put_str(" CENTER");
    if (m == 0u)                 put_str(" released");
    put_crlf();
}

/* ------------------------------------------------------------------ main */
int main(void)
{
    uint64_t next_step, next_beat, next_poll;
    uint32_t seen = 0;
    uint32_t step_ms = STEP_MS_DEFAULT;
    uint32_t frames = 0, errors = 0, fails = 0;
    uint8_t  hb = 0, joy = 0, joy_prev = 0, paused = 0;
    int      pos = 0, dir = 1, rc, i;

    (void)gpio_init(&gpio, GPIO_BASE, GPIO_LINES, GPIO_OUT_MASK);
    led_heartbeat(0);                                          /* all four LEDs off */

    (void)uart_init(&uart, UART_BASE, APB_HZ, UART_BAUD, 1u, 8u);
    uart.blockingRx = 0;
    (void)timer_init(&tmr, TIMER_BASE, CPU_HZ);

    put_str("SENSE HAT KNIGHT RIDER 1.0 (RISC-V SM 24 MHz, EFB I2C2 100 kHz, 19200 8N1)");
    put_crlf();

    (void)sensehat_efb_init(&hat, SENSEHAT_BASE);
    hat.delay_us = udelay;
    rc = sensehat_i2c_init(&hat, APB_HZ, I2C_HZ);
    put_str("I2C init: ");
    put_str(sensehat_strerror(rc));
    put_str(", SCL ");
    put_num(hat.i2c_hz / 1000u);
    put_str(" kHz");
    put_crlf();

    hat_reset();
    put_str("HAT reset done");
    put_crlf();

    for (i = 0; i < 3; i++) {                                  /* the ATTINY88 needs a moment after reset */
        rc = sensehat_probe(&hat);
        if (rc == SENSEHAT_OK)
            break;
        (void)sensehat_i2c_recover(&hat);
        mdelay(100u);
    }

    put_str("I2C scan 0x08..0x77:");
    put_crlf();
    sensors_init(rc == SENSEHAT_OK);

    sensehat_fb_clear(fb);
    (void)sensehat_fb_write(&hat, fb);

    (void)sensehat_joystick_read(&hat, &joy_prev);             /* starting state, no event */
    int1_init();

    next_step = now_ticks();
    next_beat = next_step;
    next_poll = next_step + (uint64_t)JOY_POLL_MS * (CPU_HZ / 1000u);

    for (;;) {
        uint64_t t = now_ticks();

        /* heartbeat on LED1 */
        if ((int64_t)(t - next_beat) >= 0) {
            hb ^= 1u;
            led_heartbeat(hb);
            next_beat += (uint64_t)HEARTBEAT_MS * (CPU_HZ / 1000u);
        }

        /* joystick: read over I2C when INT1 fired (interrupt counter changed), plus a slow safety
         * poll that only reports a change INT1 did not announce */
        {
            uint32_t ev = int1_events;
            int by_int = (ev != seen);
            if (by_int || (int64_t)(t - next_poll) >= 0) {
                seen = ev;
                next_poll = t + (uint64_t)JOY_POLL_MS * (CPU_HZ / 1000u);
                rc = sensehat_joystick_read(&hat, &joy);
                if (rc == SENSEHAT_OK) {
                    if (joy != joy_prev) {
                        put_str(by_int ? "INT1 " : "(poll, no INT1) ");
                        print_joystick(joy);
                        if (joy != 0u)                         /* a press, not the release */
                            sensors_report();
                        if ((joy & SENSEHAT_JOY_LEFT) && !(joy_prev & SENSEHAT_JOY_LEFT)) {     /* previous hue */
                            hue = (uint8_t)((hue + HUE_COUNT - 1u) % HUE_COUNT);
                            put_str("hue "); put_str(hue_name[hue]); put_crlf();
                        }
                        if ((joy & SENSEHAT_JOY_RIGHT) && !(joy_prev & SENSEHAT_JOY_RIGHT)) {   /* next hue */
                            hue = (uint8_t)((hue + 1u) % HUE_COUNT);
                            put_str("hue "); put_str(hue_name[hue]); put_crlf();
                        }
                        if ((joy & SENSEHAT_JOY_CENTER) && !(joy_prev & SENSEHAT_JOY_CENTER)) {
                            paused ^= 1u;
                            put_str(paused ? "paused" : "running");
                            put_crlf();
                        }
                        if ((joy & SENSEHAT_JOY_UP) && !(joy_prev & SENSEHAT_JOY_UP)) {      /* bar up one row */
                            if (row_top > 0u) row_top--;
                        }
                        if ((joy & SENSEHAT_JOY_DOWN) && !(joy_prev & SENSEHAT_JOY_DOWN)) {  /* bar down one row */
                            if (row_top < SENSEHAT_ROWS - 2u) row_top++;
                        }
                        joy_prev = joy;
                    }
                } else {
                    errors++;
                    report_error("joystick read", rc);
                    (void)sensehat_i2c_recover(&hat);
                }
            }
        }

        if ((int64_t)(t - next_step) < 0)
            continue;
        next_step += (uint64_t)step_ms * (CPU_HZ / 1000u);

        /* effect: decay the trail, light the head, move the head */
        if (!paused) {
            for (i = 0; i < (int)SENSEHAT_COLS; i++)
                level[i] = (uint8_t)(level[i] >> 1);
            level[pos] = HEAD_LEVEL;
            if (pos + dir < 0 || pos + dir >= (int)SENSEHAT_COLS)
                dir = -dir;
            pos += dir;
        }

        render();
        rc = sensehat_fb_write(&hat, fb);
        if (rc == SENSEHAT_OK) {
            fails = 0;
            frames++;
        } else {
            errors++;
            fails++;
            report_error("frame write", rc);
            (void)sensehat_i2c_recover(&hat);
            if (fails >= FAIL_RESET_LIMIT) {
                put_str("too many failures, resetting the HAT");
                put_crlf();
                hat_reset();
                (void)sensehat_i2c_reset(&hat);
                fails = 0;
            }
        }
    }
    return 0;
}
