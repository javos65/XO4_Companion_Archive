# Timing constraints for sensehat_soc
# 12 MHz input clock on the top-level port; the 24 MHz (CPU) and 12 MHz (peripheral) PLL outputs
# are derived by the tool from the PLL (do not create clocks on the PLL outputs).
create_clock -name clk12_i -period 83.333 [get_ports clk12_i]

# I2C2 SCL (EFB secondary controller): the SCL pad also feeds the hardened controller as a clock
# (net BB_scl_2/PADDI). 100 kHz bus rate -> 10 us period.
create_clock -name i2c2_scl -period 10000 [get_ports i2c2_scl]

# Slow, asynchronous board I/O (I2C2 clock and data, UART transmit, LEDs, SW1 pin direction,
# HAT reset): no timing relationship to the system clocks. Waiver recorded in design_plan.html.
set_false_path -to   [get_ports {txd_o i2c2_sda i2c2_scl {gpio_io[0]} {gpio_io[1]} {gpio_io[2]} {gpio_io[3]} {gpio_io[4]} {gpio_io[5]} {gpio_io[6]}}]
set_false_path -from [get_ports {i2c2_sda i2c2_scl {gpio_io[0]} {gpio_io[1]} {gpio_io[2]} {gpio_io[3]} {gpio_io[5]} {gpio_io[6]}}]

# Asynchronous user inputs (SW2 reset button, SW1 button, UART receive): no timing relationship
# to the system clocks. Waiver recorded in design_plan.html.
set_false_path -from [get_ports {sw2_n_i rxd_i {gpio_io[4]}}]
